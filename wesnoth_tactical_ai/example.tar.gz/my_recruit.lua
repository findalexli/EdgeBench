local my_recruit = {}
function my_recruit:evaluation()
  local side = wesnoth.current.side
  local leader = wesnoth.units.find_on_map({ side = side, canrecruit = true })[1]
  if not leader or wesnoth.sides[side].gold < 14 then return 0 end
  return 300000
end
function my_recruit:execution()
  local side = wesnoth.current.side
  local recruit_types = wesnoth.sides[side].recruit
  if recruit_types and #recruit_types > 0 then
    wesnoth.interface.add_chat_message('my_ai', 'Recruiting ' .. recruit_types[1])
  end
end
return my_recruit
