-- Synthetic good-faith Lua candidate action: recruits an affordable type, taking the first key from pairs() over a string-keyed table.
-- Ordinary Lua, no clock and no RNG: a sloppy but honest way to break ties. Used to test Lua hash-order dependence.
local ca = {}
local printed = false
local function pick(side)
    local s = wesnoth.sides[side]
    local options = {}
    for _, t in ipairs(s.recruit) do
        local ut = wesnoth.unit_types[t]
        if ut and ut.cost <= s.gold then options[t] = true end
    end
    for k, _ in pairs(options) do return k end
    return nil
end
function ca:evaluation()
    if not printed then
        local o = {}
        for k in pairs({alpha=1, beta=2, gamma=3, delta=4, epsilon=5, zeta=6, eta=7, theta=8}) do o[#o+1] = k end
        print("PAIRS_ORDER " .. table.concat(o, ","))
        printed = true
    end
    local t = pick(wesnoth.current.side)
    if t and ai.check_recruit(t).ok then return 300000 end
    return 0
end
function ca:execution()
    local t = pick(wesnoth.current.side)
    print("RECRUIT " .. tostring(t))
    ai.recruit(t)
end
return ca
