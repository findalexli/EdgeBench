-- Test control: stops every unit of the side. If this file runs, the side never moves or attacks.
local ca = {}
local function active(side)
    local r = {}
    for _, u in ipairs(wesnoth.units.find_on_map({ side = side })) do
        if u.moves > 0 or u.attacks_left > 0 then r[#r+1] = u end
    end
    return r
end
function ca:evaluation()
    if #active(wesnoth.current.side) > 0 then return 300000 end
    return 0
end
function ca:execution()
    for _, u in ipairs(active(wesnoth.current.side)) do ai.stopunit_all(u) end
end
return ca
