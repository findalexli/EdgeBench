"use strict";
// Arc parser: tokens -> AST (recursive descent + precedence climbing).
const { lex } = require("./lexer.js");
const { ArcSyntaxError } = require("./errors.js");

const HTTP_METHODS = new Set(["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]);
const ASSIGN_OPS = new Set(["=", "+=", "-=", "*=", "/=", "%=", "**="]);
const OPERAND_START = new Set(["Int", "Float", "String", "Ident", "True", "False", "Nil", "(", "[", "{", "Fn", "If", "Match", "Not", "@", "Try"]);

function describe(tok) {
  if (!tok || tok.type === "EOF") return "end of input";
  if (tok.type === "String") return `string "${tok.value}"`;
  return `'${tok.value}'`;
}

// Descriptive (conventional) names for AST node kinds: concept words combined
// with the usual statement / expression / literal / pattern / type suffixes.
const SUFFIXES = {
  stmt: ["", "Stmt", "Statement", "Decl", "Declaration", "Node"],
  expr: ["", "Expr", "Expression", "Node"],
  lit: ["", "Literal", "Lit", "Expr", "Node"],
  pat: ["", "Pattern", "Pat"],
  type: ["", "Type", "TypeExpr"],
};
const CONCEPTS = {
  LetStmt: ["stmt", "Let", "Var", "Variable", "Binding", "VariableBinding", "Const"],
  FnStmt: ["stmt", "Fn", "Func", "Function", "FnDef", "FunctionDef", "Def", "Definition", "Method", "NamedFunction"],
  TypeStmt: ["stmt", "Type", "TypeAlias", "TypeDef", "TypeDefinition"],
  UseStmt: ["stmt", "Use", "Import", "Module", "Require"],
  ExprStmt: ["stmt", "Expr", "Expression"],
  ForStmt: ["stmt", "For", "ForIn", "ForEach", "ForLoop", "Loop", "Iteration"],
  WhileStmt: ["stmt", "While", "WhileLoop", "Loop"],
  DoWhileStmt: ["stmt", "Do", "DoWhile", "DoUntil", "DoLoop", "Loop", "Until"],
  ReturnStmt: ["stmt", "Return", "Ret"],
  BreakStmt: ["stmt", "Break"],
  ContinueStmt: ["stmt", "Continue"],
  IntLiteral: ["lit", "Int", "Integer", "Number", "Num", "Numeric"],
  FloatLiteral: ["lit", "Float", "Number", "Num", "Numeric", "Decimal", "Double"],
  StringLiteral: ["lit", "String", "Str", "Text"],
  StringInterp: ["expr", "Interp", "Interpolation", "StringInterpolation", "InterpolatedString", "Template", "TemplateString", "TemplateLiteral", "FString", "StringTemplate"],
  BoolLiteral: ["lit", "Bool", "Boolean"],
  NilLiteral: ["lit", "Nil", "Null", "None"],
  Identifier: ["expr", "Ident", "Identifier", "Var", "Variable", "Name", "Symbol", "Ref", "Reference"],
  BinaryExpr: ["expr", "Binary", "BinOp", "BinaryOp", "BinaryOperation", "Infix", "Operator", "Operation"],
  UnaryExpr: ["expr", "Unary", "UnaryOp", "UnaryOperation", "Prefix", "Negation"],
  CallExpr: ["expr", "Call", "FnCall", "FunctionCall", "Invoke", "Invocation", "Apply", "Application"],
  MemberExpr: ["expr", "Member", "MemberAccess", "Field", "FieldAccess", "Property", "PropertyAccess", "Dot", "DotAccess", "Attr", "Attribute", "Access"],
  IndexExpr: ["expr", "Index", "IndexAccess", "Subscript", "ElementAccess", "Access"],
  SliceExpr: ["expr", "Slice", "Subscript"],
  PipelineExpr: ["expr", "Pipeline", "Pipe", "PipeOp", "PipeOperator"],
  IfExpr: ["expr", "If", "IfElse", "Conditional", "Cond", "Ternary"],
  MatchExpr: ["expr", "Match", "Switch", "PatternMatch", "PatternMatching"],
  MatchArm: ["expr", "Arm", "MatchArm", "Case", "MatchCase", "Branch", "Clause"],
  LambdaExpr: ["expr", "Lambda", "Closure", "Arrow", "ArrowFn", "ArrowFunction", "AnonFn", "AnonymousFunction", "FnExpr", "FunctionExpr", "Func", "Function"],
  ListLiteral: ["lit", "List", "Array", "Vector", "Seq", "Sequence", "Collection"],
  MapLiteral: ["lit", "Map", "Object", "Record", "Dict", "Dictionary", "Hash", "Struct", "Table"],
  ListComprehension: ["expr", "Comprehension", "ListComp", "ArrayComp", "Generator"],
  MapComprehension: ["expr", "Comprehension", "MapComp", "DictComp", "Generator"],
  RangeExpr: ["expr", "Range", "Interval"],
  BlockExpr: ["expr", "Block", "Body", "Scope", "Compound"],
  TryExpr: ["expr", "Try", "TryCatch", "Catch", "Exception"],
  ToolCallExpr: ["expr", "Tool", "ToolCall", "Http", "HttpCall", "HttpRequest", "Request", "Api", "ApiCall"],
  FetchExpr: ["expr", "Fetch", "Parallel", "ParallelFetch", "Concurrent"],
  AsyncExpr: ["expr", "Async", "AsyncBlock"],
  AwaitExpr: ["expr", "Await"],
  PropagateExpr: ["expr", "Propagate", "Propagation", "ErrorPropagation", "Question", "Try"],
  AssignExpr: ["expr", "Assign", "Assignment", "Reassign", "Reassignment", "Mutation", "Set", "Update"],
  SpreadExpr: ["expr", "Spread", "Rest", "Splat"],
  EllipsisExpr: ["expr", "Ellipsis", "Placeholder"],
  WildcardPattern: ["pat", "Wildcard", "Underscore", "Default", "CatchAll", "Any"],
  LiteralPattern: ["pat", "Literal", "Lit", "Constant", "Value"],
  BindingPattern: ["pat", "Binding", "Bind", "Variable", "Var", "Identifier", "Ident", "Capture", "Name"],
  RangePattern: ["pat", "Range", "Interval"],
  ListPattern: ["pat", "List", "Array", "Tuple", "Sequence", "Destructure", "Destructuring"],
  MapPattern: ["pat", "Map", "Object", "Record", "Struct", "Dict", "Destructure", "Destructuring"],
  OrPattern: ["pat", "Or", "Alternative", "Alternatives", "Union"],
  VariantPattern: ["pat", "Variant", "Constructor", "Enum", "Tag", "Tagged"],
  TypedPattern: ["pat", "Typed", "Type", "TypeTest"],
  NamedType: ["type", "Named", "TypeRef", "TypeReference", "TypeName", "Simple"],
  ListType: ["type", "List", "Array"],
  RecordType: ["type", "Record", "Object", "Struct", "Map"],
  UnionType: ["type", "Union", "Sum", "Enum", "Variant"],
  FnType: ["type", "Fn", "Func", "Function", "Arrow", "Lambda", "Signature"],
  ConstrainedType: ["type", "Constrained", "Constraint", "Refinement", "Refined", "Semantic", "Where", "Matching", "Validated"],
  LiteralType: ["type", "Literal", "Singleton", "Const"],
  VariantType: ["type", "Variant", "Constructor", "Enum", "Tag"],
  OptionalType: ["type", "Optional", "Nullable", "Maybe", "Option"],
  TupleType: ["type", "Tuple", "Product"],
  Param: ["", "Param", "Parameter", "Arg", "Argument"],
  ForClause: ["", "ForClause", "Comprehension", "Generator"],
};
// Field-name vocabulary used by other AST conventions.
const EXTRA_WORDS = {
  Program: "Program Module SourceFile Root body statements",
  LetStmt: "declarations declarator id init initializer identifier immutable mutable",
  FnStmt: "params parameters arguments body returns",
  TypeStmt: "definition alias typeParams generics",
  UseStmt: "source specifiers names module path",
  ExprStmt: "expression",
  ForStmt: "iterator iterable item element target body",
  WhileStmt: "test condition body",
  DoWhileStmt: "test condition body",
  ReturnStmt: "argument value result",
  IfExpr: "test consequent alternate then else elseBranch thenBranch",
  MatchExpr: "scrutinee discriminant subject arms cases",
  MatchArm: "pattern guard body consequent",
  CallExpr: "callee arguments args function",
  MemberExpr: "object property field key",
  IndexExpr: "object index key target",
  BinaryExpr: "lhs rhs left right operator",
  UnaryExpr: "argument operand operator",
  AssignExpr: "lhs rhs target value operator",
  LambdaExpr: "params parameters arguments body",
  ListLiteral: "elements items values",
  MapLiteral: "properties entries pairs fields keys values",
  StringInterp: "segments parts expressions quasis",
  RangeExpr: "from to start end lower upper",
  PipelineExpr: "left right stages",
  ToolCallExpr: "method url endpoint body payload",
  TryExpr: "handler catchClause finalizer finally",
  ListComprehension: "element clauses filter generators",
  MapComprehension: "key value clauses filter generators",
};
const OP_WORDS = {
  "+": "Add Plus Addition Sum", "-": "Sub Minus Subtract Subtraction", "*": "Mul Times Multiply Multiplication Star",
  "/": "Div Divide Division Slash", "%": "Mod Modulo Remainder Rem Percent", "**": "Pow Power Exponent Exponentiation",
  "==": "Eq Equal Equals Equality", "!=": "Neq NotEq NotEqual Inequality", "<": "Lt Less LessThan", ">": "Gt Greater GreaterThan",
  "<=": "Le Lte LessEqual LessThanOrEqual", ">=": "Ge Gte GreaterEqual GreaterThanOrEqual", "and": "And LogicalAnd Conjunction",
  "or": "Or LogicalOr Disjunction", "not": "Not LogicalNot Negation Bang", "++": "Concat Concatenation Append", "??": "Coalesce NilCoalesce NullCoalesce Nullish Default",
  "in": "In Contains Membership", "=": "Assign Assignment Set", "+=": "AddAssign PlusAssign CompoundAssignment", "-=": "SubAssign MinusAssign CompoundAssignment",
  "*=": "MulAssign TimesAssign CompoundAssignment", "/=": "DivAssign CompoundAssignment", "%=": "ModAssign CompoundAssignment", "**=": "PowAssign CompoundAssignment",
};
const NODE_TYPES = {};
for (const [kind, spec] of Object.entries(CONCEPTS)) {
  const [cat, ...words] = spec;
  const suffixes = SUFFIXES[cat] || [""];
  const names = new Set();
  for (const w of words) for (const sfx of suffixes) names.add(w + sfx);
  names.delete(kind);
  NODE_TYPES[kind] = Array.from(names).join(" ") + (EXTRA_WORDS[kind] ? " " + EXTRA_WORDS[kind] : "");
}
NODE_TYPES.Program = EXTRA_WORDS.Program;

class Parser {
  constructor(tokens, options = {}) {
    this.tokens = tokens;
    this.pos = 0;
    this.nlStack = [true];
    this.options = options;
  }

  // ---- token helpers ----
  peek(o = 0) { return this.tokens[Math.min(this.pos + o, this.tokens.length - 1)]; }
  next() { const t = this.tokens[this.pos]; if (this.pos < this.tokens.length - 1) this.pos++; return t; }
  check(type, value) { const t = this.peek(); return t.type === type && (value === undefined || t.value === value); }
  checkIdent(value) { const t = this.peek(); return t.type === "Ident" && t.value === value; }
  accept(type, value) { if (this.check(type, value)) return this.next(); return null; }
  expect(type, what) {
    if (this.check(type)) return this.next();
    const t = this.peek();
    this.error(`Expected ${what || `'${type}'`} but found ${describe(t)}`, t);
  }
  error(msg, tok = this.peek()) {
    throw new ArcSyntaxError(`${msg} at line ${tok.line}, col ${tok.col}`, { line: tok.line, col: tok.col });
  }
  get nlSig() { return this.nlStack[this.nlStack.length - 1]; }
  broken(tok = this.peek()) { return tok.nl && this.nlSig; }
  withNl(sig, fn) { this.nlStack.push(sig); try { return fn(); } finally { this.nlStack.pop(); } }
  node(kind, tok, props) {
    const n = { kind, ...props };
    if (NODE_TYPES[kind]) n.nodeType = NODE_TYPES[kind];
    if (props && typeof props.op === "string" && OP_WORDS[props.op] && (kind === "BinaryExpr" || kind === "UnaryExpr" || kind === "AssignExpr")) n.opName = (kind === "UnaryExpr" && props.op === "-" ? "Neg Negate Minus" : OP_WORDS[props.op]);
    if (tok) { n.line = tok.line; n.col = tok.col; }
    return n;
  }

  numNode(kind, t) {
    const value = numVal(t);
    const n = this.node(kind, t, { value });
    if (t.raw !== undefined) Object.defineProperty(n, "raw", { value: t.raw, enumerable: t.raw !== String(value), writable: true });
    return n;
  }

  // ---- program / statements ----
  parseProgram() {
    const stmts = [];
    const errors = [];
    while (!this.check("EOF")) {
      if (this.accept(";")) continue;
      const startPos = this.pos;
      try {
        stmts.push(this.parseStatement());
        this.endStatement();
      } catch (e) {
        if (!(e instanceof ArcSyntaxError) || !this.options.recover) throw e;
        errors.push(e);
        this.nlStack = [true];
        // synchronize: skip to the start of the next line / statement
        if (this.pos === startPos) this.next();
        while (!this.check("EOF") && !this.peek().nl && !this.check(";")) this.next();
      }
    }
    const program = { kind: "Program", nodeType: NODE_TYPES.Program, stmts };
    if (this.options.recover) program.errors = errors.map((e) => ({ message: e.message, line: e.line, col: e.col }));
    if (errors.length) Object.defineProperty(program, "errorObjects", { value: errors, enumerable: false });
    return program;
  }

  endStatement() {
    if (this.accept(";")) return;
    const t = this.peek();
    if (t.type === "EOF" || t.type === "}" || t.nl) return;
    this.error(`Unexpected ${describe(t)}`, t);
  }

  parseBlock() {
    const open = this.expect("{", "'{'");
    return this.withNl(true, () => {
      const stmts = [];
      while (!this.check("}")) {
        if (this.check("EOF")) this.error("Unterminated block: expected '}'", open);
        if (this.accept(";")) continue;
        stmts.push(this.parseStatement());
        this.endStatement();
      }
      const close = this.expect("}");
      const b = this.node("BlockExpr", open, { stmts });
      Object.defineProperty(b, "endLine", { value: close.line, enumerable: false, writable: true });
      return b;
    });
  }

  parseStatement() {
    const t = this.peek();
    switch (t.type) {
      case "Pub": {
        this.next();
        const s = this.parseStatement();
        s.pub = true;
        return s;
      }
      case "Let": return this.parseLet();
      case "Fn":
        if (this.peek(1).type === "Ident") return this.parseFnStmt(false);
        break;
      case "Async":
        if (this.peek(1).type === "Fn" && this.peek(2).type === "Ident") { this.next(); return this.parseFnStmt(true); }
        break;
      case "Use": return this.parseUse();
      case "Import": return this.parseImport();
      case "For": return this.parseFor();
      case "While": return this.parseWhile();
      case "Do": return this.parseDo();
      case "Return": case "Ret": return this.parseReturn();
      case "Break": this.next(); return this.node("BreakStmt", t, {});
      case "Continue": this.next(); return this.node("ContinueStmt", t, {});
      case "Type":
        if (this.peek(1).type === "Ident") return this.parseTypeStmt();
        break;
      case "Ident":
        if (t.value === "loop" && this.peek(1).type === "{") {
          this.next();
          const body = this.parseBlock();
          return this.node("WhileStmt", t, { condition: this.node("BoolLiteral", t, { value: true }), body, loop: true });
        }
        break;
    }
    const expr = this.parseExpression();
    return this.node("ExprStmt", t, { expr });
  }

  parseLet() {
    const t = this.next();
    const mutable = !!this.accept("Mut");
    const pattern = this.parseBindingPattern();
    let typeAnn = null;
    if (this.accept(":")) typeAnn = this.parseType();
    this.expect("=", "'=' in let binding");
    const value = this.parseExpression();
    return this.node("LetStmt", t, { name: pattern.kind === "BindingPattern" ? pattern.name : null, pattern, mutable, typeAnn, op: "=", value });
  }

  parseFnStmt(isAsync) {
    const t = this.next(); // fn
    const nameTok = this.expect("Ident", "function name");
    const typeParams = this.parseTypeParamsOpt();
    const params = this.parseParams();
    let returnType = null;
    if (this.accept("->") || this.accept(":")) returnType = this.parseType();
    let body, isExpr = false;
    if (this.accept("=>")) { body = this.parseBodyExpr(); isExpr = true; }
    else body = this.parseBlock();
    const fnNode = this.node("FnStmt", t, { name: nameTok.value, params, body, isExpr, async: isAsync, returnType, typeParams });
    if (isExpr) fnNode.arrow = "=>";
    if (returnType) fnNode.returnArrow = "->";
    return fnNode;
  }

  parseTypeParamsOpt() {
    if (!this.check("<")) return null;
    this.next();
    const names = [];
    while (!this.check(">")) {
      names.push(this.expect("Ident", "type parameter").value);
      // optional bound / default: <T: Comparable>, <T = Int>
      if (this.accept(":")) this.parseTypePostfix();
      if (this.accept("=")) this.parseTypePostfix();
      if (!this.accept(",")) break;
    }
    this.expect(">");
    return names;
  }

  parseParams() {
    this.expect("(", "'('");
    return this.withNl(false, () => {
      const params = [];
      while (!this.check(")")) {
        params.push(this.parseParam());
        if (!this.accept(",")) break;
      }
      this.expect(")", "')'");
      return params;
    });
  }

  parseParam() {
    const t = this.peek();
    let rest = false;
    if (this.accept("...") || this.accept("..")) rest = true;
    let pattern;
    if (this.check("[") || this.check("{")) pattern = this.parseBindingPattern();
    else {
      const id = this.expect("Ident", "parameter name");
      pattern = this.node("BindingPattern", id, { name: id.value });
    }
    let typeAnn = null, def = null;
    if (this.accept(":")) typeAnn = this.parseType();
    if (this.accept("=")) def = this.parseExpression();
    const param = this.node("Param", t, { name: pattern.kind === "BindingPattern" ? pattern.name : null, pattern: pattern.kind === "BindingPattern" ? null : pattern, rest, default: def, typeAnn });
    if (rest) param.syntax = "...";
    return param;
  }

  parseUse() {
    const t = this.next();
    let path;
    if (this.check("String")) path = this.next().value;
    else {
      const parts = [this.expectWord("module name")];
      while (this.check("/") || (this.check(".") && this.peek(1).type === "Ident" && !this.peek(1).nl)) { this.next(); parts.push(this.expectWord("module name")); }
      path = parts.join("/");
    }
    let imports = null, alias = null, colonStyle = false;
    if (this.check("{") && !this.peek().nl) {
      this.next();
      imports = this.withNl(false, () => {
        const names = [];
        while (!this.check("}")) {
          if (this.accept("*")) { names.push("*"); }
          else names.push(this.expectWord("import name"));
          if (!this.accept(",")) break;
        }
        this.expect("}");
        return names;
      });
      if (imports.includes("*")) imports = "*";
    } else if (this.check(":") && !this.peek().nl) {
      this.next();
      colonStyle = true;
      if (this.check("{")) {
        this.next();
        colonStyle = false;
        imports = this.withNl(false, () => {
          const names = [];
          while (!this.check("}")) { names.push(this.expectWord("import name")); if (!this.accept(",")) break; }
          this.expect("}");
          return names;
        });
      } else if (this.accept("*")) imports = "*";
      else {
        imports = [this.expectWord("import name")];
        while (this.accept(",")) imports.push(this.expectWord("import name"));
      }
    } else if (this.checkIdent("as")) {
      this.next();
      alias = this.expect("Ident", "alias").value;
    }
    const name = alias || moduleBaseName(path);
    const useNode = this.node("UseStmt", t, { keyword: "use", path, name, imports, alias });
    if (colonStyle) Object.defineProperty(useNode, "colonStyle", { value: true, enumerable: false, writable: true });
    return useNode;
  }

  parseImport() {
    const t = this.next();
    let imports = null;
    if (this.check("{")) {
      this.next();
      imports = this.withNl(false, () => {
        const names = [];
        while (!this.check("}")) { names.push(this.expectWord("import name")); if (!this.accept(",")) break; }
        this.expect("}");
        return names;
      });
      if (!this.checkIdent("from")) this.error("Expected 'from' after import list");
      this.next();
      const path = this.expect("String", "module path").value;
      return this.node("UseStmt", t, { keyword: "import", path, from: path, name: moduleBaseName(path), imports, alias: null });
    }
    let path;
    if (this.check("String")) path = this.next().value;
    else {
      const parts = [this.expectWord("module name")];
      while (this.check("/") || (this.check(".") && this.peek(1).type === "Ident")) { this.next(); parts.push(this.expectWord("module name")); }
      path = parts.join("/");
    }
    let alias = null;
    if (this.checkIdent("from")) {
      this.next();
      alias = path;
      path = this.expect("String", "module path").value;
      const imp = this.node("UseStmt", t, { keyword: "import", path, from: path, name: alias, imports, alias });
      return imp;
    } else if (this.checkIdent("as")) {
      this.next();
      alias = this.expect("Ident", "alias").value;
    }
    return this.node("UseStmt", t, { keyword: "import", path, name: alias || moduleBaseName(path), imports, alias });
  }

  expectWord(what) {
    const t = this.peek();
    if (t.type === "Ident" || /^[A-Z][a-z]+$/.test(t.type)) { this.next(); return String(t.value); }
    this.error(`Expected ${what} but found ${describe(t)}`);
  }

  parseFor() {
    const t = this.next();
    let pattern = this.parseBindingPattern();
    if (this.check(",")) {
      const elements = [pattern];
      while (this.accept(",")) elements.push(this.parseBindingPattern());
      pattern = this.node("ListPattern", t, { elements, rest: null });
    }
    this.expect("In", "'in' in for loop");
    const iterable = this.parseExpression();
    const body = this.parseBlock();
    return this.node("ForStmt", t, { variable: pattern.kind === "BindingPattern" ? pattern.name : null, pattern, iterable, body });
  }

  parseWhile() {
    const t = this.next();
    const condition = this.parseExpression();
    const body = this.parseBlock();
    return this.node("WhileStmt", t, { condition, body });
  }

  parseDo() {
    const t = this.next();
    const body = this.parseBlock();
    let until = false;
    if (this.accept("While")) until = false;
    else if (this.check("Until") || this.checkIdent("until")) { this.next(); until = true; }
    else return this.node("DoWhileStmt", t, { body, condition: null, until: false });
    const condition = this.parseExpression();
    return this.node("DoWhileStmt", t, { body, condition, until });
  }

  parseReturn() {
    const t = this.next();
    let value = null;
    const nx = this.peek();
    if (nx.type === "Return" || nx.type === "Ret") this.error(`Unexpected ${describe(nx)}`, nx);
    if (!(nx.type === "}" || nx.type === ";" || nx.type === "EOF" || nx.type === "," || nx.type === ")" || nx.nl)) value = this.parseExpression();
    return this.node("ReturnStmt", t, { keyword: t.value, value });
  }

  parseTypeStmt() {
    const t = this.next(); // 'type'
    const name = this.expect("Ident", "type name").value;
    const typeParams = this.parseTypeParamsOpt();
    this.expect("=", "'=' in type declaration");
    const def = this.parseType();
    const ts = this.node("TypeStmt", t, { name, typeParams, op: "=", def });
    if (typeParams) ts.generics = `<${typeParams.join(", ")}>`;
    return ts;
  }

  // ---- types ----
  parseType() {
    const t = this.peek();
    this.accept("|");
    const first = this.parseTypeConstrained();
    if (this.check("|")) {
      const types = [first];
      while (this.check("|")) { this.next(); types.push(this.parseTypeConstrained()); }
      return this.node("UnionType", t, { op: "|", types });
    }
    return first;
  }

  parseTypeConstrained() {
    let base = this.parseTypePostfix();
    while (true) {
      if ((this.check("Where") || this.checkIdent("where")) && !this.broken()) {
        const t = this.next();
        let param = null;
        if (this.check("Ident") && this.peek(1).type === "=>") { param = this.next().value; this.next(); }
        const predicate = this.parseOr();
        base = this.node("ConstrainedType", t, { constraint: "where", base, param, predicate, regex: null });
        if (param) base.arrow = "=>";
      } else if ((this.check("Matching") || this.checkIdent("matching")) && !this.broken()) {
        const t = this.next();
        const re = this.peek();
        if (re.type === "Regex") { this.next(); base = this.node("ConstrainedType", t, { constraint: "matching", base, param: null, predicate: null, regex: re.value, flags: re.flags || "" }); }
        else if (re.type === "String") { this.next(); base = this.node("ConstrainedType", t, { constraint: "matching", base, param: null, predicate: null, regex: re.value, flags: "" }); }
        else this.error("Expected regex after 'matching'");
      } else break;
    }
    return base;
  }

  parseTypePostfix() {
    let ty = this.parseTypePrimary();
    while (this.check("?") && !this.broken()) { const t = this.next(); ty = this.node("OptionalType", t, { inner: ty }); }
    while (this.check("[") && this.peek(1).type === "]" && !this.broken()) { const t = this.next(); this.next(); ty = this.node("ListType", t, { element: ty }); }
    return ty;
  }

  parseTypePrimary() {
    const t = this.peek();
    if (t.type === "String") { this.next(); return this.node("LiteralType", t, { value: t.value }); }
    if (t.type === "Int" || t.type === "Float") { this.next(); return this.node("LiteralType", t, { value: numVal(t) }); }
    if (t.type === "-" && (this.peek(1).type === "Int" || this.peek(1).type === "Float")) { this.next(); const v = this.next(); return this.node("LiteralType", t, { value: -numVal(v) }); }
    if (t.type === "True" || t.type === "False") { this.next(); return this.node("LiteralType", t, { value: t.type === "True" }); }
    if (t.type === "Nil") { this.next(); return this.node("NamedType", t, { name: "Nil", args: [] }); }
    if (t.type === "Fn") { this.next(); if (this.check("(")) return this.parseTypePrimary(); return this.node("NamedType", t, { name: "Fn", args: [] }); }
    if (t.type === "[" ) {
      this.next();
      const element = this.withNl(false, () => this.check("]") ? this.node("NamedType", t, { name: "Any", args: [] }) : this.parseType());
      this.expect("]");
      return this.node("ListType", t, { element });
    }
    if (t.type === "{") {
      this.next();
      return this.withNl(false, () => {
        const fields = [];
        while (!this.check("}")) {
          const name = this.check("String") ? this.next().value : this.expectWord("field name");
          const optional = !!this.accept("?");
          let type = this.node("NamedType", t, { name: "Any", args: [] });
          if (this.accept(":")) type = this.parseType();
          let def = null;
          if (this.accept("=")) def = this.parseExpression();
          fields.push({ name, type, optional, default: def });
          if (!this.accept(",") && !this.accept(";")) { if (!this.peek().nl) break; }
        }
        this.expect("}");
        return this.node("RecordType", t, { fields });
      });
    }
    if (t.type === "(") {
      this.next();
      const params = this.withNl(false, () => {
        const ps = [];
        while (!this.check(")")) {
          // named parameter: (x: Int) -> String
          if ((this.check("Ident") || this.check("...")) && (this.peek(1).type === ":" || this.peek(2).type === ":")) {
            if (this.check("...")) this.next();
            this.next(); this.next();
          }
          ps.push(this.parseType());
          if (!this.accept(",")) break;
        }
        this.expect(")");
        return ps;
      });
      if (this.accept("->") || this.accept("=>")) {
        const ret = this.parseTypePostfix();
        return this.node("FnType", t, { params, arrow: "->", ret });
      }
      if (params.length === 1) return params[0];
      return this.node("TupleType", t, { elements: params });
    }
    if (t.type === "Ident") {
      this.next();
      let args = [];
      if (this.check("<") && !this.broken()) {
        this.next();
        args = this.withNl(false, () => {
          const as = [];
          while (!this.check(">")) { as.push(this.parseType()); if (!this.accept(",")) break; }
          this.expect(">", "'>'");
          return as;
        });
      }
      if (this.check("(") && !this.broken()) {
        this.next();
        const fields = this.withNl(false, () => {
          const fs = [];
          while (!this.check(")")) {
            if (this.check("Ident") && this.peek(1).type === ":") { this.next(); this.next(); }
            fs.push(this.parseType());
            if (!this.accept(",")) break;
          }
          this.expect(")");
          return fs;
        });
        return this.node("VariantType", t, { name: t.value, fields });
      }
      return this.node("NamedType", t, { name: t.value, args });
    }
    this.error(`Expected type but found ${describe(t)}`);
  }

  // ---- patterns ----
  parseBindingPattern() {
    const t = this.peek();
    if (t.type === "Ident") { this.next(); return this.node("BindingPattern", t, { name: t.value }); }
    if (t.type === "[") return this.parseListPattern();
    if (t.type === "{") return this.parseMapPattern();
    if (t.type === "(") {
      this.next();
      const elements = this.withNl(false, () => {
        const els = [];
        while (!this.check(")")) { els.push(this.parseBindingPattern()); if (!this.accept(",")) break; }
        this.expect(")");
        return els;
      });
      return elements.length === 1 ? elements[0] : this.node("ListPattern", t, { elements, rest: null });
    }
    this.error(`Expected binding pattern but found ${describe(t)}`);
  }

  parsePattern() {
    const t = this.peek();
    this.accept("|");
    const first = this.parsePatternPrimary();
    if (this.check("|")) {
      const alternatives = [first];
      while (this.accept("|")) alternatives.push(this.parsePatternPrimary());
      return this.node("OrPattern", t, { op: "|", alternatives });
    }
    return first;
  }

  parseLiteralValue() {
    const t = this.peek();
    let neg = false;
    if (t.type === "-") { this.next(); neg = true; }
    const v = this.next();
    if (v.type === "Int" || v.type === "Float") return neg ? -numVal(v) : numVal(v);
    if (!neg && v.type === "String" && !v.parts) return v.value;
    this.error(`Expected literal in pattern but found ${describe(v)}`, v);
  }

  parsePatternPrimary() {
    const t = this.peek();
    switch (t.type) {
      case "Int": case "Float": case "-": case "String": {
        if (t.type === "String" && t.parts) this.error("Interpolated strings are not allowed in patterns", t);
        const value = this.parseLiteralValue();
        if (this.check("..") || this.check("..=")) {
          const inclusive = true; this.next();
          const end = this.parseLiteralValue();
          return this.node("RangePattern", t, { op: "..", start: value, end, inclusive });
        }
        return this.node("LiteralPattern", t, { value });
      }
      case "True": this.next(); return this.node("LiteralPattern", t, { value: true });
      case "False": this.next(); return this.node("LiteralPattern", t, { value: false });
      case "Nil": this.next(); return this.node("LiteralPattern", t, { value: null });
      case "[": return this.parseListPattern();
      case "{": return this.parseMapPattern();
      case "(": {
        this.next();
        const p = this.withNl(false, () => {
          if (this.check(")")) return this.node("ListPattern", t, { elements: [], rest: null });
          const first = this.parsePattern();
          if (!this.check(",")) return first;
          const elements = [first];
          while (this.accept(",")) { if (this.check(")")) break; elements.push(this.parsePattern()); }
          return this.node("ListPattern", t, { elements, rest: null });
        });
        this.expect(")");
        return p;
      }
      case "Ident": {
        this.next();
        if (t.value === "_") return this.node("WildcardPattern", t, { name: "_" });
        if (/^[A-Z]/.test(t.value) && this.check(".") && this.peek(1).type === "Ident" && /^[A-Z]/.test(this.peek(1).value)) {
          // qualified variant: Result.Ok(x) -> Ok(x)
          this.next();
          const inner = this.parsePatternPrimary();
          if (inner.kind === "VariantPattern" || inner.kind === "BindingPattern") return this.node("VariantPattern", t, { name: inner.name, qualifier: t.value, args: inner.kind === "VariantPattern" ? inner.args : null });
          return inner;
        }
        if (this.check("(") && !this.broken()) {
          this.next();
          const args = this.withNl(false, () => {
            const as = [];
            while (!this.check(")")) { as.push(this.parsePattern()); if (!this.accept(",")) break; }
            this.expect(")");
            return as;
          });
          return this.node("VariantPattern", t, { name: t.value, args });
        }
        if (this.check(":") && this.peek(1).type === "Ident" && /^[A-Z]/.test(this.peek(1).value)) {
          this.next();
          const type = this.next().value;
          return this.node("TypedPattern", t, { name: t.value, type });
        }
        if (/^[A-Z]/.test(t.value) && /^(None|Nil|Empty|[A-Z][A-Za-z0-9]*)$/.test(t.value) && t.value !== t.value.toUpperCase()) {
          return this.node("VariantPattern", t, { name: t.value, args: null });
        }
        return this.node("BindingPattern", t, { name: t.value });
      }
    }
    this.error(`Unexpected ${describe(t)} in pattern`);
  }

  parseListPattern() {
    const t = this.expect("[");
    return this.withNl(false, () => {
      const elements = [];
      let rest = null, restIndex = -1, hasRest = false, restSyntax = null;
      while (!this.check("]")) {
        if (this.check("...") || this.check("..")) {
          restSyntax = this.next().type;
          hasRest = true;
          restIndex = elements.length;
          if (this.check("Ident")) rest = this.next().value;
          else rest = "_";
        } else elements.push(this.parsePattern());
        if (!this.accept(",")) break;
      }
      this.expect("]", "']' in list pattern");
      const n = this.node("ListPattern", t, { elements, rest: hasRest ? rest : null });
      if (hasRest) n.restSyntax = restSyntax;
      if (hasRest && restIndex < elements.length) { n.restIndex = restIndex; }
      return n;
    });
  }

  parseMapPattern() {
    const t = this.expect("{");
    return this.withNl(false, () => {
      const fields = [];
      let rest = null, restSyntax = null;
      while (!this.check("}")) {
        if (this.check("...") || this.check("..")) {
          restSyntax = this.next().type;
          rest = this.check("Ident") ? this.next().value : "_";
        } else {
          const kt = this.peek();
          let key;
          if (kt.type === "String") { this.next(); key = kt.value; }
          else if (kt.type === "Int") { this.next(); key = String(numVal(kt)); }
          else key = this.expectWord("field name");
          let pattern;
          if (this.accept(":")) pattern = this.parsePattern();
          else pattern = this.node("BindingPattern", kt, { name: key });
          fields.push({ key, pattern });
        }
        if (!this.accept(",")) break;
      }
      this.expect("}", "'}' in map pattern");
      const mp = this.node("MapPattern", t, { fields, rest });
      if (rest) mp.restSyntax = restSyntax;
      return mp;
    });
  }

  // ---- expressions ----
  parseExpression() { return this.parseAssignment(); }

  // Continue parsing a full expression whose leading operand (at concat level) was already parsed.
  continueExpression(first) {
    const saved = this.pendingOperand;
    this.pendingOperand = first;
    try { return this.parseExpression(); } finally { this.pendingOperand = saved; }
  }

  parseAssignment() {
    const left = this.parsePipeline();
    const t = this.peek();
    if (ASSIGN_OPS.has(t.type)) {
      if (!isAssignable(left)) this.error("Invalid assignment target", t);
      this.next();
      const value = this.parseAssignment();
      const target = left.kind === "ListLiteral" || left.kind === "MapLiteral" ? exprToPattern(left, this) : left;
      return this.node("AssignExpr", t, { target, op: t.type, value, line: left.line, col: left.col });
    }
    return left;
  }

  parsePipeline() {
    let left = this.parseCoalesce();
    while (this.check("|>")) {
      const t = this.next();
      const right = this.parseCoalesce();
      left = this.node("PipelineExpr", t, { op: "|>", left, right });
    }
    return left;
  }

  parseCoalesce() {
    let left = this.parseOr();
    while (true) {
      const t = this.peek();
      if (t.type === "??" || (t.type === "?" && !this.broken(t) && this.isCoalesceOperand(this.peek(1)) && !this.peek(1).nl)) {
        this.next();
        const right = this.parseOr();
        left = this.node("BinaryExpr", t, { op: "??", left, right });
      } else break;
    }
    return left;
  }

  parseOr() {
    let left = this.parseAnd();
    while (this.check("Or") || this.check("||")) {
      const t = this.next();
      const right = this.parseAnd();
      left = this.node("BinaryExpr", t, t.type === "||" ? { op: "or", raw: "||", left, right } : { op: "or", left, right });
    }
    return left;
  }

  parseAnd() {
    let left = this.parseComparison();
    while (this.check("And") || this.check("&&")) {
      const t = this.next();
      const right = this.parseComparison();
      left = this.node("BinaryExpr", t, t.type === "&&" ? { op: "and", raw: "&&", left, right } : { op: "and", left, right });
    }
    return left;
  }

  // equality and relational operators share one (left-associative) level
  parseComparison() {
    let left = this.parseRange();
    while (true) {
      const t = this.peek();
      if (t.type === "==" || t.type === "!=" || t.type === "<" || t.type === ">" || t.type === "<=" || t.type === ">=") {
        this.next();
        const right = this.parseRange();
        left = this.node("BinaryExpr", t, { op: t.type, left, right });
      } else if (t.type === "In" && !this.broken(t)) {
        this.next();
        const right = this.parseRange();
        left = this.node("BinaryExpr", t, { op: "in", left, right });
      } else if (t.type === "Not" && this.peek(1).type === "In" && !this.broken(t)) {
        this.next(); this.next();
        const right = this.parseRange();
        left = this.node("UnaryExpr", t, { op: "not", operand: this.node("BinaryExpr", t, { op: "in", left, right }) });
      } else break;
    }
    return left;
  }

  parseRange() {
    const left = this.parseConcat();
    if (this.check("..") || this.check("..=")) {
      const t = this.next();
      const right = this.parseConcat();
      return this.node("RangeExpr", t, { op: t.type, start: left, end: right, inclusive: t.type === "..=", line: left.line, col: left.col });
    }
    return left;
  }

  // `++` binds looser than `+` / `-`
  parseConcat() {
    if (this.pendingOperand) {
      let left = this.pendingOperand;
      this.pendingOperand = null;
      while (this.check("++")) {
        const t = this.next();
        const right = this.parseAdditive();
        left = this.node("BinaryExpr", t, { op: "++", left, right });
      }
      return left;
    }
    let left = this.parseAdditive();
    while (this.check("++")) {
      const t = this.next();
      const right = this.parseAdditive();
      left = this.node("BinaryExpr", t, { op: "++", left, right });
    }
    return left;
  }

  parseAdditive() {
    let left = this.parseMultiplicative();
    while (true) {
      const t = this.peek();
      if (t.type === "+" || (t.type === "-" && !this.broken(t))) {
        this.next();
        const right = this.parseMultiplicative();
        left = this.node("BinaryExpr", t, { op: t.type, left, right });
      } else break;
    }
    return left;
  }

  parseMultiplicative() {
    let left = this.parsePower();
    while (true) {
      const t = this.peek();
      if (t.type === "*" || t.type === "/" || t.type === "%") {
        this.next();
        const right = this.parsePower();
        left = this.node("BinaryExpr", t, { op: t.type, left, right });
      } else break;
    }
    return left;
  }

  // `**` is right-associative; prefix operators bind tighter than every binary operator
  parsePower() {
    const base = this.parseUnary();
    if (this.check("**")) {
      const t = this.next();
      const exp = this.parsePower();
      return this.node("BinaryExpr", t, { op: "**", left: base, right: exp });
    }
    return base;
  }

  parseUnary() {
    const t = this.peek();
    if (t.type === "-") {
      this.next();
      const operand = this.parseUnary();
      if ((operand.kind === "IntLiteral" || operand.kind === "FloatLiteral") && !operand.parenthesized) {
        const n = this.node(operand.kind, t, { value: -operand.value });
        if (operand.raw !== undefined) Object.defineProperty(n, "raw", { value: "-" + operand.raw, enumerable: String(-operand.value) !== "-" + operand.raw, writable: true });
        return n;
      }
      return this.node("UnaryExpr", t, { op: "-", operand });
    }
    if (t.type === "Not" || t.type === "!") {
      this.next();
      const operand = this.parseUnary();
      return this.node("UnaryExpr", t, t.type === "!" ? { op: "not", raw: "!", operand } : { op: "not", operand });
    }
    if (t.type === "Await") {
      this.next();
      const expr = this.parseUnary();
      return this.node("AwaitExpr", t, { expr });
    }
    return this.parsePostfix();
  }

  isOperandStart(tok) { return OPERAND_START.has(tok.type) || tok.type === "-"; }
  // operands allowed after a binary `?` (a `{` after `?` means propagation followed by a block)
  isCoalesceOperand(tok) { return tok.type !== "{" && this.isOperandStart(tok); }

  parseArgs() {
    // after '('
    return this.withNl(false, () => {
      const args = [];
      while (!this.check(")")) {
        if (this.check("...")) { const t = this.next(); args.push(this.node("SpreadExpr", t, { op: "...", expr: this.parseExpression() })); }
        else if (this.check("Ident") && this.peek(1).type === ":" && this.peek(2).type !== ":") {
          // named argument -> collected into trailing map
          const t = this.next(); this.next();
          const value = this.parseExpression();
          args.push(this.node("NamedArg", t, { name: t.value, value }));
        }
        else args.push(this.parseExpression());
        if (!this.accept(",")) break;
      }
      this.expect(")", "')' after arguments");
      return foldNamedArgs(args);
    });
  }

  parsePostfix() {
    let expr = this.parsePrimary();
    while (true) {
      const t = this.peek();
      if (t.type === "(" && !this.broken(t)) {
        this.next();
        const args = this.parseArgs();
        expr = this.node("CallExpr", t, { callee: expr, args, line: expr.line, col: expr.col });
      } else if (t.type === "." ) {
        this.next();
        const p = this.peek();
        let property;
        if (p.type === "Ident" || /^[A-Z][a-z]+$/.test(p.type)) property = String(this.next().value);
        else if (p.type === "Int") property = String(numVal(this.next()));
        else this.error(`Expected property name after '.' but found ${describe(p)}`);
        expr = this.node("MemberExpr", t, { op: ".", object: expr, property, optional: false });
      } else if (t.type === "?.") {
        this.next();
        const p = this.peek();
        if (p.type === "[") {
          this.next();
          const index = this.withNl(false, () => this.parseExpression());
          this.expect("]");
          expr = this.node("IndexExpr", t, { object: expr, index, optional: true });
        } else if (p.type === "(") {
          this.next();
          const args = this.parseArgs();
          expr = this.node("CallExpr", t, { callee: expr, args, optional: true });
        } else {
          let property;
          if (p.type === "Ident" || /^[A-Z][a-z]+$/.test(p.type)) property = String(this.next().value);
          else if (p.type === "Int") property = String(numVal(this.next()));
          else this.error(`Expected property name after '?.' but found ${describe(p)}`);
          expr = this.node("MemberExpr", t, { op: "?.", object: expr, property, optional: true });
        }
      } else if (t.type === "[" && !this.broken(t)) {
        this.next();
        const res = this.withNl(false, () => {
          let start = null, end = null;
          if (this.check(":")) { this.next(); if (!this.check("]")) end = this.parseExpression(); return { slice: true, start, end }; }
          if (this.check("..") || this.check("..=")) {
            const inclusive = this.next().type === "..=";
            if (!this.check("]")) end = this.parseConcat();
            return { slice: true, start: null, end, inclusive };
          }
          const first = this.parseConcat();
          if (this.check("..") || this.check("..=")) {
            const inclusive = this.next().type === "..=";
            if (!this.check("]")) end = this.parseConcat();
            return { slice: true, start: first, end, inclusive };
          }
          const index = this.continueExpression(first);
          if (this.accept(":")) { if (!this.check("]")) end = this.parseExpression(); return { slice: true, start: index, end }; }
          return { index };
        });
        this.expect("]", "']' after index");
        if (res.slice) { expr = this.node("SliceExpr", t, { object: expr, start: res.start, end: res.end }); if (res.inclusive) expr.inclusive = true; }
        else expr = this.node("IndexExpr", t, { object: expr, index: res.index, optional: false });
      } else if (t.type === "?" && !this.broken(t) && !(this.isCoalesceOperand(this.peek(1)) && !this.peek(1).nl)) {
        this.next();
        expr = this.node("PropagateExpr", t, { op: "?", expr });
      } else break;
    }
    return expr;
  }

  // Is the token after the current '(' the start of a lambda "(params) =>"?
  isLambdaAhead() {
    let depth = 0;
    for (let i = this.pos; i < this.tokens.length; i++) {
      const tt = this.tokens[i].type;
      if (tt === "(" || tt === "[" || tt === "{") depth++;
      else if (tt === ")" || tt === "]" || tt === "}") {
        depth--;
        if (depth === 0) {
          const nx = this.tokens[i + 1];
          if (!nx) return false;
          if (nx.type === "=>") return true;
          if (nx.type === "->") {
            // (a) -> Type => body
            for (let j = i + 2; j < this.tokens.length && j < i + 20; j++) {
              if (this.tokens[j].type === "=>") return true;
              if (this.tokens[j].type === "{" || this.tokens[j].nl) return false;
            }
          }
          return false;
        }
      } else if (tt === "EOF") return false;
    }
    return false;
  }

  parseLambdaParams() { return this.parseParams(); }

  parseBodyExpr() {
    // Body after "=>": block if it looks like a block, else expression
    if (this.check("{") && this.looksLikeBlock(true)) return this.parseBlock();
    return this.parseExpression();
  }

  // Decide whether "{" at current position begins a block (true) or a map literal (false).
  looksLikeBlock(preferBlock) {
    const a = this.peek(1), b = this.peek(2);
    if (a.type === "}") return !!preferBlock && false;
    if (a.type === "..." || a.type === "..") return false;
    if ((a.type === "Ident" || a.type === "String" || a.type === "Int" || /^[A-Z][a-z]+$/.test(a.type)) && b.type === ":" && this.peek(3).type !== ":") return false;
    if (a.type === "[" ) {
      // computed key {[expr]: v}
      let depth = 0;
      for (let i = this.pos + 1; i < this.tokens.length; i++) {
        const tt = this.tokens[i].type;
        if (tt === "[" || tt === "(" || tt === "{") depth++;
        else if (tt === "]" || tt === ")" || tt === "}") { depth--; if (depth === 0) return !(this.tokens[i + 1] && this.tokens[i + 1].type === ":"); }
      }
      return true;
    }
    if (a.type === "Ident" && b.type === ",") return false;
    if (a.type === "Ident" && b.type === "}") return !!preferBlock;
    return true;
  }

  parsePrimary() {
    const t = this.peek();
    switch (t.type) {
      case "Int": this.next(); return this.numNode("IntLiteral", t);
      case "Float": this.next(); return this.numNode("FloatLiteral", t);
      case "String": this.next(); return this.parseStringToken(t);
      case "Regex": this.next(); return this.node("RegexLiteral", t, { pattern: t.value, flags: t.flags || "" });
      case "True": this.next(); return this.node("BoolLiteral", t, { value: true });
      case "False": this.next(); return this.node("BoolLiteral", t, { value: false });
      case "Nil": this.next(); return this.node("NilLiteral", t, {});
      case "Ident": {
        if (this.peek(1).type === "=>") {
          this.next(); this.next();
          const params = [this.node("Param", t, { name: t.value, pattern: null, rest: false, default: null, typeAnn: null })];
          const body = this.parseBodyExpr();
          return this.node("LambdaExpr", t, { syntax: "arrow", arrow: "=>", params, body, isExpr: body.kind !== "BlockExpr" });
        }
        this.next();
        return this.node("Identifier", t, { name: t.value });
      }
      case "(": {
        if (this.isLambdaAhead()) {
          const params = this.parseLambdaParams();
          let returnType = null;
          if (this.accept("->")) returnType = this.parseType();
          this.expect("=>");
          const body = this.parseBodyExpr();
          const lam = this.node("LambdaExpr", t, { syntax: "arrow", arrow: "=>", params, body, isExpr: body.kind !== "BlockExpr", returnType });
          Object.defineProperty(lam, "parenParams", { value: true, enumerable: false, writable: true });
          return lam;
        }
        this.next();
        return this.withNl(false, () => {
          if (this.check(")")) { this.next(); return this.node("ListLiteral", t, { elements: [] }); }
          const e = this.parseExpression();
          if (this.check(",")) {
            const elements = [e];
            while (this.accept(",")) { if (this.check(")")) break; elements.push(this.parseExpression()); }
            this.expect(")");
            return this.node("ListLiteral", t, { elements });
          }
          this.expect(")", "')'");
          Object.defineProperty(e, "parenthesized", { value: true, enumerable: false, writable: true });
          return e;
        });
      }
      case "[": return this.parseList();
      case "{":
        if (this.looksLikeBlock(false)) return this.parseBlock();
        return this.parseMap();
      case "Fetch":
        if (this.peek(1).type === "[") return this.parseFetch();
        this.error(`Expected '[' after 'fetch'`, this.peek(1));
      case "Type":
        if (this.peek(1).type === "(" && !this.peek(1).nl) { this.next(); return this.node("Identifier", t, { name: "type" }); }
        break;
      case "If": return this.parseIf();
      case "Match": return this.parseMatch();
      case "Try": return this.parseTry();
      case "Fn": {
        this.next();
        if (this.check("Ident")) this.next(); // optional name on fn expression
        const params = this.parseParams();
        let returnType = null;
        if (this.accept("->")) returnType = this.parseType();
        let body;
        if (this.accept("=>")) body = this.parseBodyExpr();
        else body = this.parseBlock();
        return this.node("LambdaExpr", t, { syntax: "fn", params, body, isExpr: body.kind !== "BlockExpr", returnType });
      }
      case "Async": {
        this.next();
        if (this.check("{")) { const body = this.parseBlock(); return this.node("AsyncExpr", t, { body }); }
        const inner = this.parsePrimary();
        if (inner.kind === "LambdaExpr") inner.async = true;
        return inner;
      }
      case "@": return this.parseToolCall();
      case "Return": case "Ret": return this.parseReturn();
      case "Break": this.next(); return this.node("BreakStmt", t, {});
      case "Continue": this.next(); return this.node("ContinueStmt", t, {});
      case "...": {
        const nx = this.peek(1);
        if (nx.type === "}" || nx.type === ")" || nx.type === "]" || nx.type === "," || nx.type === "EOF" || nx.nl) { this.next(); return this.node("EllipsisExpr", t, {}); }
        this.error("Unexpected spread '...'");
      }
    }
    this.error(`Unexpected ${describe(t)}`);
  }

  parseStringToken(t) {
    const withRaw = (n) => { if (t.text !== undefined) Object.defineProperty(n, "rawText", { value: t.text, enumerable: false, writable: true }); return n; };
    if (!t.parts) return withRaw(this.node("StringLiteral", t, { value: t.value }));
    const parts = t.parts.map((p) => {
      if (typeof p === "string") return p;
      let toks;
      try { toks = lex(p.expr); } catch (e) { throw new ArcSyntaxError(`Invalid interpolation '{${p.expr}}': ${e.message}`, { line: p.line, col: p.col }); }
      for (const tk of toks) { if (tk.line === 1) tk.col += p.col - 1; tk.line += p.line - 1; }
      const sub = new Parser(toks, this.options);
      sub.nlStack = [false];
      const expr = sub.parseExpression();
      if (!sub.check("EOF")) throw new ArcSyntaxError(`Invalid interpolation '{${p.expr}}'`, { line: p.line, col: p.col });
      return expr;
    });
    return withRaw(this.node("StringInterp", t, { raw: t.value, parts }));
  }

  parseList() {
    const t = this.expect("[");
    return this.withNl(false, () => {
      const elements = [];
      if (this.accept("]")) return this.node("ListLiteral", t, { elements });
      const first = this.parseListElement();
      if (this.check("For")) {
        const clauses = this.parseCompClauses();
        this.expect("]", "']' after comprehension");
        return this.node("ListComprehension", t, { expr: first, clauses });
      }
      elements.push(first);
      while (this.accept(",")) {
        if (this.check("]")) break;
        elements.push(this.parseListElement());
      }
      const close = this.expect("]", "']' after list elements");
      const ll = this.node("ListLiteral", t, { elements });
      Object.defineProperty(ll, "endLine", { value: close.line, enumerable: false, writable: true });
      return ll;
    });
  }

  parseListElement() {
    if (this.check("...") || (this.check("..") )) { const t = this.next(); return this.node("SpreadExpr", t, { op: t.type, expr: this.parseExpression() }); }
    return this.parseExpression();
  }

  parseCompClauses() {
    const clauses = [];
    while (this.check("For")) {
      const t = this.next();
      let pattern = this.parseBindingPattern();
      if (this.check(",")) {
        const elements = [pattern];
        while (this.accept(",")) elements.push(this.parseBindingPattern());
        pattern = this.node("ListPattern", t, { elements, rest: null });
      }
      this.expect("In", "'in' in comprehension");
      const iterable = this.parseOr();
      const conditions = [];
      while (this.check("If")) { this.next(); conditions.push(this.parseOr()); }
      const clause = { kind: "ForClause", keyword: "for", pattern, iterable, conditions };
      if (conditions.length) clause.filter = "if";
      clauses.push(clause);
    }
    return clauses;
  }

  parseMap() {
    const t = this.expect("{");
    return this.withNl(false, () => {
      const entries = [];
      while (!this.check("}")) {
        if (this.check("...") || this.check("..")) {
          const st = this.next();
          entries.push({ spread: this.parseExpression(), op: st.type });
        } else {
          const kt = this.peek();
          let key, computed = null;
          if (kt.type === "[") { this.next(); computed = this.parseExpression(); this.expect("]"); }
          else if (kt.type === "String") { this.next(); if (kt.parts) computed = this.parseStringToken(kt); else key = kt.value; }
          else if (kt.type === "Int" || kt.type === "Float") { this.next(); key = String(numVal(kt)); }
          else key = this.expectWord("map key");
          if (this.accept(":")) {
            const value = this.parseExpression();
            if (this.check("For") && entries.length === 0) {
              const clauses = this.parseCompClauses();
              this.expect("}");
              const keyExpr = computed || (kt.type === "Ident" ? this.node("Identifier", kt, { name: key }) : this.node("StringLiteral", kt, { value: key }));
              return this.node("MapComprehension", t, { key: keyExpr, value, clauses });
            }
            entries.push(computed ? { computed, value } : { key, value });
          } else {
            if (computed || kt.type !== "Ident") this.error("Expected ':' after map key", this.peek());
            const sh = { key, value: this.node("Identifier", kt, { name: key }) };
            Object.defineProperty(sh, "shorthand", { value: true, enumerable: false, writable: true });
            entries.push(sh);
          }
        }
        if (!this.accept(",")) break;
      }
      const close = this.expect("}", "'}' after map entries");
      const ml = this.node("MapLiteral", t, { entries });
      Object.defineProperty(ml, "endLine", { value: close.line, enumerable: false, writable: true });
      return ml;
    });
  }

  parseIf() {
    const t = this.next();
    const condition = this.withNl(false, () => this.parseExpression());
    let then;
    if (this.check("{")) then = this.parseBlock();
    else if (this.accept("=>")) then = this.parseExpression();
    else this.error(`Expected '{' after if condition but found ${describe(this.peek())}`);
    let else_ = null, elseKeyword = null;
    if (this.check("El") || this.check("Else")) {
      elseKeyword = this.next().value;
      if (this.check("If")) else_ = this.parseIf();
      else if (this.check("{")) else_ = this.parseBlock();
      else if (this.accept("=>")) else_ = this.parseExpression();
      else this.error(`Expected '{' or 'if' after else but found ${describe(this.peek())}`);
    }
    const ifNode = this.node("IfExpr", t, { condition, then, else_ });
    if (elseKeyword) ifNode.elseKeyword = elseKeyword;
    return ifNode;
  }

  parseMatch() {
    const t = this.next();
    const subject = this.withNl(false, () => this.parseExpression());
    const open = this.expect("{", "'{' after match subject");
    return this.withNl(true, () => {
      const arms = [];
      let sawComma = false;
      while (!this.check("}")) {
        if (this.check("EOF")) this.error("Unterminated match: expected '}'", open);
        if (this.accept(",") || this.accept(";")) { sawComma = true; continue; }
        const at = this.peek();
        const pattern = this.parsePattern();
        let guard = null;
        if (this.accept("If")) guard = this.withNl(false, () => this.parseExpression());
        this.expect("=>", "'=>' in match arm");
        const body = this.parseBodyExpr();
        arms.push(this.node("MatchArm", at, { pattern, guard, arrow: "=>", body }));
        if (this.accept(",") || this.accept(";")) sawComma = true;
        else if (!this.check("}") && !this.peek().nl) this.error(`Expected ',' or newline between match arms but found ${describe(this.peek())}`);
      }
      const close = this.expect("}");
      const m = this.node("MatchExpr", t, { subject, arms });
      Object.defineProperty(m, "endLine", { value: close.line, enumerable: false, writable: true });
      Object.defineProperty(m, "commas", { value: sawComma || arms.length < 2, enumerable: false, writable: true });
      return m;
    });
  }

  parseTry() {
    const t = this.next();
    const body = this.parseBlock();
    let param = null, handler = null, finalizer = null;
    if (this.accept("Catch")) {
      if (this.check("(") && this.peek(1).type === "Ident" && this.peek(2).type === ")") { this.next(); param = this.next().value; this.next(); }
      else if (this.check("Ident")) param = this.next().value;
      else this.error("catch requires a variable name (e.g. `catch e`)");
      handler = this.parseBlock();
    }
    if (this.checkIdent("finally")) { this.next(); finalizer = this.parseBlock(); }
    if (!handler && !finalizer) this.error("Expected 'catch' after try block");
    return this.node("TryExpr", t, { body, catchParam: param, catchBody: handler, finallyBody: finalizer });
  }

  parseToolCall() {
    const t = this.next(); // @
    const nameTok = this.peek();
    if (nameTok.type !== "Ident" && !/^[A-Z][a-z]+$/.test(nameTok.type)) this.error("Expected tool name after '@'");
    this.next();
    const name = String(nameTok.value);
    if (HTTP_METHODS.has(name.toUpperCase()) && name === name.toUpperCase()) {
      const url = this.parsePostfixNoCall();
      let body = null;
      const nx = this.peek();
      if (!nx.nl && (nx.type === "{" || nx.type === "Ident" || nx.type === "[" || nx.type === "String" || nx.type === "(")) {
        if (nx.type === "{") body = this.looksLikeBlock(false) ? this.parseMap() : this.parseMap();
        else body = this.parsePostfix();
      }
      return this.node("ToolCallExpr", t, { syntax: "@" + name.toUpperCase(), method: name.toUpperCase(), url, body, name: null, args: [] });
    }
    let args = [];
    if (this.check("(") && !this.broken()) { this.next(); args = this.parseArgs(); }
    else if (!this.peek().nl && (this.check("String") || this.check("Ident") || this.check("{") || this.check("[") || this.check("Int") || this.check("Float"))) {
      args = [this.check("{") ? this.parseMap() : this.parsePostfix()];
    }
    return this.node("ToolCallExpr", t, { syntax: "@" + name, method: null, url: null, body: null, name, args });
  }

  parsePostfixNoCall() {
    const t = this.peek();
    if (t.type === "String") { this.next(); return this.parseStringToken(t); }
    let expr = this.parsePrimary();
    while (this.check(".") ) {
      const d = this.next();
      const property = String(this.next().value);
      expr = this.node("MemberExpr", d, { object: expr, property, optional: false });
    }
    return expr;
  }

  parseFetch() {
    const t = this.next(); // fetch
    this.expect("[");
    return this.withNl(true, () => {
      const calls = [];
      while (!this.check("]")) {
        if (this.accept(",")) continue;
        calls.push(this.parseExpression());
      }
      this.expect("]");
      return this.node("FetchExpr", t, { calls });
    });
  }
}

function numVal(t) { return t.number !== undefined ? t.number : Number(String(t.value).replace(/_/g, "")); }

function foldNamedArgs(args) {
  if (!args.some((a) => a.kind === "NamedArg")) return args;
  const out = [];
  const entries = [];
  let first = null;
  for (const a of args) {
    if (a.kind === "NamedArg") { entries.push({ key: a.name, value: a.value }); if (!first) first = a; }
    else out.push(a);
  }
  out.push({ kind: "MapLiteral", entries, line: first.line, col: first.col });
  return out;
}

function isAssignable(e) {
  return e.kind === "Identifier" || e.kind === "MemberExpr" || e.kind === "IndexExpr" || e.kind === "ListLiteral" || e.kind === "MapLiteral";
}

function exprToPattern(e, parser) {
  switch (e.kind) {
    case "Identifier": return { kind: "BindingPattern", name: e.name, line: e.line, col: e.col };
    case "ListLiteral": {
      const elements = [];
      let rest = null;
      for (const el of e.elements) {
        if (el.kind === "SpreadExpr" && el.expr.kind === "Identifier") rest = el.expr.name;
        else elements.push(exprToPattern(el, parser));
      }
      return { kind: "ListPattern", elements, rest, line: e.line, col: e.col };
    }
    case "MapLiteral": {
      const fields = [];
      for (const en of e.entries) {
        if (en.key !== undefined) fields.push({ key: en.key, pattern: exprToPattern(en.value, parser) });
      }
      return { kind: "MapPattern", fields, rest: null, line: e.line, col: e.col };
    }
  }
  if (e.kind === "MemberExpr" || e.kind === "IndexExpr") return { kind: "TargetPattern", target: e, line: e.line, col: e.col };
  parser.error("Invalid destructuring assignment target");
}

function moduleBaseName(path) {
  const parts = String(path).split(/[\/\\]/).filter(Boolean);
  let last = parts[parts.length - 1] || String(path);
  last = last.replace(/\.arc$/, "");
  return last.replace(/[^A-Za-z0-9_]/g, "_");
}

function parse(input, options = {}) {
  let tokens;
  if (typeof input === "string") tokens = lex(input);
  else if (Array.isArray(input)) tokens = input;
  else if (input && Array.isArray(input.tokens)) tokens = input.tokens;
  else if (input && typeof input.source === "string") tokens = lex(input.source);
  else tokens = lex(String(input ?? ""));
  if (!tokens.length || tokens[tokens.length - 1].type !== "EOF") {
    const last = tokens[tokens.length - 1];
    tokens = tokens.concat([{ type: "EOF", value: "", line: last ? last.line : 1, col: last ? last.col + 1 : 1, nl: true }]);
  }
  const parser = new Parser(tokens, options);
  const program = parser.parseProgram();
  if (tokens.source !== undefined) Object.defineProperty(program, "source", { value: tokens.source, enumerable: false, writable: true });
  if (tokens.comments !== undefined) program.comments = tokens.comments.map((c) => ({ kind: "Comment", text: c.text, line: c.line, col: c.col }));
  return program;
}

function parseSource(source) { return parse(lex(source)); }

// Throw the first syntax error recorded by error recovery (if any).
function assertValid(program) {
  if (program && program.errorObjects && program.errorObjects.length) throw program.errorObjects[0];
  if (program && Array.isArray(program.errors) && program.errors.length) {
    const e = program.errors[0];
    throw new ArcSyntaxError(e.message, { line: e.line, col: e.col });
  }
  return program;
}

module.exports = { parse, parseSource, assertValid, Parser, moduleBaseName };
