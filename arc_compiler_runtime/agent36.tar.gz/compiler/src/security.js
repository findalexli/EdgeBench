"use strict";
// Arc security sandbox: source limits and tool-call (HTTP) validation.

class SecurityError extends Error {
  constructor(message, code) { super(message); this.name = "SecurityError"; this.code = code || "SECURITY_VIOLATION"; }
}

const DEFAULT_CONFIG = {
  maxSourceSize: 1024 * 1024,
  maxExecutionTime: 30000,
  maxRecursionDepth: 10000,
  maxLoopIterations: 10000000,
  maxUrlLength: 2048,
  allowedToolMethods: ["GET", "POST", "PUT", "DELETE"],
  allowedProtocols: ["http:", "https:"],
  allowedHosts: null,
  blockedHosts: [],
  blockPrivateNetworks: false,
  allowNetwork: true,
  allowFileSystem: true,
  allowShell: true,
};

function resolveConfig(options = {}) {
  return Object.assign({}, DEFAULT_CONFIG, options || {});
}

function validateSource(source, options = {}) {
  const cfg = resolveConfig(options);
  const text = source === null || source === undefined ? "" : String(source);
  const size = text.length;
  if (size > cfg.maxSourceSize) throw new SecurityError(`Source exceeds maximum size of ${cfg.maxSourceSize} characters (got ${size})`, "SOURCE_TOO_LARGE");
  if (text.includes("\u0000")) throw new SecurityError("Source contains null bytes", "INVALID_SOURCE");
  if (cfg.maxLines && text.split("\n").length > cfg.maxLines) throw new SecurityError(`Source exceeds maximum of ${cfg.maxLines} lines`, "SOURCE_TOO_LARGE");
  const blocked = new Set([].concat(cfg.forbiddenModules || [], cfg.blockedModules || [], cfg.deniedModules || [], cfg.disallowedModules || []));
  if (cfg.allowFileSystem === false) ["io", "os", "store", "fs"].forEach((m) => blocked.add(m));
  if (cfg.allowNetwork === false) ["http", "net", "llm"].forEach((m) => blocked.add(m));
  if (cfg.allowShell === false) blocked.add("os");
  const allowed = Array.isArray(cfg.allowedModules) ? new Set(cfg.allowedModules) : null;
  if (blocked.size || allowed) {
    const re = /^\s*(?:pub\s+)?(?:use|import)\s+(?:\{[^}]*\}\s*from\s*)?["']?([A-Za-z_][\w\/.-]*)/gm;
    let m;
    while ((m = re.exec(text))) {
      const name = m[1].replace(/\.arc$/, "").split("/").pop();
      if (blocked.has(name) || (allowed && !allowed.has(name))) throw new SecurityError(`Module '${name}' is not allowed`, "FORBIDDEN_MODULE");
    }
  }
  if (cfg.allowNetwork === false && /@(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b|\bfetch\s*\[/.test(stripStrings(text))) throw new SecurityError("Network tool calls are not allowed", "NETWORK_DISABLED");
  if (cfg.allowShell === false && /@shell\b|\bexec\s*\(/.test(stripStrings(text))) throw new SecurityError("Shell access is not allowed", "SHELL_DISABLED");
  // literal tool calls in the source must satisfy the tool-call policy
  const toolRe = /@([A-Za-z]+)\s+"([^"{}]*)"/g;
  let tm;
  while ((tm = toolRe.exec(text))) {
    const method = tm[1];
    if (method !== method.toUpperCase()) continue;
    const url = /^[a-z][a-z0-9+.-]*:/i.test(tm[2]) ? tm[2] : undefined;
    validateToolCall(method, url, cfg);
  }
  if (cfg.maxNestingDepth) {
    let depth = 0, max = 0;
    for (const ch of stripStrings(text)) { if ("([{".includes(ch)) { depth++; if (depth > max) max = depth; } else if (")]}".includes(ch)) depth--; }
    if (max > cfg.maxNestingDepth) throw new SecurityError(`Source exceeds maximum nesting depth of ${cfg.maxNestingDepth}`, "NESTING_TOO_DEEP");
  }
  return true;
}

function stripStrings(text) {
  return text.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`[^`]*`/g, '""').replace(/(#|\/\/)[^\n]*/g, "");
}

function isPrivateHost(host) {
  const h = String(host).toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (h === "0.0.0.0" || h === "::" || h === "::1" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")) return /:/.test(h) || h === "0.0.0.0";
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (m) {
    const [a, b] = [Number(m[1]), Number(m[2])];
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
  }
  if (/^::ffff:/.test(h)) return isPrivateHost(h.replace(/^::ffff:/, ""));
  return false;
}

function hostMatches(host, pattern) {
  const h = host.toLowerCase(), p = String(pattern).toLowerCase();
  if (p === "*") return true;
  if (p.startsWith("*.")) return h === p.slice(2) || h.endsWith(p.slice(1));
  return h === p;
}

function validateToolCall(method, url, options = {}) {
  const cfg = resolveConfig(options);
  if (cfg.allowNetwork === false) throw new SecurityError("Network access is disabled", "NETWORK_DISABLED");
  const m = String(method ?? "").toUpperCase();
  if (!m) throw new SecurityError("Tool call method is required", "METHOD_NOT_ALLOWED");
  const allowed = (cfg.allowedToolMethods || []).map((x) => String(x).toUpperCase());
  if (!allowed.includes(m)) throw new SecurityError(`Tool call method '${m}' is not allowed`, "METHOD_NOT_ALLOWED");
  if (url === undefined || url === null) return true;
  const u = String(url);
  if (u.length > cfg.maxUrlLength) throw new SecurityError(`URL exceeds maximum length of ${cfg.maxUrlLength}`, "URL_TOO_LONG");
  let parsed;
  try { parsed = new URL(u); } catch (e) { throw new SecurityError(`Invalid URL: ${u}`, "INVALID_URL"); }
  if (!(cfg.allowedProtocols || []).includes(parsed.protocol)) throw new SecurityError(`Protocol '${parsed.protocol}' is not allowed`, "PROTOCOL_NOT_ALLOWED");
  const host = parsed.hostname;
  const blockedHosts = [].concat(cfg.blockedHosts || [], cfg.blockedDomains || [], cfg.deniedHosts || [], cfg.denyHosts || []);
  const allowedHosts = cfg.allowedHosts || cfg.allowedDomains || cfg.allowHosts || null;
  cfg.blockedHosts = blockedHosts;
  cfg.allowedHosts = allowedHosts;
  if ((cfg.blockedHosts || []).some((p) => hostMatches(host, p))) throw new SecurityError(`Host '${host}' is blocked`, "HOST_BLOCKED");
  if (Array.isArray(cfg.allowedHosts) && cfg.allowedHosts.length && !cfg.allowedHosts.some((p) => hostMatches(host, p))) throw new SecurityError(`Host '${host}' is not in the allowed hosts list`, "HOST_NOT_ALLOWED");
  const explicitlyAllowed = Array.isArray(cfg.allowedHosts) && cfg.allowedHosts.some((p) => p !== "*" && hostMatches(host, p));
  if (cfg.blockPrivateNetworks && !explicitlyAllowed && isPrivateHost(host)) throw new SecurityError(`Access to private network host '${host}' is not allowed`, "PRIVATE_NETWORK");
  return true;
}

function isToolCallAllowed(method, url, options) {
  try { return validateToolCall(method, url, options); } catch (e) { return false; }
}

function isSourceAllowed(source, options) {
  try { return validateSource(source, options); } catch (e) { return false; }
}

function createSandbox(options = {}) {
  const config = resolveConfig(options);
  return {
    config,
    validateSource: (src) => validateSource(src, config),
    validateToolCall: (m, u) => validateToolCall(m, u, config),
    checkToolCall: (m, u) => validateToolCall(m, u, config),
    run(source, envOptions = {}) {
      validateSource(source, config);
      const { createEnv, interpretWithEnv } = require("./interpreter.js");
      const { lex } = require("./lexer.js");
      const { parse } = require("./parser.js");
      const env = createEnv({}, Object.assign({ security: { checkToolCall: (m, u) => validateToolCall(m, u, config) }, maxDepth: config.maxRecursionDepth }, envOptions));
      return interpretWithEnv(parse(lex(source)), env);
    },
  };
}

module.exports = { validateSource, validateToolCall, isToolCallAllowed, isSourceAllowed, isPrivateHost, createSandbox, SecurityError, DEFAULT_CONFIG, DEFAULT_SECURITY_CONFIG: DEFAULT_CONFIG, resolveConfig };
