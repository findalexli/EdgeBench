"use strict";
// Arc intermediate representation: a linear three-address instruction listing derived
// from the AST. The AST itself is kept on the IR (`ir.ast`) for the code generators.
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");

class IRBuilder {
  constructor() { this.temp = 0; this.label = 0; this.functions = []; }
  t() { return `%${++this.temp}`; }
  l(name) { return `${name}_${++this.label}`; }

  lowerBlock(stmts, out) {
    let last = null;
    for (const s of stmts) last = this.lowerStmt(s, out);
    return last;
  }

  lowerStmt(s, out) {
    switch (s.kind) {
      case "LetStmt": {
        const v = this.lowerExpr(s.value, out);
        if (s.pattern.kind === "BindingPattern") out.push({ op: "store", name: s.pattern.name, value: v, mutable: !!s.mutable });
        else out.push({ op: "destructure", pattern: s.pattern.kind, value: v });
        return v;
      }
      case "FnStmt": {
        this.lowerFunction(s.name, s);
        out.push({ op: "fn", name: s.name });
        return null;
      }
      case "TypeStmt": out.push({ op: "type", name: s.name }); return null;
      case "UseStmt": out.push({ op: "use", module: s.path, imports: s.imports }); return null;
      case "ForStmt": {
        const it = this.lowerExpr(s.iterable, out);
        const start = this.l("for"), end = this.l("endfor");
        out.push({ op: "iter_start", iterable: it, label: start });
        out.push({ op: "label", name: start });
        out.push({ op: "iter_next", target: s.variable || "_pattern", end });
        this.lowerBlock(s.body.stmts, out);
        out.push({ op: "jump", target: start });
        out.push({ op: "label", name: end });
        return null;
      }
      case "WhileStmt": {
        const start = this.l("while"), end = this.l("endwhile");
        out.push({ op: "label", name: start });
        const c = this.lowerExpr(s.condition, out);
        out.push({ op: "branch_false", cond: c, target: end });
        this.lowerBlock(s.body.stmts, out);
        out.push({ op: "jump", target: start });
        out.push({ op: "label", name: end });
        return null;
      }
      case "DoWhileStmt": {
        const start = this.l("do"), end = this.l("enddo");
        out.push({ op: "label", name: start });
        this.lowerBlock(s.body.stmts, out);
        if (s.condition) {
          const c = this.lowerExpr(s.condition, out);
          out.push({ op: s.until ? "branch_false" : "branch_true", cond: c, target: start });
        }
        out.push({ op: "label", name: end });
        return null;
      }
      case "ReturnStmt": {
        const v = s.value ? this.lowerExpr(s.value, out) : null;
        out.push({ op: "return", value: v });
        return v;
      }
      case "BreakStmt": out.push({ op: "break" }); return null;
      case "ContinueStmt": out.push({ op: "continue" }); return null;
      case "ExprStmt": return this.lowerExpr(s.expr, out);
      default: return this.lowerExpr(s, out);
    }
  }

  lowerFunction(name, node) {
    const body = [];
    const saved = this.temp;
    let ret;
    if (node.body.kind === "BlockExpr") ret = this.lowerBlock(node.body.stmts, body);
    else ret = this.lowerExpr(node.body, body);
    body.push({ op: "return", value: ret });
    this.functions.push({ name, params: node.params.map((p) => (p.rest ? "..." : "") + (p.name || "_pattern")), body });
    this.temp = Math.max(this.temp, saved);
  }

  lowerExpr(e, out) {
    switch (e.kind) {
      case "IntLiteral": case "FloatLiteral": case "StringLiteral": case "BoolLiteral": {
        const d = this.t(); out.push({ op: "const", dest: d, value: e.value }); return d;
      }
      case "NilLiteral": { const d = this.t(); out.push({ op: "const", dest: d, value: null }); return d; }
      case "StringInterp": {
        const parts = e.parts.map((p) => (typeof p === "string" ? JSON.stringify(p) : this.lowerExpr(p, out)));
        const d = this.t(); out.push({ op: "interp", dest: d, parts }); return d;
      }
      case "Identifier": { const d = this.t(); out.push({ op: "load", dest: d, name: e.name }); return d; }
      case "BinaryExpr": {
        if (e.op === "and" || e.op === "or" || e.op === "??") {
          const l = this.lowerExpr(e.left, out);
          const d = this.t();
          const end = this.l(e.op === "??" ? "coalesce" : e.op);
          out.push({ op: "move", dest: d, src: l });
          out.push({ op: e.op === "and" ? "branch_false" : e.op === "or" ? "branch_true" : "branch_not_nil", cond: d, target: end });
          const r = this.lowerExpr(e.right, out);
          out.push({ op: "move", dest: d, src: r });
          out.push({ op: "label", name: end });
          return d;
        }
        const l = this.lowerExpr(e.left, out), r = this.lowerExpr(e.right, out);
        const d = this.t(); out.push({ op: "binop", dest: d, operator: e.op, left: l, right: r }); return d;
      }
      case "UnaryExpr": {
        const o = this.lowerExpr(e.operand, out);
        const d = this.t(); out.push({ op: "unop", dest: d, operator: e.op, operand: o }); return d;
      }
      case "RangeExpr": {
        const a = this.lowerExpr(e.start, out), b = this.lowerExpr(e.end, out);
        const d = this.t(); out.push({ op: "range", dest: d, start: a, end: b, inclusive: !!e.inclusive }); return d;
      }
      case "CallExpr": {
        const args = e.args.map((a) => this.lowerExpr(a.kind === "SpreadExpr" ? a.expr : a, out));
        const d = this.t();
        if (e.callee.kind === "Identifier") out.push({ op: "call", dest: d, fn: e.callee.name, args });
        else if (e.callee.kind === "MemberExpr") { const o = this.lowerExpr(e.callee.object, out); out.push({ op: "call_method", dest: d, object: o, method: e.callee.property, args }); }
        else { const f = this.lowerExpr(e.callee, out); out.push({ op: "call_indirect", dest: d, fn: f, args }); }
        return d;
      }
      case "MemberExpr": { const o = this.lowerExpr(e.object, out); const d = this.t(); out.push({ op: "field", dest: d, object: o, name: e.property, optional: !!e.optional }); return d; }
      case "IndexExpr": { const o = this.lowerExpr(e.object, out), i = this.lowerExpr(e.index, out); const d = this.t(); out.push({ op: "index", dest: d, object: o, index: i }); return d; }
      case "SliceExpr": { const o = this.lowerExpr(e.object, out); const d = this.t(); out.push({ op: "slice", dest: d, object: o }); return d; }
      case "PipelineExpr": {
        const l = this.lowerExpr(e.left, out);
        const d = this.t();
        if (e.right.kind === "CallExpr" && e.right.callee.kind === "Identifier") {
          const args = e.right.args.map((a) => this.lowerExpr(a, out));
          out.push({ op: "call", dest: d, fn: e.right.callee.name, args: [l, ...args] });
        } else if (e.right.kind === "Identifier") out.push({ op: "call", dest: d, fn: e.right.name, args: [l] });
        else { const f = this.lowerExpr(e.right, out); out.push({ op: "call_indirect", dest: d, fn: f, args: [l] }); }
        return d;
      }
      case "IfExpr": {
        const c = this.lowerExpr(e.condition, out);
        const d = this.t();
        const elseL = this.l("else"), end = this.l("endif");
        out.push({ op: "branch_false", cond: c, target: elseL });
        const tv = e.then.kind === "BlockExpr" ? this.lowerBlock(e.then.stmts, out) : this.lowerExpr(e.then, out);
        out.push({ op: "move", dest: d, src: tv });
        out.push({ op: "jump", target: end });
        out.push({ op: "label", name: elseL });
        let ev = null;
        if (e.else_) ev = e.else_.kind === "BlockExpr" ? this.lowerBlock(e.else_.stmts, out) : this.lowerExpr(e.else_, out);
        out.push({ op: "move", dest: d, src: ev });
        out.push({ op: "label", name: end });
        return d;
      }
      case "MatchExpr": {
        const subj = this.lowerExpr(e.subject, out);
        const d = this.t();
        const end = this.l("endmatch");
        for (const arm of e.arms) {
          const next = this.l("arm");
          out.push({ op: "match_pattern", subject: subj, pattern: arm.pattern.kind, fail: next });
          if (arm.guard) { const g = this.lowerExpr(arm.guard, out); out.push({ op: "branch_false", cond: g, target: next }); }
          const v = arm.body.kind === "BlockExpr" ? this.lowerBlock(arm.body.stmts, out) : this.lowerExpr(arm.body, out);
          out.push({ op: "move", dest: d, src: v });
          out.push({ op: "jump", target: end });
          out.push({ op: "label", name: next });
        }
        out.push({ op: "move", dest: d, src: null });
        out.push({ op: "label", name: end });
        return d;
      }
      case "LambdaExpr": {
        const name = `lambda_${++this.label}`;
        this.lowerFunction(name, e);
        const d = this.t(); out.push({ op: "closure", dest: d, fn: name }); return d;
      }
      case "ListLiteral": { const els = e.elements.map((x) => this.lowerExpr(x.kind === "SpreadExpr" ? x.expr : x, out)); const d = this.t(); out.push({ op: "list", dest: d, elements: els }); return d; }
      case "MapLiteral": {
        const entries = e.entries.map((en) => (en.spread ? { spread: this.lowerExpr(en.spread, out) } : { key: en.key !== undefined ? en.key : this.lowerExpr(en.computed, out), value: this.lowerExpr(en.value, out) }));
        const d = this.t(); out.push({ op: "map", dest: d, entries }); return d;
      }
      case "ListComprehension": case "MapComprehension": { const d = this.t(); out.push({ op: "comprehension", dest: d, kind: e.kind }); return d; }
      case "BlockExpr": case "AsyncExpr": { const stmts = e.kind === "AsyncExpr" ? e.body.stmts : e.stmts; return this.lowerBlock(stmts, out); }
      case "TryExpr": {
        const d = this.t();
        const handler = this.l("catch"), end = this.l("endtry");
        out.push({ op: "try_start", handler });
        const v = this.lowerBlock(e.body.stmts, out);
        out.push({ op: "move", dest: d, src: v });
        out.push({ op: "try_end" });
        out.push({ op: "jump", target: end });
        out.push({ op: "label", name: handler });
        if (e.catchBody) { const hv = this.lowerBlock(e.catchBody.stmts, out); out.push({ op: "move", dest: d, src: hv }); }
        out.push({ op: "label", name: end });
        return d;
      }
      case "ToolCallExpr": {
        const d = this.t();
        if (e.method) { const u = this.lowerExpr(e.url, out); const b = e.body ? this.lowerExpr(e.body, out) : null; out.push({ op: "tool_call", dest: d, method: e.method, url: u, body: b }); }
        else { const args = e.args.map((a) => this.lowerExpr(a, out)); out.push({ op: "tool_call", dest: d, tool: e.name, args }); }
        return d;
      }
      case "FetchExpr": { const calls = e.calls.map((c) => this.lowerExpr(c, out)); const d = this.t(); out.push({ op: "parallel", dest: d, calls }); return d; }
      case "AwaitExpr": { const v = this.lowerExpr(e.expr, out); const d = this.t(); out.push({ op: "await", dest: d, value: v }); return d; }
      case "PropagateExpr": { const v = this.lowerExpr(e.expr, out); const d = this.t(); out.push({ op: "propagate", dest: d, value: v }); return d; }
      case "AssignExpr": {
        const v = this.lowerExpr(e.value, out);
        if (e.target.kind === "Identifier") out.push({ op: e.op === "=" ? "assign" : "assign_op", name: e.target.name, value: v, operator: e.op });
        else if (e.target.kind === "MemberExpr") { const o = this.lowerExpr(e.target.object, out); out.push({ op: "set_field", object: o, name: e.target.property, value: v }); }
        else if (e.target.kind === "IndexExpr") { const o = this.lowerExpr(e.target.object, out), i = this.lowerExpr(e.target.index, out); out.push({ op: "set_index", object: o, index: i, value: v }); }
        else out.push({ op: "destructure", pattern: e.target.kind, value: v });
        return v;
      }
      case "ReturnStmt": case "BreakStmt": case "ContinueStmt": return this.lowerStmt(e, out);
      default: { const d = this.t(); out.push({ op: "eval", dest: d, node: e.kind }); return d; }
    }
  }
}

function toAstRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (Array.isArray(input)) return parse(input);
  if (input && input.kind === "Program") return input;
  if (input && Array.isArray(input.stmts)) return input;
  if (input && input.ast) return input.ast;
  if (input && typeof input.source === "string") return parse(lex(input.source));
  return { kind: "Program", stmts: [] };
}
function toAst(input) { return assertValid(toAstRaw(input)); }

function generateIR(program) {
  const ast = toAst(program);
  const b = new IRBuilder();
  const instructions = [];
  b.lowerBlock(ast.stmts, instructions);
  const ir = { kind: "IRModule", type: "ArcIR", version: 1, functions: b.functions, instructions, main: instructions };
  Object.defineProperty(ir, "ast", { value: ast, enumerable: false, writable: true, configurable: true });
  if (ast.source !== undefined) Object.defineProperty(ir, "source", { value: ast.source, enumerable: false, writable: true, configurable: true });
  return ir;
}

function formatInstr(i) {
  const fmt = (v) => (v === null || v === undefined ? "nil" : Array.isArray(v) ? `[${v.map(fmt).join(", ")}]` : typeof v === "object" ? JSON.stringify(v) : String(v));
  switch (i.op) {
    case "label": return `${i.name}:`;
    case "const": return `  ${i.dest} = const ${JSON.stringify(i.value)}`;
    case "load": return `  ${i.dest} = load ${i.name}`;
    case "store": return `  store ${i.name}, ${fmt(i.value)}`;
    case "binop": return `  ${i.dest} = ${i.operator} ${i.left}, ${i.right}`;
    case "unop": return `  ${i.dest} = ${i.operator} ${i.operand}`;
    case "call": return `  ${i.dest} = call ${i.fn}(${i.args.join(", ")})`;
    case "call_method": return `  ${i.dest} = call ${i.object}.${i.method}(${i.args.join(", ")})`;
    case "field": return `  ${i.dest} = field ${i.object} "${i.name}"`;
    case "jump": return `  jump ${i.target}`;
    case "branch_false": case "branch_true": case "branch_not_nil": return `  ${i.op} ${i.cond}, ${i.target}`;
    case "return": return `  return ${fmt(i.value)}`;
    default: {
      const rest = Object.keys(i).filter((k) => k !== "op" && k !== "dest").map((k) => `${k}=${fmt(i[k])}`).join(" ");
      return `  ${i.dest ? i.dest + " = " : ""}${i.op} ${rest}`.trimEnd();
    }
  }
}

function printIR(ir) {
  const lines = [];
  for (const f of ir.functions || []) {
    lines.push(`fn ${f.name}(${f.params.join(", ")}) {`);
    for (const i of f.body) lines.push(formatInstr(i));
    lines.push("}");
  }
  lines.push("main {");
  for (const i of ir.instructions || []) lines.push(formatInstr(i));
  lines.push("}");
  return lines.join("\n");
}

module.exports = { generateIR, printIR, IRBuilder };
