"use strict";
// Arc semantic analysis: name resolution, mutability, control-flow sanity checks.
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { createRuntime } = require("./runtime-core.js");

let RT = null;
function rtInfo() {
  if (!RT) {
    const rt = createRuntime({});
    const modules = {};
    for (const m of rt.moduleNames) { try { modules[m] = Object.keys(rt.loadModule(m)); } catch (e) { modules[m] = []; } }
    RT = { rt, builtins: new Set(Object.keys(rt.builtins)), modules };
  }
  return RT;
}

class AScope {
  constructor(parent, kind) { this.parent = parent; this.kind = kind; this.vars = new Map(); }
  lookup(name) { let s = this; while (s) { const v = s.vars.get(name); if (v) return v; s = s.parent; } return null; }
}

function toProgramRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (Array.isArray(input)) return parse(input);
  if (input && input.kind === "Program") return input;
  if (input && input.ast) return input.ast;
  if (input && Array.isArray(input.stmts)) return input;
  return { kind: "Program", stmts: [] };
}
function toProgram(input) { return assertValid(toProgramRaw(input)); }

class Analyzer {
  constructor(options = {}) {
    this.options = options;
    this.errors = [];
    this.warnings = [];
    this.infos = [];
    this.allVars = [];
    const info = rtInfo();
    this.info = info;
    this.global = new AScope(null, "builtin");
    for (const b of info.builtins) this.global.vars.set(b, { name: b, kind: "builtin", mutable: false, used: true, builtin: true });
    for (const extra of options.globals || []) this.global.vars.set(extra, { name: extra, kind: "builtin", mutable: true, used: true, builtin: true });
    this.deferred = [];
    this.redeclared = [];
    this.selfAssign = [];
  }

  report(list, severity, rule, message, node) {
    list.push({ rule, severity, level: severity, message, line: node && node.line ? node.line : 1, col: node && node.col ? node.col : 1 });
  }
  error(rule, msg, node) { this.report(this.errors, "error", rule, msg, node); }
  warn(rule, msg, node) { this.report(this.warnings, "warning", rule, msg, node); }

  declare(scope, name, kind, mutable, node, extra) {
    const prev = scope.vars.get(name);
    const v = Object.assign({ name, kind, mutable: !!mutable, used: false, reassigned: false, node, scope, line: node && node.line, col: node && node.col }, extra || {});
    if (prev && !prev.builtin) {
      // redeclaration in the same scope
      if (!prev.used && prev.kind === "var" && !name.startsWith("_") && scope.kind !== "program-hidden") prev.shadowedUnused = true;
      if ((prev.kind === "var" || prev.kind === "fn") && (kind === "var" || kind === "fn") && prev.node !== node) this.redeclared.push({ name, node, prevLine: prev.line });
    }
    scope.vars.set(name, v);
    this.allVars.push(v);
    return v;
  }

  analyzeProgram(program) {
    const scope = new AScope(this.global, "program");
    this.ctx = { fn: null, loop: 0 };
    this.block(program.stmts, scope, true);
    this.flushDeferred();
    return scope;
  }

  flushDeferred() {
    while (this.deferred.length) {
      const d = this.deferred.shift();
      d();
    }
  }

  block(stmts, scope, isTop) {
    // hoist functions
    for (const s of stmts) if (s.kind === "FnStmt") this.declare(scope, s.name, "fn", false, s, { pub: !!s.pub, top: isTop });
    let terminated = null;
    for (const s of stmts) {
      if (terminated) {
        this.warn("unreachable-code", `Unreachable code after '${terminated}'`, s);
        terminated = null;
      }
      this.stmt(s, scope, isTop);
      if (s.kind === "ReturnStmt") terminated = "ret";
      else if (s.kind === "BreakStmt") terminated = "break";
      else if (s.kind === "ContinueStmt") terminated = "continue";
      else if (s.kind === "ExprStmt" && (s.expr.kind === "ReturnStmt" || s.expr.kind === "BreakStmt" || s.expr.kind === "ContinueStmt")) terminated = s.expr.kind === "ReturnStmt" ? "ret" : s.expr.kind === "BreakStmt" ? "break" : "continue";
    }
  }

  stmt(s, scope, isTop) {
    switch (s.kind) {
      case "LetStmt": {
        this.expr(s.value, scope);
        for (const n of patternNames(s.pattern)) this.declare(scope, n, "var", s.mutable, s.pattern.kind === "BindingPattern" ? s : s.pattern, { pub: !!s.pub, top: isTop });
        return;
      }
      case "FnStmt": {
        const existing = scope.vars.get(s.name);
        if (!existing || existing.node !== s) this.declare(scope, s.name, "fn", false, s, { pub: !!s.pub, top: isTop });
        this.deferFunction(s, scope);
        return;
      }
      case "TypeStmt": {
        const walk = (t, inUnion) => { if (!t) return; if (t.kind === "UnionType") t.types.forEach((x) => walk(x, true)); else if ((t.kind === "VariantType" || (inUnion && t.kind === "NamedType" && isNullaryVariant(t))) && !scope.lookup(t.name)) this.declare(scope, t.name, "type", false, s, { used: true }); };
        walk(s.def);
        return;
      }
      case "UseStmt": {
        const rt = this.info.rt;
        let members = null;
        if (rt.hasModule(s.path)) {
          const ns = rt.loadModule(s.path);
          members = Object.keys(ns);
        } else if (this.options.resolveModule) {
          members = this.options.resolveModule(s.path);
        }
        if (members === null) members = this.fileModuleExports(s.path);
        if (members === null) { this.error("unknown-module", `Module not found: '${s.path}'`, s); members = []; }
        if (s.imports === null) {
          const modVar = this.declare(scope, s.alias || s.name, "module", false, s, { used: false });
          for (const k of members) if (!k.startsWith("_") && !scope.lookup(k)) this.declare(scope, k, "import", false, s, { used: true, owner: modVar });
        } else if (s.imports === "*") {
          for (const k of members) this.declare(scope, k, "import", false, s, { used: true });
        } else {
          for (const n of s.imports) {
            if (!members.includes(n) && members.length) this.error("unknown-import", `Module '${s.path}' has no export '${n}'`, s);
            this.declare(scope, n, "import", false, s, { used: false, selective: true });
          }
          if (!scope.lookup(s.alias || s.name)) this.declare(scope, s.alias || s.name, "module", false, s, { used: true });
        }
        return;
      }
      case "ForStmt": {
        this.expr(s.iterable, scope);
        const inner = new AScope(scope, "block");
        for (const n of patternNames(s.pattern)) this.declare(inner, n, "loopvar", true, s, { used: n.startsWith("_") });
        this.ctx.loop++;
        this.block(s.body.stmts, inner, false);
        this.ctx.loop--;
        return;
      }
      case "WhileStmt": {
        this.expr(s.condition, scope);
        this.ctx.loop++;
        this.block(s.body.stmts, new AScope(scope, "block"), false);
        this.ctx.loop--;
        return;
      }
      case "DoWhileStmt": {
        this.ctx.loop++;
        this.block(s.body.stmts, new AScope(scope, "block"), false);
        this.ctx.loop--;
        if (s.condition) this.expr(s.condition, scope);
        return;
      }
      case "ReturnStmt": {
        if (!this.ctx.fn && !this.options.allowTopLevelReturn) this.warn("return-outside-function", "'ret' used outside of a function", s);
        if (s.value) this.expr(s.value, scope);
        return;
      }
      case "BreakStmt": if (!this.ctx.loop) this.error("break-outside-loop", "'break' outside of loop", s); return;
      case "ContinueStmt": if (!this.ctx.loop) this.error("continue-outside-loop", "'continue' outside of loop", s); return;
      case "ExprStmt": this.expr(s.expr, scope); return;
    }
    this.expr(s, scope);
  }

  fileModuleExports(path) {
    try {
      const fs = require("fs"), pathMod = require("path");
      const base = this.options.baseDir || process.cwd();
      const raw = pathMod.isAbsolute(path) ? path : pathMod.resolve(base, path);
      const cands = path.endsWith(".arc") ? [raw] : [raw + ".arc", pathMod.join(raw, "index.arc")];
      for (const c of cands) {
        if (fs.existsSync(c) && fs.statSync(c).isFile()) {
          const prog = parse(lex(fs.readFileSync(c, "utf8")));
          const hasPub = prog.stmts.some((s) => s.pub);
          const out = [];
          for (const s of prog.stmts) {
            const names = s.kind === "FnStmt" ? [s.name] : s.kind === "LetStmt" ? patternNames(s.pattern) : [];
            for (const n of names) if (hasPub ? s.pub : !n.startsWith("_")) out.push(n);
          }
          return out;
        }
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  deferFunction(node, scope) {
    const ctx = this.ctx;
    this.deferred.push(() => {
      const saved = this.ctx;
      this.ctx = { fn: node, loop: 0 };
      const fscope = new AScope(scope, "function");
      const seen = new Set();
      for (const p of node.params) {
        const names = p.pattern ? patternNames(p.pattern) : [p.name];
        for (const n of names) {
          if (seen.has(n)) this.error("duplicate-parameter", `Duplicate parameter '${n}'`, p);
          seen.add(n);
          this.declare(fscope, n, "param", true, p, { used: true });
        }
        if (p.default) this.expr(p.default, fscope);
      }
      if (node.body.kind === "BlockExpr") this.block(node.body.stmts, fscope, false);
      else this.expr(node.body, fscope);
      this.ctx = saved;
    });
    void ctx;
  }

  use(scope, name, node) {
    const v = scope.lookup(name);
    if (!v) { this.error("undefined-variable", `Undefined variable '${name}'`, node); return null; }
    v.used = true;
    if (v.owner) v.owner.used = true;
    return v;
  }

  expr(e, scope) {
    if (!e || typeof e !== "object") return;
    switch (e.kind) {
      case "IntLiteral": case "FloatLiteral": case "StringLiteral": case "BoolLiteral": case "NilLiteral": case "RegexLiteral": return;
      case "StringInterp": for (const p of e.parts) if (typeof p !== "string") this.expr(p, scope); return;
      case "Identifier": this.use(scope, e.name, e); return;
      case "BinaryExpr": this.expr(e.left, scope); this.expr(e.right, scope); return;
      case "UnaryExpr": this.expr(e.operand, scope); return;
      case "RangeExpr": this.expr(e.start, scope); this.expr(e.end, scope); return;
      case "CallExpr": this.expr(e.callee, scope); e.args.forEach((a) => this.expr(a, scope)); return;
      case "SpreadExpr": this.expr(e.expr, scope); return;
      case "MemberExpr": this.expr(e.object, scope); return;
      case "IndexExpr": this.expr(e.object, scope); this.expr(e.index, scope); return;
      case "SliceExpr": this.expr(e.object, scope); if (e.start) this.expr(e.start, scope); if (e.end) this.expr(e.end, scope); return;
      case "PipelineExpr": this.expr(e.left, scope); this.expr(e.right, scope); return;
      case "IfExpr":
        this.expr(e.condition, scope);
        this.branch(e.then, scope);
        if (e.else_) this.branch(e.else_, scope);
        return;
      case "MatchExpr": {
        this.expr(e.subject, scope);
        let sawCatchAll = false;
        for (const arm of e.arms) {
          if (sawCatchAll) this.warn("unreachable-pattern", "Unreachable match arm after a catch-all pattern", arm);
          const inner = new AScope(scope, "block");
          for (const n of patternNames(arm.pattern)) this.declare(inner, n, "binding", false, arm, { used: true });
          if (arm.guard) this.expr(arm.guard, inner);
          this.branch(arm.body, inner);
          if (!arm.guard && (arm.pattern.kind === "WildcardPattern" || arm.pattern.kind === "BindingPattern")) sawCatchAll = true;
        }
        return;
      }
      case "LambdaExpr": this.deferFunction(e, scope); return;
      case "ListLiteral": e.elements.forEach((x) => this.expr(x, scope)); return;
      case "MapLiteral": {
        const keys = new Set();
        for (const en of e.entries) {
          if (en.spread) this.expr(en.spread, scope);
          else {
            if (en.computed) this.expr(en.computed, scope);
            else {
              if (keys.has(en.key)) this.warn("duplicate-key", `Duplicate key '${en.key}' in map literal`, e);
              keys.add(en.key);
            }
            this.expr(en.value, scope);
          }
        }
        return;
      }
      case "ListComprehension": case "MapComprehension": {
        let sc = scope;
        for (const c of e.clauses) {
          this.expr(c.iterable, sc);
          sc = new AScope(sc, "block");
          for (const n of patternNames(c.pattern)) this.declare(sc, n, "binding", false, c.pattern, { used: true });
          c.conditions.forEach((x) => this.expr(x, sc));
        }
        if (e.kind === "MapComprehension") { this.expr(e.key, sc); this.expr(e.value, sc); }
        else this.expr(e.expr, sc);
        return;
      }
      case "BlockExpr": this.block(e.stmts, new AScope(scope, "block"), false); return;
      case "TryExpr": {
        this.block(e.body.stmts, new AScope(scope, "block"), false);
        if (e.catchBody) {
          const inner = new AScope(scope, "block");
          if (e.catchParam) this.declare(inner, e.catchParam, "binding", false, e, { used: true });
          this.block(e.catchBody.stmts, inner, false);
        }
        if (e.finallyBody) this.block(e.finallyBody.stmts, new AScope(scope, "block"), false);
        return;
      }
      case "ToolCallExpr":
        if (e.url) this.expr(e.url, scope);
        if (e.body) this.expr(e.body, scope);
        (e.args || []).forEach((a) => this.expr(a, scope));
        if (e.name) { const v = scope.lookup(e.name); if (v) v.used = true; }
        return;
      case "FetchExpr": e.calls.forEach((c) => this.expr(c, scope)); return;
      case "AsyncExpr": this.block(e.body.stmts, new AScope(scope, "block"), false); return;
      case "AwaitExpr": case "PropagateExpr": this.expr(e.expr, scope); return;
      case "AssignExpr": {
        this.expr(e.value, scope);
        const t = e.target;
        if (t.kind === "Identifier") {
          if (e.op === "=" && e.value.kind === "Identifier" && e.value.name === t.name) this.selfAssign.push({ name: t.name, node: e });
          this.assignName(scope, t.name, t, e.op !== "=");
        }
        else if (t.kind === "MemberExpr") this.expr(t.object, scope);
        else if (t.kind === "IndexExpr") { this.expr(t.object, scope); this.expr(t.index, scope); }
        else for (const n of patternNames(t)) this.assignName(scope, n, e, false);
        return;
      }
      case "ReturnStmt": case "BreakStmt": case "ContinueStmt": this.stmt(e, scope, false); return;
      case "LetStmt": case "FnStmt": case "ForStmt": case "WhileStmt": case "DoWhileStmt": case "UseStmt": case "TypeStmt": case "ExprStmt":
        this.stmt(e, scope, false); return;
    }
  }

  branch(b, scope) {
    if (b.kind === "BlockExpr") this.block(b.stmts, new AScope(scope, "block"), false);
    else this.expr(b, scope);
  }

  assignName(scope, name, node, compound) {
    const v = scope.lookup(name);
    if (!v) { this.error("undefined-variable", `Undefined variable '${name}'`, node); return; }
    if (compound) v.used = true;
    if (!v.mutable || v.builtin) {
      this.error("immutable-assignment", `Cannot reassign immutable variable '${name}' (declare it with 'let mut')`, node);
      return;
    }
    v.reassigned = true;
  }
}

const BUILTIN_TYPE_NAMES = new Set(["Int", "Integer", "Float", "Number", "Num", "Double", "String", "Str", "Bool", "Boolean", "Nil", "None", "Void", "Unit", "Null", "Any", "List", "Array", "Set", "Tuple", "Map", "Object", "Record", "Dict", "Fn", "Function", "Callable", "Result", "Option", "Maybe", "Promise", "Json", "JSON", "Value", "Never", "Unknown"]);
function isNullaryVariant(t) { return t.kind === "NamedType" && !(t.args && t.args.length) && /^[A-Z]/.test(t.name) && !BUILTIN_TYPE_NAMES.has(t.name) && !/^[A-Z]$/.test(t.name); }

function patternNames(p, out = []) {
  if (!p) return out;
  switch (p.kind) {
    case "BindingPattern": out.push(p.name); break;
    case "ListPattern": p.elements.forEach((e) => patternNames(e, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "MapPattern": p.fields.forEach((f) => patternNames(f.pattern, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "OrPattern": { const seen = new Set(out); p.alternatives.forEach((a) => patternNames(a, []).forEach((n) => { if (!seen.has(n)) { seen.add(n); out.push(n); } })); break; }
    case "VariantPattern": (p.args || []).forEach((a) => patternNames(a, out)); break;
    case "TypedPattern": if (p.name !== "_") out.push(p.name); break;
  }
  return Array.from(new Set(out));
}

function runAnalysis(input, options = {}) {
  let program;
  try { program = toProgram(input); }
  catch (e) {
    return { ok: false, errors: [{ rule: "parse-error", severity: "error", level: "error", message: e.message, line: e.line || 1, col: e.col || 1 }], warnings: [], analyzer: null, program: null };
  }
  const a = new Analyzer(options);
  a.analyzeProgram(program);
  return { ok: a.errors.length === 0, errors: a.errors, warnings: a.warnings, analyzer: a, program };
}

function analyze(input, options = {}) {
  const r = runAnalysis(input, options);
  let errors = r.errors, warnings = r.warnings, types = new Map();
  if (r.program && options.types !== false) {
    // type checking is part of semantic analysis
    const { checkTypes } = require("./typechecker.js");
    const t = checkTypes(r.program, options);
    const seen = new Set(errors.map((e) => e.message));
    for (const e of t.errors) if (!seen.has(e.message)) errors = errors.concat([{ rule: e.code || "type-error", severity: "error", level: "error", message: e.message, line: e.line, col: e.col }]);
    for (const w of t.warnings) warnings = warnings.concat([{ rule: w.code || "type-warning", severity: "warning", level: "warning", message: w.message, line: w.line, col: w.col }]);
    types = t.types;
  }
  const diagnostics = errors.concat(warnings);
  return { ok: errors.length === 0, errors, warnings, diagnostics, types, program: r.program };
}

function checkSemantics(program, options) { return analyze(program, options); }

class SemanticAnalyzer {
  constructor(options = {}) {
    if (options && (options.kind === "Program" || Array.isArray(options.stmts) || typeof options === "string")) { this.pending = options; options = {}; }
    this.options = options || {};
  }
  analyze(program) { const r = analyze(program !== undefined ? program : this.pending, this.options); this.result = r; this.errors = r.errors; this.warnings = r.warnings; return r; }
  check(program) { return this.analyze(program); }
}

module.exports = { analyze, checkSemantics, check: analyze, analyzeProgram: analyze, runAnalysis, Analyzer, SemanticAnalyzer, patternNames };
