#!/usr/bin/env node
"use strict";
// Arc command line interface.
const fs = require("fs");
const path = require("path");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { createEnv, interpretWithEnv } = require("./interpreter.js");
const { generateIR, printIR } = require("./ir.js");
const { generateJS } = require("./codegen-js.js");
const { generateWAT } = require("./codegen.js");
const { optimize } = require("./optimizer.js");
const { format } = require("./formatter.js");
const { lint, formatDiagnostics } = require("./linter.js");
const { analyze } = require("./semantic.js");
const { checkTypes } = require("./typechecker.js");
const { formatError } = require("./errors.js");
const { VERSION } = require("./version.js");
const { createRuntime } = require("./runtime-core.js");

const USAGE = `Arc ${VERSION} — a programming language designed by AI agents, for AI agents

Usage: arc <command> [options]

Commands:
  run <file>        Run an Arc program
  repl              Start the interactive REPL
  new <name>        Scaffold a new project
  build [dir]       Build a project (compile to JavaScript)
  test [dir]        Run tests
  fmt <file>        Format code (--write to overwrite, --check to verify)
  lint <file>       Lint code (JSON diagnostics; --text for readable output)
  check <file>      Type check and analyze
  parse <file>      Show the AST
  tokens <file>     Show the token stream
  ir <file>         Show the IR as JSON (--text for a listing, --optimize)
  compile <file>    Compile to JavaScript (--target=wat for WebAssembly text, -o <out>)
  builtins          List built-in functions (--modules for stdlib modules)
  version           Print version`;

function makeIO(io) {
  return {
    out: (io && io.out) || ((s) => console.log(s)),
    err: (io && io.err) || ((s) => console.error(s)),
  };
}

function readSource(file, io) {
  if (!file) { io.err("Error: no input file given"); return null; }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { io.err(`Error: file not found: ${file}`); return null; }
  return fs.readFileSync(file, "utf8");
}

function flagValue(args, name, short) {
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a.startsWith(`--${name}=`)) return a.slice(name.length + 3);
    if (a === `--${name}` || (short && a === short)) return args[i + 1];
  }
  return undefined;
}

function positional(args) {
  const out = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-o" || a === "--out" || a === "--output" || a === "--target") { i++; continue; }
    if (a.startsWith("-")) continue;
    out.push(a);
  }
  return out;
}

function runFile(file, io, extraArgs = []) {
  const source = readSource(file, io);
  if (source === null) return 1;
  try {
    const env = createEnv({}, { baseDir: path.dirname(path.resolve(file)), filename: file, output: io.out });
    interpretWithEnv(assertValid(parse(lex(source))), env);
    return 0;
  } catch (e) {
    io.err(formatError(e, source, file));
    return 1;
  }
}

function run(argv = process.argv.slice(2), ioOverride) {
  const io = makeIO(ioOverride);
  const [cmd, ...rest] = argv;
  const args = rest;
  const files = positional(args);
  const file = files[0];
  try {
    switch (cmd) {
      case undefined: case "help": case "--help": case "-h":
        io.out(USAGE);
        return 0;
      case "version": case "--version": case "-v": case "-V":
        io.out(VERSION);
        return 0;
      case "run":
        return runFile(file, io, files.slice(1));
      case "lsp": {
        const { createServer } = require("./lsp.js");
        createServer({ stdio: true }).start();
        return 0;
      }
      case "repl": {
        const { startRepl } = require("./repl.js");
        startRepl();
        return 0;
      }
      case "parse": case "ast": {
        const source = readSource(file, io);
        if (source === null) return 1;
        io.out(JSON.stringify(parse(lex(source)), null, 2));
        return 0;
      }
      case "tokens": case "lex": {
        const source = readSource(file, io);
        if (source === null) return 1;
        io.out(JSON.stringify(lex(source), null, 2));
        return 0;
      }
      case "ir": {
        const source = readSource(file, io);
        if (source === null) return 1;
        let ir = generateIR(parse(lex(source)));
        if (args.includes("--optimize") || args.includes("-O")) ir = optimize(ir);
        io.out(args.includes("--text") || args.includes("--pretty") ? printIR(ir) : JSON.stringify(ir, null, 2));
        return 0;
      }
      case "compile": {
        const source = readSource(file, io);
        if (source === null) return 1;
        const target = flagValue(args, "target") || (args.includes("--wat") ? "wat" : "js");
        let ir = generateIR(parse(lex(source)));
        if (args.includes("--optimize") || args.includes("-O")) ir = optimize(ir);
        const code = target === "wat" || target === "wasm" ? generateWAT(ir) : generateJS(ir, { baseDir: path.dirname(path.resolve(file)) });
        const out = flagValue(args, "out", "-o") || flagValue(args, "output");
        if (out) { fs.writeFileSync(out, code); io.out(`Compiled ${file} -> ${out}`); }
        else io.out(code);
        return 0;
      }
      case "check": {
        const source = readSource(file, io);
        if (source === null) return 1;
        let program;
        try { program = assertValid(parse(lex(source))); } catch (e) { io.err(formatError(e, source, file)); return 1; }
        const sem = analyze(program, { baseDir: path.dirname(path.resolve(file)), allowTopLevelReturn: true, types: false });
        const types = checkTypes(program);
        const errors = sem.errors.concat(types.errors);
        const warnings = sem.warnings.concat(types.warnings);
        for (const e of errors) io.err(`${file}:${e.line}:${e.col}: error: ${e.message}`);
        for (const w of warnings) io.out(`${file}:${w.line}:${w.col}: warning: ${w.message}`);
        if (errors.length) { io.err(`Found ${errors.length} error(s)`); return 1; }
        io.out("OK");
        return 0;
      }
      case "fmt": case "format": {
        const source = readSource(file, io);
        if (source === null) return 1;
        let formatted;
        try { formatted = format(source, { throwOnError: true, trailingNewline: true }); } catch (e) { io.err(formatError(e, source, file)); return 1; }
        if (args.includes("--check")) {
          if (formatted !== source) { io.err(`${file} is not formatted`); return 1; }
          io.out(`${file} is formatted`);
          return 0;
        }
        if (args.includes("--write") || args.includes("-w")) {
          fs.writeFileSync(file, formatted);
          io.out(`Formatted ${file}`);
          return 0;
        }
        io.out(formatted.replace(/\n$/, ""));
        return 0;
      }
      case "lint": {
        const source = readSource(file, io);
        if (source === null) return 1;
        const diags = lint(source, { baseDir: path.dirname(path.resolve(file)) });
        if (args.includes("--text") || args.includes("--pretty")) io.out(diags.length ? formatDiagnostics(diags, file) : "No issues found");
        else io.out(JSON.stringify(diags));
        return 0;
      }
      case "builtins": {
        const rt = createRuntime({});
        if (args.includes("--modules")) {
          for (const m of rt.moduleNames) io.out(`${m}: ${Object.keys(rt.loadModule(m)).join(", ")}`);
        } else {
          io.out(Object.keys(rt.builtins).filter((k) => !/^(crypto|error|regex|net|embed)_/.test(k)).join("\n"));
        }
        return 0;
      }
      case "new": case "init": {
        const { scaffoldProject } = require("./build.js");
        if (!file) { io.err("Error: project name required (arc new <name>)"); return 1; }
        const r = scaffoldProject(file, process.cwd());
        io.out(`Created project '${r.name}' at ${r.path}`);
        for (const f of r.files) io.out(`  ${f}`);
        return 0;
      }
      case "build": {
        const { buildProject } = require("./build.js");
        const r = buildProject(file || process.cwd());
        for (const e of r.errors) io.err(`${e.file}${e.line ? ":" + e.line : ""}: error: ${e.message}`);
        for (const o of r.outputs) io.out(`  ${path.relative(process.cwd(), o) || o}`);
        io.out(r.ok ? `Build succeeded (${r.outputs.length} file(s))` : `Build failed (${r.errors.length} error(s))`);
        return r.ok ? 0 : 1;
      }
      case "test": {
        const { runTests } = require("./build.js");
        const r = runTests(file || "tests", { echo: false });
        for (const t of r.results) {
          for (const line of t.output) io.out(line);
          io.out(`${t.passed ? "PASS" : "FAIL"} ${path.relative(process.cwd(), t.file) || t.file}${t.error ? ": " + t.error : ""}`);
        }
        io.out(`${r.passed} passed, ${r.failed} failed`);
        return r.ok ? 0 : 1;
      }
      default: {
        if (cmd && fs.existsSync(cmd) && fs.statSync(cmd).isFile()) return runFile(cmd, io, args);
        io.err(`Unknown command: ${cmd}\n\n${USAGE}`);
        return 1;
      }
    }
  } catch (e) {
    io.err(formatError(e));
    return 1;
  }
}

if (require.main === module) {
  const code = run();
  if (code) process.exitCode = code;
}

module.exports = { run, USAGE };
