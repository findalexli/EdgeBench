"use strict";
// Arc package manager: arc.toml manifests, semver helpers, dependency resolution.
const { createRuntime } = require("./runtime-core.js");

let RT = null;
function rt() { if (!RT) RT = createRuntime({}); return RT; }

function parseArcToml(source) {
  const data = rt().tomlParse(String(source ?? ""));
  return data;
}

function parseManifest(source) {
  const raw = parseArcToml(source);
  const pkg = raw.package || raw.project || {};
  return {
    raw,
    package: pkg,
    name: pkg.name ?? null,
    version: pkg.version ?? null,
    description: pkg.description ?? null,
    main: pkg.main ?? pkg.entry ?? null,
    dependencies: Object.assign({}, raw.dependencies || {}),
    devDependencies: Object.assign({}, raw["dev-dependencies"] || raw.devDependencies || raw.dev_dependencies || {}),
    scripts: Object.assign({}, raw.scripts || {}),
  };
}

function tomlValue(v) {
  if (typeof v === "string") return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(tomlValue).join(", ")}]`;
  if (v && typeof v === "object") return `{ ${Object.keys(v).map((k) => `${tomlKey(k)} = ${tomlValue(v[k])}`).join(", ")} }`;
  if (v === null || v === undefined) return '""';
  return String(v);
}
function tomlKey(k) { return /^[A-Za-z0-9_-]+$/.test(k) ? k : JSON.stringify(k); }

function stringifyArcToml(obj) {
  const lines = [];
  const simple = Object.keys(obj).filter((k) => !(obj[k] && typeof obj[k] === "object" && !Array.isArray(obj[k])));
  for (const k of simple) lines.push(`${tomlKey(k)} = ${tomlValue(obj[k])}`);
  const emit = (prefix, o) => {
    const keys = Object.keys(o);
    const scalars = keys.filter((k) => !(o[k] && typeof o[k] === "object" && !Array.isArray(o[k])));
    const tables = keys.filter((k) => o[k] && typeof o[k] === "object" && !Array.isArray(o[k]));
    if (lines.length) lines.push("");
    lines.push(`[${prefix}]`);
    for (const k of scalars) lines.push(`${tomlKey(k)} = ${tomlValue(o[k])}`);
    for (const k of tables) emit(`${prefix}.${tomlKey(k)}`, o[k]);
  };
  for (const k of Object.keys(obj)) if (obj[k] && typeof obj[k] === "object" && !Array.isArray(obj[k])) emit(tomlKey(k), obj[k]);
  return lines.join("\n") + "\n";
}

const SEMVER = /^v?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/;

function parseVersion(v) {
  const m = SEMVER.exec(String(v).trim());
  if (!m) return null;
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), prerelease: m[4] || null };
}

function compareVersions(a, b) {
  const x = typeof a === "string" ? parseVersion(a) : a, y = typeof b === "string" ? parseVersion(b) : b;
  if (!x || !y) throw new Error(`Invalid version: ${!x ? a : b}`);
  for (const k of ["major", "minor", "patch"]) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  if (x.prerelease === y.prerelease) return 0;
  if (!x.prerelease) return 1;
  if (!y.prerelease) return -1;
  return x.prerelease < y.prerelease ? -1 : 1;
}

function satisfies(version, range) {
  const v = parseVersion(version);
  if (!v) return false;
  const r = String(range ?? "*").trim();
  if (r === "*" || r === "" || r === "latest") return true;
  if (r.includes("||")) return r.split("||").some((part) => satisfies(version, part));
  const parts = r.split(/\s+/).filter(Boolean);
  if (parts.length > 1 && !/^[<>=~^]+$/.test(parts[0])) return parts.every((p) => satisfies(version, p));
  const m = /^(\^|~|>=|<=|>|<|=)?\s*v?(\d+)(?:\.(\d+|x|\*))?(?:\.(\d+|x|\*))?(?:-([0-9A-Za-z.-]+))?$/.exec(r);
  if (!m) return false;
  const op = m[1] || "";
  const major = Number(m[2]);
  const minorWild = m[3] === undefined || m[3] === "x" || m[3] === "*";
  const patchWild = m[4] === undefined || m[4] === "x" || m[4] === "*";
  const minor = minorWild ? 0 : Number(m[3]);
  const patch = patchWild ? 0 : Number(m[4]);
  const target = { major, minor, patch, prerelease: m[5] || null };
  const cmp = compareVersions(v, target);
  switch (op) {
    case "^":
      if (cmp < 0) return false;
      if (major > 0) return v.major === major;
      if (minor > 0) return v.major === 0 && v.minor === minor;
      return v.major === 0 && v.minor === 0 && (patchWild || v.patch === patch);
    case "~":
      if (cmp < 0) return false;
      return v.major === major && (minorWild || v.minor === minor);
    case ">=": return cmp >= 0;
    case "<=": return cmp <= 0;
    case ">": return cmp > 0;
    case "<": return cmp < 0;
    default:
      if (minorWild) return v.major === major;
      if (patchWild) return v.major === major && v.minor === minor;
      return cmp === 0;
  }
}

function maxSatisfying(versions, range) {
  const ok = versions.filter((v) => satisfies(v, range));
  if (!ok.length) return null;
  return ok.sort(compareVersions)[ok.length - 1];
}

function validateManifest(manifest) {
  const m = typeof manifest === "string" ? parseArcToml(manifest) : manifest;
  const errors = [];
  const pkg = m && (m.package || m);
  if (!pkg || typeof pkg !== "object") errors.push("Missing [package] section");
  else {
    if (!pkg.name) errors.push("Missing package name");
    else if (!/^[a-z0-9][a-z0-9_-]*$/i.test(pkg.name)) errors.push(`Invalid package name '${pkg.name}'`);
    if (!pkg.version) errors.push("Missing package version");
    else if (!parseVersion(pkg.version)) errors.push(`Invalid version '${pkg.version}'`);
  }
  const deps = (m && m.dependencies) || {};
  for (const [name, spec] of Object.entries(deps)) {
    const range = typeof spec === "string" ? spec : spec && spec.version;
    if (range !== undefined && typeof range !== "string") errors.push(`Invalid version range for dependency '${name}'`);
  }
  return { valid: errors.length === 0, ok: errors.length === 0, errors };
}

// registry: { name: { "1.0.0": { dependencies: {...} }, ... } }
function resolveDependencies(manifest, registry = {}) {
  const m = typeof manifest === "string" ? parseArcToml(manifest) : manifest;
  const resolved = {};
  const errors = [];
  const visit = (name, range, path) => {
    if (path.includes(name)) { errors.push(`Circular dependency: ${[...path, name].join(" -> ")}`); return; }
    const versions = registry[name] ? Object.keys(registry[name]) : [];
    if (!versions.length) { errors.push(`Package '${name}' not found`); return; }
    const best = maxSatisfying(versions, typeof range === "string" ? range : (range && range.version) || "*");
    if (!best) { errors.push(`No version of '${name}' satisfies '${range}'`); return; }
    if (resolved[name]) {
      if (resolved[name] !== best && !satisfies(resolved[name], range)) errors.push(`Version conflict for '${name}': ${resolved[name]} vs ${range}`);
      return;
    }
    resolved[name] = best;
    const deps = (registry[name][best] && registry[name][best].dependencies) || {};
    for (const [d, r] of Object.entries(deps)) visit(d, r, [...path, name]);
  };
  for (const [name, range] of Object.entries((m && m.dependencies) || {})) visit(name, range, []);
  return { ok: errors.length === 0, resolved, errors };
}

function addDependency(manifest, name, version = "*") {
  const m = typeof manifest === "string" ? parseArcToml(manifest) : JSON.parse(JSON.stringify(manifest || {}));
  m.dependencies = Object.assign({}, m.dependencies || {}, { [name]: version });
  return m;
}

function removeDependency(manifest, name) {
  const m = typeof manifest === "string" ? parseArcToml(manifest) : JSON.parse(JSON.stringify(manifest || {}));
  if (m.dependencies) delete m.dependencies[name];
  return m;
}

function createManifest(name, version = "0.1.0", extra = {}) {
  return { package: Object.assign({ name, version, description: "", main: "src/main.arc" }, extra), dependencies: {} };
}

function readManifest(dir) {
  const fs = require("fs"), path = require("path");
  const file = path.join(dir || process.cwd(), "arc.toml");
  if (!fs.existsSync(file)) return null;
  return parseArcToml(fs.readFileSync(file, "utf8"));
}

module.exports = {
  parseArcToml, parseToml: parseArcToml, parseManifest, stringifyArcToml, parseVersion, compareVersions, satisfies, maxSatisfying,
  validateManifest, resolveDependencies, addDependency, removeDependency, createManifest, readManifest,
};
