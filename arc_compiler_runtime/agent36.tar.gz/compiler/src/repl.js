"use strict";
// Arc REPL: persistent environment evaluation and an interactive readline loop.
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { createEnv, interpretWithEnv } = require("./interpreter.js");
const { formatError } = require("./errors.js");
const { VERSION } = require("./version.js");

function evaluate(source, env = createEnv()) {
  return interpretWithEnv(assertValid(parse(lex(source))), env);
}

function formatValue(v) {
  const { createRuntime } = require("./runtime-core.js");
  const rt = formatValue.rt || (formatValue.rt = createRuntime({}));
  return rt.repr(v);
}

class Repl {
  constructor(options = {}) {
    this.env = options.env || createEnv({}, options);
    this.buffer = "";
    this.history = [];
  }

  // Evaluate one input; returns { value, output, error, incomplete }
  eval(line) {
    const src = this.buffer ? this.buffer + "\n" + line : line;
    if (needsMore(src)) { this.buffer = src; return { incomplete: true }; }
    this.buffer = "";
    if (!src.trim()) return { value: undefined, output: "" };
    this.history.push(src);
    try {
      const program = assertValid(parse(lex(src)));
      const value = interpretWithEnv(program, this.env);
      const last = program.stmts[program.stmts.length - 1];
      const silent = !last || ["LetStmt", "FnStmt", "TypeStmt", "UseStmt", "ForStmt", "WhileStmt", "DoWhileStmt"].includes(last.kind)
        || (last.kind === "ExprStmt" && last.expr.kind === "CallExpr" && last.expr.callee.kind === "Identifier" && last.expr.callee.name === "print");
      return { value, output: silent || value === null || value === undefined ? (silent ? "" : "nil") : formatValue(value) };
    } catch (e) {
      return { error: e, output: formatError(e, src) };
    }
  }
}

function needsMore(src) {
  let depth = 0, q = null;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (q) { if (c === "\\") { i++; continue; } if (c === q) q = null; continue; }
    if (c === "#") { while (i < src.length && src[i] !== "\n") i++; continue; }
    if (c === '"' || c === "'" || c === "`") q = c;
    else if ("([{".includes(c)) depth++;
    else if (")]}".includes(c)) depth--;
  }
  return depth > 0 || q !== null;
}

function createRepl(options) { return new Repl(options); }

function startRepl(options = {}) {
  const readline = require("readline");
  const input = options.input || process.stdin, output = options.output || process.stdout;
  const repl = new Repl(options);
  const rl = readline.createInterface({ input, output, prompt: "> " });
  output.write(`Arc REPL v${VERSION} — Type expressions to evaluate (:help, :quit)\n`);
  rl.prompt();
  rl.on("line", (line) => {
    const t = line.trim();
    if (t === ":quit" || t === ":exit" || t === ".exit") { rl.close(); return; }
    if (t === ":help") { output.write("Commands: :quit, :help, :reset\n"); rl.prompt(); return; }
    if (t === ":reset") { repl.env = createEnv(); output.write("Environment reset\n"); rl.prompt(); return; }
    const r = repl.eval(line);
    if (r.incomplete) { rl.setPrompt("... "); rl.prompt(); return; }
    if (r.output) output.write(r.output + "\n");
    rl.setPrompt("> ");
    rl.prompt();
  });
  rl.on("close", () => { if (options.onExit) options.onExit(); });
  return rl;
}

module.exports = { evaluate, Repl, createRepl, startRepl, formatValue };
