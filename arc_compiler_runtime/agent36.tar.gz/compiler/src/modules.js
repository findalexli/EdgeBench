"use strict";
// Arc module system: stdlib registry (native modules) and file module resolution.
const { createRuntime } = require("./runtime-core.js");

let RT = null;
function rt() { if (!RT) RT = createRuntime({}); return RT; }

const STDLIB_MODULES = ["math", "strings", "collections", "map", "io", "http", "json", "csv", "test", "result", "time", "regex", "datetime", "os", "error", "net", "crypto", "prompt", "embed", "llm", "store", "yaml", "toml", "html", "path", "env", "log"];

function isStdlibModule(name) { return rt().hasModule(name); }

function loadModule(name) {
  const ns = rt().loadModule(name);
  if (!ns) throw new Error(`Module not found: '${name}'`);
  return ns;
}

// Stdlib modules resolve to their namespace object; file modules to { kind, name, path }.
function resolveModule(name, baseDir) {
  if (isStdlibModule(name)) return loadModule(name);
  const fs = require("fs"), path = require("path");
  const base = baseDir || process.cwd();
  const raw = path.isAbsolute(name) ? name : path.resolve(base, name);
  const candidates = String(name).endsWith(".arc") ? [raw] : [raw + ".arc", path.join(raw, "index.arc"), path.join(raw, "main.arc")];
  for (const c of candidates) { try { if (fs.statSync(c).isFile()) return { kind: "file", name, path: c }; } catch (e) { /* skip */ } }
  throw new Error(`Module not found: '${name}'`);
}

function listModules() { return STDLIB_MODULES.slice(); }

function moduleExports(name) { return Object.keys(loadModule(name)); }

const modules = new Proxy({}, {
  get(_, key) { if (typeof key !== "string") return undefined; return rt().hasModule(key) ? rt().loadModule(key) : undefined; },
  has(_, key) { return typeof key === "string" && rt().hasModule(key); },
  ownKeys() { return STDLIB_MODULES.slice(); },
  getOwnPropertyDescriptor(_, key) { return rt().hasModule(key) ? { enumerable: true, configurable: true, value: rt().loadModule(key) } : undefined; },
});

module.exports = { modules, loadModule, resolveModule, isStdlibModule, listModules, moduleExports, STDLIB_MODULES };
