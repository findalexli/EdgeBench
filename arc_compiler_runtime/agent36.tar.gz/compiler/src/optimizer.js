"use strict";
// Arc optimizer: constant folding and dead-code elimination over the AST behind the IR.
const { generateIR } = require("./ir.js");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");

function clone(node) {
  if (node === null || typeof node !== "object") return node;
  if (Array.isArray(node)) return node.map(clone);
  const out = {};
  for (const k of Object.keys(node)) out[k] = clone(node[k]);
  for (const k of ["raw", "endLine"]) if (node[k] !== undefined) Object.defineProperty(out, k, { value: node[k], enumerable: false, writable: true });
  return out;
}

const isNumLit = (n) => n && (n.kind === "IntLiteral" || n.kind === "FloatLiteral");
const isLit = (n) => n && ["IntLiteral", "FloatLiteral", "StringLiteral", "BoolLiteral", "NilLiteral"].includes(n.kind);
const litValue = (n) => (n.kind === "NilLiteral" ? null : n.value);
function truthy(v) { return !(v === null || v === false || v === 0 || v === ""); }

function mkLit(value, at) {
  const base = { line: at.line, col: at.col };
  if (value === null) return Object.assign({ kind: "NilLiteral" }, base);
  if (typeof value === "boolean") return Object.assign({ kind: "BoolLiteral", value }, base);
  if (typeof value === "string") return Object.assign({ kind: "StringLiteral", value }, base);
  if (typeof value === "number") return Object.assign({ kind: Number.isInteger(value) ? "IntLiteral" : "FloatLiteral", value }, base);
  return null;
}

class Optimizer {
  constructor() { this.stats = { constantsFolded: 0, deadCodeRemoved: 0, branchesSimplified: 0 }; }

  program(p) { p.stmts = this.stmts(p.stmts); return p; }

  stmts(list) {
    const out = [];
    for (const s of list) {
      const r = this.stmt(s);
      if (r === null) { this.stats.deadCodeRemoved++; continue; }
      out.push(r);
      const k = r.kind === "ExprStmt" ? r.expr.kind : r.kind;
      if (k === "ReturnStmt" || k === "BreakStmt" || k === "ContinueStmt") {
        this.stats.deadCodeRemoved += list.length - list.indexOf(s) - 1;
        break;
      }
    }
    return out;
  }

  block(b) { if (b && b.kind === "BlockExpr") b.stmts = this.stmts(b.stmts); return b; }

  stmt(s) {
    switch (s.kind) {
      case "LetStmt": s.value = this.expr(s.value); return s;
      case "FnStmt": if (s.body.kind === "BlockExpr") this.block(s.body); else s.body = this.expr(s.body); s.params.forEach((p) => { if (p.default) p.default = this.expr(p.default); }); return s;
      case "ForStmt": s.iterable = this.expr(s.iterable); this.block(s.body); return s;
      case "WhileStmt":
        s.condition = this.expr(s.condition);
        if (isLit(s.condition) && !truthy(litValue(s.condition))) return null;
        this.block(s.body); return s;
      case "DoWhileStmt": this.block(s.body); if (s.condition) s.condition = this.expr(s.condition); return s;
      case "ReturnStmt": if (s.value) s.value = this.expr(s.value); return s;
      case "ExprStmt": {
        s.expr = this.expr(s.expr);
        if (s.expr.kind === "IfExpr" && isLit(s.expr.condition)) return s; // handled in expr
        return s;
      }
    }
    return s;
  }

  expr(e) {
    if (!e || typeof e !== "object") return e;
    switch (e.kind) {
      case "BinaryExpr": {
        e.left = this.expr(e.left); e.right = this.expr(e.right);
        const folded = this.foldBinary(e);
        if (folded) { this.stats.constantsFolded++; return folded; }
        return e;
      }
      case "UnaryExpr": {
        e.operand = this.expr(e.operand);
        if (isLit(e.operand)) {
          const v = litValue(e.operand);
          if (e.op === "not") { this.stats.constantsFolded++; return mkLit(!truthy(v), e); }
          if (e.op === "-" && typeof v === "number") { this.stats.constantsFolded++; return mkLit(-v, e); }
        }
        return e;
      }
      case "StringInterp": {
        e.parts = e.parts.map((p) => (typeof p === "string" ? p : this.expr(p)));
        if (e.parts.every((p) => typeof p === "string" || (isLit(p) && p.kind !== "FloatLiteral"))) {
          this.stats.constantsFolded++;
          return mkLit(e.parts.map((p) => (typeof p === "string" ? p : p.kind === "NilLiteral" ? "nil" : String(p.value))).join(""), e);
        }
        return e;
      }
      case "IfExpr": {
        e.condition = this.expr(e.condition);
        if (e.then.kind === "BlockExpr") this.block(e.then); else e.then = this.expr(e.then);
        if (e.else_) { if (e.else_.kind === "BlockExpr") this.block(e.else_); else e.else_ = this.expr(e.else_); }
        if (isLit(e.condition)) {
          this.stats.branchesSimplified++;
          if (truthy(litValue(e.condition))) return e.then;
          return e.else_ || mkLit(null, e);
        }
        return e;
      }
      case "RangeExpr": e.start = this.expr(e.start); e.end = this.expr(e.end); return e;
      case "CallExpr": e.callee = this.expr(e.callee); e.args = e.args.map((a) => this.expr(a)); return e;
      case "SpreadExpr": e.expr = this.expr(e.expr); return e;
      case "MemberExpr": e.object = this.expr(e.object); return e;
      case "IndexExpr": e.object = this.expr(e.object); e.index = this.expr(e.index); return e;
      case "PipelineExpr": e.left = this.expr(e.left); e.right = this.expr(e.right); return e;
      case "MatchExpr": e.subject = this.expr(e.subject); e.arms.forEach((a) => { if (a.guard) a.guard = this.expr(a.guard); if (a.body.kind === "BlockExpr") this.block(a.body); else a.body = this.expr(a.body); }); return e;
      case "LambdaExpr": if (e.body.kind === "BlockExpr") this.block(e.body); else e.body = this.expr(e.body); return e;
      case "ListLiteral": e.elements = e.elements.map((x) => this.expr(x)); return e;
      case "MapLiteral": e.entries.forEach((en) => { if (en.spread) en.spread = this.expr(en.spread); else en.value = this.expr(en.value); }); return e;
      case "BlockExpr": return this.block(e);
      case "TryExpr": this.block(e.body); if (e.catchBody) this.block(e.catchBody); if (e.finallyBody) this.block(e.finallyBody); return e;
      case "AssignExpr": e.value = this.expr(e.value); return e;
      case "AwaitExpr": case "PropagateExpr": e.expr = this.expr(e.expr); return e;
    }
    return e;
  }

  foldBinary(e) {
    const l = e.left, r = e.right;
    if (e.op === "and" || e.op === "or") {
      if (!isLit(l)) return null;
      const t = truthy(litValue(l));
      if (e.op === "and") return t ? r : l;
      return t ? l : r;
    }
    if (e.op === "??" && isLit(l)) return litValue(l) === null ? r : l;
    if (!isLit(l) || !isLit(r)) return null;
    const a = litValue(l), b = litValue(r);
    const num = typeof a === "number" && typeof b === "number";
    switch (e.op) {
      case "+": if (num) return mkLit(a + b, e); if (typeof a === "string" && typeof b === "string") return mkLit(a + b, e); return null;
      case "-": return num ? mkLit(a - b, e) : null;
      case "*":
        if (num) return mkLit(a * b, e);
        if (typeof a === "string" && typeof b === "number" && b >= 0 && b < 1000) return mkLit(a.repeat(Math.floor(b)), e);
        return null;
      case "/": return num && b !== 0 ? mkLit(a / b, e) : null;
      case "%": return num && b !== 0 ? mkLit(a % b, e) : null;
      case "**": return num ? mkLit(Math.pow(a, b), e) : null;
      case "++": return typeof a === "string" && typeof b === "string" ? mkLit(a + b, e) : null;
      case "==": return mkLit(a === b, e);
      case "!=": return mkLit(a !== b, e);
      case "<": case ">": case "<=": case ">=": {
        if (!(num || (typeof a === "string" && typeof b === "string"))) return null;
        const res = e.op === "<" ? a < b : e.op === ">" ? a > b : e.op === "<=" ? a <= b : a >= b;
        return mkLit(res, e);
      }
    }
    return null;
  }
}

function toAstRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (input && input.kind === "Program") return input;
  if (input && input.ast) return input.ast;
  if (input && Array.isArray(input.stmts)) return input;
  return { kind: "Program", stmts: [] };
}
function toAst(input) { return assertValid(toAstRaw(input)); }

function optimizeAST(ast) {
  const o = new Optimizer();
  const out = o.program(clone(toAst(ast)));
  return { ast: out, stats: o.stats };
}

function optimizeIR(ir) {
  const { ast, stats } = optimizeAST(ir);
  const out = generateIR(ast);
  out.optimized = true;
  out.stats = stats;
  return out;
}

function optimize(ir) { return optimizeIR(ir); }
function constantFold(ast) { return optimizeAST(ast).ast; }

module.exports = { optimizeIR, optimize, optimizeAST, constantFold, Optimizer };
