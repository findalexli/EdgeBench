"use strict";
// Arc tree-walking interpreter (AST nodes are compiled to JS closures once, then run).
const { createRuntime } = require("./runtime-core.js");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { ArcRuntimeError } = require("./errors.js");

class ReturnSignal { constructor(value) { this.value = value; } }
class BreakSignal {}
class ContinueSignal {}
const BREAK = new BreakSignal();
const CONTINUE = new ContinueSignal();
const isSignal = (e) => e instanceof ReturnSignal || e === BREAK || e === CONTINUE;

class Scope {
  constructor(parent) { this.vars = new Map(); this.parent = parent; }
  lookup(name) {
    let s = this;
    while (s) { const b = s.vars.get(name); if (b !== undefined) return b; s = s.parent; }
    return undefined;
  }
  declare(name, value, mutable, type) {
    const b = { v: value === undefined ? null : value, m: !!mutable };
    if (type) b.t = type;
    this.vars.set(name, b);
  }
  has(name) { return this.lookup(name) !== undefined; }
}

function rtError(msg, node) {
  const loc = node && node.line ? { line: node.line, col: node.col } : undefined;
  return new ArcRuntimeError(msg, loc);
}

function createEnv(seed = {}, options = {}) {
  if (seed && (seed.output || seed.tools || seed.baseDir || seed.httpHandler || seed.security) && !options.__noSeedOptions && seed.vars === undefined) {
    // allow createEnv({ output, tools, baseDir }) style options
    const looksLikeOptions = Object.keys(seed).every((k) => ["output", "errorOutput", "tools", "baseDir", "httpHandler", "security", "maxDepth", "filename", "vars"].includes(k));
    if (looksLikeOptions) { options = seed; seed = seed.vars || {}; }
  }
  const rt = createRuntime(options);
  const builtinScope = new Scope(null);
  for (const [k, v] of Object.entries(rt.builtins)) builtinScope.declare(k, v, false);
  const globals = new Scope(builtinScope);
  for (const [k, v] of Object.entries(seed || {})) globals.declare(k, v, true);
  const env = {
    rt,
    scope: globals,
    builtinScope,
    options,
    baseDir: options.baseDir || null,
    filename: options.filename || null,
    moduleCache: options.moduleCache || new Map(),
    depth: 0,
    maxDepth: options.maxDepth || 100000,
    get vars() { const o = {}; for (const [k, b] of globals.vars) o[k] = b.v; return o; },
  };
  return env;
}

// ---------------- compiler: AST -> closures ----------------
function compileProgram(program, env) {
  const c = new Compiler(env);
  return c.compileBlockBody(program.stmts || []);
}

class Compiler {
  constructor(env) { this.env = env; this.rt = env.rt; }

  compileBlockBody(stmts) {
    const fnDecls = [];
    const compiled = [];
    for (const s of stmts) {
      if (s.kind === "TypeStmt") fnDecls.unshift(this.compileTypeDecl(s));
    }
    for (const s of stmts) {
      if (s.kind === "FnStmt") fnDecls.push(this.compileFnDecl(s));
      compiled.push(this.compileStmt(s));
    }
    const n = compiled.length;
    if (n === 0 && fnDecls.length === 0) return () => null;
    if (n === 1 && fnDecls.length === 0) return compiled[0];
    if (fnDecls.length === 0) {
      return (scope) => {
        let v = null;
        for (let i = 0; i < n; i++) v = compiled[i](scope);
        return v;
      };
    }
    return (scope) => {
      for (let i = 0; i < fnDecls.length; i++) fnDecls[i](scope);
      let v = null;
      for (let i = 0; i < n; i++) v = compiled[i](scope);
      return v;
    };
  }

  compileBlock(block) {
    const body = this.compileBlockBody(block.stmts);
    // blocks that declare nothing can share the enclosing scope
    if (!declaresNames(block.stmts)) return body;
    return (scope) => body(new Scope(scope));
  }

  // Runtime type descriptors: type AST with `where` predicates compiled to functions.
  compileTypeDesc(t) {
    if (!t) return null;
    let dynamic = false;
    const self = this;
    const build = (n) => {
      if (n === null || typeof n !== "object") return () => n;
      if (Array.isArray(n)) { const parts = n.map(build); return (scope) => parts.map((p) => p(scope)); }
      if (n.kind === "ConstrainedType" && n.predicate) {
        dynamic = true;
        const base = build(n.base);
        const params = [n.param || "x", "value", "it", "self"].map((name) => ({ kind: "Param", name, pattern: null, rest: false, default: null, typeAnn: null }));
        const make = self.compileFunction({ kind: "LambdaExpr", params, body: n.predicate }, "where");
        let text = "";
        try { text = new (require("./formatter.js").Printer)([]).expr(n.predicate, 0, 0); } catch (e) { text = ""; }
        return (scope) => ({ kind: "ConstrainedType", base: base(scope), regex: null, test: make(scope), text });
      }
      const keys = Object.keys(n).filter((k) => k !== "line" && k !== "col" && k !== "predicate");
      const parts = keys.map((k) => [k, build(n[k])]);
      const isField = n.name !== undefined && n.type !== undefined && n.kind === undefined;
      return (scope) => {
        const o = {};
        for (const [k, f] of parts) o[k] = f(scope);
        if (isField && n.default) o.hasDefault = true;
        return o;
      };
    };
    const f = build(t);
    if (!dynamic) { const fixed = f(null); return () => fixed; }
    return f;
  }

  compileTypeDecl(s) {
    const desc = this.compileTypeDesc(s.def);
    const rt = this.rt;
    return (scope) => { rt.declareType(s.name, desc(scope)); };
  }

  // FnStmt hoisting: declares the function in the block scope before statements run.
  compileFnDecl(s) {
    const make = this.compileFunction(s, s.name);
    return (scope) => { scope.declare(s.name, make(scope), false); };
  }

  compileStmt(s) {
    switch (s.kind) {
      case "LetStmt": return this.compileLet(s);
      case "FnStmt": {
        const make = this.compileFunction(s, s.name);
        return (scope) => { const f = make(scope); scope.declare(s.name, f, false); return f; };
      }
      case "TypeStmt": return this.compileTypeStmt(s);
      case "UseStmt": return this.compileUse(s);
      case "ForStmt": return this.compileFor(s);
      case "WhileStmt": return this.compileWhile(s);
      case "DoWhileStmt": return this.compileDoWhile(s);
      case "ReturnStmt": case "BreakStmt": case "ContinueStmt": return this.compileExpr(s);
      case "ExprStmt": return this.compileExpr(s.expr);
      default: return this.compileExpr(s);
    }
  }

  compileLet(s) {
    const value = this.compileExpr(s.value);
    const mutable = s.mutable;
    const rt = this.rt;
    if (s.pattern.kind === "BindingPattern") {
      const name = s.pattern.name;
      if (s.typeAnn) {
        const desc = this.compileTypeDesc(s.typeAnn);
        const what = `'${name}'`;
        return (scope) => {
          const v = value(scope);
          const d = desc(scope);
          try { rt.assertType(d, v, what); } catch (e) { throw locate(e, s, rt, true); }
          scope.declare(name, v, mutable, d);
          return v === undefined ? null : v;
        };
      }
      return (scope) => { const v = value(scope); scope.declare(name, v, mutable); return v === undefined ? null : v; };
    }
    const pattern = s.pattern;
    const annDesc = s.typeAnn ? this.compileTypeDesc(s.typeAnn) : null;
    return (scope) => {
      const v = value(scope);
      if (annDesc) { try { rt.assertType(annDesc(scope), v, "destructured value"); } catch (e) { throw locate(e, s, rt, true); } }
      let b;
      try { b = rt.destructure(pattern, v); } catch (e) { throw rtError(e.message, s); }
      for (const k of Object.keys(b)) scope.declare(k, b[k], mutable);
      return v === undefined ? null : v;
    };
  }

  compileTypeStmt(s) {
    const rt = this.rt;
    const variants = [];
    const nullary = [];
    const collect = (t, inUnion) => {
      if (!t) return;
      if (t.kind === "UnionType") t.types.forEach((x) => collect(x, true));
      else if (t.kind === "VariantType") variants.push(t);
      else if (inUnion && isNullaryVariant(t)) nullary.push(t.name);
    };
    collect(s.def, false);
    return (scope) => {
      for (const v of variants) {
        if (["Ok", "Err", "Some", "None"].includes(v.name)) continue;
        if (!scope.vars.has(v.name)) scope.declare(v.name, rt.makeVariant(v.name, v.fields.length), false);
      }
      for (const n of nullary) if (!scope.vars.has(n) && !scope.lookup(n)) scope.declare(n, { __tag: n, __values: [] }, false);
      return null;
    };
  }

  compileUse(s) {
    const env = this.env;
    return (scope) => {
      const ns = loadModuleFor(env, s.path, s);
      if (s.imports === null) {
        scope.declare(s.alias || s.name, ns, false);
        // also expose module members directly when they don't shadow anything
        for (const k of Object.keys(ns)) if (!k.startsWith("_") && scope.lookup(k) === undefined) scope.declare(k, ns[k], false);
      }
      else if (s.imports === "*") { for (const k of Object.keys(ns)) scope.declare(k, ns[k], false); }
      else {
        for (const name of s.imports) {
          if (!Object.prototype.hasOwnProperty.call(ns, name)) throw rtError(`Module '${s.path}' has no export '${name}'`, s);
          scope.declare(name, ns[name], false);
        }
        if (scope.lookup(s.alias || s.name) === undefined) scope.declare(s.alias || s.name, ns, false);
      }
      return null;
    };
  }

  compileFor(s) {
    const iterable = this.compileExpr(s.iterable);
    const body = this.compileBlockBody(s.body.stmts);
    const rt = this.rt;
    const pattern = s.pattern;
    const simple = pattern.kind === "BindingPattern" ? pattern.name : null;
    return (scope) => {
      const items = rt.iterate(iterable(scope));
      for (let i = 0; i < items.length; i++) {
        const inner = new Scope(scope);
        if (simple !== null) inner.vars.set(simple, { v: items[i] === undefined ? null : items[i], m: true });
        else { const b = rt.destructure(pattern, items[i]); for (const k in b) inner.declare(k, b[k], true); }
        try { body(inner); }
        catch (e) {
          if (e === BREAK) break;
          if (e === CONTINUE) continue;
          throw e;
        }
      }
      return null;
    };
  }

  compileWhile(s) {
    const cond = this.compileExpr(s.condition);
    const body = this.compileBlockBody(s.body.stmts);
    const declares = declaresNames(s.body.stmts);
    const rt = this.rt;
    return (scope) => {
      const fresh = declares;
      while (rt.truthy(cond(scope))) {
        try { body(fresh ? new Scope(scope) : scope); }
        catch (e) {
          if (e === BREAK) break;
          if (e === CONTINUE) continue;
          throw e;
        }
      }
      return null;
    };
  }

  compileDoWhile(s) {
    const body = this.compileBlockBody(s.body.stmts);
    const cond = s.condition ? this.compileExpr(s.condition) : null;
    const until = s.until;
    const rt = this.rt;
    return (scope) => {
      while (true) {
        let brk = false;
        try { body(new Scope(scope)); }
        catch (e) {
          if (e === BREAK) brk = true;
          else if (e !== CONTINUE) throw e;
        }
        if (brk || !cond) break;
        const c = rt.truthy(cond(scope));
        if (until ? c : !c) break;
      }
      return null;
    };
  }

  compileFunction(node, name) {
    const params = node.params || [];
    const rt = this.rt;
    const env = this.env;
    const fname = name || node.name || "anonymous";
    const paramInfo = params.map((p, i) => ({
      name: p.name,
      pattern: p.pattern,
      rest: p.rest,
      def: p.default ? this.compileExpr(p.default) : null,
      type: p.typeAnn ? this.compileTypeDesc(p.typeAnn) : null,
      what: `parameter '${p.name || "#" + (i + 1)}' of '${fname}'`,
    }));
    const isExpr = node.body.kind !== "BlockExpr";
    const body = isExpr ? this.compileExpr(node.body) : this.compileBlockBody(node.body.stmts);
    const arity = params.filter((p) => !p.rest).length;
    const variadic = params.some((p) => p.rest || p.default);
    const retType = node.returnType ? this.compileTypeDesc(node.returnType) : null;
    const retWhat = `return value of '${fname}'`;
    const needsCatch = containsSignal(node.body, false);
    const bind = (scope, args, closure) => {
      for (let i = 0; i < paramInfo.length; i++) {
        const p = paramInfo[i];
        let v;
        if (p.rest) v = Array.prototype.slice.call(args, i);
        else {
          v = args[i];
          if (v === undefined) v = p.def ? p.def(scope) : null;
        }
        if (p.type) { const d = p.type(closure); try { rt.assertType(d, v, p.what); } catch (e) { throw locate(e, node, rt, true); } }
        if (p.pattern) { const b = rt.destructure(p.pattern, v); for (const k in b) scope.declare(k, b[k], true); }
        else scope.vars.set(p.name, p.type ? { v: v === undefined ? null : v, m: true, t: p.type(closure) } : { v: v === undefined ? null : v, m: true });
      }
    };
    const run = (scope) => {
      try {
        const r = body(scope);
        return r === undefined ? null : r;
      } catch (e) {
        if (e instanceof ReturnSignal) return e.value;
        if (e === BREAK || e === CONTINUE) throw new ArcRuntimeError(`'${e === BREAK ? "break" : "continue"}' outside of loop`);
        throw e;
      }
    };
    return (closure) => {
      let f;
      if (!retType && !needsCatch) {
        f = function () {
          const scope = new Scope(closure);
          bind(scope, arguments, closure);
          const r = body(scope);
          return r === undefined ? null : r;
        };
      } else if (!retType) {
        f = function () {
          const scope = new Scope(closure);
          bind(scope, arguments, closure);
          try {
            const r = body(scope);
            return r === undefined ? null : r;
          } catch (e) {
            if (e instanceof ReturnSignal) return e.value;
            if (e === BREAK || e === CONTINUE) throw new ArcRuntimeError(`'${e === BREAK ? "break" : "continue"}' outside of loop`);
            throw e;
          }
        };
      } else {
        f = function () {
          const scope = new Scope(closure);
          bind(scope, arguments, closure);
          const r = needsCatch ? run(scope) : nil(body(scope));
          try { rt.assertType(retType(closure), r, retWhat); } catch (e) { throw locate(e, node, rt, true); }
          return r;
        };
      }
      f.arcName = fname;
      f.__arity = arity;
      if (variadic) f.__variadic = true;
      return f;
    };
  }

  compileArgs(args) {
    const hasSpread = args.some((a) => a.kind === "SpreadExpr");
    const rt = this.rt;
    if (!hasSpread) {
      const cs = args.map((a) => this.compileExpr(a));
      const n = cs.length;
      if (n === 0) return () => [];
      if (n === 1) { const a0 = cs[0]; return (scope) => [a0(scope)]; }
      if (n === 2) { const a0 = cs[0], a1 = cs[1]; return (scope) => [a0(scope), a1(scope)]; }
      return (scope) => { const out = new Array(n); for (let i = 0; i < n; i++) out[i] = cs[i](scope); return out; };
    }
    const cs = args.map((a) => (a.kind === "SpreadExpr" ? { spread: true, f: this.compileExpr(a.expr) } : { spread: false, f: this.compileExpr(a) }));
    return (scope) => {
      const out = [];
      for (const c of cs) { if (c.spread) out.push(...rt.iterate(c.f(scope))); else out.push(c.f(scope)); }
      return out;
    };
  }

  compileExpr(e) {
    const rt = this.rt;
    switch (e.kind) {
      case "IntLiteral": case "FloatLiteral": case "StringLiteral": case "BoolLiteral": { const v = e.value; return () => v; }
      case "NilLiteral": case "EllipsisExpr": return () => null;
      case "RegexLiteral": { const v = e.pattern; return () => v; }
      case "StringInterp": {
        const parts = e.parts.map((p) => (typeof p === "string" ? p : this.compileExpr(p)));
        return (scope) => {
          let s = "";
          for (const p of parts) s += typeof p === "string" ? p : rt.toStr(p(scope));
          return s;
        };
      }
      case "Identifier": {
        const name = e.name;
        return (scope) => {
          let s = scope;
          while (s) { const b = s.vars.get(name); if (b !== undefined) return b.v; s = s.parent; }
          throw rtError(`Undefined variable '${name}'`, e);
        };
      }
      case "BinaryExpr": return this.compileBinary(e);
      case "UnaryExpr": {
        const operand = this.compileExpr(e.operand);
        if (e.op === "-") return (scope) => rt.neg(operand(scope));
        return (scope) => !rt.truthy(operand(scope));
      }
      case "RangeExpr": {
        const a = this.compileExpr(e.start), b = this.compileExpr(e.end), inc = e.inclusive;
        return (scope) => rt.range(a(scope), b(scope), inc);
      }
      case "CallExpr": return this.compileCall(e);
      case "MemberExpr": {
        const obj = this.compileExpr(e.object), prop = e.property, opt = e.optional;
        return (scope) => {
          try { return rt.getMember(obj(scope), prop, opt); }
          catch (err) { if (err instanceof rt.ArcRuntimeError && !err.loc) { err.loc = { line: e.line, col: e.col }; err.line = e.line; err.col = e.col; } throw err; }
        };
      }
      case "IndexExpr": {
        const obj = this.compileExpr(e.object), idx = this.compileExpr(e.index), opt = e.optional;
        return (scope) => rt.getIndex(obj(scope), idx(scope), opt);
      }
      case "SliceExpr": {
        const obj = this.compileExpr(e.object);
        const st = e.start ? this.compileExpr(e.start) : () => null;
        const en = e.end ? this.compileExpr(e.end) : () => null;
        if (e.inclusive) return (scope) => { const end = en(scope); return rt.slice(obj(scope), st(scope), end === null ? null : rt.add(end, 1)); };
        return (scope) => rt.slice(obj(scope), st(scope), en(scope));
      }
      case "PipelineExpr": return this.compilePipeline(e);
      case "IfExpr": {
        const cond = this.compileExpr(e.condition);
        const then = this.compileBranch(e.then);
        const els = e.else_ ? this.compileBranch(e.else_) : null;
        return (scope) => (rt.truthy(cond(scope)) ? then(scope) : els ? els(scope) : null);
      }
      case "MatchExpr": return this.compileMatch(e);
      case "LambdaExpr": {
        const make = this.compileFunction(e, null);
        return (scope) => make(scope);
      }
      case "ListLiteral": {
        const hasSpread = e.elements.some((x) => x.kind === "SpreadExpr");
        if (!hasSpread) {
          const cs = e.elements.map((x) => this.compileExpr(x));
          return (scope) => cs.map((c) => { const v = c(scope); return v === undefined ? null : v; });
        }
        return this.compileArgs(e.elements);
      }
      case "ListComprehension": return this.compileComprehension(e, false);
      case "MapComprehension": return this.compileComprehension(e, true);
      case "MapLiteral": {
        const entries = e.entries.map((en) => {
          if (en.spread) return { spread: this.compileExpr(en.spread) };
          if (en.computed) return { computed: this.compileExpr(en.computed), value: this.compileExpr(en.value) };
          return { key: en.key, value: this.compileExpr(en.value) };
        });
        return (scope) => {
          const o = {};
          for (const en of entries) {
            if (en.spread) {
              const v = en.spread(scope);
              if (v === null || v === undefined) continue;
              if (typeof v !== "object") throw rtError("Cannot spread " + rt.typeOf(v) + " into a map", e);
              for (const k of Object.keys(v)) rt.defineKey(o, k, v[k]);
            } else if (en.computed) rt.defineKey(o, rt.toStr(en.computed(scope)), en.value(scope));
            else rt.defineKey(o, en.key, en.value(scope));
          }
          return o;
        };
      }
      case "BlockExpr": return this.compileBlock(e);
      case "TryExpr": return this.compileTry(e);
      case "ToolCallExpr": return this.compileToolCall(e);
      case "FetchExpr": {
        const calls = e.calls.map((c) => this.compileExpr(c));
        return (scope) => calls.map((c) => c(scope));
      }
      case "AsyncExpr": return this.compileBlock(e.body);
      case "AwaitExpr": return this.compileExpr(e.expr);
      case "PropagateExpr": {
        const inner = this.compileExpr(e.expr);
        return (scope) => {
          const r = rt.propagate(inner(scope));
          if (Object.prototype.hasOwnProperty.call(r, "ret")) throw new ReturnSignal(r.ret);
          return r.value;
        };
      }
      case "AssignExpr": return this.compileAssign(e);
      case "ReturnStmt": {
        const v = e.value ? this.compileExpr(e.value) : null;
        return (scope) => { throw new ReturnSignal(v ? v(scope) : null); };
      }
      case "BreakStmt": return () => { throw BREAK; };
      case "ContinueStmt": return () => { throw CONTINUE; };
      case "SpreadExpr": throw rtError("Spread '...' is only allowed in lists, maps and call arguments", e);
      case "ExprStmt": return this.compileExpr(e.expr);
      case "LetStmt": case "FnStmt": case "ForStmt": case "WhileStmt": case "DoWhileStmt": case "UseStmt": case "TypeStmt":
        return this.compileStmt(e);
    }
    throw rtError(`Cannot evaluate node of kind ${e.kind}`, e);
  }

  compileBranch(b) {
    if (b.kind === "BlockExpr") return this.compileBlock(b);
    return this.compileExpr(b);
  }

  compileBinary(e) {
    const rt = this.rt;
    const l = this.compileExpr(e.left), r = this.compileExpr(e.right);
    switch (e.op) {
      case "and": return (scope) => { const a = l(scope); return rt.truthy(a) ? r(scope) : a; };
      case "or": return (scope) => { const a = l(scope); return rt.truthy(a) ? a : r(scope); };
      case "??": return (scope) => { const a = l(scope); return a === null || a === undefined ? r(scope) : a; };
      case "+": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a + b : wrap(() => rt.add(a, b)); };
      case "-": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a - b : wrap(() => rt.sub(a, b)); };
      case "*": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a * b : wrap(() => rt.mul(a, b)); };
      case "==": return (scope) => rt.eq(l(scope), r(scope));
      case "!=": return (scope) => !rt.eq(l(scope), r(scope));
      case "<": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a < b : wrap(() => rt.lt(a, b)); };
      case ">": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a > b : wrap(() => rt.gt(a, b)); };
      case "<=": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a <= b : wrap(() => rt.le(a, b)); };
      case ">=": return (scope) => { const a = l(scope), b = r(scope); return typeof a === "number" && typeof b === "number" ? a >= b : wrap(() => rt.ge(a, b)); };
    }
    const op = e.op;
    return (scope) => { const a = l(scope), b = r(scope); return wrap(() => rt.binary(op, a, b)); };
    function wrap(f) {
      try { return f(); }
      catch (err) { if (err instanceof rt.ArcRuntimeError && !err.loc) { err.loc = { line: e.line, col: e.col }; err.line = e.line; err.col = e.col; } throw err; }
    }
  }

  compileCall(e) {
    const rt = this.rt;
    const args = this.compileArgs(e.args);
    const callee = e.callee;
    if (callee.kind === "MemberExpr") {
      const obj = this.compileExpr(callee.object), key = callee.property, opt = callee.optional || e.optional;
      return (scope) => {
        const o = obj(scope);
        if (opt && (o === null || o === undefined)) return null;
        try { const r = rt.callMethod(o, key, args(scope), opt); return r === undefined ? null : r; }
        catch (err) { throw locate(err, e, rt); }
      };
    }
    if (callee.kind === "Identifier") {
      const name = callee.name;
      return (scope) => {
        let s = scope, f;
        while (s) { const b = s.vars.get(name); if (b !== undefined) { f = b.v; break; } s = s.parent; }
        if (s === null) throw rtError(`Undefined function '${name}'`, callee);
        if (typeof f !== "function") {
          if (e.optional && (f === null || f === undefined)) return null;
          throw rtError(`'${name}' is not a function`, callee);
        }
        const a = args(scope);
        try { const r = f(...a); return r === undefined ? null : r; }
        catch (err) { throw locate(err, e, rt); }
      };
    }
    const fexpr = this.compileExpr(callee);
    return (scope) => {
      const f = fexpr(scope);
      if (e.optional && (f === null || f === undefined)) return null;
      if (typeof f !== "function") throw rtError(`${rt.toStr(f)} is not a function`, e);
      const r = f(...args(scope));
      return r === undefined ? null : r;
    };
  }

  compilePipeline(e) {
    const rt = this.rt;
    const left = this.compileExpr(e.left);
    const right = e.right;
    if (right.kind === "CallExpr") {
      const args = this.compileArgs(right.args);
      if (right.callee.kind === "MemberExpr") {
        const obj = this.compileExpr(right.callee.object), key = right.callee.property;
        return (scope) => { const l = left(scope); const o = obj(scope); return rt.callMethod(o, key, [l, ...args(scope)]); };
      }
      const fexpr = this.compileExpr(right.callee);
      return (scope) => {
        const l = left(scope);
        const f = fexpr(scope);
        if (typeof f !== "function") throw rtError(`Pipeline target is not a function (got ${rt.typeOf(f)})`, right);
        const r = f(l, ...args(scope));
        return r === undefined ? null : r;
      };
    }
    const fexpr = this.compileExpr(right);
    return (scope) => {
      const l = left(scope);
      const f = fexpr(scope);
      if (typeof f !== "function") throw rtError(`Pipeline target is not a function (got ${rt.typeOf(f)})`, right);
      const r = f(l);
      return r === undefined ? null : r;
    };
  }

  compileMatch(e) {
    const rt = this.rt;
    const subject = this.compileExpr(e.subject);
    const arms = e.arms.map((a) => ({
      pattern: a.pattern,
      guard: a.guard ? this.compileExpr(a.guard) : null,
      body: this.compileBranch(a.body),
    }));
    return (scope) => {
      const v = subject(scope);
      for (const arm of arms) {
        const b = {};
        if (!rt.matchPattern(arm.pattern, v, b)) continue;
        const inner = new Scope(scope);
        for (const k in b) inner.vars.set(k, { v: b[k], m: false });
        if (arm.guard && !rt.truthy(arm.guard(inner))) continue;
        return arm.body(inner);
      }
      return null;
    };
  }

  compileComprehension(e, isMap) {
    const rt = this.rt;
    const clauses = e.clauses.map((c) => ({
      pattern: c.pattern,
      iterable: this.compileExpr(c.iterable),
      conditions: c.conditions.map((x) => this.compileExpr(x)),
    }));
    const valueF = this.compileExpr(isMap ? e.value : e.expr);
    const keyF = isMap ? this.compileExpr(e.key) : null;
    return (scope) => {
      const out = isMap ? {} : [];
      const loop = (i, sc) => {
        if (i === clauses.length) {
          if (isMap) rt.defineKey(out, rt.toStr(keyF(sc)), valueF(sc));
          else { const v = valueF(sc); out.push(v === undefined ? null : v); }
          return;
        }
        const c = clauses[i];
        for (const item of rt.iterate(c.iterable(sc))) {
          const inner = new Scope(sc);
          const b = rt.destructure(c.pattern, item);
          for (const k in b) inner.declare(k, b[k], false);
          let ok = true;
          for (const cond of c.conditions) if (!rt.truthy(cond(inner))) { ok = false; break; }
          if (ok) loop(i + 1, inner);
        }
      };
      loop(0, scope);
      return out;
    };
  }

  compileTry(e) {
    const rt = this.rt;
    const body = this.compileBlock(e.body);
    const handler = e.catchBody ? this.compileBlockBody(e.catchBody.stmts) : null;
    const finalizer = e.finallyBody ? this.compileBlock(e.finallyBody) : null;
    const param = e.catchParam;
    return (scope) => {
      try {
        return body(scope);
      } catch (err) {
        if (isSignal(err) || !handler) throw err;
        const inner = new Scope(scope);
        if (param) inner.declare(param, rt.errorMessage(err), false);
        return handler(inner);
      } finally {
        if (finalizer) finalizer(scope);
      }
    };
  }

  compileToolCall(e) {
    const rt = this.rt;
    if (e.method) {
      const url = this.compileExpr(e.url);
      const body = e.body ? this.compileExpr(e.body) : null;
      const method = e.method;
      return (scope) => rt.toolCall(method, rt.toStr(url(scope)), body ? body(scope) : null);
    }
    const args = this.compileArgs(e.args);
    const name = e.name;
    return (scope) => {
      const a = args(scope);
      if (rt.tools && typeof rt.tools[name] === "function") return rt.customTool(name, a);
      const b = scope.lookup(name);
      if (b && typeof b.v === "function") return b.v(...a);
      return rt.customTool(name, a);
    };
  }

  compileAssign(e) {
    const rt = this.rt;
    const value = this.compileExpr(e.value);
    const op = e.op;
    const binop = op === "=" ? null : op.slice(0, -1);
    const t = e.target;
    if (t.kind === "Identifier") {
      const name = t.name;
      return (scope) => {
        const b = scope.lookup(name);
        if (!b) throw rtError(`Undefined variable '${name}'`, t);
        if (!b.m) throw rtError(`Cannot reassign immutable variable '${name}' (declare it with 'let mut')`, t);
        let v = value(scope);
        if (binop) v = rt.binary(binop, b.v, v);
        if (b.t) { try { rt.assertType(b.t, v, `'${name}'`); } catch (err) { throw locate(err, e, rt, true); } }
        b.v = v === undefined ? null : v;
        return b.v;
      };
    }
    if (t.kind === "MemberExpr") {
      const obj = this.compileExpr(t.object), key = t.property;
      return (scope) => {
        const o = obj(scope);
        let v = value(scope);
        try {
          if (binop) v = rt.binary(binop, rt.getMember(o, key), v);
          return rt.setMember(o, key, v);
        } catch (err) { throw locate(err, e, rt); }
      };
    }
    if (t.kind === "IndexExpr") {
      const obj = this.compileExpr(t.object), idx = this.compileExpr(t.index);
      return (scope) => {
        const o = obj(scope), i = idx(scope);
        let v = value(scope);
        try {
          if (binop) v = rt.binary(binop, rt.getIndex(o, i), v);
          return rt.setIndex(o, i, v);
        } catch (err) { throw locate(err, e, rt); }
      };
    }
    // destructuring assignment
    const pattern = t;
    return (scope) => {
      const v = value(scope);
      const b = rt.destructure(pattern, v);
      for (const k of Object.keys(b)) {
        const bind = scope.lookup(k);
        if (!bind) throw rtError(`Undefined variable '${k}'`, e);
        if (!bind.m) throw rtError(`Cannot reassign immutable variable '${k}' (declare it with 'let mut')`, e);
        bind.v = b[k];
      }
      return v;
    };
  }
}

function nil(v) { return v === undefined ? null : v; }

// Does a block's statement list declare names directly (needing its own scope)?
function declaresNames(stmts) {
  for (const s of stmts) {
    const k = s.kind === "ExprStmt" ? s.expr.kind : s.kind;
    if (k === "LetStmt" || k === "FnStmt" || k === "TypeStmt" || k === "UseStmt") return true;
  }
  return false;
}

// Can evaluating `node` raise a return/break/continue signal that escapes the
// enclosing function body? (Nested functions handle their own signals.)
function containsSignal(node, inLoop) {
  if (!node || typeof node !== "object") return false;
  if (Array.isArray(node)) { for (const n of node) if (containsSignal(n, inLoop)) return true; return false; }
  switch (node.kind) {
    case "ReturnStmt": case "PropagateExpr": return true;
    case "BreakStmt": case "ContinueStmt": return !inLoop;
    case "LambdaExpr": case "FnStmt": return false;
    case "ForStmt": return containsSignal(node.iterable, inLoop) || containsSignal(node.body, true);
    case "WhileStmt": return containsSignal(node.condition, inLoop) || containsSignal(node.body, true);
    case "DoWhileStmt": return containsSignal(node.condition, inLoop) || containsSignal(node.body, true);
  }
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (v && typeof v === "object" && containsSignal(v, inLoop)) return true;
  }
  return false;
}

function locate(err, node, rt, any) {
  if (err && (any || err instanceof ArcRuntimeError || (rt && err instanceof rt.ArcRuntimeError)) && typeof err === "object" && !err.loc && node && node.line) {
    err.loc = { line: node.line, col: node.col }; err.line = node.line; err.col = node.col;
  }
  return err;
}

// ---------------- modules ----------------
function loadModuleFor(env, path, node) {
  const ns = env.rt.loadModule(path);
  if (ns) return ns;
  const fileNs = loadFileModule(env, path);
  if (fileNs) return fileNs;
  throw rtError(`Module not found: '${path}'`, node);
}

function loadFileModule(env, modPath) {
  let fs, pathMod;
  try { fs = require("fs"); pathMod = require("path"); } catch (e) { return null; }
  const base = env.baseDir || process.cwd();
  const rel = String(modPath);
  const candidates = [];
  const raw = pathMod.isAbsolute(rel) ? rel : pathMod.resolve(base, rel);
  if (rel.endsWith(".arc")) candidates.push(raw);
  else candidates.push(raw + ".arc", pathMod.join(raw, "index.arc"), pathMod.join(raw, "main.arc"));
  const stripped = rel.replace(/^(std|stdlib)\//, "");
  candidates.push(pathMod.resolve(__dirname, "..", "stdlib", stripped + ".arc"));
  let file = null;
  for (const c of candidates) { try { if (fs.statSync(c).isFile()) { file = c; break; } } catch (e) { /* skip */ } }
  if (!file) return null;
  if (env.moduleCache.has(file)) {
    const cached = env.moduleCache.get(file);
    if (cached === "loading") throw new ArcRuntimeError(`Circular module dependency: '${modPath}'`);
    return cached;
  }
  env.moduleCache.set(file, "loading");
  try {
    const source = fs.readFileSync(file, "utf8");
    const program = assertValid(parse(lex(source)));
    const modEnv = createEnv({}, Object.assign({}, env.options, { baseDir: pathMod.dirname(file), moduleCache: env.moduleCache, filename: file }));
    modEnv.rt.output = env.rt.output;
    modEnv.rt.tools = env.rt.tools;
    const run = compileProgram(program, modEnv);
    run(modEnv.scope);
    const hasPub = program.stmts.some((s) => s.pub);
    const ns = {};
    for (const s of program.stmts) {
      const names = declaredNames(s);
      for (const n of names) {
        if (hasPub ? s.pub : !n.startsWith("_")) {
          const b = modEnv.scope.vars.get(n);
          if (b) ns[n] = b.v;
        }
      }
    }
    env.moduleCache.set(file, ns);
    return ns;
  } catch (e) {
    env.moduleCache.delete(file);
    throw e;
  }
}

const BUILTIN_TYPE_NAMES = new Set(["Int", "Integer", "Float", "Number", "Num", "Double", "String", "Str", "Bool", "Boolean", "Nil", "None", "Void", "Unit", "Null", "Any", "List", "Array", "Set", "Tuple", "Map", "Object", "Record", "Dict", "Fn", "Function", "Callable", "Result", "Option", "Maybe", "Promise", "Json", "JSON", "Value", "Never", "Unknown"]);
function isNullaryVariant(t) { return t.kind === "NamedType" && !(t.args && t.args.length) && /^[A-Z]/.test(t.name) && !BUILTIN_TYPE_NAMES.has(t.name) && !/^[A-Z]$/.test(t.name); }

function declaredNames(s) {
  switch (s.kind) {
    case "FnStmt": return [s.name];
    case "LetStmt": return patternNames(s.pattern);
    case "TypeStmt": {
      const out = [];
      const walk = (t, u) => { if (!t) return; if (t.kind === "UnionType") t.types.forEach((x) => walk(x, true)); else if (t.kind === "VariantType" || (u && isNullaryVariant(t))) out.push(t.name); };
      walk(s.def, false);
      return out;
    }
    default: return [];
  }
}

function patternNames(p, out = []) {
  if (!p) return out;
  switch (p.kind) {
    case "BindingPattern": out.push(p.name); break;
    case "ListPattern": p.elements.forEach((e) => patternNames(e, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "MapPattern": p.fields.forEach((f) => patternNames(f.pattern, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "OrPattern": p.alternatives.forEach((a) => patternNames(a, out)); break;
    case "VariantPattern": (p.args || []).forEach((a) => patternNames(a, out)); break;
    case "TypedPattern": if (p.name !== "_") out.push(p.name); break;
  }
  return out;
}

// ---------------- public API ----------------
function toProgramRaw(program) {
  if (typeof program === "string") return parse(lex(program));
  if (Array.isArray(program)) return parse(program);
  if (program && program.kind === "Program") return program;
  if (program && Array.isArray(program.stmts)) return program;
  if (program && typeof program.source === "string") return parse(lex(program.source));
  if (program && program.ast) return program.ast;
  return { kind: "Program", stmts: [] };
}
function toProgram(program) { return assertValid(toProgramRaw(program)); }

function interpretWithEnv(program, env = createEnv()) {
  if (!env || !env.scope) env = createEnv(env || {});
  const prog = toProgram(program);
  const run = compileProgram(prog, env);
  try {
    const v = run(env.scope);
    return v === undefined ? null : v;
  } catch (e) {
    if (e instanceof ReturnSignal) return e.value;
    if (e === BREAK || e === CONTINUE) throw new ArcRuntimeError(`'${e === BREAK ? "break" : "continue"}' outside of loop`);
    if (e instanceof RangeError && /call stack/i.test(e.message)) {
      env.depth = 0;
      throw new ArcRuntimeError("Stack overflow: maximum recursion depth exceeded");
    }
    if (e && e.name === "ArcThrow") e.name = "RuntimeError";
    throw e;
  }
}

function interpret(program, options = {}) {
  const env = createEnv({}, options);
  return interpretWithEnv(program, env);
}

function run(source, options = {}) {
  return interpret(assertValid(parse(lex(source))), options);
}

function evaluate(source, env = createEnv()) {
  return interpretWithEnv(assertValid(parse(lex(source))), env);
}

module.exports = { isNullaryVariant, createEnv, interpretWithEnv, interpret, run, evaluate, Scope, ReturnSignal, patternNames, declaredNames, loadFileModule };
