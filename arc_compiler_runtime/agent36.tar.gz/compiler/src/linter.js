"use strict";
// Arc linter: style and correctness diagnostics built on the semantic analyzer.
const { lex } = require("./lexer.js");
const { runAnalysis } = require("./semantic.js");

const RULES = {
  "parse-error": "error",
  "undefined-variable": "error",
  "immutable-assignment": "error",
  "break-outside-loop": "error",
  "continue-outside-loop": "error",
  "duplicate-parameter": "error",
  "unknown-module": "error",
  "unknown-import": "error",
  "unused-variable": "warning",
  "unused-mut": "warning",
  "unreachable-code": "warning",
  "unreachable-pattern": "warning",
  "duplicate-key": "warning",
  "empty-block": "warning",
  "self-comparison": "warning",
  "naming-convention": "info",
  "return-outside-function": "warning",
  "line-too-long": "warning",
  "trailing-whitespace": "warning",
  "unused-import": "warning",
  "redeclared-variable": "warning",
  "self-assignment": "warning",
};

const SNAKE = /^_*[a-z][a-z0-9_]*$|^_+$/;
const CONST_CASE = /^[A-Z][A-Z0-9_]*$/;

function lint(source, options = {}) {
  const src = typeof source === "string" ? source : String(source ?? "");
  const disabled = new Set(options.disable || []);
  const diags = [];
  const push = (rule, message, line, col, severity) => {
    if (disabled.has(rule)) return;
    diags.push({ rule, severity: severity || RULES[rule] || "warning", level: severity || RULES[rule] || "warning", message, line: line || 1, col: col || 1 });
  };
  try { lex(src); } catch (e) {
    push("parse-error", e.message, e.line, e.col, "error");
    return diags;
  }
  const r = runAnalysis(src, Object.assign({ allowTopLevelReturn: true }, options));
  if (!r.program) {
    for (const e of r.errors) push("parse-error", e.message, e.line, e.col, "error");
    return diags;
  }
  for (const e of r.errors) push(e.rule, e.message, e.line, e.col, "error");
  try {
    const { checkTypes } = require("./typechecker.js");
    for (const e of checkTypes(r.program).errors) push("type-error", e.message, e.line, e.col, "error");
  } catch (e) { /* ignore */ }
  for (const w of r.warnings) push(w.rule, w.message, w.line, w.col);
  const a = r.analyzer;
  for (const d of a.redeclared) push("redeclared-variable", `'${d.name}' is already declared in this scope (line ${d.prevLine})`, d.node.line, d.node.col);
  for (const d of a.selfAssign) push("self-assignment", `'${d.name}' is assigned to itself`, d.node.line, d.node.col);
  for (const v of a.allVars) {
    if ((v.kind === "module" || (v.kind === "import" && v.selective)) && !v.used && !v.name.startsWith("_")) {
      push("unused-import", v.kind === "module" ? `Unused import '${v.name}'` : `Unused import '${v.name}'`, v.line, v.col);
    }
  }
  for (const v of a.allVars) {
    if (v.builtin || v.name.startsWith("_")) continue;
    if (v.kind === "var" && !v.used && !v.pub && !(v.top && options.ignoreTopLevel)) {
      push("unused-variable", `Unused variable '${v.name}' (declared but never used)`, v.line, v.col);
    } else if ((v.kind === "var") && v.mutable && !v.reassigned) {
      push("unused-mut", `Variable '${v.name}' is declared 'mut' but never reassigned (unused mutability)`, v.line, v.col);
    }
    if (options.naming && (v.kind === "var" || v.kind === "fn" || v.kind === "param") && !SNAKE.test(v.name) && !CONST_CASE.test(v.name)) {
      push("naming-convention", `Name '${v.name}' should be snake_case`, v.line, v.col);
    }
  }
  walk(r.program, (n) => {
    if ((n.kind === "WhileStmt" || n.kind === "ForStmt") && n.body && n.body.stmts && n.body.stmts.length === 0) push("empty-block", `Empty ${n.kind === "ForStmt" ? "for" : "while"} loop body`, n.line, n.col);
    if (n.kind === "FnStmt" && n.body && n.body.kind === "BlockExpr" && n.body.stmts.length === 0) push("empty-block", `Function '${n.name}' has an empty body`, n.line, n.col);
    if (n.kind === "IfExpr" && n.then && n.then.kind === "BlockExpr" && n.then.stmts.length === 0) push("empty-block", "Empty if block", n.line, n.col);
    if (n.kind === "BinaryExpr" && ["==", "!=", "<", ">", "<=", ">="].includes(n.op) && n.left.kind === "Identifier" && n.right.kind === "Identifier" && n.left.name === n.right.name) {
      push("self-comparison", `Comparing '${n.left.name}' with itself`, n.line, n.col);
    }
  });
  const maxLen = options.maxLineLength || 100;
  src.split(/\r?\n/).forEach((line, i) => {
    if (line.length > maxLen) push("line-too-long", `Line ${i + 1} exceeds ${maxLen} characters (${line.length})`, i + 1, maxLen + 1);
    if (/[ \t]+$/.test(line)) push("trailing-whitespace", `Trailing whitespace on line ${i + 1}`, i + 1, line.replace(/[ \t]+$/, "").length + 1);
  });
  diags.sort((x, y) => x.line - y.line || x.col - y.col);
  return diags;
}

function walk(node, fn) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) { for (const n of node) walk(n, fn); return; }
  if (node.kind) fn(node);
  for (const k of Object.keys(node)) { const v = node[k]; if (v && typeof v === "object") walk(v, fn); }
}

function lintSource(source, options) { return lint(source, options); }
function formatDiagnostics(diags, filename) {
  return diags.map((d) => `${filename ? filename + ":" : ""}${d.line}:${d.col}: ${d.severity}: ${d.message} [${d.rule}]`).join("\n");
}

module.exports = { lint, lintSource, formatDiagnostics, RULES };
