"use strict";
// Arc code formatter: parses source and pretty-prints the AST, preserving comments.
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");

const PREC = {
  AssignExpr: 1, LambdaExpr: 1, PipelineExpr: 2, coalesce: 3, or: 4, and: 5, comparison: 6,
  RangeExpr: 7, concat: 8, additive: 9, multiplicative: 10, power: 11, unary: 12, postfix: 14, primary: 15,
};
const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;
const MAX_WIDTH = 80;

function binPrec(op) {
  switch (op) {
    case "??": return PREC.coalesce;
    case "or": return PREC.or;
    case "and": return PREC.and;
    case "==": case "!=": case "<": case ">": case "<=": case ">=": case "in": return PREC.comparison;
    case "++": return PREC.concat;
    case "+": case "-": return PREC.additive;
    case "*": case "/": case "%": return PREC.multiplicative;
    case "**": return PREC.power;
  }
  return PREC.primary;
}

function exprPrec(e) {
  switch (e.kind) {
    case "AssignExpr": case "LambdaExpr": return 1;
    case "PipelineExpr": return PREC.PipelineExpr;
    case "BinaryExpr": return binPrec(e.op);
    case "UnaryExpr": return PREC.unary;
    case "RangeExpr": return PREC.RangeExpr;
    case "AwaitExpr": return PREC.unary;
    case "IntLiteral": case "FloatLiteral": return e.value < 0 || Object.is(e.value, -0) ? PREC.unary : PREC.primary;
    case "CallExpr": case "MemberExpr": case "IndexExpr": case "SliceExpr": case "PropagateExpr": return PREC.postfix;
    case "ReturnStmt": case "BreakStmt": case "ContinueStmt": return 1;
  }
  return PREC.primary;
}

function escapeString(s, interp) {
  let out = "";
  const chars = Array.from(s);
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i];
    switch (c) {
      case "\\": {
        // keep backslashes that came from unknown escapes (e.g. "\d") readable
        const nx = chars[i + 1];
        if (nx !== undefined && /[dDwWsSbB.+*?()\[\]^$|/]/.test(nx)) out += "\\";
        else out += "\\\\";
        break;
      }
      case '"': out += '\\"'; break;
      case "\n": out += "\\n"; break;
      case "\t": out += "\\t"; break;
      case "\r": out += "\\r"; break;
      case "\0": out += "\\0"; break;
      case "{": {
        const nx = chars[i + 1];
        out += nx !== undefined && /[A-Za-z_]/.test(nx) ? "\\{" : "{";
        break;
      }
      default: out += c;
    }
  }
  return out;
}

class Printer {
  constructor(comments, options = {}) {
    this.comments = comments || [];
    this.ci = 0;
    this.indentStr = " ".repeat(options.indent || 2);
    this.layout = options.layout || "preserve";
  }

  ind(level) { return this.indentStr.repeat(level); }

  // emit own-line comments that appear before `line`
  flushComments(line, level, out) {
    while (this.ci < this.comments.length && this.comments[this.ci].line < line) {
      const c = this.comments[this.ci++];
      out.push(this.ind(level) + normalizeComment(c.text));
    }
  }

  trailingComment(line) {
    if (this.ci < this.comments.length) {
      const c = this.comments[this.ci];
      if (c.line === line && !c.ownLine) { this.ci++; return " " + normalizeComment(c.text); }
    }
    return "";
  }

  printProgram(program) {
    const out = [];
    this.printStmts(program.stmts, 0, out, Infinity);
    return out;
  }

  printStmts(stmts, level, out, endLine) {
    let prevEnd = null, prevTrail = false;
    for (const s of stmts) {
      if (prevEnd !== null && s.line && s.line - prevEnd > 1) {
        const firstComment = this.ci < this.comments.length ? this.comments[this.ci] : null;
        const gapStart = firstComment && firstComment.line < s.line ? firstComment.line : s.line;
        if (gapStart - prevEnd > 1) out.push("");
      }
      if (s.line) this.flushComments(s.line, level, out);
      const text = this.stmt(s, level);
      const lines = text.split("\n");
      const endL = lastLine(s);
      if (prevEnd !== null && s.line === prevEnd && lines.length === 1 && out.length && !prevTrail && !out[out.length - 1].endsWith("{")) {
        out[out.length - 1] += "; " + lines[0];
        const trailSame = this.trailingComment(s.line);
        if (trailSame) out[out.length - 1] += trailSame;
        prevTrail = !!trailSame;
        prevEnd = endL;
        continue;
      }
      lines[0] = this.ind(level) + lines[0];
      const trail = this.trailingComment(s.line);
      if (trail) lines[0] += trail;
      out.push(...lines);
      let t2 = "";
      if (endL !== s.line) { t2 = this.trailingComment(endL); if (t2) out[out.length - 1] += t2; }
      prevTrail = !!(trail || t2);
      prevEnd = endL;
    }
    if (endLine !== undefined) this.flushComments(endLine, level, out);
  }

  isSimpleStmt(st) {
    if (st.kind === "BreakStmt" || st.kind === "ContinueStmt") return true;
    if (st.kind === "ReturnStmt") return !st.value || isFlat(st.value);
    if (st.kind === "ExprStmt") return isFlat(st.expr) || (st.expr.kind === "AssignExpr" && isFlat(st.expr.value));
    if (st.kind === "LetStmt") return isFlat(st.value);
    return false;
  }

  block(b, level) {
    // returns "{\n...\n}" with inner lines indented at level+1 (first line not indented)
    if (!b.stmts.length && !this.hasCommentsBefore(b.endLine)) return "{}";
    // keep blocks that were written on a single line inline (layout: "preserve")
    if (this.layout === "preserve" && b.endLine !== undefined && b.line === b.endLine && b.stmts.length === 1 && this.isSimpleStmt(b.stmts[0])) {
      const inner = this.stmt(b.stmts[0], level);
      if (!inner.includes("\n") && inner.length + level * 2 + 4 <= MAX_WIDTH * 1.5) return `{ ${inner} }`;
    }
    const out = [];
    this.printStmts(b.stmts, level + 1, out, b.endLine === undefined ? (b.stmts.length ? lastLine(b.stmts[b.stmts.length - 1]) + 1 : b.line + 1) : b.endLine);
    return "{\n" + out.join("\n") + "\n" + this.ind(level) + "}";
  }

  hasCommentsBefore(line) { return line !== undefined && this.ci < this.comments.length && this.comments[this.ci].line < line; }

  stmt(s, level) {
    switch (s.kind) {
      case "LetStmt":
        return `${s.pub ? "pub " : ""}let ${s.mutable ? "mut " : ""}${this.pattern(s.pattern)}${s.typeAnn ? ": " + this.type(s.typeAnn) : ""} = ${this.expr(s.value, level, 1)}`;
      case "FnStmt": {
        const head = `${s.pub ? "pub " : ""}${s.async ? "async " : ""}fn ${s.name}${s.typeParams ? "<" + s.typeParams.join(", ") + ">" : ""}(${this.params(s.params, level)})${s.returnType ? " -> " + this.type(s.returnType) : ""}`;
        if (s.isExpr) return `${head} => ${this.bodyExpr(s.body, level)}`;
        return `${head} ${this.block(s.body, level)}`;
      }
      case "TypeStmt": return `${s.pub ? "pub " : ""}type ${s.name}${s.typeParams ? "<" + s.typeParams.join(", ") + ">" : ""} = ${this.type(s.def)}`;
      case "UseStmt": {
        if (s.keyword === "import") {
          if (Array.isArray(s.imports)) return `import { ${s.imports.join(", ")} } from "${escapeString(s.path)}"`;
          if (s.from !== undefined) return `import ${s.alias || s.name} from "${escapeString(s.path)}"`;
          const p2 = /^[A-Za-z_][\w]*(\/[A-Za-z_][\w]*)*$/.test(s.path) ? s.path : `"${escapeString(s.path)}"`;
          return `import ${p2}${s.alias && s.alias !== s.name ? " as " + s.alias : ""}`;
        }
        const pathStr = /^[A-Za-z_][\w]*(\/[A-Za-z_][\w]*)*$/.test(s.path) ? s.path : `"${escapeString(s.path)}"`;
        let r = `use ${pathStr}`;
        if (s.imports === "*") r += ": *";
        else if (Array.isArray(s.imports)) r += s.colonStyle ? `: ${s.imports.join(", ")}` : ` { ${s.imports.join(", ")} }`;
        else if (s.alias && s.alias !== s.name) r += ` as ${s.alias}`;
        return r;
      }
      case "ForStmt": return `for ${this.forPattern(s.pattern)} in ${this.expr(s.iterable, level, 1)} ${this.block(s.body, level)}`;
      case "WhileStmt":
        if (s.loop) return `loop ${this.block(s.body, level)}`;
        return `while ${this.expr(s.condition, level, 1)} ${this.block(s.body, level)}`;
      case "DoWhileStmt":
        if (!s.condition) return `do ${this.block(s.body, level)}`;
        return `do ${this.block(s.body, level)} ${s.until ? "until" : "while"} ${this.expr(s.condition, level, 1)}`;
      case "ReturnStmt": { const kw = s.keyword === "return" ? "return" : "ret"; return s.value ? `${kw} ${this.expr(s.value, level, 1)}` : kw; }
      case "BreakStmt": return "break";
      case "ContinueStmt": return "continue";
      case "ExprStmt": return this.expr(s.expr, level, 0);
    }
    return this.expr(s, level, 0);
  }

  forPattern(p) { return this.pattern(p); }

  params(ps, level) {
    return ps.map((p) => {
      let r = (p.rest ? "..." : "") + (p.pattern ? this.pattern(p.pattern) : p.name);
      if (p.typeAnn) r += ": " + this.type(p.typeAnn);
      if (p.default) r += " = " + this.expr(p.default, level, 2);
      return r;
    }).join(", ");
  }

  bodyExpr(b, level) {
    if (b.kind === "BlockExpr") return this.block(b, level);
    if (b.kind === "MapLiteral" && b.entries.length === 1 && b.entries[0].key !== undefined && b.entries[0].value.kind === "Identifier" && b.entries[0].value.name === b.entries[0].key) {
      return `{${keyStr(b.entries[0].key)}: ${b.entries[0].key}}`;
    }
    return this.expr(b, level, 1);
  }

  type(t) {
    if (!t) return "Any";
    switch (t.kind) {
      case "NamedType": return t.name + (t.args && t.args.length ? `<${t.args.map((a) => this.type(a)).join(", ")}>` : "");
      case "ListType": return `[${this.type(t.element)}]`;
      case "OptionalType": return this.type(t.inner) + "?";
      case "LiteralType": return typeof t.value === "string" ? `"${escapeString(t.value)}"` : String(t.value);
      case "UnionType": return t.types.map((x) => this.type(x)).join(" | ");
      case "RecordType": return `{${t.fields.map((f) => `${keyStr(f.name)}${f.optional ? "?" : ""}: ${this.type(f.type)}${f.default ? " = " + this.expr(f.default, 0, 1) : ""}`).join(", ")}}`;
      case "FnType": return `(${t.params.map((p) => this.type(p)).join(", ")}) -> ${this.type(t.ret)}`;
      case "TupleType": return `(${t.elements.map((p) => this.type(p)).join(", ")})`;
      case "VariantType": return `${t.name}(${t.fields.map((f) => this.type(f)).join(", ")})`;
      case "ConstrainedType":
        if (t.regex !== null && t.regex !== undefined) return `${this.type(t.base)} matching /${t.regex}/${t.flags || ""}`;
        return `${this.type(t.base)} where ${t.param ? t.param + " => " : ""}${this.expr(t.predicate, 0, PREC.or)}`;
    }
    return "Any";
  }

  pattern(p) {
    switch (p.kind) {
      case "WildcardPattern": return "_";
      case "BindingPattern": return p.name;
      case "LiteralPattern": return literalStr(p.value);
      case "RangePattern": return `${literalStr(p.start)}..${literalStr(p.end)}`;
      case "TypedPattern": return `${p.name}: ${p.type}`;
      case "OrPattern": return p.alternatives.map((a) => this.pattern(a)).join(" | ");
      case "VariantPattern": { const nm = p.qualifier ? p.qualifier + "." + p.name : p.name; return p.args ? `${nm}(${p.args.map((a) => this.pattern(a)).join(", ")})` : nm; }
      case "ListPattern": {
        const els = p.elements.map((e) => this.pattern(e));
        if (p.rest !== null && p.rest !== undefined) {
          const dots = p.restSyntax === ".." ? ".." : "...";
          const r = p.rest === "_" ? dots : dots + p.rest;
          const idx = p.restIndex === undefined ? els.length : p.restIndex;
          els.splice(idx, 0, r);
        }
        return `[${els.join(", ")}]`;
      }
      case "MapPattern": {
        const fs = p.fields.map((f) => (f.pattern.kind === "BindingPattern" && f.pattern.name === f.key ? keyStr(f.key) : `${keyStr(f.key)}: ${this.pattern(f.pattern)}`));
        if (p.rest) { const dots = p.restSyntax === ".." ? ".." : "..."; fs.push(p.rest === "_" ? dots : dots + p.rest); }
        return `{${fs.join(", ")}}`;
      }
      case "TargetPattern": return this.expr(p.target, 0, 1);
    }
    return "_";
  }

  expr(e, level, minPrec) {
    const s = this.exprRaw(e, level);
    // keep parentheses the author wrote, add the ones precedence requires
    return exprPrec(e) < minPrec || e.parenthesized ? `(${s})` : s;
  }

  args(args, level) {
    return args.map((a) => (a.kind === "SpreadExpr" ? "..." + this.expr(a.expr, level, PREC.postfix) : this.expr(a, level, 1))).join(", ");
  }

  exprRaw(e, level) {
    switch (e.kind) {
      case "IntLiteral": return e.raw !== undefined && Number(e.raw.replace(/_/g, "")) === e.value && !/^-?0[xob]/i.test(e.raw) ? e.raw : String(e.value);
      case "FloatLiteral": {
        if (e.raw !== undefined && Number(e.raw.replace(/_/g, "")) === e.value) return e.raw;
        const t = String(e.value);
        return /[.eE]|Infinity|NaN/.test(t) ? t : t + ".0";
      }
      case "StringLiteral": return e.rawText !== undefined ? e.rawText : `"${escapeString(e.value)}"`;
      case "StringInterp": return e.rawText !== undefined ? e.rawText : `"${e.parts.map((p) => (typeof p === "string" ? escapeString(p) : "{" + this.expr(p, level, 1) + "}")).join("")}"`;
      case "BoolLiteral": return e.value ? "true" : "false";
      case "NilLiteral": return "nil";
      case "EllipsisExpr": return "...";
      case "RegexLiteral": return `/${e.pattern}/${e.flags || ""}`;
      case "Identifier": return e.name;
      case "BinaryExpr": {
        const p = binPrec(e.op);
        if (e.op === "**") return `${this.expr(e.left, level, PREC.unary)} ** ${this.expr(e.right, level, PREC.power)}`;
        return `${this.expr(e.left, level, p)} ${e.raw || e.op} ${this.expr(e.right, level, p + 1)}`;
      }
      case "UnaryExpr":
        if (e.op === "not") return e.raw === "!" ? `!${this.expr(e.operand, level, PREC.unary)}` : `not ${this.expr(e.operand, level, PREC.unary)}`;
        return `-${this.expr(e.operand, level, PREC.unary)}`;
      case "AwaitExpr": return `await ${this.expr(e.expr, level, PREC.unary)}`;
      case "RangeExpr": return `${this.expr(e.start, level, PREC.additive)}${e.inclusive ? "..=" : ".."}${this.expr(e.end, level, PREC.additive)}`;
      case "CallExpr": return `${this.expr(e.callee, level, PREC.postfix)}${e.optional ? "?." : ""}(${this.args(e.args, level)})`;
      case "MemberExpr": return `${this.expr(e.object, level, PREC.postfix)}${e.optional ? "?." : "."}${e.property}`;
      case "IndexExpr": return `${this.expr(e.object, level, PREC.postfix)}${e.optional ? "?." : ""}[${this.expr(e.index, level, 1)}]`;
      case "SliceExpr":
        if (e.inclusive) return `${this.expr(e.object, level, PREC.postfix)}[${e.start ? this.expr(e.start, level, PREC.concat) : ""}..=${e.end ? this.expr(e.end, level, PREC.concat) : ""}]`;
        return `${this.expr(e.object, level, PREC.postfix)}[${e.start ? this.expr(e.start, level, 1) : ""}:${e.end ? this.expr(e.end, level, 1) : ""}]`;
      case "PropagateExpr": return `${this.expr(e.expr, level, PREC.postfix)}?`;
      case "PipelineExpr": {
        const chain = [];
        let cur = e;
        while (cur.kind === "PipelineExpr") { chain.unshift(cur.right); cur = cur.left; }
        const head = this.expr(cur, level, PREC.coalesce);
        const parts = chain.map((r) => this.expr(r, level + 1, PREC.coalesce));
        const one = `${head} |> ${parts.join(" |> ")}`;
        const ops = [];
        let c2 = e;
        while (c2.kind === "PipelineExpr") { ops.unshift(c2.line); c2 = c2.left; }
        const multiSrc = cur.line !== undefined && ops.some((l) => l !== undefined && l > cur.line && !String(head).includes("\n"));
        if (!multiSrc && (one.length + level * 2 <= MAX_WIDTH || parts.length < 2)) return one;
        return `${head}\n${parts.map((p) => this.ind(level + 1) + "|> " + p).join("\n")}`;
      }
      case "AssignExpr": return `${e.target.kind === "ListPattern" || e.target.kind === "MapPattern" ? this.pattern(e.target) : this.expr(e.target, level, PREC.postfix)} ${e.op} ${this.expr(e.value, level, 1)}`;
      case "LambdaExpr": {
        const params = e.params;
        const simple = params.length === 1 && !params[0].pattern && !params[0].rest && !params[0].default && !params[0].typeAnn && !e.parenParams;
        if (e.syntax === "fn") {
          if (e.body.kind === "BlockExpr") return `${e.async ? "async " : ""}fn(${this.params(params, level)}) ${this.block(e.body, level)}`;
          return `${e.async ? "async " : ""}fn(${this.params(params, level)}) => ${this.bodyExpr(e.body, level)}`;
        }
        const head = simple ? params[0].name : `(${this.params(params, level)})`;
        return `${e.async ? "async " : ""}${head} => ${this.bodyExpr(e.body, level)}`;
      }
      case "ListLiteral": {
        const items = e.elements.map((x) => (x.kind === "SpreadExpr" ? (x.op === ".." ? ".." : "...") + this.expr(x.expr, level + 1, PREC.postfix) : this.expr(x, level + 1, 1)));
        const one = `[${items.join(", ")}]`;
        const multiSrc = e.endLine !== undefined && e.endLine > e.line && items.length > 0;
        if (!multiSrc && (one.length + level * 2 <= MAX_WIDTH || items.length < 2) && !one.includes("\n")) return one;
        return `[\n${items.map((i) => this.ind(level + 1) + i).join(",\n")}\n${this.ind(level)}]`;
      }
      case "ListComprehension": return `[${this.expr(e.expr, level, 1)} ${this.compClauses(e.clauses, level)}]`;
      case "MapComprehension": return `{${this.expr(e.key, level, 1)}: ${this.expr(e.value, level, 1)} ${this.compClauses(e.clauses, level)}}`;
      case "MapLiteral": {
        if (!e.entries.length) return "{}";
        const items = e.entries.map((en) => {
          if (en.spread) return (en.op === ".." ? ".." : "...") + this.expr(en.spread, level + 1, PREC.postfix);
          if (en.computed) return `[${this.expr(en.computed, level + 1, 1)}]: ${this.expr(en.value, level + 1, 1)}`;
          if (en.value.kind === "Identifier" && en.value.name === en.key && IDENT_RE.test(en.key) && (e.entries.length > 1 || en.shorthand)) return en.key;
          return `${keyStr(en.key)}: ${this.expr(en.value, level + 1, 1)}`;
        });
        const one = `{${items.join(", ")}}`;
        const multiSrc = e.endLine !== undefined && e.endLine > e.line && items.length > 0;
        if (!multiSrc && (one.length + level * 2 <= MAX_WIDTH || items.length < 2) && !one.includes("\n")) return one;
        return `{\n${items.map((i) => this.ind(level + 1) + i).join(",\n")}\n${this.ind(level)}}`;
      }
      case "BlockExpr": return this.block(e, level);
      case "IfExpr": return this.ifExpr(e, level);
      case "MatchExpr": {
        if (!e.arms.length) return `match ${this.expr(e.subject, level, 1)} {}`;
        if (this.layout === "preserve" && e.endLine !== undefined && e.line === e.endLine && e.arms.every((a) => a.body.kind !== "BlockExpr" ? isFlat(a.body) : a.body.line === a.body.endLine)) {
          const arms = e.arms.map((a) => `${this.pattern(a.pattern)}${a.guard ? " if " + this.expr(a.guard, level + 1, 1) : ""} => ${this.bodyExpr(a.body, level + 1)}`);
          const one = `match ${this.expr(e.subject, level, 1)} { ${arms.join(", ")} }`;
          if (!one.includes("\n")) return one;
        }
        const out = [];
        e.arms.forEach((a, i) => {
          if (a.line) this.flushComments(a.line, level + 1, out);
          let line = `${this.ind(level + 1)}${this.pattern(a.pattern)}${a.guard ? " if " + this.expr(a.guard, level + 1, 1) : ""} => ${this.bodyExpr(a.body, level + 1)}`;
          if (i < e.arms.length - 1 && e.commas !== false) line += ",";
          const trail = a.line ? this.trailingComment(lastLine(a)) : "";
          out.push(line + trail);
        });
        if (e.endLine !== undefined) this.flushComments(e.endLine, level + 1, out);
        return `match ${this.expr(e.subject, level, 1)} {\n${out.join("\n")}\n${this.ind(level)}}`;
      }
      case "TryExpr": {
        let r = `try ${this.block(e.body, level)}`;
        if (e.catchBody) r += ` catch ${e.catchParam} ${this.block(e.catchBody, level)}`;
        if (e.finallyBody) r += ` finally ${this.block(e.finallyBody, level)}`;
        return r;
      }
      case "ToolCallExpr": {
        if (e.method) return `@${e.method} ${this.expr(e.url, level, PREC.postfix)}${e.body ? " " + this.expr(e.body, level, PREC.postfix) : ""}`;
        return `@${e.name}(${this.args(e.args, level)})`;
      }
      case "FetchExpr": {
        const items = e.calls.map((c) => this.ind(level + 1) + this.expr(c, level + 1, 1));
        return `fetch [\n${items.join(",\n")}\n${this.ind(level)}]`;
      }
      case "AsyncExpr": return `async ${this.block(e.body, level)}`;
      case "SpreadExpr": return "..." + this.expr(e.expr, level, PREC.postfix);
      case "ReturnStmt": { const kw = e.keyword === "return" ? "return" : "ret"; return e.value ? `${kw} ${this.expr(e.value, level, 1)}` : kw; }
      case "BreakStmt": return "break";
      case "ContinueStmt": return "continue";
      case "LetStmt": case "FnStmt": case "ForStmt": case "WhileStmt": case "DoWhileStmt": case "UseStmt": case "TypeStmt": case "ExprStmt":
        return this.stmt(e, level);
    }
    return "";
  }

  compClauses(clauses, level) {
    return clauses.map((c) => `for ${this.pattern(c.pattern)} in ${this.expr(c.iterable, level, PREC.or)}${c.conditions.map((x) => " if " + this.expr(x, level, PREC.or)).join("")}`).join(" ");
  }

  isInlineBranch(b) {
    if (!b) return true;
    if (b.kind === "IfExpr") return this.isInlineBranch(b.then) && this.isInlineBranch(b.else_);
    if (b.kind !== "BlockExpr") return true;
    if (b.stmts.length !== 1) return false;
    const st = b.stmts[0];
    if (st.kind === "BreakStmt" || st.kind === "ContinueStmt") return !this.hasCommentsBefore(b.endLine);
    if (st.kind === "ReturnStmt") return (!st.value || isFlat(st.value)) && !this.hasCommentsBefore(b.endLine);
    if (st.kind !== "ExprStmt") return false;
    const ex = st.expr;
    return !["IfExpr", "MatchExpr", "BlockExpr", "TryExpr", "LambdaExpr", "AssignExpr"].includes(ex.kind) && !this.hasCommentsBefore(b.endLine);
  }

  ifExpr(e, level) {
    let r = `if ${this.expr(e.condition, level, 1)} ${this.branch(e.then, level)}`;
    const kw = e.elseKeyword === "el" ? "el" : "else";
    if (e.else_) {
      if (e.else_.kind === "IfExpr") r += ` ${kw} ${this.ifExpr(e.else_, level)}`;
      else r += ` ${kw} ${this.branch(e.else_, level)}`;
    }
    return r;
  }

  branch(b, level) {
    if (b.kind === "BlockExpr") return this.block(b, level);
    return `{ ${this.expr(b, level, 1)} }`;
  }
}

function isFlat(e) {
  return !["IfExpr", "MatchExpr", "BlockExpr", "TryExpr", "LambdaExpr", "AssignExpr", "ListComprehension", "MapComprehension", "FetchExpr"].includes(e.kind);
}

function normalizeComment(text) {
  return text.replace(/\s+$/, "");
}

function keyStr(k) {
  return IDENT_RE.test(k) ? k : `"${escapeString(String(k))}"`;
}

function literalStr(v) {
  if (v === null) return "nil";
  if (typeof v === "string") return `"${escapeString(v)}"`;
  return String(v);
}

function lastLine(node) {
  let max = node && node.line ? node.line : 0;
  const visit = (n) => {
    if (!n || typeof n !== "object") return;
    if (Array.isArray(n)) { for (const x of n) visit(x); return; }
    if (typeof n.line === "number" && n.line > max) max = n.line;
    if (typeof n.endLine === "number" && n.endLine > max) max = n.endLine;
    for (const k of Object.keys(n)) { const v = n[k]; if (v && typeof v === "object") visit(v); }
  };
  visit(node);
  return max;
}

function format(source, options = {}) {
  const src = typeof source === "string" ? source : String(source ?? "");
  let tokens, program;
  try {
    tokens = lex(src);
    program = assertValid(parse(tokens));
  } catch (e) {
    if (options.throwOnError) throw e;
    // unparseable input is returned unchanged
    return src;
  }
  const printer = new Printer(tokens.comments, options);
  const lines = printer.printProgram(program);
  printer.flushComments(Infinity, 0, lines);
  let out = lines.map((l) => l.replace(/\s+$/, "")).join("\n");
  out = out.replace(/\n{3,}/g, "\n\n").replace(/^\n+/, "");
  return options.trailingNewline && out.length ? out + "\n" : out;
}

function formatCode(source, options) { return format(source, options); }
function check(source) { return format(source, { trailingNewline: true }) === source || format(source) === source; }

module.exports = { format, formatCode, check, Printer };
