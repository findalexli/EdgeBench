"use strict";
// Aggregated public API of the Arc compiler/runtime (kept for compatibility).
const { lex, tokenize } = require("./lexer.js");
const { parse } = require("./parser.js");
const { createEnv, interpretWithEnv, interpret, run, evaluate } = require("./interpreter.js");
const { generateIR, printIR } = require("./ir.js");
const { generateJS } = require("./codegen-js.js");
const { generateWAT } = require("./codegen.js");
const { optimize, optimizeIR } = require("./optimizer.js");
const { format } = require("./formatter.js");
const { lint } = require("./linter.js");
const { analyze } = require("./semantic.js");
const { checkTypes } = require("./typechecker.js");
const { validateSource, validateToolCall } = require("./security.js");
const { parseArcToml } = require("./package-manager.js");
const { createRuntime } = require("./runtime-core.js");

module.exports = {
  lex, tokenize, parse, createEnv, interpretWithEnv, interpret, run, evaluate,
  generateIR, printIR, generateJS, generateWAT, optimize, optimizeIR,
  format, lint, analyze, checkTypes, validateSource, validateToolCall, parseArcToml, createRuntime,
};
