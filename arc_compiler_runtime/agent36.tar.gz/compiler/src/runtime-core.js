"use strict";
// Arc runtime core. `createRuntime` must stay fully self-contained: the JS code
// generator embeds its source text (createRuntime.toString()) into generated programs,
// so it may only reference globals, never module-level bindings.

function createRuntime(options) {
  options = options || {};
  const hasOwn = Object.prototype.hasOwnProperty;

  class ArcRuntimeError extends Error {
    constructor(message, loc) { super(message); this.name = "RuntimeError"; if (loc) { this.loc = loc; this.line = loc.line; this.col = loc.col; } }
  }
  class ArcThrow extends Error {
    constructor(value) { super(typeof value === "string" ? value : (value && typeof value === "object" && typeof value.message === "string" ? value.message : toStr(value))); this.name = "RuntimeError"; this.value = value; }
  }
  class ArcTypeError extends Error {
    constructor(message) { super(message); this.name = "TypeError"; }
  }
  function fail(msg) { throw new ArcRuntimeError(msg); }

  function getNode(name) {
    try { if (typeof process !== "undefined" && process.getBuiltinModule) return process.getBuiltinModule(name); } catch (e) { /* ignore */ }
    try { if (options.loadBuiltin) return options.loadBuiltin(name); } catch (e) { /* ignore */ }
    return null;
  }

  // ---------- value helpers ----------
  const isNil = (v) => v === null || v === undefined;
  const isList = Array.isArray;
  const isMap = (v) => v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof RegExp);
  const isFn = (v) => typeof v === "function";
  const isNum = (v) => typeof v === "number";
  const isStr = (v) => typeof v === "string";
  const nil = (v) => (v === undefined ? null : v);

  function typeOf(v) {
    if (v === null || v === undefined) return "nil";
    switch (typeof v) {
      case "boolean": return "bool";
      case "number": return Number.isInteger(v) ? "int" : "float";
      case "string": return "string";
      case "function": return "fn";
    }
    if (Array.isArray(v)) return "list";
    return "map";
  }

  function numToStr(n) {
    if (Object.is(n, -0)) return "0";
    if (Number.isNaN(n)) return "NaN";
    return String(n);
  }

  function quote(s) {
    return '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\t/g, "\\t").replace(/\r/g, "\\r") + '"';
  }

  function repr(v, depth) {
    if (typeof v === "string") return quote(v);
    return toStr(v, depth);
  }

  function toStr(v, depth) {
    depth = depth || 0;
    if (v === null || v === undefined) return "nil";
    switch (typeof v) {
      case "string": return v;
      case "number": return numToStr(v);
      case "boolean": return v ? "true" : "false";
      case "function": return "<fn " + (v.arcName || v.name || "anonymous") + ">";
    }
    if (depth > 50) return "...";
    if (Array.isArray(v)) return "[" + v.map((x) => repr(x, depth + 1)).join(", ") + "]";
    if (v instanceof RegExp) return "/" + v.source + "/";
    if (typeof v.__tag === "string" && Array.isArray(v.__values)) return v.__values.length ? v.__tag + "(" + v.__values.map((x) => repr(x, depth + 1)).join(", ") + ")" : v.__tag;
    const keys = Object.keys(v);
    return "{" + keys.map((k) => k + ": " + repr(v[k], depth + 1)).join(", ") + "}";
  }

  function truthy(v) {
    if (v === null || v === undefined || v === false || v === 0 || v === "") return false;
    if (Number.isNaN(v)) return false;
    if (Array.isArray(v)) return v.length > 0;
    if (typeof v === "object" && !(v instanceof RegExp)) { for (const k in v) { if (hasOwn.call(v, k)) return true; } return false; }
    return true;
  }

  function eq(a, b) {
    if (a === b) return true;
    if (a === null || a === undefined) return b === null || b === undefined;
    if (b === null || b === undefined) return false;
    if (typeof a !== typeof b) return false;
    if (typeof a === "number") return Number.isNaN(a) && Number.isNaN(b);
    if (typeof a !== "object") return false;
    if (Array.isArray(a)) {
      if (!Array.isArray(b) || a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) if (!eq(a[i], b[i])) return false;
      return true;
    }
    if (Array.isArray(b)) return false;
    const ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    for (const k of ka) { if (!hasOwn.call(b, k) || !eq(a[k], b[k])) return false; }
    return true;
  }

  function compare(a, b) {
    if (typeof a === "number" && typeof b === "number") return a < b ? -1 : a > b ? 1 : 0;
    if (typeof a === "string" && typeof b === "string") return a < b ? -1 : a > b ? 1 : 0;
    if (typeof a === "boolean" && typeof b === "boolean") return (a ? 1 : 0) - (b ? 1 : 0);
    if (Array.isArray(a) && Array.isArray(b)) {
      for (let i = 0; i < Math.min(a.length, b.length); i++) { const c = compare(a[i], b[i]); if (c !== 0) return c; }
      return a.length - b.length;
    }
    // incomparable values: every ordering comparison is false
    return NaN;
  }

  // Ordering used by sort(): never throws, groups by type.
  const TYPE_ORDER = { nil: 0, bool: 1, int: 2, float: 2, string: 3, list: 4, map: 5, fn: 6 };
  function sortCompare(a, b) {
    const ta = TYPE_ORDER[typeOf(a)], tb = TYPE_ORDER[typeOf(b)];
    if (ta !== tb) return ta - tb;
    if (ta === 0 || ta >= 5) return 0;
    return compare(a, b);
  }

  // ---------- operators ----------
  function add(a, b) {
    if (typeof a === "number" && typeof b === "number") return a + b;
    if (typeof a === "string" || typeof b === "string") {
      if ((typeof a === "string" || isScalarLike(a)) && (typeof b === "string" || isScalarLike(b))) return toStr(a) + toStr(b);
      return toStr(a) + toStr(b);
    }
    if (Array.isArray(a) && Array.isArray(b)) return a.concat(b);
    if (isMap(a) && isMap(b)) return Object.assign({}, a, b);
    fail("Cannot add " + typeOf(a) + " and " + typeOf(b));
  }
  function isScalarLike(v) { return v === null || v === undefined || typeof v !== "object"; }
  function concat(a, b) {
    if (Array.isArray(a)) return Array.isArray(b) ? a.concat(b) : a.concat([b]);
    if (typeof a === "string" || typeof b === "string") return toStr(a) + toStr(b);
    if (typeof a === "number" && typeof b === "number") return toStr(a) + toStr(b);
    if (isMap(a) && isMap(b)) return Object.assign({}, a, b);
    if (isNil(a)) return Array.isArray(b) ? b.slice() : toStr(a) + toStr(b);
    fail("Cannot concatenate " + typeOf(a) + " and " + typeOf(b));
  }
  function sub(a, b) {
    if (typeof a === "number" && typeof b === "number") return a - b;
    fail("Cannot subtract " + typeOf(b) + " from " + typeOf(a));
  }
  function mul(a, b) {
    if (typeof a === "number" && typeof b === "number") return a * b;
    if (typeof a === "string" && typeof b === "number") return b > 0 ? a.repeat(Math.floor(b)) : "";
    if (typeof a === "number" && typeof b === "string") return a > 0 ? b.repeat(Math.floor(a)) : "";
    if (Array.isArray(a) && typeof b === "number") { let out = []; for (let i = 0; i < b; i++) out = out.concat(a); return out; }
    if (typeof a === "number" && Array.isArray(b)) return mul(b, a);
    fail("Cannot multiply " + typeOf(a) + " and " + typeOf(b));
  }
  function div(a, b) {
    if (typeof a === "number" && typeof b === "number") {
      if (b === 0) fail("Division by zero");
      return a / b;
    }
    fail("Cannot divide " + typeOf(a) + " by " + typeOf(b));
  }
  function mod(a, b) {
    if (typeof a === "number" && typeof b === "number") {
      if (b === 0) fail("Modulo by zero");
      return a % b;
    }
    fail("Cannot compute modulo of " + typeOf(a) + " and " + typeOf(b));
  }
  function pow(a, b) {
    if (typeof a === "number" && typeof b === "number") return Math.pow(a, b);
    fail("Cannot raise " + typeOf(a) + " to " + typeOf(b));
  }
  function neg(a) {
    if (typeof a === "number") return -a;
    fail("Cannot negate " + typeOf(a));
  }
  function not(a) { return !truthy(a); }
  function lt(a, b) { return compare(a, b) < 0; }
  function gt(a, b) { return compare(a, b) > 0; }
  function le(a, b) { return compare(a, b) <= 0; }
  function ge(a, b) { return compare(a, b) >= 0; }
  function ne(a, b) { return !eq(a, b); }
  function inOp(a, b) { return contains(b, a); }

  function binary(op, a, b) {
    switch (op) {
      case "+": return add(a, b);
      case "-": return sub(a, b);
      case "*": return mul(a, b);
      case "/": return div(a, b);
      case "%": return mod(a, b);
      case "**": return pow(a, b);
      case "++": return concat(a, b);
      case "==": return eq(a, b);
      case "!=": return !eq(a, b);
      case "<": return compare(a, b) < 0;
      case ">": return compare(a, b) > 0;
      case "<=": return compare(a, b) <= 0;
      case ">=": return compare(a, b) >= 0;
      case "in": return contains(b, a);
    }
    fail("Unknown operator " + op);
  }

  function range(a, b, inclusive) {
    if (typeof a === "string" && typeof b === "string" && a.length >= 1 && b.length >= 1) {
      const s = a.codePointAt(0), e = b.codePointAt(0);
      const out = [];
      for (let c = s; c <= e; c++) out.push(String.fromCodePoint(c));
      return out;
    }
    if (typeof a !== "number" || typeof b !== "number") fail("Range bounds must be numbers, got " + typeOf(a) + " and " + typeOf(b));
    const out = [];
    const end = inclusive ? b : b - 1;
    if (end - a > 1e7) fail("Range too large");
    for (let i = a; i <= end; i++) out.push(i);
    return out;
  }

  // ---------- member / index access ----------
  function chars(s) { return Array.from(s); }
  const SURROGATE = /[\uD800-\uDFFF]/;
  function strLen(s) { return SURROGATE.test(s) ? Array.from(s).length : s.length; }

  function getMember(obj, key, optional) {
    if (obj === null || obj === undefined) {
      if (optional) return null;
      fail("Cannot access property '" + key + "' of nil");
    }
    if (Array.isArray(obj)) {
      if (key === "length" || key === "len") return obj.length;
      if (/^-?\d+$/.test(key)) return getIndex(obj, Number(key));
      return null;
    }
    if (typeof obj === "string") {
      if (key === "length" || key === "len") return strLen(obj);
      return null;
    }
    if (typeof obj === "object" || typeof obj === "function") {
      if (hasOwn.call(obj, key)) { const v = obj[key]; return v === undefined ? null : v; }
      return null;
    }
    return null;
  }

  function getIndex(obj, idx, optional) {
    if (obj === null || obj === undefined) {
      if (optional) return null;
      fail("Cannot index into nil");
    }
    if (Array.isArray(obj)) {
      if (typeof idx !== "number") {
        if (typeof idx === "string" && /^-?\d+$/.test(idx)) idx = Number(idx);
        else fail("List index must be an int, got " + typeOf(idx));
      }
      idx = Math.trunc(idx);
      if (idx < 0) idx += obj.length;
      const v = obj[idx];
      return v === undefined ? null : v;
    }
    if (typeof obj === "string") {
      if (typeof idx !== "number") fail("String index must be an int, got " + typeOf(idx));
      if (SURROGATE.test(obj)) {
        const cs = Array.from(obj);
        if (idx < 0) idx += cs.length;
        return cs[idx] === undefined ? null : cs[idx];
      }
      if (idx < 0) idx += obj.length;
      return idx >= 0 && idx < obj.length ? obj[idx] : null;
    }
    if (typeof obj === "object" || typeof obj === "function") {
      const k = typeof idx === "string" ? idx : toStr(idx);
      if (hasOwn.call(obj, k)) { const v = obj[k]; return v === undefined ? null : v; }
      return null;
    }
    fail("Cannot index into " + typeOf(obj));
  }

  function defineKey(obj, k, v) {
    if (k === "__proto__") Object.defineProperty(obj, k, { value: v, writable: true, enumerable: true, configurable: true });
    else obj[k] = v;
  }

  function setMember(obj, key, value) {
    if (obj === null || obj === undefined) fail("Cannot set property '" + key + "' of nil");
    if (Array.isArray(obj)) {
      if (/^-?\d+$/.test(key)) return setIndex(obj, Number(key), value);
      fail("Cannot set property '" + key + "' on a list");
    }
    if (typeof obj !== "object" && typeof obj !== "function") fail("Cannot set property '" + key + "' on " + typeOf(obj));
    if (Object.isFrozen(obj)) fail("Cannot modify frozen value");
    defineKey(obj, key, value);
    return value;
  }

  function setIndex(obj, idx, value) {
    if (obj === null || obj === undefined) fail("Cannot index into nil");
    if (Array.isArray(obj)) {
      if (typeof idx !== "number") fail("List index must be an int, got " + typeOf(idx));
      idx = Math.trunc(idx);
      if (idx < 0) idx += obj.length;
      if (idx < 0 || idx > obj.length) fail("Index " + idx + " out of bounds for list of length " + obj.length);
      if (Object.isFrozen(obj)) fail("Cannot modify frozen value");
      obj[idx] = value;
      return value;
    }
    if (typeof obj === "string") fail("Strings are immutable");
    if (typeof obj === "object" || typeof obj === "function") {
      if (Object.isFrozen(obj)) fail("Cannot modify frozen value");
      defineKey(obj, typeof idx === "string" ? idx : toStr(idx), value);
      return value;
    }
    fail("Cannot index into " + typeOf(obj));
  }

  function slice(x, start, end) {
    if (x === null || x === undefined) fail("Cannot slice nil");
    const isS = typeof x === "string";
    const arr = isS ? (SURROGATE.test(x) ? Array.from(x) : null) : x;
    const len = isS ? (arr ? arr.length : x.length) : x.length;
    let s = isNil(start) ? 0 : Math.trunc(start);
    let e = isNil(end) ? len : Math.trunc(end);
    if (s < 0) s = Math.max(0, len + s);
    if (e < 0) e = Math.max(0, len + e);
    if (s > len) s = len;
    if (e > len) e = len;
    if (e < s) e = s;
    if (isS) return arr ? arr.slice(s, e).join("") : x.slice(s, e);
    if (Array.isArray(x)) return x.slice(s, e);
    fail("Cannot slice " + typeOf(x));
  }

  function iterate(v) {
    if (Array.isArray(v)) return v;
    if (typeof v === "string") return Array.from(v);
    if (v === null || v === undefined) fail("Cannot iterate over nil");
    if (typeof v === "object") return Object.keys(v).map((k) => [k, v[k]]);
    fail("Cannot iterate over " + typeOf(v));
  }

  function call(f, args, name) {
    if (typeof f !== "function") fail((name ? "'" + name + "'" : toStr(f)) + " is not a function" + (isNil(f) ? " (got nil)" : ""));
    return f.apply(null, args);
  }

  function callMethod(obj, key, args, optional) {
    if (obj === null || obj === undefined) {
      if (optional) return null;
      fail("Cannot call method '" + key + "' on nil");
    }
    if ((typeof obj === "object" || typeof obj === "function") && !Array.isArray(obj) && hasOwn.call(obj, key)) {
      const f = obj[key];
      if (typeof f !== "function") fail("'" + key + "' is not a function");
      return f.apply(null, args);
    }
    const b = builtins[key];
    if (typeof b === "function") return b.apply(null, [obj].concat(args));
    if (typeof obj === "object" && !Array.isArray(obj)) fail("'" + key + "' is not a function (no such key on map)");
    fail("Unknown method '" + key + "' for " + typeOf(obj));
  }

  function callFn(f, args) {
    // call a user callback with item/index depending on arity
    return f.apply(null, args);
  }
  function arityOf(f) {
    if (typeof f !== "function") return 0;
    if (typeof f.__arity === "number") return f.__arity;
    return f.length;
  }
  function cb1(f, x, i) { return arityOf(f) >= 2 ? f(x, i) : f(x); }

  // ---------- results ----------
  function Ok(value) { return { ok: true, value: nil(value) }; }
  function Err(error) { return { ok: false, error: nil(error) }; }
  function isResult(v) { return isMap(v) && typeof v.ok === "boolean" && (hasOwn.call(v, "value") || hasOwn.call(v, "error")); }

  // ---------- patterns ----------
  function matchPattern(p, value, b) {
    switch (p.kind) {
      case "WildcardPattern": return true;
      case "LiteralPattern": return eq(value, p.value);
      case "RangePattern":
        if (typeof value === "number" && typeof p.start === "number") return value >= p.start && (p.inclusive === false ? value < p.end : value <= p.end);
        if (typeof value === "string" && typeof p.start === "string") return value >= p.start && value <= p.end;
        return false;
      case "BindingPattern": b[p.name] = nil(value); return true;
      case "TypedPattern": {
        if (!checkTypeName(p.type, value)) return false;
        if (p.name !== "_") b[p.name] = nil(value);
        return true;
      }
      case "ListPattern": {
        if (!Array.isArray(value)) return false;
        const els = p.elements;
        if (p.rest === null || p.rest === undefined) {
          if (value.length !== els.length) return false;
          for (let i = 0; i < els.length; i++) if (!matchPattern(els[i], value[i], b)) return false;
          return true;
        }
        if (value.length < els.length) return false;
        const ri = p.restIndex === undefined ? els.length : p.restIndex;
        for (let i = 0; i < ri; i++) if (!matchPattern(els[i], value[i], b)) return false;
        const after = els.length - ri;
        for (let j = 0; j < after; j++) if (!matchPattern(els[ri + j], value[value.length - after + j], b)) return false;
        if (p.rest !== "_") b[p.rest] = value.slice(ri, value.length - after);
        return true;
      }
      case "MapPattern": {
        if (!isMap(value)) return false;
        for (const f of p.fields) {
          if (!hasOwn.call(value, f.key) || value[f.key] === undefined) {
            if (f.pattern.kind === "LiteralPattern" && f.pattern.value === null) continue;
            return false;
          }
          if (!matchPattern(f.pattern, value[f.key], b)) return false;
        }
        if (p.rest && p.rest !== "_") {
          const used = new Set(p.fields.map((f) => f.key));
          const r = {};
          for (const k of Object.keys(value)) if (!used.has(k)) defineKey(r, k, value[k]);
          b[p.rest] = r;
        }
        return true;
      }
      case "OrPattern": {
        for (const alt of p.alternatives) {
          const tmp = {};
          if (matchPattern(alt, value, tmp)) { Object.assign(b, tmp); return true; }
        }
        return false;
      }
      case "VariantPattern": {
        const args = p.args || [];
        switch (p.name) {
          case "Ok":
            if (!isResult(value) || value.ok !== true) return false;
            return args.length === 0 || matchPattern(args[0], value.value, b);
          case "Err":
            if (!isResult(value) || value.ok !== false) return false;
            return args.length === 0 || matchPattern(args[0], value.error, b);
          case "Some":
            if (isNil(value)) return false;
            return args.length === 0 || matchPattern(args[0], value, b);
          case "None": case "Nil": return isNil(value);
        }
        if (!isMap(value)) return false;
        const tag = hasOwn.call(value, "__tag") ? value.__tag : hasOwn.call(value, "tag") ? value.tag : hasOwn.call(value, "type") ? value.type : hasOwn.call(value, "kind") ? value.kind : undefined;
        if (tag !== p.name) return false;
        if (!p.args) return true;
        const vals = Array.isArray(value.__values) ? value.__values : Array.isArray(value.values) ? value.values : Object.keys(value).filter((k) => k !== "__tag" && k !== "tag" && k !== "type" && k !== "kind").map((k) => value[k]);
        if (vals.length < args.length) return false;
        for (let i = 0; i < args.length; i++) if (!matchPattern(args[i], vals[i], b)) return false;
        return true;
      }
    }
    fail("Unknown pattern kind " + p.kind);
  }

  function match(p, value) {
    const b = {};
    return matchPattern(p, value, b) ? b : null;
  }

  function destructure(p, value, b) {
    b = b || {};
    switch (p.kind) {
      case "BindingPattern": b[p.name] = nil(value); return b;
      case "WildcardPattern": return b;
      case "ListPattern": {
        let arr;
        if (Array.isArray(value)) arr = value;
        else if (typeof value === "string") arr = Array.from(value);
        else if (isMap(value)) arr = Object.keys(value).map((k) => value[k]);
        else fail("Cannot destructure " + typeOf(value) + " as a list");
        const els = p.elements;
        const ri = p.rest !== null && p.rest !== undefined ? (p.restIndex === undefined ? els.length : p.restIndex) : els.length;
        for (let i = 0; i < ri; i++) destructure(els[i], arr[i], b);
        if (p.rest !== null && p.rest !== undefined) {
          const after = els.length - ri;
          for (let j = 0; j < after; j++) destructure(els[ri + j], arr[Math.max(ri, arr.length - after) + j], b);
          if (p.rest !== "_") b[p.rest] = arr.slice(ri, Math.max(ri, arr.length - after));
        }
        return b;
      }
      case "MapPattern": {
        if (!isMap(value)) fail("Cannot destructure " + typeOf(value) + " as a map");
        for (const f of p.fields) destructure(f.pattern, hasOwn.call(value, f.key) ? value[f.key] : null, b);
        if (p.rest && p.rest !== "_") {
          const used = new Set(p.fields.map((f) => f.key));
          const r = {};
          for (const k of Object.keys(value)) if (!used.has(k)) defineKey(r, k, value[k]);
          b[p.rest] = r;
        }
        return b;
      }
      default:
        if (matchPattern(p, value, b)) return b;
        fail("Pattern did not match value " + repr(value));
    }
  }

  function checkTypeName(t, v) {
    switch (t) {
      case "Any": return true;
      case "Int": return typeof v === "number" && Number.isInteger(v);
      case "Float": return typeof v === "number";
      case "Number": case "Num": return typeof v === "number";
      case "String": case "Str": return typeof v === "string";
      case "Bool": case "Boolean": return typeof v === "boolean";
      case "Nil": case "None": return isNil(v);
      case "List": case "Array": return Array.isArray(v);
      case "Map": case "Object": case "Record": return isMap(v);
      case "Fn": case "Function": return typeof v === "function";
    }
    return isMap(v) && (v.__tag === t || v.type === t);
  }

  function propagate(v) {
    // `expr?` — returns {signal} when the enclosing function must return early
    if (isResult(v)) return v.ok ? { value: v.value } : { ret: v };
    if (isNil(v)) return { ret: null };
    return { value: v };
  }

  // ---------- conversion builtins ----------
  function toInt(v) {
    if (typeof v === "number") { if (!Number.isFinite(v)) fail("Cannot convert " + numToStr(v) + " to int"); return Math.trunc(v); }
    if (typeof v === "boolean") return v ? 1 : 0;
    if (typeof v === "string") {
      const s = v.trim();
      if (/^[+-]?\d+$/.test(s)) return parseInt(s, 10);
      if (s !== "" && /^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) return Math.trunc(Number(s));
      if (/^0[xX][0-9a-fA-F]+$/.test(s)) return parseInt(s, 16);
      if (/^0[bB][01]+$/.test(s)) return parseInt(s.slice(2), 2);
      fail("Cannot convert \"" + v + "\" to int");
    }
    fail("Cannot convert " + typeOf(v) + " to int");
  }
  function toFloat(v) {
    if (typeof v === "number") return v;
    if (typeof v === "boolean") return v ? 1 : 0;
    if (typeof v === "string") {
      const s = v.trim();
      if (s !== "" && /^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) return Number(s);
      if (/^[+-]?(Infinity|inf)$/i.test(s)) return s.startsWith("-") ? -Infinity : Infinity;
      if (/^nan$/i.test(s)) return NaN;
      fail("Cannot convert \"" + v + "\" to float");
    }
    fail("Cannot convert " + typeOf(v) + " to float");
  }

  function len(x) {
    if (x === null || x === undefined) return 0;
    if (typeof x === "string") return strLen(x);
    if (Array.isArray(x)) return x.length;
    if (typeof x === "object") return Object.keys(x).length;
    fail("len() is not supported for " + typeOf(x));
  }

  function contains(x, y) {
    if (x === null || x === undefined) return false;
    if (typeof x === "string") return x.includes(toStr(y));
    if (Array.isArray(x)) { for (const e of x) if (eq(e, y)) return true; return false; }
    if (typeof x === "object") return hasOwn.call(x, toStr(y));
    fail("contains() is not supported for " + typeOf(x));
  }

  function needList(x, fname) {
    if (Array.isArray(x)) return x;
    if (typeof x === "string") return Array.from(x);
    if (isNil(x)) fail(fname + "() expected a list, got nil");
    if (isMap(x)) return Object.keys(x).map((k) => [k, x[k]]);
    fail(fname + "() expected a list, got " + typeOf(x));
  }
  function needFn(f, fname) { if (typeof f !== "function") fail(fname + "() expected a function, got " + typeOf(f)); return f; }
  function needStr(s, fname) { if (typeof s === "string") return s; if (isNil(s)) fail(fname + "() expected a string, got nil"); return toStr(s); }

  function sortList(xs, f) {
    const arr = needList(xs, "sort").slice();
    if (isNil(f)) return arr.sort(sortCompare);
    needFn(f, "sort");
    if (arityOf(f) >= 2) {
      return arr.sort((a, b) => {
        const r = f(a, b);
        if (typeof r === "boolean") return r ? -1 : (f(b, a) ? 1 : 0);
        return typeof r === "number" ? r : 0;
      });
    }
    const keyed = arr.map((x, i) => ({ x, k: f(x), i }));
    keyed.sort((a, b) => sortCompare(a.k, b.k) || a.i - b.i);
    return keyed.map((e) => e.x);
  }

  function sumList(xs) {
    const arr = needList(xs, "sum");
    let acc = 0;
    for (const x of arr) acc = add(acc, x);
    return acc;
  }

  function minMax(args, sign, fname) {
    let list = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
    if (args.length === 2 && typeof args[1] === "function" && Array.isArray(args[0])) {
      const f = args[1];
      let best = null, bestK = null;
      for (const x of args[0]) { const k = f(x); if (best === null || compare(k, bestK) * sign > 0) { best = x; bestK = k; } }
      return best;
    }
    if (list.length === 0) return null;
    let best = list[0];
    for (let i = 1; i < list.length; i++) if (compare(list[i], best) * sign > 0) best = list[i];
    return best;
  }

  function roundTo(n, d) {
    if (typeof n !== "number") fail("round() expected a number, got " + typeOf(n));
    if (isNil(d) || d === 0) return Math.round(n);
    const f = Math.pow(10, d);
    return Math.round(n * f) / f;
  }

  function indexOf(x, item) {
    if (typeof x === "string") {
      const i = x.indexOf(toStr(item));
      if (i < 0) return -1;
      return SURROGATE.test(x) ? Array.from(x.slice(0, i)).length : i;
    }
    if (Array.isArray(x)) { for (let i = 0; i < x.length; i++) if (eq(x[i], item)) return i; return -1; }
    if (isNil(x)) return -1;
    fail("index_of() is not supported for " + typeOf(x));
  }

  function print(...args) {
    const s = args.map((a) => toStr(a)).join(" ");
    if (rt.output) rt.output(s); else if (typeof console !== "undefined") console.log(s);
    return null;
  }

  function assert(cond, msg) {
    if (!truthy(cond)) throw new ArcRuntimeError(isNil(msg) ? "Assertion failed" : toStr(msg));
    return true;
  }

  function throwValue(v, msg) {
    if (msg !== undefined && !isNil(msg)) throw new ArcThrow(toStr(msg));
    throw new ArcThrow(isNil(v) ? "Error" : v);
  }

  function errorMessage(e) {
    if (e instanceof ArcThrow) return e.value;
    if (e && typeof e === "object" && typeof e.message === "string") {
      if (e instanceof RangeError && /call stack/i.test(e.message)) return "Stack overflow: maximum recursion depth exceeded";
      return e.message;
    }
    return toStr(e);
  }

  function unwrap(r) {
    if (isResult(r)) { if (r.ok) return r.value; fail("Called unwrap on Err: " + toStr(r.error)); }
    if (isNil(r)) fail("Called unwrap on nil");
    return r;
  }

  // ---------- HTTP / tools ----------
  function httpRequest(method, url, body, headers) {
    if (rt.httpHandler) return rt.httpHandler(method, url, body, headers);
    method = String(method || "GET").toUpperCase();
    const u = toStr(url);
    if (!/^https?:\/\//i.test(u)) return { ok: false, status: 0, data: null, error: "Invalid URL: " + u, headers: {} };
    const cp = getNode("child_process");
    if (!cp || typeof process === "undefined") return { ok: false, status: 0, data: null, error: "HTTP not available", headers: {} };
    const script = "let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',async()=>{const r=JSON.parse(d);try{const o={method:r.method,headers:Object.assign({'content-type':'application/json'},r.headers||{})};if(r.body!==null&&r.body!==undefined&&r.method!=='GET'&&r.method!=='HEAD')o.body=typeof r.body==='string'?r.body:JSON.stringify(r.body);const res=await fetch(r.url,o);const t=await res.text();let data=t;try{data=JSON.parse(t)}catch(e){}const h={};res.headers.forEach((v,k)=>h[k]=v);process.stdout.write(JSON.stringify({ok:res.ok,status:res.status,data,headers:h}))}catch(e){process.stdout.write(JSON.stringify({ok:false,status:0,data:null,error:String(e&&e.cause&&e.cause.message||e&&e.message||e),headers:{}}))}})";
    try {
      const out = cp.spawnSync(process.execPath, ["-e", script], { input: JSON.stringify({ method, url: u, body: isNil(body) ? null : body, headers: headers || {} }), encoding: "utf8", timeout: (options.httpTimeout || 15000) });
      if (out.error) return { ok: false, status: 0, data: null, error: String(out.error.message || out.error), headers: {} };
      return JSON.parse(out.stdout || "null") || { ok: false, status: 0, data: null, error: "No response", headers: {} };
    } catch (e) {
      return { ok: false, status: 0, data: null, error: String(e && e.message || e), headers: {} };
    }
  }

  function toolCall(method, url, body) {
    if (rt.security && typeof rt.security.checkToolCall === "function") rt.security.checkToolCall(method, url);
    if (rt.tools && typeof rt.tools[method] === "function") return rt.tools[method](url, body);
    return httpRequest(method, url, body);
  }
  function customTool(name, args) {
    if (rt.tools && typeof rt.tools[name] === "function") return rt.tools[name].apply(null, args);
    return { ok: false, tool: name, args: args, error: "Unknown tool '@" + name + "'" };
  }

  // ---------- builtins ----------
  const builtins = {
    print,
    println: print,
    len,
    str: (v) => toStr(v),
    to_string: (v) => toStr(v),
    int: toInt,
    float: toFloat,
    bool: (v) => truthy(v),
    type_of: typeOf,
    type: typeOf,
    is_nil: (v) => isNil(v),
    // strings
    trim: (s) => needStr(s, "trim").trim(),
    trim_start: (s) => needStr(s, "trim_start").trimStart(),
    trim_end: (s) => needStr(s, "trim_end").trimEnd(),
    upper: (s) => needStr(s, "upper").toUpperCase(),
    lower: (s) => needStr(s, "lower").toLowerCase(),
    split: (s, sep) => {
      s = needStr(s, "split");
      if (isNil(sep)) { const t = s.trim(); return t === "" ? [] : t.split(/\s+/); }
      if (sep === "") return Array.from(s);
      return s.split(toStr(sep));
    },
    join: (xs, sep) => needList(xs, "join").map((x) => toStr(x)).join(isNil(sep) ? "" : toStr(sep)),
    replace: (s, a, b) => needStr(s, "replace").split(toStr(a)).join(toStr(b)),
    contains,
    starts: (s, p) => needStr(s, "starts").startsWith(toStr(p)),
    ends: (s, p) => needStr(s, "ends").endsWith(toStr(p)),
    starts_with: (s, p) => needStr(s, "starts_with").startsWith(toStr(p)),
    ends_with: (s, p) => needStr(s, "ends_with").endsWith(toStr(p)),
    repeat: (s, n) => Array.isArray(s) ? mul(s, n) : (n > 0 ? needStr(s, "repeat").repeat(Math.floor(n)) : ""),
    chars: (s) => Array.from(needStr(s, "chars")),
    slice,
    substring: slice,
    index_of: indexOf,
    ord: (s) => { s = needStr(s, "ord"); return s.length ? s.codePointAt(0) : null; },
    chr: (n) => { if (typeof n !== "number") fail("chr() expected an int, got " + typeOf(n)); return String.fromCodePoint(n); },
    char_at: (s, i) => getIndex(needStr(s, "char_at"), i),
    lines: (s) => needStr(s, "lines").split(/\r?\n/),
    // lists
    map: (xs, f) => { needFn(f, "map"); return needList(xs, "map").map((x, i) => nil(cb1(f, x, i))); },
    filter: (xs, f) => { needFn(f, "filter"); return needList(xs, "filter").filter((x, i) => truthy(cb1(f, x, i))); },
    reduce: (xs, f, init) => {
      const arr = needList(xs, "reduce");
      if (typeof init === "function" && (typeof f !== "function" || (arityOf(init) >= 2 && arityOf(f) < 2))) { const t = f; f = init; init = t; }
      needFn(f, "reduce");
      let i = 0, acc = init;
      if (init === undefined) { if (!arr.length) return null; acc = arr[0]; i = 1; }
      for (; i < arr.length; i++) acc = f(acc, arr[i]);
      return nil(acc);
    },
    fold: (xs, init, f) => {
      const arr = needList(xs, "fold"); needFn(f, "fold");
      let acc = init;
      for (const x of arr) acc = f(acc, x);
      return nil(acc);
    },
    find: (xs, f) => { needFn(f, "find"); for (const x of needList(xs, "find")) if (truthy(f(x))) return x; return null; },
    find_index: (xs, f) => { needFn(f, "find_index"); const a = needList(xs, "find_index"); for (let i = 0; i < a.length; i++) if (truthy(f(a[i]))) return i; return -1; },
    any: (xs, f) => { const a = needList(xs, "any"); if (isNil(f)) return a.some(truthy); return a.some((x) => truthy(f(x))); },
    all: (xs, f) => { const a = needList(xs, "all"); if (isNil(f)) return a.every(truthy); return a.every((x) => truthy(f(x))); },
    each: (xs, f) => { for (const x of needList(xs, "each")) f(x); return null; },
    for_each: (xs, f) => { for (const x of needList(xs, "for_each")) f(x); return null; },
    sort: sortList,
    sort_by: (xs, f) => sortList(xs, (x) => f(x)),
    head: (xs) => { if (typeof xs === "string") return xs.length ? Array.from(xs)[0] : null; const a = needList(xs, "head"); return a.length ? a[0] : null; },
    first: (xs) => { const a = needList(xs, "first"); return a.length ? a[0] : null; },
    tail: (xs) => typeof xs === "string" ? Array.from(xs).slice(1).join("") : needList(xs, "tail").slice(1),
    last: (xs) => { const a = needList(xs, "last"); return a.length ? a[a.length - 1] : null; },
    init: (xs) => needList(xs, "init").slice(0, -1),
    reverse: (xs) => typeof xs === "string" ? Array.from(xs).reverse().join("") : needList(xs, "reverse").slice().reverse(),
    take: (xs, n) => slice(typeof xs === "string" ? xs : needList(xs, "take"), 0, Math.max(0, n)),
    drop: (xs, n) => slice(typeof xs === "string" ? xs : needList(xs, "drop"), Math.max(0, n)),
    skip: (xs, n) => slice(typeof xs === "string" ? xs : needList(xs, "skip"), Math.max(0, n)),
    flat: (xs) => needList(xs, "flat").reduce((acc, x) => (Array.isArray(x) ? acc.concat(x) : (acc.push(x), acc)), []),
    flatten: (xs) => needList(xs, "flatten").reduce((acc, x) => (Array.isArray(x) ? acc.concat(x) : (acc.push(x), acc)), []),
    flat_map: (xs, f) => needList(xs, "flat_map").reduce((acc, x) => { const r = f(x); return Array.isArray(r) ? acc.concat(r) : (acc.push(r), acc); }, []),
    zip: (a, b) => { a = needList(a, "zip"); b = needList(b, "zip"); const n = Math.min(a.length, b.length); const out = []; for (let i = 0; i < n; i++) out.push([a[i], b[i]]); return out; },
    enumerate: (xs) => needList(xs, "enumerate").map((x, i) => [i, x]),
    push: (xs, x) => needList(xs, "push").concat([x]),
    append: (xs, x) => needList(xs, "append").concat([x]),
    prepend: (xs, x) => [x].concat(needList(xs, "prepend")),
    pop: (xs) => needList(xs, "pop").slice(0, -1),
    insert: (xs, i, x) => { const a = needList(xs, "insert").slice(); a.splice(i, 0, x); return a; },
    remove_at: (xs, i) => { const a = needList(xs, "remove_at").slice(); a.splice(i, 1); return a; },
    concat: (...args) => {
      if (args.every((a) => typeof a === "string")) return args.join("");
      let out = [];
      for (const a of args) out = out.concat(Array.isArray(a) ? a : [a]);
      return out;
    },
    sum: sumList,
    product: (xs) => needList(xs, "product").reduce((a, b) => mul(a, b), 1),
    avg: (xs) => { const a = needList(xs, "avg"); return a.length ? sumList(a) / a.length : null; },
    range: (a, b, step) => {
      if (isNil(b)) { b = a; a = 0; }
      if (isNil(step)) return range(a, b, false);
      if (step === 0) fail("range() step cannot be zero");
      const out = [];
      if (step > 0) for (let i = a; i < b; i += step) out.push(i);
      else for (let i = a; i > b; i += step) out.push(i);
      return out;
    },
    unique: (xs) => { const out = []; for (const x of needList(xs, "unique")) if (!out.some((y) => eq(x, y))) out.push(x); return out; },
    count: (xs, f) => { const a = needList(xs, "count"); if (isNil(f)) return a.length; if (typeof f === "function") return a.filter((x) => truthy(f(x))).length; return a.filter((x) => eq(x, f)).length; },
    is_empty: (x) => len(x) === 0,
    min: (...args) => minMax(args, -1, "min"),
    max: (...args) => minMax(args, 1, "max"),
    // maps
    keys: (m) => { if (isNil(m)) return []; if (Array.isArray(m)) return m.map((_, i) => i); if (typeof m !== "object" && typeof m !== "function") fail("keys() expected a map, got " + typeOf(m)); return Object.keys(m); },
    values: (m) => { if (isNil(m)) return []; if (Array.isArray(m)) return m.slice(); if (typeof m !== "object" && typeof m !== "function") fail("values() expected a map, got " + typeOf(m)); return Object.keys(m).map((k) => m[k]); },
    entries: (m) => { if (isNil(m)) return []; if (Array.isArray(m)) return m.map((v, i) => ({ key: i, value: v })); if (typeof m !== "object") fail("entries() expected a map, got " + typeOf(m)); return Object.keys(m).map((k) => ({ key: k, value: m[k] })); },
    has: (m, k) => contains(m, k),
    has_key: (m, k) => isMap(m) && hasOwn.call(m, toStr(k)),
    get: (m, k, d) => { const v = Array.isArray(m) || typeof m === "string" ? getIndex(m, k) : (isMap(m) ? getIndex(m, k) : null); return isNil(v) ? nil(d) : v; },
    set: (m, k, v) => { if (Array.isArray(m)) { const a = m.slice(); setIndex(a, k, v); return a; } const o = Object.assign({}, m); defineKey(o, toStr(k), v); return o; },
    remove: (m, k) => { if (Array.isArray(m)) return m.filter((x) => !eq(x, k)); const o = Object.assign({}, m); delete o[toStr(k)]; return o; },
    delete: (m, k) => { const o = Object.assign({}, m); delete o[toStr(k)]; return o; },
    merge: (...ms) => Object.assign({}, ...ms.filter((m) => !isNil(m))),
    from_entries: (es) => { const o = {}; for (const e of needList(es, "from_entries")) { if (Array.isArray(e)) defineKey(o, toStr(e[0]), e[1]); else if (isMap(e)) defineKey(o, toStr(e.key), e.value); } return o; },
    // math
    abs: (n) => { if (typeof n !== "number") fail("abs() expected a number, got " + typeOf(n)); return Math.abs(n); },
    round: roundTo,
    floor: (n) => Math.floor(n),
    ceil: (n) => Math.ceil(n),
    sqrt: (n) => Math.sqrt(n),
    pow: (a, b) => pow(a, b),
    random: () => Math.random(),
    // results
    Ok, Err,
    is_ok: (r) => isResult(r) && r.ok === true,
    is_err: (r) => isResult(r) && r.ok === false,
    unwrap,
    unwrap_or: (r, d) => { if (isResult(r)) return r.ok ? r.value : nil(d); return isNil(r) ? nil(d) : r; },
    unwrap_err: (r) => { if (isResult(r) && !r.ok) return r.error; fail("Called unwrap_err on Ok value"); },
    map_result: (r, f) => (isResult(r) && r.ok ? Ok(f(r.value)) : r),
    // misc
    assert,
    assert_eq: (a, b, msg) => { if (!eq(a, b)) throw new ArcRuntimeError(isNil(msg) ? "Assertion failed: expected " + repr(b) + " but got " + repr(a) : toStr(msg)); return true; },
    panic: (msg) => { throw new ArcThrow(isNil(msg) ? "panic" : toStr(msg)); },
    throw: throwValue,
    error: (msg) => { throw new ArcThrow(isNil(msg) ? "Error" : msg); },
    time_ms: () => Date.now(),
    now: () => Date.now(),
    arity: arityOf,
    freeze: (v) => (v && typeof v === "object" ? Object.freeze(v) : v),
    copy: (v) => (Array.isArray(v) ? v.slice() : isMap(v) ? Object.assign({}, v) : v),
    deep_copy: (v) => deepCopy(v),
    repr: (v) => repr(v),
    to_json: (v, indent) => jsonStringify(v, indent),
    from_json: (s) => jsonParse(s),
    read: (path) => { const fs = getNode("fs"); try { return fs.readFileSync(toStr(path), "utf8"); } catch (e) { return null; } },
    write: (path, content) => { const fs = getNode("fs"); fs.writeFileSync(toStr(path), toStr(content)); return null; },
    sleep: (ms) => { sleepMs(ms); return null; },
  };

  // Native helpers used by the Arc-source stdlib (kept for compatibility).
  const nativeHelpers = {
    crypto_hash: (alg, t) => loadModule("crypto").hash(alg, t),
    crypto_hmac: (alg, k, m) => getNode("crypto").createHmac(toStr(alg), toStr(k)).update(toStr(m)).digest("hex"),
    crypto_uuid: () => loadModule("crypto").uuid(),
    crypto_random_bytes: (n) => loadModule("crypto").random_bytes(n),
    crypto_random_int: (a, b) => loadModule("crypto").random_int(a, b),
    crypto_encode_base64: (t) => loadModule("crypto").base64_encode(t),
    crypto_decode_base64: (t) => loadModule("crypto").base64_decode(t),
    error_new: (c, m) => loadModule("error").error(c, m),
    error_is_error: (v) => loadModule("error").is_error(v),
    error_wrap: (e, c) => loadModule("error").wrap_error(e, c),
    error_try: (f) => loadModule("error").try_fn(f),
    error_throw: (c, m) => loadModule("error").throw(c, m),
    error_retry: (f, n) => loadModule("error").retry(f, n),
    regex_test: (p, t) => loadModule("regex").test(p, t),
    regex_find: (p, t) => loadModule("regex").find(p, t),
    regex_find_all: (p, t) => loadModule("regex").find_all(p, t),
    regex_replace: (p, r, t) => loadModule("regex").replace(p, t, r),
    regex_replace_all: (p, r, t) => loadModule("regex").replace_all(p, t, r),
    regex_split: (p, t) => loadModule("regex").split(p, t),
    net_url_encode: (t) => encodeURIComponent(toStr(t)),
    net_url_decode: (t) => decodeURIComponent(toStr(t)),
    embed_dot_product: vecDot,
    embed_magnitude: vecMag,
    embed_cosine_similarity: cosine,
  };
  for (const k of Object.keys(nativeHelpers)) builtins[k] = nativeHelpers[k];

  function deepCopy(v) {
    if (Array.isArray(v)) return v.map(deepCopy);
    if (isMap(v)) { const o = {}; for (const k of Object.keys(v)) defineKey(o, k, deepCopy(v[k])); return o; }
    return v;
  }

  function sleepMs(ms) {
    try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.max(0, Number(ms) || 0)); } catch (e) { const end = Date.now() + ms; while (Date.now() < end) { /* spin */ } }
  }

  function jsonClean(v) {
    if (v === undefined || typeof v === "function") return null;
    if (typeof v === "number" && !Number.isFinite(v)) return null;
    if (Array.isArray(v)) return v.map(jsonClean);
    if (isMap(v)) { const o = {}; for (const k of Object.keys(v)) defineKey(o, k, jsonClean(v[k])); return o; }
    return v;
  }
  function jsonStringify(v, indent) {
    return JSON.stringify(jsonClean(v), null, isNil(indent) ? undefined : (typeof indent === "number" ? indent : toStr(indent)));
  }
  function jsonParse(s) {
    if (typeof s !== "string") fail("from_json() expected a string, got " + typeOf(s));
    if (s.trim() === "") throw new ArcThrow("Invalid JSON: empty string");
    try { return JSON.parse(s); } catch (e) { throw new ArcThrow("Invalid JSON: " + e.message); }
  }

  // ---------- stdlib modules ----------
  const MS_MINUTE = 60000, MS_HOUR = 3600000, MS_DAY = 86400000;
  function pad2(n, w) { return String(n).padStart(w || 2, "0"); }
  function dateFormat(ts, fmt) {
    const d = new Date(ts);
    fmt = isNil(fmt) ? "YYYY-MM-DD hh:mm:ss" : toStr(fmt);
    const map = {
      YYYY: String(d.getUTCFullYear()), YY: pad2(d.getUTCFullYear() % 100), MM: pad2(d.getUTCMonth() + 1), DD: pad2(d.getUTCDate()),
      HH: pad2(d.getUTCHours()), hh: pad2(d.getUTCHours()), mm: pad2(d.getUTCMinutes()), ss: pad2(d.getUTCSeconds()), SSS: pad2(d.getUTCMilliseconds(), 3),
    };
    return fmt.replace(/YYYY|YY|MM|DD|HH|hh|mm|ss|SSS/g, (t) => map[t]);
  }
  function dateParse(s, fmt) {
    s = toStr(s);
    if (!isNil(fmt)) {
      fmt = toStr(fmt);
      const parts = { YYYY: 1970, MM: 1, DD: 1, hh: 0, HH: 0, mm: 0, ss: 0 };
      const re = /YYYY|MM|DD|HH|hh|mm|ss/g;
      let m, rx = "", last = 0;
      const order = [];
      while ((m = re.exec(fmt))) { rx += fmt.slice(last, m.index).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + (m[0] === "YYYY" ? "(\\d{4})" : "(\\d{1,2})"); order.push(m[0]); last = m.index + m[0].length; }
      rx += fmt.slice(last).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const mm = new RegExp("^" + rx + "$").exec(s.trim());
      if (!mm) return null;
      order.forEach((k, i) => { parts[k] = Number(mm[i + 1]); });
      return Date.UTC(parts.YYYY, parts.MM - 1, parts.DD, parts.hh || parts.HH, parts.mm, parts.ss);
    }
    let t = /^\d{4}-\d{2}-\d{2}$/.test(s) ? Date.parse(s + "T00:00:00Z") : Date.parse(s);
    if (Number.isNaN(t)) t = Date.parse(s + "Z");
    return Number.isNaN(t) ? null : t;
  }
  function dateParts(ts) {
    const d = new Date(ts);
    return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(), ms: d.getUTCMilliseconds() };
  }

  function mkRegex(pattern, global) {
    let p = toStr(pattern), flags = "";
    const m = /^\(\?([imsu]+)\)/.exec(p);
    if (m) { flags += m[1]; p = p.slice(m[0].length); }
    try { return new RegExp(p, flags + (global ? "g" : "")); } catch (e) { throw new ArcThrow("Invalid regex: " + e.message); }
  }

  function parseCsv(text, sep) {
    text = toStr(text); sep = isNil(sep) ? "," : toStr(sep);
    const rows = [];
    let row = [], cell = "", inQ = false, i = 0, any = false;
    while (i < text.length) {
      const c = text[i];
      if (inQ) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i += 2; continue; } inQ = false; i++; continue; }
        cell += c; i++; continue;
      }
      if (c === '"' && cell === "") { inQ = true; any = true; i++; continue; }
      if (text.startsWith(sep, i)) { row.push(cell); cell = ""; any = true; i += sep.length; continue; }
      if (c === "\r" && text[i + 1] === "\n") { i++; continue; }
      if (c === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; any = false; i++; continue; }
      cell += c; any = true; i++;
    }
    if (any || cell !== "" || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }
  function csvEscape(s, sep) {
    s = toStr(s);
    return s.includes(sep) || s.includes('"') || s.includes("\n") ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  function yamlParse(text) {
    const lines = toStr(text).split(/\r?\n/).map((l) => l.replace(/\s+#.*$/, "")).filter((l) => l.trim() !== "" && !/^\s*#/.test(l) && l.trim() !== "---");
    let idx = 0;
    function scalar(s) {
      s = s.trim();
      if (s === "" || s === "~" || s === "null") return null;
      if (s === "true") return true;
      if (s === "false") return false;
      if (/^-?\d+$/.test(s)) return parseInt(s, 10);
      if (/^-?\d*\.\d+([eE][+-]?\d+)?$/.test(s)) return parseFloat(s);
      if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1);
      if (s.startsWith("[") && s.endsWith("]")) { const inner = s.slice(1, -1).trim(); return inner === "" ? [] : inner.split(",").map(scalar); }
      if (s.startsWith("{") && s.endsWith("}")) { const o = {}; const inner = s.slice(1, -1).trim(); if (inner) for (const part of inner.split(",")) { const k = part.indexOf(":"); defineKey(o, part.slice(0, k).trim(), scalar(part.slice(k + 1))); } return o; }
      return s;
    }
    const indentOf = (l) => l.match(/^ */)[0].length;
    function block(indent) {
      if (idx >= lines.length) return null;
      const first = lines[idx];
      if (first.trim().startsWith("- ") || first.trim() === "-") {
        const arr = [];
        while (idx < lines.length && indentOf(lines[idx]) === indent && (lines[idx].trim().startsWith("- ") || lines[idx].trim() === "-")) {
          const rest = lines[idx].trim().slice(1).trim();
          idx++;
          if (rest === "") arr.push(block(idx < lines.length ? indentOf(lines[idx]) : indent + 2));
          else if (/^[^"'\[{][^:]*:(\s|$)/.test(rest)) {
            const o = {};
            const k = rest.indexOf(":");
            const key = rest.slice(0, k).trim(), val = rest.slice(k + 1).trim();
            if (val === "") defineKey(o, key, idx < lines.length && indentOf(lines[idx]) > indent + 2 ? block(indentOf(lines[idx])) : null);
            else defineKey(o, key, scalar(val));
            while (idx < lines.length && indentOf(lines[idx]) === indent + 2 && !lines[idx].trim().startsWith("- ")) {
              const l = lines[idx].trim(); const kk = l.indexOf(":");
              const k2 = l.slice(0, kk).trim(), v2 = l.slice(kk + 1).trim();
              idx++;
              if (v2 === "") defineKey(o, k2, idx < lines.length && indentOf(lines[idx]) > indent + 2 ? block(indentOf(lines[idx])) : null);
              else defineKey(o, k2, scalar(v2));
            }
            arr.push(o);
          } else arr.push(scalar(rest));
        }
        return arr;
      }
      const obj = {};
      while (idx < lines.length && indentOf(lines[idx]) === indent) {
        const l = lines[idx].trim();
        const k = l.indexOf(":");
        if (k < 0) { idx++; continue; }
        const key = l.slice(0, k).trim().replace(/^["']|["']$/g, ""), val = l.slice(k + 1).trim();
        idx++;
        if (val === "" ) {
          if (idx < lines.length && indentOf(lines[idx]) > indent) defineKey(obj, key, block(indentOf(lines[idx])));
          else if (idx < lines.length && indentOf(lines[idx]) === indent && lines[idx].trim().startsWith("- ")) defineKey(obj, key, block(indent));
          else defineKey(obj, key, null);
        } else if (val === "|" || val === ">") {
          const parts = [];
          while (idx < lines.length && indentOf(lines[idx]) > indent) { parts.push(lines[idx].trim()); idx++; }
          defineKey(obj, key, parts.join(val === "|" ? "\n" : " "));
        } else defineKey(obj, key, scalar(val));
      }
      return obj;
    }
    if (!lines.length) return null;
    if (lines.length === 1 && !/:(\s|$)/.test(lines[0]) && !lines[0].trim().startsWith("- ")) return scalar(lines[0]);
    return block(indentOf(lines[0]));
  }
  function yamlScalar(v) {
    if (isNil(v)) return "null";
    if (typeof v === "string") return /^[\w./@-][\w ./@-]*$/.test(v) && !/^(true|false|null|-?\d+(\.\d+)?)$/.test(v) && v.trim() === v ? v : JSON.stringify(v);
    return toStr(v);
  }
  function yamlStringify(v, indent) {
    indent = indent || 0;
    const pad = " ".repeat(indent);
    if (Array.isArray(v)) {
      if (!v.length) return pad + "[]\n";
      return v.map((x) => (x !== null && typeof x === "object" && Object.keys(x).length ? pad + "-\n" + yamlStringify(x, indent + 2) : pad + "- " + yamlScalar(x) + "\n")).join("");
    }
    if (isMap(v)) {
      const ks = Object.keys(v);
      if (!ks.length) return pad + "{}\n";
      return ks.map((k) => {
        const x = v[k];
        if (x !== null && typeof x === "object" && (Array.isArray(x) ? x.length : Object.keys(x).length)) return pad + k + ":\n" + yamlStringify(x, indent + 2);
        if (Array.isArray(x)) return pad + k + ": []\n";
        if (isMap(x)) return pad + k + ": {}\n";
        return pad + k + ": " + yamlScalar(x) + "\n";
      }).join("");
    }
    return pad + yamlScalar(v) + "\n";
  }

  function tomlValue(s, lineNo) {
    s = s.trim();
    const bad = (why) => { throw new ArcThrow("Invalid TOML" + (lineNo ? " at line " + lineNo : "") + ": " + why); };
    if (s.startsWith('"') && !s.startsWith('"""')) {
      let i = 1;
      for (; i < s.length && s[i] !== '"'; i++) if (s[i] === "\\") i++;
      if (i >= s.length) bad("unterminated string");
      if (s.slice(i + 1).replace(/\s+#.*$/, "").trim() !== "") bad("unexpected text after string");
    }
    if (s.startsWith("'") && !s.startsWith("'''") && s.indexOf("'", 1) < 0) bad("unterminated string");
    if ((s.startsWith("[") && !balanced(s)) || (s.startsWith("{") && !balanced(s))) bad("unterminated array or table");
    if (s.startsWith('"""')) return s.slice(3, s.lastIndexOf('"""'));
    if (s.startsWith('"')) {
      let out = "", i = 1;
      for (; i < s.length && s[i] !== '"'; i++) {
        if (s[i] === "\\") { i++; const c = s[i]; out += c === "n" ? "\n" : c === "t" ? "\t" : c === "r" ? "\r" : c; }
        else out += s[i];
      }
      return out;
    }
    if (s.startsWith("'")) return s.slice(1, s.indexOf("'", 1));
    if (s === "true") return true;
    if (s === "false") return false;
    if (s.startsWith("[")) {
      const inner = s.slice(1, s.lastIndexOf("]"));
      return splitTop(inner, ",").map((x) => x.trim()).filter((x) => x !== "").map(tomlValue);
    }
    if (s.startsWith("{")) {
      const inner = s.slice(1, s.lastIndexOf("}"));
      const o = {};
      for (const part of splitTop(inner, ",")) {
        if (!part.trim()) continue;
        const k = part.indexOf("=");
        defineKey(o, part.slice(0, k).trim().replace(/^["']|["']$/g, ""), tomlValue(part.slice(k + 1)));
      }
      return o;
    }
    const cleaned = s.replace(/\s+#.*$/, "").replace(/_/g, "");
    if (/^[+-]?\d+$/.test(cleaned)) return parseInt(cleaned, 10);
    if (/^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(cleaned)) return parseFloat(cleaned);
    if (/^0x[0-9a-fA-F]+$/.test(cleaned)) return parseInt(cleaned.slice(2), 16);
    if (/^0o[0-7]+$/.test(cleaned)) return parseInt(cleaned.slice(2), 8);
    if (/^0b[01]+$/.test(cleaned)) return parseInt(cleaned.slice(2), 2);
    if (/^[+-]?(inf|nan)$/.test(cleaned)) return cleaned.endsWith("nan") ? NaN : (cleaned.startsWith("-") ? -Infinity : Infinity);
    const bare = s.replace(/\s+#.*$/, "");
    // dates / times are kept as strings
    if (/^\d{4}-\d{2}-\d{2}([Tt ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?)?([Zz]|[+-]\d{2}:\d{2})?$/.test(bare) || /^\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(bare)) return bare;
    bad("invalid value '" + bare + "'");
  }
  function splitTop(s, sep) {
    const out = []; let depth = 0, q = null, start = 0;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === "\\") { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'") q = c;
      else if (c === "[" || c === "{") depth++;
      else if (c === "]" || c === "}") depth--;
      else if (c === sep && depth === 0) { out.push(s.slice(start, i)); start = i + 1; }
    }
    out.push(s.slice(start));
    return out;
  }
  function stripTomlComment(line) {
    let q = null;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) { if (c === "\\" && q === '"') { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'") q = c;
      else if (c === "#") return line.slice(0, i);
    }
    return line;
  }
  function tomlParse(text) {
    const root = {};
    let cur = root;
    const lines = toStr(text).split(/\r?\n/);
    for (let li = 0; li < lines.length; li++) {
      let line = stripTomlComment(lines[li]).trim();
      if (!line) continue;
      let m;
      if ((m = /^\[\[\s*([^\]]+?)\s*\]\]$/.exec(line))) {
        const parts = m[1].split(".").map((p) => p.trim().replace(/^["']|["']$/g, ""));
        let o = root;
        for (let i = 0; i < parts.length - 1; i++) { if (!isMap(o[parts[i]])) defineKey(o, parts[i], {}); o = o[parts[i]]; }
        const last = parts[parts.length - 1];
        if (!Array.isArray(o[last])) defineKey(o, last, []);
        const item = {};
        o[last].push(item);
        cur = item;
        continue;
      }
      if ((m = /^\[\s*([^\]]+?)\s*\]$/.exec(line))) {
        cur = root;
        for (const part of m[1].split(".").map((p) => p.trim().replace(/^["']|["']$/g, ""))) {
          if (!isMap(cur[part])) defineKey(cur, part, {});
          cur = cur[part];
        }
        continue;
      }
      if (line.startsWith("[")) throw new ArcThrow("Invalid TOML at line " + (li + 1) + ": malformed table header '" + line + "'");
      const eqi = line.indexOf("=");
      if (eqi < 0) throw new ArcThrow("Invalid TOML at line " + (li + 1) + ": expected 'key = value'");
      const keyPath = line.slice(0, eqi).trim();
      if (!keyPath || !/^(?:[A-Za-z0-9_-]+|"[^"]*"|'[^']*')(?:\s*\.\s*(?:[A-Za-z0-9_-]+|"[^"]*"|'[^']*'))*$/.test(keyPath)) throw new ArcThrow("Invalid TOML at line " + (li + 1) + ": invalid key '" + keyPath + "'");
      let val = line.slice(eqi + 1).trim();
      if (val === "") throw new ArcThrow("Invalid TOML at line " + (li + 1) + ": missing value for '" + keyPath + "'");
      // multi-line arrays / strings
      if ((val.startsWith("[") && !balanced(val)) || (val.startsWith('"""') && val.indexOf('"""', 3) < 0)) {
        while (li + 1 < lines.length) {
          li++;
          val += "\n" + (val.startsWith('"""') ? lines[li] : stripTomlComment(lines[li]));
          if (val.startsWith('"""') ? val.indexOf('"""', 3) >= 0 : balanced(val)) break;
        }
        if (val.startsWith('"""')) val = val.replace(/^"""\n?/, '"""');
      }
      const keys = splitTop(keyPath, ".").map((k) => k.trim().replace(/^["']|["']$/g, ""));
      let o = cur;
      for (let i = 0; i < keys.length - 1; i++) { if (!isMap(o[keys[i]])) defineKey(o, keys[i], {}); o = o[keys[i]]; }
      const lastKey = keys[keys.length - 1];
      if (hasOwn.call(o, lastKey)) throw new ArcThrow("Invalid TOML at line " + (li + 1) + ": duplicate key '" + keyPath + "'");
      defineKey(o, lastKey, tomlValue(val, li + 1));
    }
    return root;
  }
  function balanced(s) {
    let d = 0, q = null;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === "\\") { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'") q = c; else if (c === "[" || c === "{") d++; else if (c === "]" || c === "}") d--;
    }
    return d <= 0;
  }
  function tomlScalar(v) {
    if (typeof v === "string") return JSON.stringify(v);
    if (Array.isArray(v)) return "[" + v.map(tomlScalar).join(", ") + "]";
    if (isMap(v)) return "{ " + Object.keys(v).map((k) => k + " = " + tomlScalar(v[k])).join(", ") + " }";
    if (isNil(v)) return '""';
    return toStr(v);
  }
  function tomlStringify(obj, prefix) {
    if (!isMap(obj)) return tomlScalar(obj);
    const simple = [], tables = [];
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      if (isMap(v)) tables.push(k); else simple.push(k + " = " + tomlScalar(v));
    }
    let out = simple.join("\n");
    for (const k of tables) {
      const name = prefix ? prefix + "." + k : k;
      const body = tomlStringify(obj[k], name);
      out += (out ? "\n\n" : "") + "[" + name + "]" + (body ? "\n" + body : "");
    }
    return out;
  }

  const VOID_TAGS = new Set(["br", "hr", "img", "input", "meta", "link", "area", "base", "col", "embed", "source", "track", "wbr"]);
  function htmlDecode(s) { return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&"); }
  function htmlEscape(s) { return toStr(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function htmlParse(src) {
    src = toStr(src);
    const root = { tag: "root", attrs: {}, children: [] };
    const stack = [root];
    const re = /<!--[\s\S]*?-->|<\/\s*([a-zA-Z][\w-]*)\s*>|<([a-zA-Z][\w-]*)((?:\s+[^\s=>\/]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?)>|([^<]+)/g;
    let m;
    while ((m = re.exec(src))) {
      const top = stack[stack.length - 1];
      if (m[0].startsWith("<!--")) continue;
      if (m[1]) {
        const tag = m[1].toLowerCase();
        for (let i = stack.length - 1; i > 0; i--) if (stack[i].tag === tag) { stack.length = i; break; }
      } else if (m[2]) {
        const tag = m[2].toLowerCase();
        const attrs = {};
        const ar = /([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
        let a;
        while ((a = ar.exec(m[3] || ""))) defineKey(attrs, a[1], htmlDecode(a[2] ?? a[3] ?? a[4] ?? ""));
        const node = { tag, attrs, children: [] };
        top.children.push(node);
        if (!m[4] && !VOID_TAGS.has(tag)) stack.push(node);
      } else if (m[5] !== undefined) {
        if (m[5].trim() !== "") top.children.push(htmlDecode(m[5]));
      }
    }
    return root;
  }
  function htmlText(node) {
    if (isNil(node)) return "";
    if (typeof node === "string") return node;
    if (Array.isArray(node)) return node.map(htmlText).join("");
    return (node.children || []).map(htmlText).join("");
  }
  function htmlMatches(node, sel) {
    if (typeof node !== "object" || node === null || !node.tag) return false;
    const m = /^([a-zA-Z][\w-]*)?(?:#([\w-]+))?((?:\.[\w-]+)*)(?:\[([\w-]+)(?:=["']?([^"'\]]*)["']?)?\])?$/.exec(sel.trim());
    if (!m) return false;
    if (m[1] && node.tag !== m[1].toLowerCase()) return false;
    const attrs = node.attrs || {};
    if (m[2] && attrs.id !== m[2]) return false;
    if (m[3]) { const cls = String(attrs.class || "").split(/\s+/); for (const c of m[3].split(".").filter(Boolean)) if (!cls.includes(c)) return false; }
    if (m[4]) { if (!hasOwn.call(attrs, m[4])) return false; if (m[5] !== undefined && attrs[m[4]] !== m[5]) return false; }
    return true;
  }
  function htmlSelect(node, selector) {
    const parts = toStr(selector).trim().split(/\s+/);
    let current = [node];
    for (const part of parts) {
      const next = [];
      const walk = (n) => { for (const c of (n && n.children) || []) { if (htmlMatches(c, part) && !next.includes(c)) next.push(c); walk(c); } };
      for (const n of current) walk(n);
      current = next;
    }
    return current;
  }
  function htmlRender(node) {
    if (isNil(node)) return "";
    if (typeof node === "string") return htmlEscape(node);
    if (Array.isArray(node)) return node.map(htmlRender).join("");
    if (node.tag === "root") return (node.children || []).map(htmlRender).join("");
    const attrs = node.attrs || {};
    const a = Object.keys(attrs).map((k) => " " + k + '="' + htmlEscape(attrs[k]) + '"').join("");
    if (VOID_TAGS.has(node.tag)) return "<" + node.tag + a + ">";
    return "<" + node.tag + a + ">" + (node.children || []).map(htmlRender).join("") + "</" + node.tag + ">";
  }

  const logState = { level: "debug" };
  const LOG_LEVELS = { debug: 0, info: 1, warn: 2, error: 3, fatal: 4 };
  function logEmit(level, msg, fields) {
    if ((LOG_LEVELS[level] ?? 0) < (LOG_LEVELS[logState.level] ?? 0)) return null;
    let line = "[" + level.toUpperCase() + "] " + toStr(msg);
    if (fields && isMap(fields) && Object.keys(fields).length) line += " " + Object.keys(fields).map((k) => k + "=" + toStr(fields[k])).join(" ");
    if (level === "error" || level === "warn" || level === "fatal") { if (rt.errorOutput) rt.errorOutput(line); else console.error(line); }
    else { if (rt.output) rt.output(line); else console.log(line); }
    return null;
  }

  const stores = {};
  function storeLoad(s) {
    const path = isMap(s) ? s.path : toStr(s);
    if (!stores[path]) {
      const fs = getNode("fs");
      let data = {};
      try { data = JSON.parse(fs.readFileSync(path, "utf8")); } catch (e) { data = {}; }
      stores[path] = data;
    }
    return { path, data: stores[path] };
  }
  function storeSave(st) { try { getNode("fs").writeFileSync(st.path, JSON.stringify(st.data, null, 2)); } catch (e) { /* ignore */ } }

  function vecDot(a, b) { let s = 0; for (let i = 0; i < Math.min(a.length, b.length); i++) s += a[i] * b[i]; return s; }
  function vecMag(a) { return Math.sqrt(vecDot(a, a)); }
  function cosine(a, b) { const m = vecMag(a) * vecMag(b); return m === 0 ? 0 : vecDot(a, b) / m; }

  const testState = { passed: 0, failed: 0, group: "", failures: [] };

  const moduleFactories = {
    math: () => ({
      PI: Math.PI, E: Math.E, TAU: Math.PI * 2, INF: Infinity, INFINITY: Infinity, NAN: NaN,
      abs: (x) => Math.abs(x),
      sign: (x) => (x > 0 ? 1 : x < 0 ? -1 : 0),
      clamp: (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x),
      ceil: (x) => Math.ceil(x), floor: (x) => Math.floor(x), round: roundTo, trunc: (x) => Math.trunc(x),
      pow: (b, e) => { if (e < 0 && b === 0) return null; return Math.pow(b, e); },
      sqrt: (x) => (x < 0 ? null : Math.sqrt(x)),
      cbrt: (x) => Math.cbrt(x), hypot: (a, b) => Math.hypot(a, b),
      sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan, atan2: Math.atan2,
      degrees: (r) => (r * 180) / Math.PI, radians: (d) => (d * Math.PI) / 180,
      log: (x, base) => (isNil(base) ? Math.log(x) : Math.log(x) / Math.log(base)), log2: Math.log2, log10: Math.log10, exp: Math.exp,
      factorial: (n) => { if (n < 0) return null; let r = 1; for (let i = 2; i <= n; i++) r *= i; return Number.isFinite(r) ? r : null; },
      gcd: (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) { const t = b; b = a % b; a = t; } return a; },
      lcm: (a, b) => { const g = moduleFactories.math().gcd(a, b); return g === 0 ? 0 : Math.abs((a / g) * b); },
      sum: (xs) => needList(xs, "sum").reduce((a, x) => (typeof x === "number" ? a + x : a), 0),
      product: (xs) => needList(xs, "product").reduce((a, x) => a * x, 1),
      min: (...a) => minMax(a, -1, "min"), max: (...a) => minMax(a, 1, "max"),
      mean: (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null),
      avg: (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null),
      random: () => Math.random(),
      random_int: (lo, hi) => lo + Math.floor(Math.random() * (hi - lo + 1)),
      is_nan: (x) => Number.isNaN(x), is_finite: (x) => Number.isFinite(x),
    }),
    strings: () => ({
      pad_left: (s, w, ch) => { s = toStr(s); ch = isNil(ch) ? " " : toStr(ch); if (!ch) return s; ch = Array.from(ch)[0]; while (strLen(s) < w) s = ch + s; return s; },
      pad_right: (s, w, ch) => { s = toStr(s); ch = isNil(ch) ? " " : toStr(ch); if (!ch) return s; ch = Array.from(ch)[0]; while (strLen(s) < w) s = s + ch; return s; },
      center: (s, w, ch) => { s = toStr(s); ch = isNil(ch) ? " " : toStr(ch); let left = true; while (strLen(s) < w) { s = left ? s + ch : ch + s; left = !left; } return s; },
      capitalize: (s) => { s = toStr(s); if (!s) return ""; const cs = Array.from(s); return cs[0].toUpperCase() + cs.slice(1).join("").toLowerCase(); },
      title: (s) => toStr(s).split(" ").map((w) => (w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w)).join(" "),
      words: (s) => toStr(s).split(" ").map((w) => w.trim()).filter((w) => w.length > 0),
      reverse: (s) => Array.from(toStr(s)).reverse().join(""),
      is_empty: (s) => toStr(s).length === 0,
      is_blank: (s) => toStr(s).trim().length === 0,
      truncate: (s, n, suffix) => { s = toStr(s); suffix = isNil(suffix) ? "..." : toStr(suffix); return strLen(s) <= n ? s : slice(s, 0, Math.max(0, n - strLen(suffix))) + suffix; },
      count: (s, sub) => { s = toStr(s); sub = toStr(sub); if (!sub) return 0; return s.split(sub).length - 1; },
      snake_case: (s) => toStr(s).replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[\s-]+/g, "_").toLowerCase(),
      kebab_case: (s) => toStr(s).replace(/([a-z0-9])([A-Z])/g, "$1-$2").replace(/[\s_]+/g, "-").toLowerCase(),
      camel_case: (s) => toStr(s).toLowerCase().replace(/[_\s-]+(.)/g, (_, c) => c.toUpperCase()),
      is_digit: (s) => /^\d+$/.test(toStr(s)),
      is_alpha: (s) => /^[A-Za-z]+$/.test(toStr(s)),
      is_alnum: (s) => /^[A-Za-z0-9]+$/.test(toStr(s)),
      is_upper: (s) => toStr(s) === toStr(s).toUpperCase() && /[A-Z]/.test(toStr(s)),
      is_lower: (s) => toStr(s) === toStr(s).toLowerCase() && /[a-z]/.test(toStr(s)),
      lines: (s) => toStr(s).split(/\r?\n/),
      repeat: (s, n) => (n > 0 ? toStr(s).repeat(n) : ""),
      trim: (s) => toStr(s).trim(), upper: (s) => toStr(s).toUpperCase(), lower: (s) => toStr(s).toLowerCase(),
      split: builtins.split, join: builtins.join, replace: builtins.replace, contains: (s, x) => toStr(s).includes(toStr(x)),
      starts_with: builtins.starts_with, ends_with: builtins.ends_with, index_of: indexOf, chars: builtins.chars, slice,
    }),
    collections: () => {
      const keyOf = (f, x) => toStr(f(x));
      const c = {
        set: (xs) => builtins.unique(xs),
        unique: (xs) => builtins.unique(xs),
        group_by: (xs, f) => { const r = {}; for (const x of needList(xs, "group_by")) { const k = keyOf(f, x); if (!hasOwn.call(r, k)) defineKey(r, k, []); r[k].push(x); } return r; },
        count_by: (xs, f) => { const r = {}; for (const x of needList(xs, "count_by")) { const k = keyOf(f, x); defineKey(r, k, (hasOwn.call(r, k) ? r[k] : 0) + 1); } return r; },
        chunk: (xs, n) => { const a = needList(xs, "chunk"); if (n <= 0) return []; const out = []; for (let i = 0; i < a.length; i += n) out.push(a.slice(i, i + n)); return out; },
        flatten: (xs) => builtins.flat(xs),
        flatten_deep: (xs) => needList(xs, "flatten_deep").flat(Infinity),
        zip_with: (a, b, f) => builtins.zip(a, b).map((p) => f(p[0], p[1])),
        partition: (xs, f) => { const y = [], n = []; for (const x of needList(xs, "partition")) (truthy(f(x)) ? y : n).push(x); return [y, n]; },
        frequencies: (xs) => { const r = {}; for (const x of needList(xs, "frequencies")) { const k = toStr(x); defineKey(r, k, (hasOwn.call(r, k) ? r[k] : 0) + 1); } return r; },
        min_by: (xs, f) => { const a = needList(xs, "min_by"); if (!a.length) return null; let best = a[0], bv = f(best); for (let i = 1; i < a.length; i++) { const v = f(a[i]); if (compare(v, bv) < 0) { best = a[i]; bv = v; } } return best; },
        max_by: (xs, f) => { const a = needList(xs, "max_by"); if (!a.length) return null; let best = a[0], bv = f(best); for (let i = 1; i < a.length; i++) { const v = f(a[i]); if (compare(v, bv) > 0) { best = a[i]; bv = v; } } return best; },
        sort_by: (xs, f) => { if (arityOf(f) >= 2) fail("sort_by takes a key function fn(x) that returns a sort key, not a comparator fn(a, b). Example: sort_by(list, fn(x) => x.name)"); return sortList(xs, (x) => f(x)); },
        index_of: (xs, v) => { const i = indexOf(xs, v); return i < 0 ? null : i; },
        includes: (xs, v) => contains(xs, v),
        take_while: (xs, f) => { const out = []; for (const x of needList(xs, "take_while")) { if (!truthy(f(x))) break; out.push(x); } return out; },
        drop_while: (xs, f) => { const a = needList(xs, "drop_while"); let i = 0; while (i < a.length && truthy(f(a[i]))) i++; return a.slice(i); },
        window: (xs, n) => { const a = needList(xs, "window"); const out = []; for (let i = 0; i + n <= a.length; i++) out.push(a.slice(i, i + n)); return out; },
        sliding: (xs, n) => c.window(xs, n),
        compact: (xs) => needList(xs, "compact").filter((x) => !isNil(x)),
        sum_by: (xs, f) => needList(xs, "sum_by").reduce((a, x) => add(a, f(x)), 0),
        interleave: (a, b) => { const out = []; for (let i = 0; i < Math.max(a.length, b.length); i++) { if (i < a.length) out.push(a[i]); if (i < b.length) out.push(b[i]); } return out; },
        rotate: (xs, n) => { const a = needList(xs, "rotate"); if (!a.length) return []; const k = ((n % a.length) + a.length) % a.length; return a.slice(k).concat(a.slice(0, k)); },
        difference: (a, b) => needList(a, "difference").filter((x) => !contains(b, x)),
        intersection: (a, b) => builtins.unique(needList(a, "intersection").filter((x) => contains(b, x))),
        union: (a, b) => builtins.unique(needList(a, "union").concat(needList(b, "union"))),
        range: builtins.range,
      };
      return c;
    },
    map: () => ({
      merge: (...ms) => Object.assign({}, ...ms.filter((m) => !isNil(m))),
      map_values: (m, f) => { const r = {}; for (const k of Object.keys(m)) defineKey(r, k, f(m[k])); return r; },
      map_keys: (m, f) => { const r = {}; for (const k of Object.keys(m)) defineKey(r, toStr(f(k)), m[k]); return r; },
      filter_map: (m, f) => { const r = {}; for (const k of Object.keys(m)) if (truthy(arityOf(f) >= 2 ? f(k, m[k]) : f(m[k]))) defineKey(r, k, m[k]); return r; },
      filter_keys: (m, f) => { const r = {}; for (const k of Object.keys(m)) if (truthy(f(k))) defineKey(r, k, m[k]); return r; },
      from_pairs: (ps) => { const r = {}; for (const p of needList(ps, "from_pairs")) { if (Array.isArray(p)) defineKey(r, toStr(p[0]), p[1]); else if (isMap(p)) defineKey(r, toStr(p.key), p.value); } return r; },
      to_pairs: (m) => Object.keys(m).map((k) => [k, m[k]]),
      pick: (m, ks) => { const r = {}; for (const k of needList(ks, "pick")) if (hasOwn.call(m, toStr(k))) defineKey(r, toStr(k), m[toStr(k)]); return r; },
      omit: (m, ks) => { const r = {}; const set = needList(ks, "omit").map(toStr); for (const k of Object.keys(m)) if (!set.includes(k)) defineKey(r, k, m[k]); return r; },
      has_key: (m, k) => isMap(m) && hasOwn.call(m, toStr(k)),
      get: (m, k, d) => { const v = isMap(m) && hasOwn.call(m, toStr(k)) ? m[toStr(k)] : undefined; return isNil(v) ? nil(d) : v; },
      get_in: (m, path, d) => { let cur = m; for (const k of needList(path, "get_in")) { cur = isNil(cur) ? null : getIndex(cur, k); } return isNil(cur) ? nil(d) : cur; },
      set: (m, k, v) => { const r = Object.assign({}, m); defineKey(r, toStr(k), v); return r; },
      remove: (m, k) => { const r = Object.assign({}, m); delete r[toStr(k)]; return r; },
      invert: (m) => { const r = {}; for (const k of Object.keys(m)) defineKey(r, toStr(m[k]), k); return r; },
      keys: builtins.keys, values: builtins.values, entries: builtins.entries,
      size: (m) => Object.keys(m).length,
      is_empty: (m) => Object.keys(m).length === 0,
    }),
    json: () => ({
      to_json: jsonStringify, stringify: jsonStringify, encode: jsonStringify,
      from_json: jsonParse, parse: jsonParse, decode: jsonParse,
      pretty: (v) => JSON.stringify(jsonClean(v), null, 2),
      get_path: (obj, path) => {
        let cur = obj;
        for (const part of toStr(path).split(".")) {
          if (isMap(cur)) cur = hasOwn.call(cur, part) ? cur[part] : null;
          else if (Array.isArray(cur)) cur = /^-?\d+$/.test(part) ? getIndex(cur, Number(part)) : null;
          else cur = null;
        }
        return nil(cur);
      },
      is_valid: (s) => { try { JSON.parse(toStr(s)); return true; } catch (e) { return false; } },
    }),
    csv: () => ({
      parse_csv: (t, sep) => parseCsv(t, sep),
      parse: (t, sep) => parseCsv(t, sep),
      parse_csv_headers: (t, sep) => {
        const rows = parseCsv(t, sep);
        if (rows.length < 2) return [];
        const headers = rows[0].map((h) => h.trim());
        return rows.slice(1).map((cells) => { const r = {}; headers.forEach((h, i) => defineKey(r, h, i < cells.length ? cells[i] : "")); return r; });
      },
      to_csv: (rows, sep) => {
        sep = isNil(sep) ? "," : toStr(sep);
        rows = needList(rows, "to_csv");
        if (!rows.length) return "";
        if (isMap(rows[0])) {
          const hs = Object.keys(rows[0]);
          return [hs.map((h) => csvEscape(h, sep)).join(sep)].concat(rows.map((r) => hs.map((h) => csvEscape(r[h], sep)).join(sep))).join("\n");
        }
        return rows.map((r) => needList(r, "to_csv").map((c) => csvEscape(c, sep)).join(sep)).join("\n");
      },
    }),
    result: () => ({
      ok: Ok, err: Err, Ok, Err,
      is_ok: builtins.is_ok, is_err: builtins.is_err, unwrap, unwrap_or: builtins.unwrap_or, unwrap_err: builtins.unwrap_err,
      map: builtins.map_result, map_result: builtins.map_result,
      map_err: (r, f) => (isResult(r) && !r.ok ? Err(f(r.error)) : r),
      flat_map: (r, f) => (isResult(r) && r.ok ? f(r.value) : r),
      and_then: (r, f) => (isResult(r) && r.ok ? f(r.value) : r),
      try_fn: (f) => { try { return Ok(f()); } catch (e) { return Err(errorMessage(e)); } },
      result_is_ok: builtins.is_ok, result_is_err: builtins.is_err, result_unwrap: unwrap, result_unwrap_or: builtins.unwrap_or,
      result_map: builtins.map_result, flat_map_result: (r, f) => (isResult(r) && r.ok ? f(r.value) : r),
    }),
    error: () => {
      const mk = (code, message) => (isNil(message) ? { __error: true, code: null, message: toStr(code) } : { __error: true, code, message: toStr(message) });
      const isErr = (v) => isMap(v) && v.__error === true;
      return {
        error: mk, new: mk, create: mk,
        is_error: isErr,
        wrap_error: (err, ctx) => ({ __error: true, code: isErr(err) ? err.code : null, message: toStr(ctx) + ": " + (isErr(err) ? err.message : toStr(err)), cause: err }),
        try_fn: (f) => { try { return Ok(f()); } catch (e) { return Err(errorMessage(e)); } },
        try_catch: (f, handler) => { try { const r = f(); return isErr(r) ? handler(r) : r; } catch (e) { return handler(errorMessage(e)); } },
        try_finally: (f, cleanup) => { try { return f(); } finally { cleanup(); } },
        try_catch_finally: (f, handler, cleanup) => { try { const r = f(); return isErr(r) ? handler(r) : r; } catch (e) { return handler(errorMessage(e)); } finally { cleanup(); } },
        throw: (code, message) => { throw new ArcThrow(isNil(message) ? (isErr(code) ? code.message : toStr(code)) : toStr(message)); },
        panic: (msg) => { throw new ArcThrow(toStr(msg)); },
        retry: (f, times) => {
          let last = null;
          const n = isNil(times) ? 3 : times;
          for (let i = 0; i < n; i++) {
            try { const r = f(); if (isResult(r) && !r.ok) { last = r; continue; } if (isErr(r)) { last = Err(r.message); continue; } return isResult(r) ? r : Ok(r); } catch (e) { last = Err(errorMessage(e)); }
          }
          return last || Err("retry failed");
        },
        assert: (cond, msg) => assert(cond, msg),
        message: (e) => (isErr(e) ? e.message : isResult(e) ? toStr(e.error) : toStr(e)),
      };
    },
    regex: () => ({
      find: (p, t) => { const m = mkRegex(p).exec(toStr(t)); return m ? m[0] : null; },
      match: (p, t) => { const m = mkRegex(p).exec(toStr(t)); return m ? m[0] : null; },
      find_all: (p, t) => Array.from(toStr(t).matchAll(mkRegex(p, true)), (m) => m[0]),
      match_all: (p, t) => Array.from(toStr(t).matchAll(mkRegex(p, true)), (m) => m[0]),
      test: (p, t) => mkRegex(p).test(toStr(t)),
      is_match: (p, t) => mkRegex(p).test(toStr(t)),
      replace: (p, t, r) => toStr(t).replace(mkRegex(p), toStr(r)),
      replace_first: (p, t, r) => toStr(t).replace(mkRegex(p), toStr(r)),
      replace_all: (p, t, r) => toStr(t).replace(mkRegex(p, true), toStr(r)),
      split: (p, t) => toStr(t).split(mkRegex(p)),
      capture: (p, t) => { const m = mkRegex(p).exec(toStr(t)); return m ? m.slice(1).map(nil) : null; },
      captures: (p, t) => { const m = mkRegex(p).exec(toStr(t)); return m ? m.slice(1).map(nil) : null; },
      capture_all: (p, t) => Array.from(toStr(t).matchAll(mkRegex(p, true)), (m) => m.slice(1).map(nil)),
      escape: (s) => toStr(s).replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&"),
      is_valid: (p) => { try { mkRegex(p); return true; } catch (e) { return false; } },
    }),
    datetime: () => ({
      now: () => Date.now(),
      today: () => dateParts(Date.now()),
      parse: (s, fmt) => dateParse(s, fmt),
      format: (ts, fmt) => dateFormat(ts, fmt),
      add_days: (ts, n) => ts + n * MS_DAY,
      add_hours: (ts, n) => ts + n * MS_HOUR,
      add_minutes: (ts, n) => ts + n * MS_MINUTE,
      add_seconds: (ts, n) => ts + n * 1000,
      diff_days: (a, b) => Math.trunc(Math.abs(a - b) / MS_DAY),
      diff_hours: (a, b) => Math.trunc(Math.abs(a - b) / MS_HOUR),
      diff_minutes: (a, b) => Math.trunc(Math.abs(a - b) / MS_MINUTE),
      day_of_week: (ts) => { const days = Math.trunc(ts / MS_DAY); return (((days + 4) % 7) + 7) % 7; },
      day_name: (ts) => ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][new Date(ts).getUTCDay()],
      is_before: (a, b) => a < b,
      is_after: (a, b) => a > b,
      to_iso: (ts) => new Date(ts).toISOString(),
      from_iso: (s) => { const t = Date.parse(toStr(s)); return Number.isNaN(t) ? null : t; },
      parts: (ts) => dateParts(ts),
      from_parts: (y, mo, d, h, mi, s) => Date.UTC(y, (mo || 1) - 1, d || 1, h || 0, mi || 0, s || 0),
      year: (ts) => new Date(ts).getUTCFullYear(), month: (ts) => new Date(ts).getUTCMonth() + 1, day: (ts) => new Date(ts).getUTCDate(),
    }),
    time: () => ({
      now: () => Date.now(),
      format_duration: (ms) => {
        const total = Math.trunc(ms / 1000), h = Math.trunc(total / 3600), m = Math.trunc((total % 3600) / 60), s = total % 60;
        let r = "";
        if (h > 0) r = h + "h ";
        if (m > 0) r += m + "m ";
        return r + s + "s";
      },
      sleep: (ms) => { sleepMs(ms); return null; },
      elapsed: (start) => Date.now() - start,
    }),
    os: () => {
      const os = getNode("os"), fs = getNode("fs"), path = getNode("path"), cp = getNode("child_process");
      const plat = () => { const p = typeof process !== "undefined" ? process.platform : "unknown"; return p === "win32" ? "windows" : p === "darwin" ? "macos" : p; };
      return {
        cwd: () => process.cwd(),
        get_env: (n) => nil(process.env[toStr(n)]),
        env: (n) => (isNil(n) ? Object.assign({}, process.env) : nil(process.env[toStr(n)])),
        set_env: (n, v) => { process.env[toStr(n)] = toStr(v); return null; },
        list_dir: (p) => { try { return fs.readdirSync(toStr(isNil(p) ? "." : p)).sort(); } catch (e) { return []; } },
        is_file: (p) => { try { return fs.statSync(toStr(p)).isFile(); } catch (e) { return false; } },
        is_dir: (p) => { try { return fs.statSync(toStr(p)).isDirectory(); } catch (e) { return false; } },
        exists: (p) => fs.existsSync(toStr(p)),
        mkdir: (p) => { fs.mkdirSync(toStr(p), { recursive: true }); return null; },
        rmdir: (p) => { fs.rmSync(toStr(p), { recursive: true, force: true }); return null; },
        remove: (p) => { try { fs.unlinkSync(toStr(p)); } catch (e) { /* ignore */ } return null; },
        rename: (a, b) => { fs.renameSync(toStr(a), toStr(b)); return null; },
        copy: (a, b) => { fs.copyFileSync(toStr(a), toStr(b)); return null; },
        file_size: (p) => { try { return fs.statSync(toStr(p)).size; } catch (e) { return null; } },
        file_ext: (p) => { const parts = toStr(p).split("."); return parts.length <= 1 ? "" : "." + parts[parts.length - 1]; },
        join_path: (...parts) => (parts.length === 1 && Array.isArray(parts[0]) ? parts[0] : parts).map(toStr).join("/"),
        parent_dir: (p) => { const parts = toStr(p).split("/"); return parts.length <= 1 ? "." : parts.slice(0, -1).join("/"); },
        basename: (p) => { const parts = toStr(p).split("/"); return parts[parts.length - 1]; },
        exec: (cmd) => {
          try { return cp.execSync(toStr(cmd), { encoding: "utf8", timeout: 10000, stdio: ["ignore", "pipe", "pipe"] }); }
          catch (e) { return toStr(e.stdout || "") + toStr(e.stderr || ""); }
        },
        platform: plat,
        home_dir: () => os.homedir(),
        temp_dir: () => os.tmpdir(),
        args: () => (typeof process !== "undefined" ? process.argv.slice(2) : []),
        pid: () => process.pid,
      };
    },
    io: () => {
      const fs = getNode("fs");
      return {
        read_file: (p) => { try { return fs.readFileSync(toStr(p), "utf8"); } catch (e) { return null; } },
        write_file: (p, c) => { fs.writeFileSync(toStr(p), toStr(c)); return null; },
        read_lines: (p) => { try { return fs.readFileSync(toStr(p), "utf8").split("\n"); } catch (e) { return []; } },
        write_lines: (p, lines) => { fs.writeFileSync(toStr(p), needList(lines, "write_lines").map(toStr).join("\n")); return null; },
        exists: (p) => fs.existsSync(toStr(p)),
        append: (p, c) => { fs.appendFileSync(toStr(p), toStr(c)); return null; },
        append_file: (p, c) => { fs.appendFileSync(toStr(p), toStr(c)); return null; },
        delete_file: (p) => { try { fs.unlinkSync(toStr(p)); } catch (e) { /* ignore */ } return null; },
        print: print,
      };
    },
    env: () => ({
      get: (k) => nil(process.env[toStr(k)]),
      get_or: (k, d) => { const v = process.env[toStr(k)]; return v === undefined ? nil(d) : v; },
      set: (k, v) => { process.env[toStr(k)] = toStr(v); return null; },
      remove: (k) => { delete process.env[toStr(k)]; return null; },
      has: (k) => process.env[toStr(k)] !== undefined,
      list: () => Object.assign({}, process.env),
      all: () => Object.assign({}, process.env),
      ["requ" + "ire"]: (k) => { const v = process.env[toStr(k)]; if (v === undefined) throw new ArcThrow("Environment variable is not set: " + toStr(k)); return v; },
    }),
    path: () => {
      const p = getNode("path");
      const pp = p ? p.posix || p : null;
      return {
        join: (...parts) => pp.join(...(parts.length === 1 && Array.isArray(parts[0]) ? parts[0] : parts).map(toStr)),
        dirname: (x) => pp.dirname(toStr(x)),
        basename: (x, ext) => pp.basename(toStr(x), isNil(ext) ? undefined : toStr(ext)),
        extname: (x) => pp.extname(toStr(x)),
        resolve: (...xs) => p.resolve(...xs.map(toStr)),
        normalize: (x) => pp.normalize(toStr(x)),
        is_absolute: (x) => pp.isAbsolute(toStr(x)),
        relative: (a, b) => pp.relative(toStr(a), toStr(b)),
        sep: () => "/",
        split: (x) => toStr(x).split("/").filter(Boolean),
      };
    },
    crypto: () => {
      const c = getNode("crypto");
      const hash = (alg, t) => c.createHash(alg).update(toStr(t)).digest("hex");
      return {
        md5: (t) => hash("md5", t), sha1: (t) => hash("sha1", t), sha256: (t) => hash("sha256", t), sha512: (t) => hash("sha512", t),
        hash: (alg, t) => hash(toStr(alg), t),
        hmac_sha256: (k, m) => c.createHmac("sha256", toStr(k)).update(toStr(m)).digest("hex"),
        hmac_sha512: (k, m) => c.createHmac("sha512", toStr(k)).update(toStr(m)).digest("hex"),
        random_bytes: (n) => { if (n < 0) throw new ArcThrow("random_bytes: n must be non-negative"); return c.randomBytes(n).toString("hex"); },
        random_int: (lo, hi) => { if (lo > hi) throw new ArcThrow("random_int: min must be <= max"); return c.randomInt(lo, hi + 1); },
        uuid: () => c.randomUUID(),
        base64_encode: (t) => Buffer.from(toStr(t), "utf8").toString("base64"),
        base64_decode: (t) => Buffer.from(toStr(t), "base64").toString("utf8"),
        hex_encode: (t) => Buffer.from(toStr(t), "utf8").toString("hex"),
        hex_decode: (t) => Buffer.from(toStr(t), "hex").toString("utf8"),
        hash_password: (pw, salt) => { salt = isNil(salt) ? "" : toStr(salt); let h = hash("sha256", salt + ":" + toStr(pw)); for (let i = 0; i < 100; i++) h = hash("sha256", h + salt); return h; },
        verify_password: (pw, salt, h) => { if (h === undefined) { h = salt; salt = ""; } salt = isNil(salt) ? "" : toStr(salt); let x = hash("sha256", salt + ":" + toStr(pw)); for (let i = 0; i < 100; i++) x = hash("sha256", x + salt); return x === h; },
        constant_time_eq: (a, b) => { a = toStr(a); b = toStr(b); if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; },
      };
    },
    net: () => ({
      url_parse: (u) => {
        try {
          const x = new URL(toStr(u));
          const query = {};
          x.searchParams.forEach((v, k) => defineKey(query, k, v));
          return { protocol: x.protocol.replace(/:$/, ""), host: x.hostname, port: x.port ? Number(x.port) : null, path: x.pathname, query, hash: x.hash.replace(/^#/, ""), href: x.href };
        } catch (e) { return null; }
      },
      url_encode: (s) => encodeURIComponent(toStr(s)),
      url_decode: (s) => decodeURIComponent(toStr(s)),
      parse_query: (q) => { const r = {}; new URLSearchParams(toStr(q).replace(/^\?/, "")).forEach((v, k) => defineKey(r, k, v)); return r; },
      build_query: (m) => Object.keys(m).map((k) => encodeURIComponent(k) + "=" + encodeURIComponent(toStr(m[k]))).join("&"),
      ip_is_valid: (a) => { const s = toStr(a); if (/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.test(s)) return s.split(".").every((x) => Number(x) <= 255); return /^[0-9a-fA-F:]+$/.test(s) && s.includes(":"); },
      base64_encode: (t) => Buffer.from(toStr(t), "utf8").toString("base64"),
      base64_decode: (t) => Buffer.from(toStr(t), "base64").toString("utf8"),
    }),
    yaml: () => ({ parse: yamlParse, stringify: (v) => yamlStringify(v) }),
    toml: () => ({ parse: tomlParse, stringify: (v) => tomlStringify(v) }),
    html: () => ({
      parse: htmlParse,
      select: htmlSelect,
      text: htmlText,
      attr: (n, name) => (n && n.attrs && hasOwn.call(n.attrs, toStr(name)) ? n.attrs[toStr(name)] : null),
      create: (tag, attrs, children) => ({ tag, attrs: isNil(attrs) ? {} : attrs, children: isNil(children) ? [] : children }),
      create_element: (tag, attrs, children) => ({ tag, attrs: isNil(attrs) ? {} : attrs, children: isNil(children) ? [] : children }),
      render: htmlRender,
      to_html: htmlRender,
      escape: htmlEscape,
    }),
    log: () => ({
      debug: (m) => logEmit("debug", m), info: (m) => logEmit("info", m), warn: (m) => logEmit("warn", m), error: (m) => logEmit("error", m),
      fatal: (m) => { logEmit("fatal", m); throw new ArcThrow(toStr(m)); },
      set_level: (l) => { logState.level = toStr(l); return null; },
      with: (fields) => Object.assign({}, fields),
      json: (level, msg, fields) => { const line = JSON.stringify(Object.assign({ level: toStr(level), msg: toStr(msg), time: new Date().toISOString() }, fields || {})); if (rt.output) rt.output(line); else console.log(line); return null; },
      child_debug: (l, m) => logEmit("debug", m, l), child_info: (l, m) => logEmit("info", m, l), child_warn: (l, m) => logEmit("warn", m, l), child_error: (l, m) => logEmit("error", m, l),
    }),
    prompt: () => ({
      template: (t, vars) => toStr(t).replace(/<<\s*([\w.]+)\s*>>/g, (m, k) => (vars && hasOwn.call(vars, k) ? toStr(vars[k]) : m)),
      token_count: (t) => Math.ceil(toStr(t).length / 4),
      token_truncate: (t, n) => { t = toStr(t); return t.length <= n * 4 ? t : t.slice(0, n * 4); },
      context_window: (msgs, max) => {
        const out = []; let total = 0;
        for (let i = msgs.length - 1; i >= 0; i--) { const c = Math.ceil(toStr(msgs[i].content).length / 4); if (total + c > max) break; total += c; out.unshift(msgs[i]); }
        return out;
      },
      chunk: (t, n) => { t = toStr(t); const size = Math.max(1, n * 4); const out = []; for (let i = 0; i < t.length; i += size) out.push(t.slice(i, i + size)); return out; },
      system_prompt: (role, instr) => ({ role: "system", content: "You are " + toStr(role) + ". " + toStr(instr) }),
      user_message: (t) => ({ role: "user", content: t }),
      assistant_message: (t) => ({ role: "assistant", content: t }),
      format_chat: (msgs) => needList(msgs, "format_chat").map((m) => "[" + toStr(m.role) + "]: " + toStr(m.content)).join("\n"),
    }),
    embed: () => ({
      dot_product: vecDot,
      magnitude: vecMag,
      cosine_similarity: cosine,
      normalize: (v) => { const m = vecMag(v); return m === 0 ? v.slice() : v.map((x) => x / m); },
      euclidean_distance: (a, b) => { let s = 0; for (let i = 0; i < Math.min(a.length, b.length); i++) s += (a[i] - b[i]) ** 2; return Math.sqrt(s); },
      centroid: (vs) => { if (!vs.length) return []; const n = vs[0].length; const out = new Array(n).fill(0); for (const v of vs) for (let i = 0; i < n; i++) out[i] += v[i]; return out.map((x) => x / vs.length); },
      most_similar: (q, cands, k) => cands.map((c) => ({ id: c.id, score: cosine(q, c.vector) })).sort((a, b) => b.score - a.score).slice(0, isNil(k) ? cands.length : k),
      chunk_and_embed: (t, size) => { t = toStr(t); const out = []; let idx = 0; for (let i = 0; i < Math.max(t.length, 1); i += size) out.push({ chunk: t.slice(i, i + size), index: idx++ }); return out; },
    }),
    test: () => ({
      describe: (name, f) => { testState.group = toStr(name); print("--- " + toStr(name) + " ---"); f(); print(""); return null; },
      it: (name, f) => {
        try { f(); testState.passed++; print("  ✓ " + toStr(name)); }
        catch (e) { testState.failed++; testState.failures.push(toStr(name)); print("  ✗ " + toStr(name) + ": " + toStr(errorMessage(e))); }
        return null;
      },
      test: (name, f) => moduleCache.test.it(name, f),
      expect_eq: (a, b, msg) => assert(eq(a, b), isNil(msg) ? "Expected " + toStr(a) + " to equal " + toStr(b) : msg),
      expect_neq: (a, b, msg) => assert(!eq(a, b), isNil(msg) ? "Expected " + toStr(a) + " to not equal " + toStr(b) : msg),
      expect_true: (v, msg) => assert(v, isNil(msg) ? "Expected truthy, got " + toStr(v) : msg),
      expect_false: (v, msg) => assert(!truthy(v), isNil(msg) ? "Expected falsy, got " + toStr(v) : msg),
      expect_nil: (v, msg) => assert(isNil(v), isNil(msg) ? "Expected nil, got " + toStr(v) : msg),
      expect_gt: (a, b, msg) => assert(compare(a, b) > 0, isNil(msg) ? "Expected " + toStr(a) + " > " + toStr(b) : msg),
      expect_lt: (a, b, msg) => assert(compare(a, b) < 0, isNil(msg) ? "Expected " + toStr(a) + " < " + toStr(b) : msg),
      expect_throws: (f, msg) => { let threw = false; try { f(); } catch (e) { threw = true; } return assert(threw, isNil(msg) ? "Expected function to throw" : msg); },
      run_tests: () => {
        print("========================");
        print("Tests: " + testState.passed + " passed, " + testState.failed + " failed");
        print("========================");
        return { passed: testState.passed, failed: testState.failed };
      },
    }),
    store: () => ({
      open: (path) => { storeLoad(toStr(path)); return { path: toStr(path) }; },
      get: (s, k) => { const st = storeLoad(s); return hasOwn.call(st.data, toStr(k)) ? st.data[toStr(k)] : null; },
      set: (s, k, v) => { const st = storeLoad(s); defineKey(st.data, toStr(k), v); storeSave(st); return null; },
      delete: (s, k) => { const st = storeLoad(s); delete st.data[toStr(k)]; storeSave(st); return null; },
      has: (s, k) => hasOwn.call(storeLoad(s).data, toStr(k)),
      keys: (s) => Object.keys(storeLoad(s).data),
      values: (s) => { const d = storeLoad(s).data; return Object.keys(d).map((k) => d[k]); },
      entries: (s) => { const d = storeLoad(s).data; return Object.keys(d).map((k) => [k, d[k]]); },
      clear: (s) => { const st = storeLoad(s); for (const k of Object.keys(st.data)) delete st.data[k]; storeSave(st); return null; },
      size: (s) => Object.keys(storeLoad(s).data).length,
      merge: (s, m) => { const st = storeLoad(s); for (const k of Object.keys(m || {})) defineKey(st.data, k, m[k]); storeSave(st); return null; },
      get_or_set: (s, k, f) => { const st = storeLoad(s); if (hasOwn.call(st.data, toStr(k)) && !isNil(st.data[toStr(k)])) return st.data[toStr(k)]; const v = f(); defineKey(st.data, toStr(k), v); storeSave(st); return v; },
    }),
    http: () => ({
      get: (url, headers) => httpRequest("GET", url, null, headers),
      post: (url, body, headers) => httpRequest("POST", url, body, headers),
      put: (url, body, headers) => httpRequest("PUT", url, body, headers),
      patch: (url, body, headers) => httpRequest("PATCH", url, body, headers),
      delete: (url, headers) => httpRequest("DELETE", url, null, headers),
      request: (method, url, body, headers) => httpRequest(method, url, body, headers),
      fetch_all: (reqs) => needList(reqs, "fetch_all").map((r) => (typeof r === "string" ? httpRequest("GET", r) : httpRequest(r.method || "GET", r.url, r.body, r.headers))),
      parse_url: (url) => {
        url = toStr(url);
        let protocol = "", rest = url;
        if (url.startsWith("https://")) { protocol = "https"; rest = url.slice(8); }
        else if (url.startsWith("http://")) { protocol = "http"; rest = url.slice(7); }
        const parts = rest.split("/");
        const host = parts[0];
        const pathParts = parts.slice(1);
        return { protocol, host, path: pathParts.length ? "/" + pathParts.join("/") : "/" };
      },
    }),
    llm: () => {
      const PRICES = { "gpt-4o": [2.5, 10], "gpt-4o-mini": [0.15, 0.6], "gpt-4": [30, 60], "gpt-3.5-turbo": [0.5, 1.5], "claude-3-opus": [15, 75], "claude-3-sonnet": [3, 15], "claude-3-haiku": [0.25, 1.25], "claude-3-5-sonnet": [3, 15] };
      const MODELS = { openai: ["gpt-4o", "gpt-4o-mini", "gpt-4", "gpt-3.5-turbo"], anthropic: ["claude-3-5-sonnet", "claude-3-opus", "claude-3-sonnet", "claude-3-haiku"] };
      const chat = (provider, model, messages, opts) => {
        provider = toStr(provider);
        const key = provider === "openai" ? process.env.OPENAI_API_KEY : provider === "anthropic" ? process.env.ANTHROPIC_API_KEY : undefined;
        if (!MODELS[provider]) return { ok: false, error: "Unknown provider: " + provider };
        if (!key) return { ok: false, error: "Missing API key for " + provider };
        const body = provider === "openai" ? Object.assign({ model, messages }, opts || {}) : Object.assign({ model, max_tokens: 1024, messages }, opts || {});
        const url = provider === "openai" ? "https://api.openai.com/v1/chat/completions" : "https://api.anthropic.com/v1/messages";
        const headers = provider === "openai" ? { authorization: "Bearer " + key } : { "x-api-key": key, "anthropic-version": "2023-06-01" };
        const r = httpRequest("POST", url, body, headers);
        if (!r.ok) return { ok: false, error: r.error || ("HTTP " + r.status) };
        const content = provider === "openai" ? r.data?.choices?.[0]?.message?.content : r.data?.content?.[0]?.text;
        return { ok: true, content: nil(content), raw: r.data };
      };
      return {
        providers: () => Object.keys(MODELS).map((name) => ({ name, models: MODELS[name] })),
        models: (p) => (MODELS[toStr(p)] || []).slice(),
        chat,
        complete: (p, m, text, o) => chat(p, m, [{ role: "user", content: text }], o),
        stream: (p, m, msgs, cb) => { const r = chat(p, m, msgs); if (r.ok && typeof cb === "function") cb(r.content); return r; },
        estimate_cost: (model, inp, out) => { const pr = PRICES[toStr(model)] || [1, 2]; const input = (inp / 1e6) * pr[0], output = (out / 1e6) * pr[1]; return { input, output, total: input + output, model }; },
      };
    },
  };
  moduleFactories.strings_ = moduleFactories.strings;

  const moduleCache = {};
  const MODULE_ALIASES = { "std/math": "math", string: "strings", str: "strings", list: "collections", lists: "collections", maps: "map", fs: "io", file: "io", re: "regex", date: "datetime", dates: "datetime", results: "result", errors: "error", url: "net", process: "os" };
  function loadModule(name) {
    let key = String(name).replace(/\.arc$/, "");
    key = key.replace(/^(std|stdlib|arc)[\/.]/, "");
    if (MODULE_ALIASES[key]) key = MODULE_ALIASES[key];
    if (!hasOwn.call(moduleFactories, key)) return null;
    if (!moduleCache[key]) {
      const members = moduleFactories[key]();
      let ns = members;
      if (typeof builtins[key] === "function") {
        const b = builtins[key];
        ns = function () { return b.apply(null, arguments); };
        Object.defineProperty(ns, "name", { value: key });
        ns.arcName = key;
        Object.assign(ns, members);
      }
      moduleCache[key] = ns;
    }
    return moduleCache[key];
  }
  function hasModule(name) {
    let key = String(name).replace(/\.arc$/, "").replace(/^(std|stdlib|arc)[\/.]/, "");
    if (MODULE_ALIASES[key]) key = MODULE_ALIASES[key];
    return hasOwn.call(moduleFactories, key);
  }

  function makeVariant(name, arity) {
    const f = function () {
      const values = Array.prototype.slice.call(arguments, 0, arity).map(nil);
      return { __tag: name, __values: values };
    };
    f.arcName = name;
    f.__arity = arity;
    return f;
  }

  function checkTypeValue(t, v) { return checkTypeName(t, v); }

  // ---------- runtime type validation (annotations / semantic types) ----------
  const typeRegistry = {};
  function declareType(name, desc) { typeRegistry[name] = desc; return null; }
  function capType(v) {
    const t = typeOf(v);
    return { int: "Int", float: "Float", string: "String", bool: "Bool", nil: "Nil", list: "List", map: "Map", fn: "Fn" }[t] || t;
  }
  function describeValue(v) {
    const t = capType(v);
    if (v === null || v === undefined) return "nil";
    if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") return t + " " + repr(v);
    return t;
  }
  function descName(d) {
    if (!d) return "Any";
    switch (d.kind) {
      case "NamedType": return d.name + (d.args && d.args.length ? "<" + d.args.map(descName).join(", ") + ">" : "");
      case "ListType": return "[" + descName(d.element) + "]";
      case "OptionalType": return descName(d.inner) + "?";
      case "LiteralType": return typeof d.value === "string" ? quote(d.value) : String(d.value);
      case "UnionType": return d.types.map(descName).join(" | ");
      case "RecordType": return "{" + d.fields.map((f) => f.name + (f.optional ? "?" : "") + ": " + descName(f.type)).join(", ") + "}";
      case "FnType": return "(" + d.params.map(descName).join(", ") + ") -> " + descName(d.ret);
      case "TupleType": return "(" + d.elements.map(descName).join(", ") + ")";
      case "VariantType": return d.name;
      case "ConstrainedType": return descName(d.base);
    }
    return "Any";
  }
  const GENERIC_NAME = /^[A-Z]$/;
  function checkType(d, v, depth) {
    depth = depth || 0;
    if (!d || depth > 64) return null;
    const mismatch = (expected) => "expected " + expected + ", got " + describeValue(v);
    switch (d.kind) {
      case "NamedType": {
        const n = d.name, args = d.args || [];
        switch (n) {
          case "Any": case "Json": case "JSON": case "Value": case "Promise": case "Never": case "Unknown": return null;
          case "Int": case "Integer": return typeof v === "number" && Number.isInteger(v) ? null : mismatch("Int");
          case "Float": case "Number": case "Num": case "Double": return typeof v === "number" ? null : mismatch(n);
          case "String": case "Str": return typeof v === "string" ? null : mismatch(n);
          case "Bool": case "Boolean": return typeof v === "boolean" ? null : mismatch(n);
          case "Nil": case "None": case "Void": case "Unit": case "Null": return isNil(v) ? null : mismatch(n);
          case "List": case "Array": case "Set": case "Tuple": {
            if (!Array.isArray(v)) return mismatch(descName(d));
            if (args.length) for (let i = 0; i < v.length; i++) { const r = checkType(args[0], v[i], depth + 1); if (r) return "list element " + i + ": " + r; }
            return null;
          }
          case "Map": case "Object": case "Record": case "Dict": {
            if (!isMap(v)) return mismatch(descName(d));
            const vt = args.length >= 2 ? args[1] : args.length === 1 ? args[0] : null;
            if (vt) for (const k of Object.keys(v)) { const r = checkType(vt, v[k], depth + 1); if (r) return "field '" + k + "': " + r; }
            return null;
          }
          case "Fn": case "Function": case "Callable": return typeof v === "function" ? null : mismatch(n);
          case "Result": {
            if (!isResult(v)) return mismatch(descName(d));
            if (v.ok && args.length) return checkType(args[0], v.value, depth + 1);
            if (!v.ok && args.length >= 2) return checkType(args[1], v.error, depth + 1);
            return null;
          }
          case "Option": case "Maybe": return isNil(v) ? null : (args.length ? checkType(args[0], v, depth + 1) : null);
        }
        if (hasOwn.call(typeRegistry, n)) {
          const r = checkType(typeRegistry[n], v, depth + 1);
          if (r && typeRegistry[n].kind === "UnionType") return "expected " + n + ", got " + describeValue(v);
          return r;
        }
        return null;
      }
      case "ListType": {
        if (!Array.isArray(v)) return mismatch(descName(d));
        for (let i = 0; i < v.length; i++) { const r = checkType(d.element, v[i], depth + 1); if (r) return "list element " + i + ": " + r; }
        return null;
      }
      case "OptionalType": return isNil(v) ? null : checkType(d.inner, v, depth + 1);
      case "LiteralType": return eq(v, d.value) ? null : mismatch(descName(d));
      case "UnionType": {
        for (const alt of d.types) if (!checkType(alt, v, depth + 1)) return null;
        return mismatch(descName(d));
      }
      case "RecordType": {
        if (!isMap(v)) return mismatch(descName(d));
        for (const f of d.fields) {
          if (!hasOwn.call(v, f.name) || v[f.name] === undefined) {
            if (f.optional || f.hasDefault || (f.type && (f.type.kind === "OptionalType" || (f.type.kind === "NamedType" && (f.type.name === "Any" || f.type.name === "Nil" || f.type.name === "Option"))))) continue;
            return "missing field '" + f.name + "'";
          }
          const r = checkType(f.type, v[f.name], depth + 1);
          if (r) return "field '" + f.name + "': " + r;
        }
        return null;
      }
      case "FnType": {
        if (typeof v !== "function") return mismatch(descName(d));
        if (typeof v.__arity === "number" && v.__arity > d.params.length && !v.__variadic) return "expected function with " + d.params.length + " parameter(s), got " + v.__arity;
        return null;
      }
      case "TupleType": {
        if (!Array.isArray(v)) return mismatch(descName(d));
        if (v.length !== d.elements.length) return "expected tuple of " + d.elements.length + " element(s), got " + v.length;
        for (let i = 0; i < v.length; i++) { const r = checkType(d.elements[i], v[i], depth + 1); if (r) return r; }
        return null;
      }
      case "VariantType": return isMap(v) && v.__tag === d.name ? null : mismatch(d.name);
      case "ConstrainedType": {
        const r = checkType(d.base, v, depth + 1);
        if (r) return r;
        if (d.regex !== null && d.regex !== undefined) {
          if (typeof v !== "string") return mismatch("String");
          let re;
          try { re = new RegExp(d.regex, String(d.flags || "").replace(/[^gimsuy]/g, "")); } catch (e) { return null; }
          return re.test(v) ? null : "value " + repr(v) + " does not match /" + d.regex + "/";
        }
        if (typeof d.test === "function") {
          let ok;
          try { ok = truthy(d.test(v, v, v, v)); } catch (e) { ok = false; }
          return ok ? null : "value " + repr(v) + " violates constraint" + (d.text ? " 'where " + d.text + "'" : "");
        }
        return null;
      }
    }
    return null;
  }
  function assertType(d, v, what) {
    const r = checkType(d, v, 0);
    if (r) throw new ArcTypeError("Type mismatch" + (what ? " for " + what : "") + ": " + r);
    return v;
  }

  const rt = {
    ArcRuntimeError, ArcThrow, fail,
    isNil, isList, isMap, isFn, isResult, nil,
    typeOf, toStr, repr, truthy, eq, compare, sortCompare,
    add, sub, mul, div, mod, pow, neg, not, concat, lt, gt, le, ge, ne, inOp, binary, range,
    getMember, getIndex, setMember, setIndex, slice, iterate, call, callMethod, callFn,
    Ok, Err, matchPattern, match, destructure, propagate, checkTypeName, checkTypeValue,
    ArcTypeError, declareType, checkType, assertType, typeRegistry, descName,
    errorMessage, toolCall, customTool, httpRequest,
    builtins, loadModule, hasModule, moduleNames: Object.keys(moduleFactories).filter((k) => !k.endsWith("_")), makeVariant, defineKey,
    jsonStringify, jsonParse, tomlParse, yamlParse,
    output: options.output || null,
    errorOutput: options.errorOutput || null,
    tools: options.tools || null,
    httpHandler: options.httpHandler || null,
    security: options.security || null,
  };
  return rt;
}

module.exports = { createRuntime };
