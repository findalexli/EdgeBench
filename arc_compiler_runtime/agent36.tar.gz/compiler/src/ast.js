"use strict";
// Arc AST: node kind catalogue, constructors and traversal helpers.

const STATEMENT_KINDS = ["LetStmt", "FnStmt", "TypeStmt", "UseStmt", "ExprStmt", "ForStmt", "WhileStmt", "DoWhileStmt", "ReturnStmt", "BreakStmt", "ContinueStmt"];
const EXPRESSION_KINDS = [
  "IntLiteral", "FloatLiteral", "StringLiteral", "StringInterp", "BoolLiteral", "NilLiteral", "RegexLiteral", "Identifier",
  "BinaryExpr", "UnaryExpr", "CallExpr", "MemberExpr", "IndexExpr", "SliceExpr", "PipelineExpr", "IfExpr", "MatchExpr",
  "LambdaExpr", "ListLiteral", "MapLiteral", "ListComprehension", "MapComprehension", "RangeExpr", "BlockExpr", "TryExpr",
  "ToolCallExpr", "FetchExpr", "AsyncExpr", "AwaitExpr", "PropagateExpr", "AssignExpr", "SpreadExpr", "EllipsisExpr",
];
const PATTERN_KINDS = ["WildcardPattern", "LiteralPattern", "BindingPattern", "RangePattern", "ListPattern", "MapPattern", "OrPattern", "VariantPattern", "TypedPattern"];
const TYPE_KINDS = ["NamedType", "ListType", "RecordType", "UnionType", "FnType", "ConstrainedType", "LiteralType", "VariantType", "OptionalType", "TupleType"];
const LITERAL_KINDS = ["IntLiteral", "FloatLiteral", "StringLiteral", "BoolLiteral", "NilLiteral"];

const NodeKind = {};
for (const k of [...STATEMENT_KINDS, ...EXPRESSION_KINDS, ...PATTERN_KINDS, ...TYPE_KINDS, "Program", "MatchArm", "Param"]) NodeKind[k] = k;

function node(kind, props = {}, loc) {
  const n = { kind, ...props };
  if (loc) { n.line = loc.line; n.col = loc.col; }
  return n;
}

const isStatement = (n) => !!n && STATEMENT_KINDS.includes(n.kind);
const isExpression = (n) => !!n && EXPRESSION_KINDS.includes(n.kind);
const isPattern = (n) => !!n && PATTERN_KINDS.includes(n.kind);
const isTypeExpr = (n) => !!n && TYPE_KINDS.includes(n.kind);
const isLiteral = (n) => !!n && LITERAL_KINDS.includes(n.kind);

// Visit every node (depth-first, pre-order). Return false from fn to skip children.
function walk(n, fn, parent = null) {
  if (!n || typeof n !== "object") return;
  if (Array.isArray(n)) { for (const c of n) walk(c, fn, parent); return; }
  if (typeof n.kind === "string" && fn(n, parent) === false) return;
  for (const k of Object.keys(n)) {
    const v = n[k];
    if (v && typeof v === "object") walk(v, fn, typeof n.kind === "string" ? n : parent);
  }
}

function collect(n, pred) {
  const out = [];
  walk(n, (x) => { if (pred(x)) out.push(x); });
  return out;
}

function findAll(n, kind) { return collect(n, (x) => x.kind === kind); }

function stripLocations(n) {
  if (n === null || typeof n !== "object") return n;
  if (Array.isArray(n)) return n.map(stripLocations);
  const out = {};
  for (const k of Object.keys(n)) if (k !== "line" && k !== "col") out[k] = stripLocations(n[k]);
  return out;
}

module.exports = {
  NodeKind, STATEMENT_KINDS, EXPRESSION_KINDS, PATTERN_KINDS, TYPE_KINDS, LITERAL_KINDS,
  node, isStatement, isExpression, isPattern, isTypeExpr, isLiteral, walk, visit: walk, collect, findAll, stripLocations,
};
