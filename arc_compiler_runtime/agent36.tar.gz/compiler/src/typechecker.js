"use strict";
// Arc type checker: validates declared types (`type X = ...`) and annotations
// (let / params / return types) using local type inference over literals and
// well-known builtins. Constrained types (`where` / `matching`) are validated
// whenever the checked value is statically known.
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");

const T = {
  any: { tag: "any" }, int: { tag: "int" }, float: { tag: "float" }, string: { tag: "string" },
  bool: { tag: "bool" }, nil: { tag: "nil" }, fn: { tag: "fn" }, list: { tag: "list", elem: { tag: "any" } }, map: { tag: "map", fields: null },
};

const BUILTIN_RETURNS = {
  len: T.int, str: T.string, to_string: T.string, int: T.int, float: T.float, bool: T.bool, type_of: T.string, type: T.string,
  trim: T.string, upper: T.string, lower: T.string, split: { tag: "list", elem: T.string }, join: T.string, replace: T.string,
  contains: T.bool, starts: T.bool, ends: T.bool, repeat: T.string, chars: { tag: "list", elem: T.string }, index_of: T.int,
  ord: T.int, chr: T.string, char_at: T.string, keys: { tag: "list", elem: T.string }, any: T.bool, all: T.bool,
  range: { tag: "list", elem: T.int }, abs: null, time_ms: T.int, is_ok: T.bool, is_err: T.bool, enumerate: T.list, zip: T.list,
  map: T.list, filter: T.list, sort: T.list, reverse: null, take: null, drop: null, push: T.list, concat: null, flat: T.list, entries: T.list, values: T.list,
};

function runtimeTypeName(t) {
  if (!t) return "any";
  switch (t.tag) {
    case "int": case "float": case "string": case "bool": case "nil": case "list": case "map": case "fn": return t.tag;
    case "literal": return typeof t.value === "string" ? "string" : typeof t.value === "boolean" ? "bool" : Number.isInteger(t.value) ? "int" : "float";
  }
  return "any";
}

function typeName(t) {
  if (!t) return "Any";
  switch (t.tag) {
    case "any": return "Any";
    case "int": return "Int";
    case "float": return "Float";
    case "string": return "String";
    case "bool": return "Bool";
    case "nil": return "Nil";
    case "fn": return t.params ? `(${t.params.map(typeName).join(", ")}) -> ${typeName(t.ret)}` : "Fn";
    case "list": return `[${typeName(t.elem)}]`;
    case "map": return t.fields ? `{${Object.keys(t.fields).map((k) => `${k}: ${typeName(t.fields[k])}`).join(", ")}}` : "Map";
    case "literal": return JSON.stringify(t.value);
  }
  return "Any";
}

class TypeChecker {
  constructor(options = {}) {
    if (options && (options.kind === "Program" || Array.isArray(options.stmts) || typeof options === "string" || Array.isArray(options))) { this.pendingProgram = options; options = {}; }
    this.options = options || {};
    this.errors = [];
    this.warnings = [];
    this.types = new Map(); // declared type aliases: name -> TypeStmt
    this.fns = [];          // scope stack of function signatures
    this.vars = [new Map()];
    this.exprTypes = new Map();
    this.interp = null;
  }

  error(message, node, code) {
    this.errors.push({ message, line: node && node.line ? node.line : 1, col: node && node.col ? node.col : 1, severity: "error", code: code || "type-error" });
  }
  warn(message, node, code) {
    this.warnings.push({ message, line: node && node.line ? node.line : 1, col: node && node.col ? node.col : 1, severity: "warning", code: code || "type-warning" });
  }

  // ---------- type declarations ----------
  collectTypes(stmts) {
    for (const s of stmts) {
      if (s.kind === "TypeStmt") {
        if (this.types.has(s.name)) this.error(`Duplicate type declaration '${s.name}'`, s, "duplicate-type");
        this.types.set(s.name, s);
      }
    }
    for (const s of stmts) if (s.kind === "TypeStmt") this.validateTypeExpr(s.def, new Set(s.typeParams || []), s);
  }

  isKnownTypeName(name, params) {
    if (params && params.has(name)) return true;
    if (this.types.has(name)) return true;
    return ["Int", "Float", "Number", "Num", "String", "Str", "Bool", "Boolean", "Nil", "None", "Any", "List", "Array", "Map", "Object", "Record", "Fn", "Function", "Result", "Option", "Promise", "Void", "Unit", "Never", "Dict", "Set", "Tuple", "Json", "JSON", "Value", "T", "U", "K", "V", "E"].includes(name);
  }

  validateTypeExpr(t, params, owner) {
    if (!t) return;
    switch (t.kind) {
      case "NamedType":
        if (!this.isKnownTypeName(t.name, params) && !this.isVariantName(t.name)) this.warn(`Unknown type '${t.name}'`, t.line ? t : owner, "unknown-type");
        (t.args || []).forEach((a) => this.validateTypeExpr(a, params, owner));
        return;
      case "ListType": this.validateTypeExpr(t.element, params, owner); return;
      case "OptionalType": this.validateTypeExpr(t.inner, params, owner); return;
      case "UnionType": t.types.forEach((x) => this.validateTypeExpr(x, params, owner)); return;
      case "RecordType": {
        const seen = new Set();
        for (const f of t.fields) {
          if (seen.has(f.name)) this.error(`Duplicate field '${f.name}' in record type`, t, "duplicate-field");
          seen.add(f.name);
          this.validateTypeExpr(f.type, params, owner);
        }
        return;
      }
      case "FnType": t.params.forEach((p) => this.validateTypeExpr(p, params, owner)); this.validateTypeExpr(t.ret, params, owner); return;
      case "TupleType": t.elements.forEach((p) => this.validateTypeExpr(p, params, owner)); return;
      case "VariantType": t.fields.forEach((p) => this.validateTypeExpr(p, params, owner)); return;
      case "ConstrainedType":
        this.validateTypeExpr(t.base, params, owner);
        if (t.regex !== null && t.regex !== undefined) {
          try { new RegExp(t.regex, (t.flags || "").replace(/[^gimsuy]/g, "")); } catch (e) { this.error(`Invalid regex in type constraint: ${e.message}`, t, "invalid-regex"); }
        }
        return;
    }
  }

  isVariantName(name) {
    for (const [, decl] of this.types) {
      const walk = (t) => t && ((t.kind === "UnionType" && t.types.some((x) => (x.kind === "NamedType" && x.name === name && !(x.args && x.args.length)) || walk(x))) || (t.kind === "VariantType" && t.name === name));
      if (walk(decl.def)) return true;
    }
    return false;
  }

  resolveNamed(name, seen = new Set()) {
    const decl = this.types.get(name);
    if (!decl || seen.has(name)) return null;
    seen.add(name);
    return decl.def;
  }

  // ---------- checking values against type expressions ----------
  // Returns null if OK, or a string reason if the (static) value type does not fit.
  check(tyExpr, info, seen = new Set()) {
    if (!tyExpr) return null;
    const vt = info.type;
    switch (tyExpr.kind) {
      case "NamedType": {
        const n = tyExpr.name;
        switch (n) {
          case "Any": case "T": case "U": case "K": case "V": case "E": case "Json": case "JSON": case "Value": return null;
          case "Int": return this.fits(vt, ["int"], info) ? null : this.mismatch("Int", info);
          case "Float": return this.fits(vt, ["int", "float"], info) ? null : this.mismatch("Float", info);
          case "Number": case "Num": return this.fits(vt, ["int", "float"], info) ? null : this.mismatch("Number", info);
          case "String": case "Str": return this.fits(vt, ["string"], info) ? null : this.mismatch("String", info);
          case "Bool": case "Boolean": return this.fits(vt, ["bool"], info) ? null : this.mismatch("Bool", info);
          case "Nil": case "None": case "Void": case "Unit": return this.fits(vt, ["nil"], info) ? null : this.mismatch("Nil", info);
          case "List": case "Array": case "Tuple": case "Set": {
            if (!this.fits(vt, ["list"], info)) return this.mismatch(n, info);
            if (tyExpr.args && tyExpr.args.length && info.elements) {
              for (const el of info.elements) { const r = this.check(tyExpr.args[0], el, seen); if (r) return `list element: ${r}`; }
            }
            return null;
          }
          case "Map": case "Object": case "Record": case "Dict": return this.fits(vt, ["map"], info) ? null : this.mismatch(n, info);
          case "Fn": case "Function": return this.fits(vt, ["fn"], info) ? null : this.mismatch(n, info);
          case "Result": return this.fits(vt, ["map"], info) ? null : this.mismatch("Result", info);
          case "Option": {
            if (vt.tag === "nil") return null;
            return tyExpr.args && tyExpr.args.length ? this.check(tyExpr.args[0], info, seen) : null;
          }
          case "Promise": case "Never": return null;
        }
        const def = this.types.get(n);
        if (!def) return null;
        if (seen.has(n + ":" + (info.key || ""))) return null;
        const seen2 = new Set(seen); seen2.add(n + ":" + (info.key || ""));
        const r = this.check(def.def, info, seen2);
        if (r && def.def.kind === "UnionType" && r.startsWith("expected ")) return `expected ${n} (${this.typeExprName(def.def)}), got ${this.describe(info)}`;
        return r;
      }
      case "LiteralType": {
        if (vt.tag === "any") return null;
        if (info.known) return info.value === tyExpr.value ? null : `expected ${JSON.stringify(tyExpr.value)}, got ${JSON.stringify(info.value)}`;
        const lt = typeof tyExpr.value === "string" ? "string" : typeof tyExpr.value === "number" ? (Number.isInteger(tyExpr.value) ? "int" : "float") : "bool";
        return this.fits(vt, [lt], info) ? null : this.mismatch(JSON.stringify(tyExpr.value), info);
      }
      case "UnionType": {
        const reasons = [];
        for (const alt of tyExpr.types) { const r = this.check(alt, info, seen); if (!r) return null; reasons.push(r); }
        return `expected ${tyExpr.types.map((x) => this.typeExprName(x)).join(" | ")}, got ${this.describe(info)}`;
      }
      case "OptionalType": return vt.tag === "nil" ? null : this.check(tyExpr.inner, info, seen);
      case "ListType": {
        if (!this.fits(vt, ["list"], info)) return this.mismatch(this.typeExprName(tyExpr), info);
        if (info.elements) for (const el of info.elements) { const r = this.check(tyExpr.element, el, seen); if (r) return `list element: ${r}`; }
        return null;
      }
      case "RecordType": {
        if (!this.fits(vt, ["map"], info)) return this.mismatch(this.typeExprName(tyExpr), info);
        if (!info.fields) return null;
        for (const f of tyExpr.fields) {
          const fi = info.fields[f.name];
          if (!fi) {
            if (f.optional || f.default || (f.type && f.type.kind === "OptionalType")) continue;
            return `missing field '${f.name}'`;
          }
          const r = this.check(f.type, fi, seen);
          if (r) return `field '${f.name}': ${r}`;
        }
        if (this.options.strictRecords !== false) {
          const declared = new Set(tyExpr.fields.map((f) => f.name));
          for (const k of Object.keys(info.fields)) if (!declared.has(k)) return `unknown field '${k}'`;
        }
        return null;
      }
      case "FnType": {
        if (!this.fits(vt, ["fn"], info)) return this.mismatch(this.typeExprName(tyExpr), info);
        if (info.arity !== undefined && info.arity !== tyExpr.params.length && !info.variadic) return `expected function with ${tyExpr.params.length} parameter(s), got ${info.arity}`;
        return null;
      }
      case "TupleType": {
        if (!this.fits(vt, ["list"], info)) return this.mismatch("tuple", info);
        if (info.elements) {
          if (info.elements.length !== tyExpr.elements.length) return `expected tuple of ${tyExpr.elements.length} elements, got ${info.elements.length}`;
          for (let i = 0; i < info.elements.length; i++) { const r = this.check(tyExpr.elements[i], info.elements[i], seen); if (r) return r; }
        }
        return null;
      }
      case "VariantType": {
        if (vt.tag === "any") return null;
        if (info.variant !== undefined) return info.variant === tyExpr.name ? null : `expected ${tyExpr.name}, got ${info.variant}`;
        return this.fits(vt, ["map"], info) ? null : this.mismatch(tyExpr.name, info);
      }
      case "ConstrainedType": {
        const r = this.check(tyExpr.base, info, seen);
        if (r) return r;
        if (!info.known) return null;
        if (tyExpr.regex !== null && tyExpr.regex !== undefined) {
          if (typeof info.value !== "string") return null;
          let re;
          try { re = new RegExp(tyExpr.regex, (tyExpr.flags || "").replace(/[^gimsuy]/g, "")); } catch (e) { return null; }
          return re.test(info.value) ? null : `value ${JSON.stringify(info.value)} does not match /${tyExpr.regex}/`;
        }
        if (tyExpr.predicate) {
          const ok = this.evalPredicate(tyExpr, info.value);
          if (ok === false) return `value ${JSON.stringify(info.value)} violates constraint 'where ${predicateText(tyExpr)}'`;
        }
        return null;
      }
    }
    return null;
  }

  typeExprName(t) {
    if (!t) return "Any";
    switch (t.kind) {
      case "NamedType": return t.name + (t.args && t.args.length ? `<${t.args.map((a) => this.typeExprName(a)).join(", ")}>` : "");
      case "LiteralType": return JSON.stringify(t.value);
      case "ListType": return `[${this.typeExprName(t.element)}]`;
      case "UnionType": return t.types.map((x) => this.typeExprName(x)).join(" | ");
      case "RecordType": return `{${t.fields.map((f) => `${f.name}: ${this.typeExprName(f.type)}`).join(", ")}}`;
      case "FnType": return `(${t.params.map((p) => this.typeExprName(p)).join(", ")}) -> ${this.typeExprName(t.ret)}`;
      case "ConstrainedType": return this.typeExprName(t.base);
      case "OptionalType": return this.typeExprName(t.inner) + "?";
      case "VariantType": return t.name;
    }
    return "Any";
  }

  fits(vt, tags, info) {
    if (!vt || vt.tag === "any") return true;
    if (vt.tag === "union") return vt.types.every((x) => this.fits(x, tags, info));
    return tags.includes(vt.tag);
  }

  describe(info) {
    if (info.known) return `${typeName(info.type)} ${JSON.stringify(info.value)}`;
    return typeName(info.type);
  }

  mismatch(expected, info) { return `expected ${expected}, got ${this.describe(info)}`; }

  evalPredicate(tyExpr, value) {
    try {
      if (!this.interp) this.interp = require("./interpreter.js");
      const { createEnv, interpretWithEnv } = this.interp;
      const env = createEnv({}, { output: () => {} });
      const names = tyExpr.param ? [tyExpr.param] : ["x", "value", "v", "n", "s", "it", "self", "val"];
      for (const n of names) env.scope.declare(n, value, false);
      const r = interpretWithEnv({ kind: "Program", stmts: [{ kind: "ExprStmt", expr: tyExpr.predicate }] }, env);
      return env.rt.truthy(r);
    } catch (e) {
      return null;
    }
  }

  // ---------- inference ----------
  lookupVar(name) {
    for (let i = this.vars.length - 1; i >= 0; i--) { const v = this.vars[i].get(name); if (v) return v; }
    return null;
  }

  infer(e) {
    if (!e) return { type: T.any };
    switch (e.kind) {
      case "IntLiteral": return { type: T.int, known: true, value: e.value };
      case "FloatLiteral": return { type: Number.isInteger(e.value) ? T.float : T.float, known: true, value: e.value };
      case "StringLiteral": return { type: T.string, known: true, value: e.value };
      case "BoolLiteral": return { type: T.bool, known: true, value: e.value };
      case "NilLiteral": return { type: T.nil, known: true, value: null };
      case "StringInterp": e.parts.forEach((p) => { if (typeof p !== "string") this.infer(p); }); return { type: T.string };
      case "ListLiteral": {
        if (e.elements.some((x) => x.kind === "SpreadExpr")) { e.elements.forEach((x) => this.infer(x.kind === "SpreadExpr" ? x.expr : x)); return { type: T.list }; }
        const elements = e.elements.map((x) => this.infer(x));
        return { type: T.list, elements };
      }
      case "ListComprehension": return { type: T.list };
      case "MapComprehension": return { type: T.map };
      case "MapLiteral": {
        const fields = {};
        let exact = true;
        for (const en of e.entries) {
          if (en.spread || en.computed) { exact = false; this.infer(en.spread || en.value); continue; }
          fields[en.key] = this.infer(en.value);
        }
        return { type: T.map, fields: exact ? fields : null };
      }
      case "Identifier": {
        const v = this.lookupVar(e.name);
        if (v) return v.info || { type: T.any };
        if (/^[A-Z]/.test(e.name) && this.variantOf(e.name)) return { type: T.fn };
        return { type: T.any };
      }
      case "UnaryExpr": {
        const o = this.infer(e.operand);
        if (e.op === "not") return { type: T.bool };
        if (o.type.tag !== "any" && o.type.tag !== "int" && o.type.tag !== "float") this.error(`Cannot negate ${typeName(o.type)}`, e, "invalid-operand");
        if (o.known && typeof o.value === "number") return { type: o.type, known: true, value: -o.value };
        return { type: o.type.tag === "int" || o.type.tag === "float" ? o.type : T.any };
      }
      case "BinaryExpr": return this.inferBinary(e);
      case "RangeExpr": this.infer(e.start); this.infer(e.end); return { type: { tag: "list", elem: T.int } };
      case "LambdaExpr": this.checkFunction(e); return { type: T.fn, arity: e.params.filter((p) => !p.rest).length, variadic: e.params.some((p) => p.rest || p.default) };
      case "CallExpr": return this.inferCall(e);
      case "PipelineExpr": {
        const l = this.infer(e.left);
        if (e.right.kind === "CallExpr") {
          const fake = Object.assign({}, e.right, { args: [{ kind: "__Typed", info: l }, ...e.right.args] });
          return this.inferCall(fake);
        }
        this.infer(e.right);
        return { type: T.any };
      }
      case "__Typed": return e.info;
      case "IfExpr": {
        this.infer(e.condition);
        const a = this.inferBranch(e.then);
        const b = e.else_ ? this.inferBranch(e.else_) : { type: T.nil };
        return this.join(a, b);
      }
      case "MatchExpr": {
        this.infer(e.subject);
        let acc = null;
        for (const arm of e.arms) {
          this.vars.push(new Map());
          for (const n of patternNames(arm.pattern)) this.vars[this.vars.length - 1].set(n, { info: { type: T.any } });
          if (arm.guard) this.infer(arm.guard);
          const t = this.inferBranch(arm.body);
          this.vars.pop();
          acc = acc ? this.join(acc, t) : t;
        }
        return acc || { type: T.nil };
      }
      case "BlockExpr": return this.inferBlock(e.stmts);
      case "TryExpr": {
        const a = this.inferBlock(e.body.stmts);
        if (e.catchBody) { this.vars.push(new Map([[e.catchParam, { info: { type: T.string } }]])); const b = this.inferBlock(e.catchBody.stmts); this.vars.pop(); return this.join(a, b); }
        return a;
      }
      case "AssignExpr": {
        const v = this.infer(e.value);
        if (e.target.kind === "Identifier") {
          const vv = this.lookupVar(e.target.name);
          if (vv && vv.annotation) {
            const r = this.check(vv.annotation, v);
            if (r) this.error(`Type mismatch in assignment to '${e.target.name}': ${r}`, e, "type-mismatch");
          }
          if (vv && !vv.annotation) vv.info = this.widen(v);
        } else this.infer(e.target);
        return v;
      }
      case "MemberExpr": {
        const o = this.infer(e.object);
        if (o.fields && Object.prototype.hasOwnProperty.call(o.fields, e.property)) return o.fields[e.property];
        if (o.type.tag !== "any" && o.type.tag !== "map" && !(o.type.tag === "nil" && e.optional) && !["length", "len"].includes(e.property) && o.type.tag !== "fn") {
          if (o.type.tag === "nil") this.error(`Cannot access property '${e.property}' of nil`, e, "nil-access");
        }
        return { type: T.any };
      }
      case "IndexExpr": {
        const o = this.infer(e.object);
        const i = this.infer(e.index);
        if (o.type.tag === "list" && i.type.tag !== "any" && i.type.tag !== "int") this.error(`List index must be Int, got ${typeName(i.type)}`, e, "invalid-index");
        if (o.type.tag === "list" && o.elements && i.known && typeof i.value === "number") { const el = o.elements[i.value < 0 ? o.elements.length + i.value : i.value]; if (el) return el; }
        if (o.type.tag === "list" && o.type.elem) return { type: o.type.elem };
        if (o.type.tag === "string") return { type: T.string };
        return { type: T.any };
      }
      case "ToolCallExpr": (e.args || []).forEach((a) => this.infer(a)); if (e.url) this.infer(e.url); if (e.body) this.infer(e.body); return { type: T.map };
      case "FetchExpr": e.calls.forEach((c) => this.infer(c)); return { type: T.list };
      case "AwaitExpr": case "PropagateExpr": this.infer(e.expr); return { type: T.any };
      case "AsyncExpr": return this.inferBlock(e.body.stmts);
      case "SpreadExpr": this.infer(e.expr); return { type: T.any };
      case "SliceExpr": { const o = this.infer(e.object); if (e.start) this.infer(e.start); if (e.end) this.infer(e.end); return { type: o.type.tag === "string" ? T.string : o.type.tag === "list" ? T.list : T.any }; }
      case "ReturnStmt": this.checkReturn(e); return { type: T.any };
      case "BreakStmt": case "ContinueStmt": return { type: T.any };
      default:
        if (e.kind && e.kind.endsWith("Stmt")) { this.stmt(e); return { type: T.nil }; }
        return { type: T.any };
    }
  }

  widen(info) {
    if (!info) return { type: T.any };
    return { type: info.type, fields: info.fields, elements: info.elements, arity: info.arity, variadic: info.variadic };
  }

  join(a, b) {
    if (!a) return b;
    if (!b) return a;
    if (a.type.tag === b.type.tag && a.type.tag !== "any") return { type: a.type };
    if ((a.type.tag === "int" || a.type.tag === "float") && (b.type.tag === "int" || b.type.tag === "float")) return { type: T.float };
    return { type: T.any };
  }

  inferBranch(b) { return b.kind === "BlockExpr" ? this.inferBlock(b.stmts) : this.infer(b); }

  inferBlock(stmts) {
    this.vars.push(new Map());
    this.hoistFns(stmts);
    let last = { type: T.nil };
    for (const s of stmts) last = this.stmt(s);
    this.vars.pop();
    return last || { type: T.nil };
  }

  inferBinary(e) {
    const l = this.infer(e.left), r = this.infer(e.right);
    const lt = l.type.tag, rt = r.type.tag;
    const num = (t) => t === "int" || t === "float";
    const known = l.known && r.known;
    switch (e.op) {
      case "and": case "or": return { type: lt === rt && lt !== "any" ? l.type : T.any };
      case "??": return lt === "nil" ? r : lt === "any" ? { type: T.any } : l;
      case "==": case "!=": return { type: T.bool };
      case "in": return { type: T.bool };
      case "<": case ">": case "<=": case ">=": {
        if (lt !== "any" && rt !== "any" && !(num(lt) && num(rt)) && !(lt === "string" && rt === "string") && !(lt === "list" && rt === "list")) {
          this.error(`Cannot compare ${typeName(l.type)} with ${typeName(r.type)} using '${e.op}'`, e, "invalid-operand");
        }
        return { type: T.bool };
      }
      case "+": {
        if (num(lt) && num(rt)) return known ? { type: lt === "int" && rt === "int" ? T.int : T.float, known: true, value: l.value + r.value } : { type: lt === "int" && rt === "int" ? T.int : T.float };
        if (lt === "string" || rt === "string") return known ? { type: T.string, known: true, value: String(l.value) + String(r.value) } : { type: T.string };
        if (lt === "list" && rt === "list") return { type: T.list };
        if (lt === "map" && rt === "map") return { type: T.map };
        if (lt !== "any" && rt !== "any") this.error(`Cannot apply '+' to ${typeName(l.type)} and ${typeName(r.type)}`, e, "invalid-operand");
        return { type: T.any };
      }
      case "-": case "/": case "%": case "**": {
        if (lt !== "any" && rt !== "any" && !(num(lt) && num(rt))) {
          this.error(`Cannot apply '${e.op}' to ${typeName(l.type)} and ${typeName(r.type)}`, e, "invalid-operand");
          return { type: T.any };
        }
        if ((e.op === "/" || e.op === "%") && r.known && r.value === 0) this.warn("Division by zero", e, "division-by-zero");
        if (e.op === "/") return { type: T.float };
        return { type: lt === "int" && rt === "int" && e.op !== "**" ? T.int : num(lt) && num(rt) ? (lt === "int" && rt === "int" ? T.int : T.float) : T.any };
      }
      case "*": {
        if (num(lt) && num(rt)) return { type: lt === "int" && rt === "int" ? T.int : T.float };
        if ((lt === "string" && num(rt)) || (num(lt) && rt === "string")) return { type: T.string };
        if ((lt === "list" && num(rt)) || (num(lt) && rt === "list")) return { type: T.list };
        if (lt !== "any" && rt !== "any") this.error(`Cannot apply '*' to ${typeName(l.type)} and ${typeName(r.type)}`, e, "invalid-operand");
        return { type: T.any };
      }
      case "++": {
        if (lt === "list") return { type: T.list };
        if (lt === "string" || rt === "string") return { type: T.string };
        return { type: T.any };
      }
    }
    return { type: T.any };
  }

  variantOf(name) {
    for (const [tname, decl] of this.types) {
      const walk = (t) => { if (!t) return null; if (t.kind === "UnionType") { for (const x of t.types) { const r = walk(x); if (r) return r; } return null; } if (t.kind === "VariantType" && t.name === name) return { type: tname, variant: t }; return null; };
      const r = walk(decl.def);
      if (r) return r;
    }
    return null;
  }

  inferCall(e) {
    const args = e.args.map((a) => (a.kind === "SpreadExpr" ? (this.infer(a.expr), { type: T.any, spread: true }) : this.infer(a)));
    if (e.callee.kind === "Identifier") {
      const name = e.callee.name;
      const v = this.lookupVar(name);
      if (v && v.fn) {
        this.checkCallArgs(v.fn, args, e);
        if (v.fn.returnType) return this.infoFromTypeExpr(v.fn.returnType);
        return { type: T.any };
      }
      if (!v) {
        const variant = this.variantOf(name);
        if (variant) {
          const fields = variant.variant.fields;
          if (args.length !== fields.length) this.error(`Variant '${name}' expects ${fields.length} argument(s), got ${args.length}`, e, "arity-mismatch");
          else args.forEach((a, i) => { const r = this.check(fields[i], a); if (r) this.error(`Argument ${i + 1} of '${name}': ${r}`, e, "type-mismatch"); });
          return { type: T.map, variant: name };
        }
        if (name === "Ok" || name === "Err") return { type: T.map };
        if (Object.prototype.hasOwnProperty.call(BUILTIN_RETURNS, name)) {
          const rt = BUILTIN_RETURNS[name];
          if (rt) return { type: rt };
          if ((name === "abs") && args[0]) return { type: args[0].type };
          if (args[0] && (name === "reverse" || name === "take" || name === "drop" || name === "concat")) return { type: args[0].type };
        }
      }
      return { type: T.any };
    }
    this.infer(e.callee);
    return { type: T.any };
  }

  infoFromTypeExpr(t) {
    if (!t) return { type: T.any };
    if (t.kind === "NamedType") {
      switch (t.name) {
        case "Int": return { type: T.int };
        case "Float": case "Number": return { type: t.name === "Float" ? T.float : T.any };
        case "String": return { type: T.string };
        case "Bool": return { type: T.bool };
        case "Nil": return { type: T.nil };
        case "List": return { type: T.list };
        case "Map": return { type: T.map };
      }
      const def = this.types.get(t.name);
      if (def && def.def.kind !== "NamedType") return this.infoFromTypeExpr(def.def);
      if (def) return this.infoFromTypeExpr(def.def);
    }
    if (t.kind === "ConstrainedType") return this.infoFromTypeExpr(t.base);
    if (t.kind === "ListType") return { type: T.list };
    if (t.kind === "RecordType") return { type: T.map };
    return { type: T.any };
  }

  checkCallArgs(fn, args, node) {
    const params = fn.params;
    const required = params.filter((p) => !p.rest && !p.default).length;
    const hasRest = params.some((p) => p.rest);
    const hasSpread = args.some((a) => a.spread);
    if (!hasRest && !hasSpread && args.length > params.length) this.error(`Function '${fn.name}' expects at most ${params.length} argument(s), got ${args.length}`, node, "arity-mismatch");
    if (!hasSpread && args.length < required && params.slice(args.length).some((p) => p.typeAnn && !this.acceptsNil(p.typeAnn))) {
      this.error(`Function '${fn.name}' expects ${required} argument(s), got ${args.length}`, node, "arity-mismatch");
    }
    params.forEach((p, i) => {
      if (p.rest || !p.typeAnn || i >= args.length || args[i].spread) return;
      const r = this.check(p.typeAnn, args[i]);
      if (r) this.error(`Argument '${p.name || i + 1}' of '${fn.name}': ${r}`, node, "type-mismatch");
    });
  }

  acceptsNil(t) {
    if (!t) return true;
    if (t.kind === "OptionalType") return true;
    if (t.kind === "NamedType" && ["Any", "Nil", "Option"].includes(t.name)) return true;
    if (t.kind === "UnionType") return t.types.some((x) => this.acceptsNil(x));
    return false;
  }

  hoistFns(stmts) {
    const scope = this.vars[this.vars.length - 1];
    for (const s of stmts) if (s.kind === "FnStmt") scope.set(s.name, { fn: s, info: { type: T.fn, arity: s.params.filter((p) => !p.rest).length, variadic: s.params.some((p) => p.rest || p.default) } });
  }

  checkFunction(node) {
    for (const p of node.params) if (p.typeAnn) this.validateTypeExpr(p.typeAnn, new Set(node.typeParams || []), p);
    if (node.returnType) this.validateTypeExpr(node.returnType, new Set(node.typeParams || []), node);
    const scope = new Map();
    for (const p of node.params) {
      const names = p.pattern ? patternNames(p.pattern) : [p.name];
      for (const n of names) scope.set(n, { info: p.typeAnn && !p.pattern ? this.infoFromTypeExpr(p.typeAnn) : { type: p.rest ? T.list : T.any }, annotation: p.pattern ? null : p.typeAnn });
      if (p.default && p.typeAnn) {
        const d = this.infer(p.default);
        const r = this.check(p.typeAnn, d);
        if (r) this.error(`Default value for parameter '${p.name}': ${r}`, p, "type-mismatch");
      }
    }
    this.vars.push(scope);
    this.fns.push(node);
    let bodyInfo;
    if (node.body.kind === "BlockExpr") { this.hoistFns(node.body.stmts); bodyInfo = { type: T.nil }; for (const s of node.body.stmts) bodyInfo = this.stmt(s); }
    else bodyInfo = this.infer(node.body);
    if (node.returnType && bodyInfo && !endsWithReturn(node.body)) {
      const r = this.check(node.returnType, bodyInfo);
      if (r) this.error(`Return type mismatch in '${node.name || "lambda"}': ${r}`, node, "return-type");
    }
    this.fns.pop();
    this.vars.pop();
  }

  checkReturn(s) {
    const fn = this.fns[this.fns.length - 1];
    const info = s.value ? this.infer(s.value) : { type: T.nil, known: true, value: null };
    if (fn && fn.returnType) {
      const r = this.check(fn.returnType, info);
      if (r) this.error(`Return type mismatch in '${fn.name || "lambda"}': ${r}`, s, "return-type");
    }
  }

  stmt(s) {
    switch (s.kind) {
      case "LetStmt": {
        const info = this.infer(s.value);
        if (s.typeAnn) {
          this.validateTypeExpr(s.typeAnn, new Set(), s);
          const r = this.check(s.typeAnn, info);
          if (r) this.error(`Type mismatch for '${s.name || "pattern"}': ${r}`, s, "type-mismatch");
        }
        const scope = this.vars[this.vars.length - 1];
        if (s.pattern.kind === "BindingPattern") scope.set(s.pattern.name, { info: s.typeAnn ? Object.assign(this.infoFromTypeExpr(s.typeAnn), info.fields ? { fields: info.fields } : {}) : (s.mutable ? this.widen(info) : info), annotation: s.typeAnn, mutable: s.mutable, fn: s.value.kind === "LambdaExpr" ? { name: s.pattern.name, params: s.value.params, returnType: s.value.returnType } : null });
        else for (const n of patternNames(s.pattern)) scope.set(n, { info: { type: T.any } });
        return info;
      }
      case "FnStmt": {
        const scope = this.vars[this.vars.length - 1];
        if (!scope.has(s.name) || !scope.get(s.name).fn || scope.get(s.name).fn !== s) scope.set(s.name, { fn: s, info: { type: T.fn, arity: s.params.length } });
        this.checkFunction(s);
        return { type: T.fn };
      }
      case "TypeStmt": return { type: T.nil };
      case "UseStmt": return { type: T.nil };
      case "ForStmt": {
        const it = this.infer(s.iterable);
        if (["int", "float", "bool"].includes(it.type.tag)) this.error(`Cannot iterate over ${typeName(it.type)}`, s, "not-iterable");
        this.vars.push(new Map());
        for (const n of patternNames(s.pattern)) this.vars[this.vars.length - 1].set(n, { info: { type: it.type.tag === "list" && it.type.elem ? it.type.elem : it.type.tag === "string" ? T.string : T.any }, mutable: true });
        this.inferBlock(s.body.stmts);
        this.vars.pop();
        return { type: T.nil };
      }
      case "WhileStmt": this.infer(s.condition); this.inferBlock(s.body.stmts); return { type: T.nil };
      case "DoWhileStmt": this.inferBlock(s.body.stmts); if (s.condition) this.infer(s.condition); return { type: T.nil };
      case "ReturnStmt": this.checkReturn(s); return { type: T.any };
      case "BreakStmt": case "ContinueStmt": return { type: T.any };
      case "ExprStmt": return this.infer(s.expr);
    }
    return this.infer(s);
  }

  // Public class API: new TypeChecker().check(program) -> result
  check(program) {
    const input = program !== undefined ? program : this.pendingProgram;
    const r = checkTypes(input, this.options);
    this.result = r;
    return r;
  }

  checkProgram(program) {
    if (!program || !Array.isArray(program.stmts)) return this.check(program);
    this.collectTypes(program.stmts);
    this.hoistFns(program.stmts);
    for (const s of program.stmts) {
      const info = this.stmt(s);
      if (s.kind === "LetStmt") {
        if (s.name) this.exprTypes.set(s.name, this.typeOfInfo(info, s));
        else for (const n of patternNames(s.pattern)) this.exprTypes.set(n, "any");
      } else if (s.kind === "FnStmt") this.exprTypes.set(s.name, "fn");
    }
  }

  // Inferred types are reported with the runtime type names used by type_of().
  typeOfInfo(info, s) {
    if (s && s.typeAnn) return this.typeExprName(s.typeAnn);
    return runtimeTypeName(info && info.type);
  }
}

function predicateText(t) {
  try {
    const { Printer } = require("./formatter.js");
    return new Printer([]).expr(t.predicate, 0, 0);
  } catch (e) { return "..."; }
}

function endsWithReturn(body) {
  if (!body || body.kind !== "BlockExpr" || !body.stmts.length) return false;
  const last = body.stmts[body.stmts.length - 1];
  return last.kind === "ReturnStmt";
}

function patternNames(p, out = []) {
  if (!p) return out;
  switch (p.kind) {
    case "BindingPattern": out.push(p.name); break;
    case "ListPattern": p.elements.forEach((e) => patternNames(e, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "MapPattern": p.fields.forEach((f) => patternNames(f.pattern, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "OrPattern": p.alternatives.forEach((a) => patternNames(a, out)); break;
    case "VariantPattern": (p.args || []).forEach((a) => patternNames(a, out)); break;
    case "TypedPattern": if (p.name !== "_") out.push(p.name); break;
  }
  return Array.from(new Set(out));
}

function toProgramRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (Array.isArray(input)) return parse(input);
  if (input && input.kind === "Program") return input;
  if (input && input.ast) return input.ast;
  if (input && Array.isArray(input.stmts)) return input;
  return { kind: "Program", stmts: [] };
}
function toProgram(input) { return assertValid(toProgramRaw(input)); }

// Diagnostics behave both like objects ({message, line, col}) and like strings.
function diag(d) {
  const s = Object.assign(new String(d.message), d);
  Object.defineProperty(s, "toJSON", { value: () => ({ message: d.message, line: d.line, col: d.col, severity: d.severity, code: d.code }), enumerable: false });
  return s;
}

// The result is an array of errors that also carries the summary fields
// (ok / errors / warnings / types), so it works with both result styles.
function makeResult(errors, warnings, extra) {
  const errs = errors.map(diag);
  const warns = warnings.map(diag);
  const result = errs.slice();
  Object.assign(result, { ok: errs.length === 0, valid: errs.length === 0, errors: errs, warnings: warns, diagnostics: errs.concat(warns) }, extra);
  return result;
}

function checkTypes(input, options = {}) {
  let program;
  try { program = toProgram(input); }
  catch (e) {
    return makeResult([{ message: e.message, line: e.line || 1, col: e.col || 1, severity: "error", code: "parse-error" }], [], { types: new Map(), program: null });
  }
  const tc = new TypeChecker(options);
  try { tc.checkProgram(program); }
  catch (e) { tc.error(`Type checker failure: ${e.message}`, null, "internal"); }
  return makeResult(tc.errors, tc.warnings, { types: tc.exprTypes, declaredTypes: tc.types, program });
}

function typeCheck(program, options) { return checkTypes(program, options); }
function check(source, options) { return checkTypes(source, options); }

function inferTypes(program, options) { return checkTypes(program, options).types; }

module.exports = { checkTypes, typeCheck, typecheck: typeCheck, check, checkProgram: checkTypes, checkSource: checkTypes, inferTypes, TypeChecker };
