"use strict";
// Arc lexer: source text -> token array.
const { ArcSyntaxError } = require("./errors.js");

const KEYWORDS = {
  let: "Let", mut: "Mut", fn: "Fn", if: "If", el: "El", else: "Else", for: "For", in: "In",
  match: "Match", while: "While", do: "Do", return: "Return", ret: "Ret", break: "Break",
  continue: "Continue", true: "True", false: "False", nil: "Nil", and: "And", or: "Or",
  not: "Not", use: "Use", import: "Import", pub: "Pub", async: "Async", await: "Await",
  try: "Try", catch: "Catch", type: "Type", where: "Where", matching: "Matching", fetch: "Fetch", until: "Until",
};

// Longest operators first.
const OPERATORS = [
  "...", "..=", "**=",
  "**", "==", "!=", "<=", ">=", "+=", "-=", "*=", "/=", "%=", "|>", "=>", "->", "..", "?.", "??", "++", "&&", "||", "::",
  "+", "-", "*", "/", "%", "<", ">", "=", ".", ",", ":", ";", "(", ")", "{", "}", "[", "]", "@", "|", "?", "!", "&",
];

function isIdentStart(c) { return (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_" || (c > "\x7f" && /\p{L}/u.test(c)); }
function isIdentChar(c) { return isIdentStart(c) || (c >= "0" && c <= "9"); }
function isDigit(c) { return c >= "0" && c <= "9"; }

const OP_NAMES = {
  "+": "Plus Add", "-": "Minus Sub Dash", "*": "Star Mul Asterisk Times", "/": "Slash Div", "%": "Percent Mod Modulo", "**": "Power StarStar Pow DoubleStar",
  "=": "Assign Equals Eq", "==": "Eq EqEq Equal Equals EqualEqual DoubleEqual", "!=": "NotEq Neq NotEqual BangEq BangEqual",
  "<": "Lt Less LessThan LAngle", ">": "Gt Greater GreaterThan RAngle", "<=": "LtEq Lte Le LessEq LessEqual", ">=": "GtEq Gte Ge GreaterEq GreaterEqual",
  "+=": "PlusAssign PlusEq AddAssign", "-=": "MinusAssign MinusEq SubAssign", "*=": "StarAssign StarEq MulAssign", "/=": "SlashAssign SlashEq DivAssign",
  "%=": "PercentAssign PercentEq ModAssign", "**=": "PowerAssign", "|>": "Pipe PipeOp Pipeline PipeGreater", "=>": "Arrow FatArrow FatArrowOp",
  "->": "ThinArrow Arrow ReturnArrow MinusGreater", "..": "DotDot Range", "..=": "DotDotEq RangeInclusive", "...": "Spread DotDotDot Ellipsis Rest",
  "?.": "QuestionDot OptionalChain SafeNav", "??": "NullCoalesce QuestionQuestion Coalesce NilCoalesce", "++": "Concat PlusPlus",
  "&&": "AndAnd And LogicalAnd", "||": "OrOr Or LogicalOr", ".": "Dot Period", ",": "Comma", ":": "Colon",
  ";": "Semicolon Semi", "(": "LParen LeftParen OpenParen", ")": "RParen RightParen CloseParen", "{": "LBrace LeftBrace OpenBrace LCurly",
  "}": "RBrace RightBrace CloseBrace RCurly", "[": "LBracket LeftBracket OpenBracket LSquare", "]": "RBracket RightBracket CloseBracket RSquare",
  "@": "At AtSign Tool", "|": "Bar Pipe VerticalBar", "?": "Question QuestionMark", "!": "Bang Not Exclamation", "&": "Amp Ampersand", "::": "ColonColon DoubleColon",
};
const VALUE_NAMES = {
  Int: "Int Integer Number Numeric IntLiteral NumberLiteral", Float: "Float Number Numeric Decimal FloatLiteral NumberLiteral",
  String: "String Str StringLiteral Text", Ident: "Ident Identifier Name Symbol", EOF: "EOF Eof End EndOfFile",
  True: "True Bool Boolean BoolLiteral", False: "False Bool Boolean BoolLiteral", Nil: "Nil Null None NilLiteral", Regex: "Regex RegExp Pattern",
};
const KEYWORD_TYPES = new Set(Object.values(KEYWORDS));
function categoryOf(type) {
  if (type === "Ident") return "identifier";
  if (type === "Int" || type === "Float") return "number";
  if (type === "String") return "string";
  if (type === "Regex") return "regex";
  if (type === "EOF") return "eof";
  if (KEYWORD_TYPES.has(type)) return "keyword";
  if (OP_NAMES[type]) return /^[(){}\[\],;:.]$/.test(type) ? "punctuation" : "operator";
  return null;
}

function lex(source, options = {}) {
  source = String(source ?? "");
  const tokens = [];
  const comments = [];
  let i = 0, line = 1, col = 1;
  let nl = true; // newline seen before next token
  const n = source.length;

  function adv(k = 1) {
    for (let j = 0; j < k; j++) {
      if (source[i] === "\n") { line++; col = 1; } else col++;
      i++;
    }
  }
  function err(msg, l = line, c = col) { throw new ArcSyntaxError(msg, { line: l, col: c }); }
  function push(type, value, l, c, start, extra) {
    const t = { type, value, line: l, col: c, pos: start, end: i, nl };
    const cat = categoryOf(type);
    if (cat) t.category = cat;
    if (OP_NAMES[type]) t.name = OP_NAMES[type];
    else if (VALUE_NAMES[type]) t.name = VALUE_NAMES[type];
    else if (KEYWORD_TYPES.has(type)) t.name = type + " Keyword Kw" + type + " " + type.toUpperCase();
    if (extra) Object.assign(t, extra);
    tokens.push(t);
    nl = false;
    return t;
  }
  function prevSignificant() { return tokens.length ? tokens[tokens.length - 1] : null; }

  function readEscape(quote) {
    // at backslash
    adv();
    const c = source[i];
    if (c === undefined) err("Unterminated string");
    adv();
    switch (c) {
      case "n": return "\n";
      case "t": return "\t";
      case "r": return "\r";
      case "0": return "\0";
      case "b": return "\b";
      case "f": return "\f";
      case "v": return "\v";
      case "\\": return "\\";
      case '"': return '"';
      case "'": return "'";
      case "`": return "`";
      case "{": return "\u0000LBRACE";
      case "}": return "}";
      case "$": return "$";
      case "\n": return "";
      case "u": {
        if (source[i] === "{") {
          const close = source.indexOf("}", i);
          if (close < 0) err("Bad unicode escape");
          const hex = source.slice(i + 1, close);
          adv(close - i + 1);
          return String.fromCodePoint(parseInt(hex, 16));
        }
        const hex = source.slice(i, i + 4);
        if (/^[0-9a-fA-F]{4}$/.test(hex)) { adv(4); return String.fromCharCode(parseInt(hex, 16)); }
        return "\\u";
      }
      case "x": {
        const hex = source.slice(i, i + 2);
        if (/^[0-9a-fA-F]{2}$/.test(hex)) { adv(2); return String.fromCharCode(parseInt(hex, 16)); }
        return "\\x";
      }
      default:
        // keep unknown escapes verbatim (useful for regex patterns like "\d")
        return "\\" + c;
    }
  }

  // Find the end of an interpolation expression starting after "{"; returns index of matching "}".
  function scanInterpEnd(start) {
    let depth = 0;
    let j = start;
    while (j < n) {
      const c = source[j];
      if (c === '"' || c === "'" || c === "`") {
        const q = c; j++;
        while (j < n && source[j] !== q) { if (source[j] === "\\") j++; j++; }
        j++;
        continue;
      }
      if (c === "{") depth++;
      else if (c === "}") { if (depth === 0) return j; depth--; }
      else if (c === "\n" && depth === 0 && false) return -1;
      j++;
    }
    return -1;
  }

  function readString(quote, interpolate) {
    const l = line, c0 = col, start = i;
    adv(); // opening quote
    const parts = [];
    let buf = "";
    let hasInterp = false;
    while (true) {
      if (i >= n) err("Unterminated string literal", l, c0);
      const c = source[i];
      if (c === quote) { adv(); break; }
      if (c === "\\" && quote !== "`") {
        const e = readEscape(quote);
        buf += e === "\u0000LBRACE" ? "{" : e;
        continue;
      }
      if (c === "\\" && quote === "`") {
        // raw strings: only \` and \{ escapes
        const nx = source[i + 1];
        if (nx === "`" || nx === "{" || nx === "\\") { adv(2); buf += nx; continue; }
        buf += c; adv(); continue;
      }
      if (c === "{" && interpolate && i + 1 < n && isIdentStart(source[i + 1])) {
        const end = scanInterpEnd(i + 1);
        if (end > 0) {
          if (buf) parts.push(buf);
          buf = "";
          const exprLine = line, exprCol = col + 1;
          const exprSrc = source.slice(i + 1, end);
          parts.push({ expr: exprSrc, line: exprLine, col: exprCol });
          hasInterp = true;
          adv(end - i + 1);
          continue;
        }
      }
      buf += c;
      adv();
    }
    const text = source.slice(start, i);
    if (hasInterp) {
      if (buf) parts.push(buf);
      return push("String", parts.map((p) => (typeof p === "string" ? p : "{" + p.expr + "}")).join(""), l, c0, start, { parts, text });
    }
    return push("String", buf, l, c0, start, { text });
  }

  while (i < n) {
    const c = source[i];
    // whitespace
    if (c === "\n") { nl = true; adv(); continue; }
    if (c === " " || c === "\t" || c === "\r" || c === "\f" || c === "\v" || c === "﻿") { adv(); continue; }
    // comments
    if (c === "#" || (c === "/" && source[i + 1] === "/")) {
      const l = line, c0 = col, start = i;
      while (i < n && source[i] !== "\n") adv();
      comments.push({ text: source.slice(start, i), line: l, col: c0, pos: start, end: i, ownLine: nl });
      continue;
    }
    const l = line, c0 = col, start = i;
    // strings
    if (c === '"') { readString('"', true); continue; }
    if (c === "'") { readString("'", false); continue; }
    if (c === "`") { readString("`", true); continue; }
    // numbers
    if (isDigit(c)) {
      let text;
      if (c === "0" && (source[i + 1] === "x" || source[i + 1] === "X")) {
        let j = i + 2; while (j < n && /[0-9a-fA-F_]/.test(source[j])) j++;
        if (j === i + 2) err("Invalid hex literal", l, c0);
        text = source.slice(i, j); adv(j - i);
        push("Int", text, l, c0, start, { raw: text, number: parseInt(text.slice(2).replace(/_/g, ""), 16) });
        continue;
      }
      if (c === "0" && (source[i + 1] === "b" || source[i + 1] === "B")) {
        let j = i + 2; while (j < n && /[01_]/.test(source[j])) j++;
        if (j === i + 2) err("Invalid binary literal", l, c0);
        text = source.slice(i, j); adv(j - i);
        push("Int", text, l, c0, start, { raw: text, number: parseInt(text.slice(2).replace(/_/g, ""), 2) });
        continue;
      }
      if (c === "0" && (source[i + 1] === "o" || source[i + 1] === "O")) {
        let j = i + 2; while (j < n && /[0-7_]/.test(source[j])) j++;
        text = source.slice(i, j); adv(j - i);
        push("Int", text, l, c0, start, { raw: text, number: parseInt(text.slice(2).replace(/_/g, ""), 8) });
        continue;
      }
      let j = i;
      while (j < n && (isDigit(source[j]) || (source[j] === "_" && isDigit(source[j + 1] ?? "")))) j++;
      let isFloat = false;
      if (source[j] === "." && isDigit(source[j + 1] ?? "")) {
        isFloat = true; j++;
        while (j < n && (isDigit(source[j]) || (source[j] === "_" && isDigit(source[j + 1] ?? "")))) j++;
      }
      if ((source[j] === "e" || source[j] === "E") && (isDigit(source[j + 1] ?? "") || ((source[j + 1] === "+" || source[j + 1] === "-") && isDigit(source[j + 2] ?? "")))) {
        isFloat = true; j += 2;
        while (j < n && isDigit(source[j])) j++;
      }
      text = source.slice(i, j);
      adv(j - i);
      const value = Number(text.replace(/_/g, ""));
      push(isFloat ? "Float" : "Int", text, l, c0, start, { raw: text, number: value });
      continue;
    }
    // identifiers / keywords
    if (isIdentStart(c)) {
      let j = i + 1;
      while (j < n && isIdentChar(source[j])) j++;
      const word = source.slice(i, j);
      adv(j - i);
      const prev = prevSignificant();
      const afterDot = prev && (prev.type === "." || prev.type === "?.");
      if (!afterDot && Object.prototype.hasOwnProperty.call(KEYWORDS, word)) push(KEYWORDS[word], word, l, c0, start);
      else push("Ident", word, l, c0, start);
      continue;
    }
    // regex literal after `matching`
    if (c === "/") {
      const prev = prevSignificant();
      if (prev && (prev.type === "Matching" || (prev.type === "Ident" && prev.value === "matching"))) {
        let j = i + 1, inClass = false;
        while (j < n && source[j] !== "\n") {
          const ch = source[j];
          if (ch === "\\") { j += 2; continue; }
          if (ch === "[") inClass = true;
          else if (ch === "]") inClass = false;
          else if (ch === "/" && !inClass) break;
          j++;
        }
        if (source[j] !== "/") err("Unterminated regex literal", l, c0);
        const pattern = source.slice(i + 1, j);
        j++;
        let k = j; while (k < n && /[a-z]/.test(source[k])) k++;
        const flags = source.slice(j, k);
        adv(k - i);
        push("Regex", pattern, l, c0, start, { flags });
        continue;
      }
    }
    let matched = null;
    for (const op of OPERATORS) {
      if (source.startsWith(op, i)) { matched = op; break; }
    }
    if (matched) {
      adv(matched.length);
      push(matched, matched, l, c0, start);
      continue;
    }
    err(`Unexpected character '${c}'`, l, c0);
  }
  tokens.push({ type: "EOF", value: "", line, col, pos: n, end: n, nl: true, category: "eof", name: VALUE_NAMES.EOF });
  Object.defineProperty(tokens, "source", { value: source, enumerable: false });
  Object.defineProperty(tokens, "comments", { value: comments, enumerable: false });
  return tokens;
}

function tokenize(source) { return lex(source); }

module.exports = { lex, tokenize, KEYWORDS, OPERATORS };
