"use strict";
// Arc -> JavaScript code generator. Generated code embeds the shared runtime core.
const { createRuntime } = require("./runtime-core.js");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { isNullaryVariant } = require("./interpreter.js");

const JS_RESERVED = new Set(("break case catch class const continue debugger default delete do else enum export extends false finally for function if import in instanceof new null return super switch this throw true try typeof var void while with yield let static implements interface package private protected public await async arguments eval undefined NaN Infinity of get set").split(" "));

let RUNTIME_SOURCE = null;
let RUNTIME_INFO = null;
function runtimeInfo() {
  if (!RUNTIME_INFO) {
    const rt = createRuntime({});
    const modules = {};
    for (const name of rt.moduleNames) {
      try { modules[name] = Object.keys(rt.loadModule(name)); } catch (e) { modules[name] = []; }
    }
    RUNTIME_INFO = { builtins: new Set(Object.keys(rt.builtins)), modules, rt };
  }
  return RUNTIME_INFO;
}

function jsSafe(name) {
  if (JS_RESERVED.has(name) || name.startsWith("__") || Object.prototype.hasOwnProperty.call(globalThis, name) || name === "require" || name === "module" || name === "exports" || name === "process" || name === "Buffer" || name === "console" || name === "result$") return name + "$";
  return name;
}

class CScope {
  constructor(parent, kind) { this.parent = parent; this.kind = kind; this.vars = new Map(); }
  // Names declared later in a block are only visible to straight-line code after their
  // declaration, but nested functions (deferred execution) can see every name.
  lookup(name) {
    let s = this, crossed = false;
    while (s) {
      const v = s.vars.get(name);
      if (v && (v.visible || crossed)) return v;
      if (s.kind === "function") crossed = true;
      s = s.parent;
    }
    return null;
  }
}

class FnCtx {
  constructor(parent) { this.parent = parent; this.temps = 0; this.needsRet = false; this.iife = 0; }
}

class Gen {
  constructor(options = {}) {
    this.options = options;
    this.uid = 0;
    this.info = runtimeInfo();
    this.usedNames = new Set();
    this.moduleCode = [];
    this.moduleIds = new Map();
  }

  fresh(base) {
    const b = String(base).replace(/[^A-Za-z0-9_]/g, "_");
    return `${b}$${++this.uid}`;
  }

  // ---------- scopes ----------
  declareName(scope, name, mutable, kind) {
    const existing = scope.vars.get(name);
    if (existing) {
      existing.mutable = mutable;
      if (kind === "fn") existing.kind = "fn"; else existing.notOnlyFn = true;
      return existing;
    }
    let js = jsSafe(name);
    // avoid TDZ / shadowing conflicts: fresh name if visible elsewhere already
    if (this.usedNames.has(js) && !(scope.kind === "program" && name === "result")) js = this.fresh(js.replace(/\$$/, ""));
    this.usedNames.add(js);
    const v = { js, mutable, kind: kind || "var", declared: false, visible: kind === "fn" || kind === "visible", notOnlyFn: kind !== "fn" };
    scope.vars.set(name, v);
    return v;
  }

  resolve(scope, name) {
    const v = scope.lookup(name);
    if (v) return v.js;
    if (this.info.builtins.has(name)) return `__b.${name}`;
    return `__undef(${JSON.stringify(name)})`;
  }

  // Pre-scan a block's statements: names declared directly in it.
  prescan(stmts, scope) {
    const decls = [];
    for (const s of stmts) {
      switch (s.kind) {
        case "LetStmt": for (const n of patternNames(s.pattern)) decls.push(this.declareName(scope, n, s.mutable)); break;
        case "FnStmt": decls.push(this.declareName(scope, s.name, false, "fn")); break;
        case "UseStmt": {
          if (s.imports === null) {
            decls.push(this.declareName(scope, s.alias || s.name, false));
          } else if (Array.isArray(s.imports)) {
            for (const n of s.imports) decls.push(this.declareName(scope, n, false));
            if (!scope.lookup(s.alias || s.name) && !this.info.builtins.has(s.alias || s.name)) decls.push(this.declareName(scope, s.alias || s.name, false));
          }
          break;
        }
        case "TypeStmt": {
          const walk = (t, u) => { if (!t) return; if (t.kind === "UnionType") t.types.forEach((x) => walk(x, true)); else if ((t.kind === "VariantType" || (u && isNullaryVariant(t))) && !["Ok", "Err", "Some", "None"].includes(t.name) && !scope.vars.has(t.name) && !(u && t.kind === "NamedType" && scope.lookup(t.name))) decls.push(this.declareName(scope, t.name, false)); };
          walk(s.def, false);
          break;
        }
      }
    }
    const uniq = [];
    for (const d of decls) if (!d.declared) { d.declared = true; uniq.push(d.js); }
    return uniq;
  }

  temp(fn) { const n = `$t${++fn.temps}`; return n; }

  // Runtime type descriptor (type AST without locations; `where` predicates become functions).
  genTypeDesc(t, scope, fn) {
    if (!t) return "null";
    const hasPred = (n) => {
      if (!n || typeof n !== "object") return false;
      if (Array.isArray(n)) return n.some(hasPred);
      if (n.kind === "ConstrainedType" && n.predicate) return true;
      return Object.keys(n).some((k) => k !== "predicate" && hasPred(n[k]));
    };
    const strip = (n) => {
      if (n === null || typeof n !== "object") return n;
      if (Array.isArray(n)) return n.map(strip);
      const o = {};
      for (const k of Object.keys(n)) { if (k === "line" || k === "col" || k === "predicate" || k === "default") continue; o[k] = strip(n[k]); }
      if (n.name !== undefined && n.type !== undefined && n.kind === undefined && n.default) o.hasDefault = true;
      return o;
    };
    if (!hasPred(t)) return JSON.stringify(strip(t));
    const emit = (n) => {
      if (n === null || typeof n !== "object") return JSON.stringify(n);
      if (Array.isArray(n)) return `[${n.map(emit).join(", ")}]`;
      if (n.kind === "ConstrainedType" && n.predicate) {
        const params = [n.param || "x", "value", "it", "self"].map((name) => ({ kind: "Param", name, pattern: null, rest: false, default: null, typeAnn: null }));
        const lam = this.genFunction({ kind: "LambdaExpr", params, body: n.predicate }, scope, fn, null, false);
        let text = "";
        try { text = new (require("./formatter.js").Printer)([]).expr(n.predicate, 0, 0); } catch (e) { text = ""; }
        return `{ kind: "ConstrainedType", base: ${emit(n.base)}, regex: null, test: ${lam}, text: ${JSON.stringify(text)} }`;
      }
      if (!hasPred(n)) return JSON.stringify(strip(n));
      const parts = Object.keys(n).filter((k) => k !== "line" && k !== "col" && k !== "default").map((k) => `${JSON.stringify(k)}: ${emit(n[k])}`);
      if (n.name !== undefined && n.type !== undefined && n.kind === undefined && n.default) parts.push(`"hasDefault": true`);
      return `{ ${parts.join(", ")} }`;
    };
    return emit(t);
  }

  // ---------- program ----------
  genProgram(program, bindResult) {
    const scope = new CScope(null, "program");
    const fn = new FnCtx(null);
    fn.isTop = true;
    const split = {};
    // When the program never declares `result`, expose its final value as `result`
    // (the same value the interpreter returns).
    const declaresResult = program.stmts.some((st) => declaredNamesOf(st).includes("result") || (st.kind === "UseStmt" && (st.alias || st.name) === "result"));
    const useResult = bindResult && !declaresResult && program.stmts.length > 0;
    if (useResult) this.usedNames.add("result");
    const body = this.genBlockBody(program.stmts, scope, fn, useResult ? "assign" : "discard", useResult ? "result" : null, null, split);
    let decl = split.decl || "";
    if (useResult) decl = decl ? decl.replace(/^let /, "let result, ") : "let result;";
    const temps = fn.temps ? `let ${Array.from({ length: fn.temps }, (_, i) => `$t${i + 1}`).join(", ")};\n` : "";
    return { code: temps + (decl ? decl + "\n" : "") + body, scope, temps, decl, body, needsRet: fn.needsRet };
  }

  // Generate statements of a block; `mode` applies to the value of the last statement.
  genBlockBody(stmts, scope, fn, mode, target, loop, split) {
    const lines = [];
    const decls = this.prescan(stmts, scope);
    if (decls.length) {
      if (split) split.decl = `let ${decls.join(", ")};`;
      else lines.push(`let ${decls.join(", ")};`);
    }
    // hoist type declarations (runtime type registry)
    for (const s of stmts) {
      if (s.kind === "TypeStmt") lines.push(`__rt.declareType(${JSON.stringify(s.name)}, ${this.genTypeDesc(s.def, scope, fn)});`);
    }
    // hoist function declarations
    const hoisted = [];
    for (const s of stmts) {
      if (s.kind === "FnStmt") {
        const v = scope.vars.get(s.name);
        const fname = this.fresh(s.name);
        s.__jsFn = fname;
        lines.push(this.genFunction(s, scope, fn, fname, true));
        hoisted.push(`${v.js} = ${fname};`);
      }
    }
    lines.push(...hoisted);
    if (!stmts.length) {
      if (mode === "return") lines.push("return null;");
      else if (mode === "assign") lines.push(`${target} = null;`);
      return lines.join("\n");
    }
    for (let i = 0; i < stmts.length; i++) {
      const last = i === stmts.length - 1;
      lines.push(this.genStmt(stmts[i], scope, fn, last ? mode : "discard", last ? target : null, loop));
    }
    return lines.join("\n");
  }

  applyMode(expr, mode, target) {
    if (mode === "return") return `return ${expr};`;
    if (mode === "assign") return `${target} = ${expr};`;
    return `${expr};`;
  }

  genStmt(s, scope, fn, mode, target, loop) {
    switch (s.kind) {
      case "LetStmt": return this.genLet(s, scope, fn, mode, target);
      case "FnStmt": {
        const v = scope.vars.get(s.name);
        return `${v.js} = ${s.__jsFn};` + (mode === "discard" ? "" : "\n" + this.applyMode(v.js, mode, target));
      }
      case "TypeStmt": {
        const out = [];
        const walk = (t, u) => {
          if (!t) return;
          if (t.kind === "UnionType") t.types.forEach((x) => walk(x, true));
          else if (t.kind === "VariantType" && !["Ok", "Err", "Some", "None"].includes(t.name)) {
            const v = scope.vars.get(t.name);
            if (v) v.visible = true;
            if (v) out.push(`if (${v.js} === undefined) ${v.js} = __rt.makeVariant(${JSON.stringify(t.name)}, ${t.fields.length});`);
          } else if (u && isNullaryVariant(t) && !["None"].includes(t.name)) {
            const v = scope.vars.get(t.name);
            if (v && !v.visible) { v.visible = true; out.push(`if (${v.js} === undefined) ${v.js} = { __tag: ${JSON.stringify(t.name)}, __values: [] };`); }
          }
        };
        walk(s.def, false);
        if (mode !== "discard") out.push(this.applyMode("null", mode, target));
        return out.join("\n");
      }
      case "UseStmt": return this.genUse(s, scope, fn) + (mode !== "discard" ? "\n" + this.applyMode("null", mode, target) : "");
      case "ForStmt": return this.genFor(s, scope, fn) + (mode !== "discard" ? "\n" + this.applyMode("null", mode, target) : "");
      case "WhileStmt": return this.genWhile(s, scope, fn) + (mode !== "discard" ? "\n" + this.applyMode("null", mode, target) : "");
      case "DoWhileStmt": return this.genDoWhile(s, scope, fn) + (mode !== "discard" ? "\n" + this.applyMode("null", mode, target) : "");
      case "ReturnStmt": return this.genReturn(s, scope, fn);
      case "BreakStmt": return this.genBreak(fn, true);
      case "ContinueStmt": return this.genBreak(fn, false);
      case "ExprStmt": return this.genExprStmt(s.expr, scope, fn, mode, target);
      default: return this.genExprStmt(s, scope, fn, mode, target);
    }
  }

  genReturn(s, scope, fn) {
    const v = s.value ? this.genExpr(s.value, scope, fn) : "null";
    if (fn.iife > 0 || fn.isTop) { fn.needsRet = true; return `throw new __Ret(${v});`; }
    return `return ${v};`;
  }

  genBreak(fn, isBreak) {
    const loop = fn.loop;
    if (!loop) return `__rt.fail(${JSON.stringify(`'${isBreak ? "break" : "continue"}' outside of loop`)});`;
    if (fn.iife > loop.iife) { loop.needsCatch = true; return isBreak ? "throw __BRK;" : "throw __CONT;"; }
    return isBreak ? "break;" : "continue;";
  }

  genExprStmt(e, scope, fn, mode, target) {
    switch (e.kind) {
      case "IfExpr": return this.genIfStmt(e, scope, fn, mode, target);
      case "MatchExpr": return this.genMatchStmt(e, scope, fn, mode, target);
      case "BlockExpr": return `{\n${this.genBlockBody(e.stmts, new CScope(scope, "block"), fn, mode, target)}\n}`;
      case "AsyncExpr": return `{\n${this.genBlockBody(e.body.stmts, new CScope(scope, "block"), fn, mode, target)}\n}`;
      case "TryExpr": return this.genTryStmt(e, scope, fn, mode, target);
      case "ReturnStmt": return this.genReturn(e, scope, fn);
      case "BreakStmt": return this.genBreak(fn, true);
      case "ContinueStmt": return this.genBreak(fn, false);
      case "LetStmt": case "FnStmt": case "ForStmt": case "WhileStmt": case "DoWhileStmt": case "UseStmt": case "TypeStmt":
        return this.genStmt(e, scope, fn, mode, target);
    }
    return this.applyMode(this.genExpr(e, scope, fn), mode, target);
  }

  genBranch(b, scope, fn, mode, target) {
    if (b.kind === "BlockExpr") return this.genBlockBody(b.stmts, new CScope(scope, "block"), fn, mode, target);
    return this.genExprStmt(b, scope, fn, mode, target);
  }

  genIfStmt(e, scope, fn, mode, target) {
    let out = `if (__t(${this.genExpr(e.condition, scope, fn)})) {\n${this.genBranch(e.then, scope, fn, mode, target)}\n}`;
    if (e.else_) {
      if (e.else_.kind === "IfExpr") out += ` else ${this.genIfStmt(e.else_, scope, fn, mode, target)}`;
      else out += ` else {\n${this.genBranch(e.else_, scope, fn, mode, target)}\n}`;
    } else if (mode !== "discard") out += ` else {\n${this.applyMode("null", mode, target)}\n}`;
    return out;
  }

  genMatchStmt(e, scope, fn, mode, target) {
    const label = this.fresh("$m");
    const subj = this.fresh("$s");
    const lines = [`${label}: {`, `const ${subj} = ${this.genExpr(e.subject, scope, fn)};`];
    for (const arm of e.arms) {
      const inner = new CScope(scope, "block");
      const names = patternNames(arm.pattern);
      const bvar = this.fresh("$b");
      const pat = JSON.stringify(stripPattern(arm.pattern));
      const binds = names.map((n) => { const v = this.declareName(inner, n, false, "visible"); v.declared = true; return `const ${v.js} = ${bvar}[${JSON.stringify(n)}];`; });
      const body = this.genBranch(arm.body, inner, fn, mode, target);
      const brk = mode === "return" ? "" : `\nbreak ${label};`;
      let armCode;
      if (arm.guard) {
        const guard = this.genExpr(arm.guard, inner, fn);
        armCode = `${binds.join("\n")}\nif (__t(${guard})) {\n${body}${brk}\n}`;
      } else armCode = `${binds.join("\n")}\n${body}${brk}`;
      lines.push(`{ const ${bvar} = __match(${pat}, ${subj});\nif (${bvar} !== null) {\n${armCode}\n} }`);
    }
    if (mode !== "discard") lines.push(this.applyMode("null", mode, target));
    lines.push("}");
    return lines.join("\n");
  }

  genTryStmt(e, scope, fn, mode, target) {
    const ev = this.fresh("$e");
    let out = `try {\n${this.genBlockBody(e.body.stmts, new CScope(scope, "block"), fn, mode, target)}\n}`;
    if (e.catchBody) {
      const inner = new CScope(scope, "block");
      let bind = "";
      if (e.catchParam) { const v = this.declareName(inner, e.catchParam, false, "visible"); v.declared = true; bind = `const ${v.js} = __rt.errorMessage(${ev});\n`; }
      out += ` catch (${ev}) {\nif (__isSig(${ev})) throw ${ev};\n${bind}${this.genBlockBody(e.catchBody.stmts, inner, fn, mode, target)}\n}`;
    }
    if (e.finallyBody) out += ` finally {\n${this.genBlockBody(e.finallyBody.stmts, new CScope(scope, "block"), fn, "discard", null)}\n}`;
    return out;
  }

  genLet(s, scope, fn, mode, target) {
    const names = patternNames(s.pattern);
    let code;
    if (s.pattern.kind === "BindingPattern") {
      const v = scope.vars.get(s.pattern.name) || this.declareName(scope, s.pattern.name, s.mutable);
      const val = s.value;
      if (["IfExpr", "MatchExpr", "TryExpr", "BlockExpr"].includes(val.kind)) {
        const tmp = this.temp(fn);
        code = this.genExprStmt(val, scope, fn, "assign", tmp) + `\n${v.js} = ${tmp};`;
      } else code = `${v.js} = ${this.genExpr(val, scope, fn)};`;
      if (s.typeAnn) {
        const desc = this.genTypeDesc(s.typeAnn, scope, fn);
        code += `\n__rt.assertType(${desc}, ${v.js}, ${JSON.stringify(`'${s.pattern.name}'`)});`;
        v.typeDesc = desc;
        v.typeName = s.pattern.name;
      } else { v.typeDesc = null; }
      v.mutable = s.mutable;
      v.visible = true;
      if (mode !== "discard") code += "\n" + this.applyMode(v.js, mode, target);
      return code;
    }
    const tmp = this.temp(fn);
    const d = this.temp(fn);
    code = `${tmp} = ${this.genExpr(s.value, scope, fn)};\n`;
    if (s.typeAnn) code += `__rt.assertType(${this.genTypeDesc(s.typeAnn, scope, fn)}, ${tmp}, "destructured value");\n`;
    code += `${d} = __destr(${JSON.stringify(stripPattern(s.pattern))}, ${tmp});`;
    for (const n of names) {
      const v = scope.vars.get(n) || this.declareName(scope, n, s.mutable);
      v.mutable = s.mutable;
      v.visible = true;
      code += `\n${v.js} = ${d}[${JSON.stringify(n)}];`;
    }
    if (mode !== "discard") code += "\n" + this.applyMode(tmp, mode, target);
    return code;
  }

  genUse(s, scope, fn) {
    const ns = this.fresh("$ns");
    let load;
    const info = this.info;
    let memberNames = null;
    if (info.rt.hasModule(s.path)) {
      load = `__rt.loadModule(${JSON.stringify(s.path)})`;
      const key = Object.keys(info.modules).find((k) => info.rt.loadModule(k) === info.rt.loadModule(s.path));
      memberNames = key ? info.modules[key] : [];
    } else {
      const compiled = this.compileFileModule(s.path);
      if (compiled) { load = compiled.id; memberNames = compiled.exports; }
      else load = `__rt.fail(${JSON.stringify(`Module not found: '${s.path}'`)})`;
    }
    const lines = [`const ${ns} = ${load};`];
    const markVisible = (n) => { const v = scope.vars.get(n); if (v) v.visible = true; };
    markVisible(s.alias || s.name);
    if (Array.isArray(s.imports)) s.imports.forEach(markVisible);
    if (s.imports === null) {
      const v = scope.vars.get(s.alias || s.name);
      lines.push(`${v.js} = ${ns};`);
      for (const k of memberNames || []) {
        if (k.startsWith("_") || scope.lookup(k) || info.builtins.has(k)) continue;
        const pre = scope.vars.get(k);
        if (pre) { pre.visible = true; lines.push(`${pre.js} = ${ns}[${JSON.stringify(k)}];`); continue; }
        const kv = this.declareName(scope, k, false, "visible");
        kv.declared = true;
        lines.push(`let ${kv.js} = ${ns}[${JSON.stringify(k)}];`);
      }
    } else if (s.imports === "*") {
      for (const k of memberNames || []) {
        const kv = scope.vars.get(k) || this.declareName(scope, k, false, "visible");
        kv.visible = true;
        if (!kv.declared) { kv.declared = true; lines.push(`let ${kv.js};`); }
        lines.push(`${kv.js} = ${ns}[${JSON.stringify(k)}];`);
      }
    } else {
      for (const n of s.imports) {
        const v = scope.vars.get(n);
        lines.push(`if (!Object.prototype.hasOwnProperty.call(${ns}, ${JSON.stringify(n)})) __rt.fail(${JSON.stringify(`Module '${s.path}' has no export '${n}'`)});`);
        lines.push(`${v.js} = ${ns}[${JSON.stringify(n)}];`);
      }
      const mv = scope.vars.get(s.alias || s.name);
      if (mv && !s.imports.includes(s.alias || s.name)) lines.push(`${mv.js} = ${ns};`);
    }
    return lines.join("\n");
  }

  compileFileModule(modPath) {
    let fs, pathMod;
    try { fs = require("fs"); pathMod = require("path"); } catch (e) { return null; }
    const base = this.options.baseDir || process.cwd();
    const rel = String(modPath);
    const raw = pathMod.isAbsolute(rel) ? rel : pathMod.resolve(base, rel);
    const candidates = rel.endsWith(".arc") ? [raw] : [raw + ".arc", pathMod.join(raw, "index.arc"), pathMod.join(raw, "main.arc")];
    candidates.push(pathMod.resolve(__dirname, "..", "stdlib", rel.replace(/^(std|stdlib)\//, "") + ".arc"));
    let file = null;
    for (const c of candidates) { try { if (fs.statSync(c).isFile()) { file = c; break; } } catch (e) { /* skip */ } }
    if (!file) return null;
    if (this.moduleIds.has(file)) return this.moduleIds.get(file);
    const id = this.fresh("$mod");
    const entry = { id, exports: [] };
    this.moduleIds.set(file, entry);
    const program = assertValid(parse(lex(fs.readFileSync(file, "utf8"))));
    const sub = new Gen(Object.assign({}, this.options, { baseDir: pathMod.dirname(file) }));
    sub.uid = this.uid + 1000;
    sub.moduleIds = this.moduleIds;
    sub.moduleCode = this.moduleCode;
    const { code, scope } = sub.genProgram(program);
    this.uid = sub.uid + 1;
    const hasPub = program.stmts.some((s) => s.pub);
    const exportsList = [];
    for (const s of program.stmts) {
      for (const n of declaredNamesOf(s)) {
        if (hasPub ? s.pub : !n.startsWith("_")) { const v = scope.vars.get(n); if (v) exportsList.push(`${JSON.stringify(n)}: ${v.js}`); entry.exports.push(n); }
      }
    }
    this.moduleCode.push(`const ${id} = (function () {\n${code}\nreturn { ${exportsList.join(", ")} };\n})();`);
    return entry;
  }

  genLoopBody(stmts, scope, fn, loop, prefix) {
    const saved = fn.loop;
    fn.loop = loop;
    const body = this.genBlockBody(stmts, scope, fn, "discard", null);
    fn.loop = saved;
    if (loop.needsCatch) {
      return `try {\n${prefix}${body}\n} catch ($le) { if ($le === __BRK) break; if ($le === __CONT) continue; throw $le; }`;
    }
    return prefix + body;
  }

  genFor(s, scope, fn) {
    const it = this.fresh("$it");
    const inner = new CScope(scope, "block");
    let prefix;
    if (s.pattern.kind === "BindingPattern") {
      const v = this.declareName(inner, s.pattern.name, true, "visible"); v.declared = true;
      prefix = `let ${v.js} = ${it};\n`;
    } else {
      const d = this.fresh("$d");
      const names = patternNames(s.pattern);
      prefix = `const ${d} = __destr(${JSON.stringify(stripPattern(s.pattern))}, ${it});\n` + names.map((n) => { const v = this.declareName(inner, n, true, "visible"); v.declared = true; return `let ${v.js} = ${d}[${JSON.stringify(n)}];\n`; }).join("");
    }
    const loop = { iife: fn.iife, needsCatch: false };
    const body = this.genLoopBody(s.body.stmts, inner, fn, loop, prefix);
    return `for (const ${it} of __it(${this.genExpr(s.iterable, scope, fn)})) {\n${body}\n}`;
  }

  genWhile(s, scope, fn) {
    const loop = { iife: fn.iife, needsCatch: false };
    const body = this.genLoopBody(s.body.stmts, new CScope(scope, "block"), fn, loop, "");
    return `while (__t(${this.genExpr(s.condition, scope, fn)})) {\n${body}\n}`;
  }

  genDoWhile(s, scope, fn) {
    const loop = { iife: fn.iife, needsCatch: false };
    const body = this.genLoopBody(s.body.stmts, new CScope(scope, "block"), fn, loop, "");
    if (!s.condition) return `do {\n${body}\n} while (false);`;
    const c = `__t(${this.genExpr(s.condition, scope, fn)})`;
    return `do {\n${body}\n} while (${s.until ? `!${c}` : c});`;
  }

  // ---------- functions ----------
  genFunction(node, scope, parentFn, name, isDecl) {
    const fscope = new CScope(scope, "function");
    const fn = new FnCtx(parentFn);
    const params = [];
    const prologue = [];
    node.params.forEach((p, i) => {
      if (p.rest) {
        const pn = p.name ? this.declareName(fscope, p.name, true, "visible") : null;
        const js = pn ? pn.js : this.fresh("$rest");
        if (pn) pn.declared = true;
        params.push("..." + js);
        if (p.pattern) this.genParamDestructure(p, js, fscope, fn, prologue);
        return;
      }
      if (p.pattern) {
        const js = this.fresh("$p");
        params.push(js);
        if (p.default) prologue.push(`if (${js} === undefined) ${js} = ${this.genExpr(p.default, fscope, fn)};`);
        else prologue.push(`if (${js} === undefined) ${js} = null;`);
        this.genParamDestructure(p, js, fscope, fn, prologue);
        return;
      }
      const v = this.declareName(fscope, p.name, true, "visible");
      v.declared = true;
      params.push(v.js);
      if (p.default) prologue.push(`if (${v.js} === undefined) ${v.js} = ${this.genExpr(p.default, fscope, fn)};`);
      else prologue.push(`if (${v.js} === undefined) ${v.js} = null;`);
      if (p.typeAnn) {
        const desc = this.genTypeDesc(p.typeAnn, scope, fn);
        prologue.push(`__rt.assertType(${desc}, ${v.js}, ${JSON.stringify(`parameter '${p.name}' of '${node.name || "anonymous"}'`)});`);
        v.typeDesc = desc;
        v.typeName = p.name;
      }
    });
    let body;
    if (node.body.kind === "BlockExpr") body = this.genBlockBody(node.body.stmts, fscope, fn, "return", null);
    else body = this.genExprStmt(node.body, fscope, fn, "return", null);
    if (fn.needsRet) body = `try {\n${body}\n} catch ($r) { if ($r instanceof __Ret) return $r.value; throw $r; }`;
    const temps = fn.temps ? `let ${Array.from({ length: fn.temps }, (_, i) => `$t${i + 1}`).join(", ")};\n` : "";
    const arcName = node.name || "anonymous";
    if (node.returnType) {
      const desc = this.genTypeDesc(node.returnType, scope, parentFn);
      body = `const $rv = (() => {\n${temps}${body}\n})();\nreturn __rt.assertType(${desc}, $rv === undefined ? null : $rv, ${JSON.stringify(`return value of '${arcName}'`)});`;
    } else body = temps + body;
    const fname = name || this.fresh("$fn");
    const arity = node.params.filter((p) => !p.rest).length;
    const variadic = node.params.some((p) => p.rest || p.default);
    const code = `function ${fname}(${params.join(", ")}) {\n${prologue.join("\n")}\n${body}\n}`;
    if (isDecl) return `${code}\n${fname}.arcName = ${JSON.stringify(arcName)}; ${fname}.__arity = ${arity};${variadic ? ` ${fname}.__variadic = true;` : ""}`;
    return `__fn(${code}, ${JSON.stringify(arcName)}, ${arity}, ${variadic})`;
  }

  genParamDestructure(p, js, fscope, fn, prologue) {
    const d = this.fresh("$d");
    prologue.push(`const ${d} = __destr(${JSON.stringify(stripPattern(p.pattern))}, ${js});`);
    for (const n of patternNames(p.pattern)) {
      const v = this.declareName(fscope, n, true, "visible");
      v.declared = true;
      prologue.push(`let ${v.js} = ${d}[${JSON.stringify(n)}];`);
    }
  }

  // ---------- expressions ----------
  iife(body, fn) { return `(() => {\n${body}\n})()`; }

  withIIFE(fn, gen) {
    fn.iife++;
    try { return gen(); } finally { fn.iife--; }
  }

  genArgs(args, scope, fn) {
    return args.map((a) => (a.kind === "SpreadExpr" ? `...__it(${this.genExpr(a.expr, scope, fn)})` : this.genExpr(a, scope, fn))).join(", ");
  }

  genExpr(e, scope, fn) {
    switch (e.kind) {
      case "IntLiteral": case "FloatLiteral": return numLit(e.value);
      case "StringLiteral": return JSON.stringify(e.value);
      case "BoolLiteral": return e.value ? "true" : "false";
      case "NilLiteral": case "EllipsisExpr": return "null";
      case "RegexLiteral": return JSON.stringify(e.pattern);
      case "StringInterp": {
        const parts = e.parts.map((p) => (typeof p === "string" ? JSON.stringify(p) : `__str(${this.genExpr(p, scope, fn)})`));
        return `(${parts.length ? parts.join(" + ") : '""'})`;
      }
      case "Identifier": return this.resolve(scope, e.name);
      case "BinaryExpr": return this.genBinary(e, scope, fn);
      case "UnaryExpr": {
        const o = this.genExpr(e.operand, scope, fn);
        return e.op === "-" ? `__neg(${o})` : `!__t(${o})`;
      }
      case "RangeExpr": return `__range(${this.genExpr(e.start, scope, fn)}, ${this.genExpr(e.end, scope, fn)}, ${e.inclusive ? "true" : "false"})`;
      case "CallExpr": return this.genCall(e, scope, fn);
      case "MemberExpr": return `__get(${this.genExpr(e.object, scope, fn)}, ${JSON.stringify(e.property)}${e.optional ? ", true" : ""})`;
      case "IndexExpr": return `__idx(${this.genExpr(e.object, scope, fn)}, ${this.genExpr(e.index, scope, fn)}${e.optional ? ", true" : ""})`;
      case "SliceExpr": {
        const end = e.end ? this.genExpr(e.end, scope, fn) : "null";
        return `__rt.slice(${this.genExpr(e.object, scope, fn)}, ${e.start ? this.genExpr(e.start, scope, fn) : "null"}, ${e.inclusive && e.end ? `__add(${end}, 1)` : end})`;
      }
      case "PipelineExpr": return this.genPipeline(e, scope, fn);
      case "IfExpr": {
        const simple = (b) => !b || b.kind !== "BlockExpr" ? isSimpleExpr(b) : b.stmts.length === 0 || (b.stmts.length === 1 && b.stmts[0].kind === "ExprStmt" && isSimpleExpr(b.stmts[0].expr));
        if (simple(e.then) && (e.else_ === null || e.else_.kind === "IfExpr" ? (e.else_ === null || this.isSimpleIf(e.else_)) : simple(e.else_))) {
          const br = (b) => {
            if (!b) return "null";
            if (b.kind === "BlockExpr") return b.stmts.length ? this.genExpr(b.stmts[0].expr, new CScope(scope, "block"), fn) : "null";
            return this.genExpr(b, scope, fn);
          };
          return `(__t(${this.genExpr(e.condition, scope, fn)}) ? ${br(e.then)} : ${br(e.else_)})`;
        }
        return this.withIIFE(fn, () => this.iife(this.genIfStmt(e, scope, fn, "return", null), fn));
      }
      case "MatchExpr": return this.withIIFE(fn, () => this.iife(this.genMatchStmt(e, scope, fn, "return", null), fn));
      case "TryExpr": return this.withIIFE(fn, () => this.iife(this.genTryStmt(e, scope, fn, "return", null), fn));
      case "BlockExpr": return this.withIIFE(fn, () => this.iife(this.genBlockBody(e.stmts, new CScope(scope, "block"), fn, "return", null), fn));
      case "AsyncExpr": return this.withIIFE(fn, () => this.iife(this.genBlockBody(e.body.stmts, new CScope(scope, "block"), fn, "return", null), fn));
      case "AwaitExpr": return this.genExpr(e.expr, scope, fn);
      case "LambdaExpr": {
        const saved = fn.loop;
        const code = this.genFunction(e, scope, fn, null, false);
        fn.loop = saved;
        return code;
      }
      case "ListLiteral": return `[${this.genArgs(e.elements, scope, fn)}]`;
      case "MapLiteral": return this.genMap(e, scope, fn);
      case "ListComprehension": case "MapComprehension": return this.genComprehension(e, scope, fn);
      case "ToolCallExpr": {
        if (e.method) return `__rt.toolCall(${JSON.stringify(e.method)}, __str(${this.genExpr(e.url, scope, fn)}), ${e.body ? this.genExpr(e.body, scope, fn) : "null"})`;
        const args = `[${this.genArgs(e.args, scope, fn)}]`;
        const v = scope.lookup(e.name);
        if (v) return `((__rt.tools && typeof __rt.tools[${JSON.stringify(e.name)}] === "function") ? __rt.customTool(${JSON.stringify(e.name)}, ${args}) : __call(${v.js}, ${args}, ${JSON.stringify(e.name)}))`;
        return `__rt.customTool(${JSON.stringify(e.name)}, ${args})`;
      }
      case "FetchExpr": return `[${e.calls.map((c) => this.genExpr(c, scope, fn)).join(", ")}]`;
      case "PropagateExpr": { fn.needsRet = true; return `__prop(${this.genExpr(e.expr, scope, fn)})`; }
      case "AssignExpr": return this.genAssign(e, scope, fn);
      case "ReturnStmt": { fn.needsRet = true; return `__throwRet(${e.value ? this.genExpr(e.value, scope, fn) : "null"})`; }
      case "BreakStmt": case "ContinueStmt": {
        const loop = fn.loop;
        if (!loop) return `__rt.fail(${JSON.stringify(`'${e.kind === "BreakStmt" ? "break" : "continue"}' outside of loop`)})`;
        loop.needsCatch = true;
        return e.kind === "BreakStmt" ? "__throwSig(__BRK)" : "__throwSig(__CONT)";
      }
      case "SpreadExpr": return `__rt.fail("Spread '...' is only allowed in lists, maps and call arguments")`;
      case "ExprStmt": return this.genExpr(e.expr, scope, fn);
      case "LetStmt": case "FnStmt": case "ForStmt": case "WhileStmt": case "DoWhileStmt": case "UseStmt": case "TypeStmt":
        return this.withIIFE(fn, () => this.iife(this.genBlockBody([e], new CScope(scope, "block"), fn, "return", null), fn));
    }
    throw new Error(`codegen: unsupported node ${e.kind}`);
  }

  isSimpleIf(e) {
    const simple = (b) => !b || (b.kind !== "BlockExpr" ? isSimpleExpr(b) : b.stmts.length === 0 || (b.stmts.length === 1 && b.stmts[0].kind === "ExprStmt" && isSimpleExpr(b.stmts[0].expr)));
    return simple(e.then) && (e.else_ === null || (e.else_.kind === "IfExpr" ? this.isSimpleIf(e.else_) : simple(e.else_)));
  }

  genBinary(e, scope, fn) {
    const L = this.genExpr(e.left, scope, fn);
    const R = this.genExpr(e.right, scope, fn);
    switch (e.op) {
      case "and": { const t = this.temp(fn); return `(__t(${t} = ${L}) ? ${R} : ${t})`; }
      case "or": { const t = this.temp(fn); return `(__t(${t} = ${L}) ? ${t} : ${R})`; }
      case "??": return `(${L} ?? ${R})`;
      case "+": return `__add(${L}, ${R})`;
      case "-": return `__sub(${L}, ${R})`;
      case "*": return `__mul(${L}, ${R})`;
      case "/": return `__div(${L}, ${R})`;
      case "%": return `__mod(${L}, ${R})`;
      case "**": return `__pow(${L}, ${R})`;
      case "++": return `__concat(${L}, ${R})`;
      case "==": return `__eq(${L}, ${R})`;
      case "!=": return `!__eq(${L}, ${R})`;
      case "<": return `__lt(${L}, ${R})`;
      case ">": return `__gt(${L}, ${R})`;
      case "<=": return `__le(${L}, ${R})`;
      case ">=": return `__ge(${L}, ${R})`;
      case "in": return `__rt.inOp(${L}, ${R})`;
    }
    return `__rt.binary(${JSON.stringify(e.op)}, ${L}, ${R})`;
  }

  genCall(e, scope, fn) {
    const callee = e.callee;
    const args = this.genArgs(e.args, scope, fn);
    if (callee.kind === "MemberExpr") {
      const opt = callee.optional || e.optional;
      return `__rt.callMethod(${this.genExpr(callee.object, scope, fn)}, ${JSON.stringify(callee.property)}, [${args}]${opt ? ", true" : ""})`;
    }
    if (callee.kind === "Identifier") {
      const v = scope.lookup(callee.name);
      if (v && v.kind === "fn" && !v.notOnlyFn) return `${v.js}(${args})`;
      if (!v && this.info.builtins.has(callee.name)) return `__nn(__b.${callee.name}(${args}))`;
      if (!v) return `__undefFn(${JSON.stringify(callee.name)})`;
      if (e.optional) return `__callOpt(${v.js}, [${args}])`;
      return `__call(${v.js}, [${args}], ${JSON.stringify(callee.name)})`;
    }
    const f = this.genExpr(callee, scope, fn);
    if (e.optional) return `__callOpt(${f}, [${args}])`;
    return `__call(${f}, [${args}])`;
  }

  genPipeline(e, scope, fn) {
    const L = this.genExpr(e.left, scope, fn);
    const right = e.right;
    if (right.kind === "CallExpr") {
      const args = this.genArgs(right.args, scope, fn);
      if (right.callee.kind === "MemberExpr") {
        return `__rt.callMethod(${this.genExpr(right.callee.object, scope, fn)}, ${JSON.stringify(right.callee.property)}, [${L}${args ? ", " + args : ""}])`;
      }
      return `__pipe(${this.genExpr(right.callee, scope, fn)}, [${L}${args ? ", " + args : ""}])`;
    }
    return `__pipe(${this.genExpr(right, scope, fn)}, [${L}])`;
  }

  genMap(e, scope, fn) {
    if (!e.entries.length) return "{}";
    const needsHelper = e.entries.some((en) => en.key === "__proto__");
    if (needsHelper) {
      const parts = e.entries.map((en) => {
        if (en.spread) return `["...", ${this.genExpr(en.spread, scope, fn)}]`;
        if (en.computed) return `[__str(${this.genExpr(en.computed, scope, fn)}), ${this.genExpr(en.value, scope, fn)}]`;
        return `[${JSON.stringify(en.key)}, ${this.genExpr(en.value, scope, fn)}]`;
      });
      return `__mkmap([${parts.join(", ")}])`;
    }
    const parts = e.entries.map((en) => {
      if (en.spread) return `...__spreadMap(${this.genExpr(en.spread, scope, fn)})`;
      if (en.computed) return `[__str(${this.genExpr(en.computed, scope, fn)})]: ${this.genExpr(en.value, scope, fn)}`;
      return `${JSON.stringify(en.key)}: ${this.genExpr(en.value, scope, fn)}`;
    });
    return `{ ${parts.join(", ")} }`;
  }

  genComprehension(e, scope, fn) {
    return this.withIIFE(fn, () => {
      const isMap = e.kind === "MapComprehension";
      const out = this.fresh("$out");
      let sc = scope;
      const opens = [];
      let closes = "";
      for (const c of e.clauses) {
        const iterable = this.genExpr(c.iterable, sc, fn);
        const inner = new CScope(sc, "block");
        const it = this.fresh("$it");
        let bind;
        if (c.pattern.kind === "BindingPattern") {
          const v = this.declareName(inner, c.pattern.name, false, "visible"); v.declared = true;
          bind = `const ${v.js} = ${it};`;
        } else {
          const d = this.fresh("$d");
          bind = `const ${d} = __destr(${JSON.stringify(stripPattern(c.pattern))}, ${it});` + patternNames(c.pattern).map((n) => { const v = this.declareName(inner, n, false, "visible"); v.declared = true; return `const ${v.js} = ${d}[${JSON.stringify(n)}];`; }).join("");
        }
        const conds = c.conditions.map((x) => `if (!__t(${this.genExpr(x, inner, fn)})) continue;`).join("\n");
        opens.push(`for (const ${it} of __it(${iterable})) {\n${bind}\n${conds}`);
        closes += "\n}";
        sc = inner;
      }
      const body = isMap ? `__rt.defineKey(${out}, __str(${this.genExpr(e.key, sc, fn)}), ${this.genExpr(e.value, sc, fn)});` : `${out}.push(${this.genExpr(e.expr, sc, fn)});`;
      return this.iife(`const ${out} = ${isMap ? "{}" : "[]"};\n${opens.join("\n")}\n${body}${closes}\nreturn ${out};`, fn);
    });
  }

  genAssign(e, scope, fn) {
    const t = e.target;
    const binop = e.op === "=" ? null : e.op.slice(0, -1);
    const R = this.genExpr(e.value, scope, fn);
    if (t.kind === "Identifier") {
      const v = scope.lookup(t.name);
      if (!v) return `__rt.fail(${JSON.stringify(`Undefined variable '${t.name}'`)})`;
      if (!v.mutable) return `__rt.fail(${JSON.stringify(`Cannot reassign immutable variable '${t.name}' (declare it with 'let mut')`)})`;
      const val = binop ? `__rt.binary(${JSON.stringify(binop)}, ${v.js}, ${R})` : R;
      if (v.typeDesc) return `(${v.js} = __rt.assertType(${v.typeDesc}, ${val}, ${JSON.stringify(`'${v.typeName}'`)}))`;
      return `(${v.js} = ${val})`;
    }
    if (t.kind === "MemberExpr") {
      const o = this.genExpr(t.object, scope, fn);
      if (binop) { const tmp = this.temp(fn); return `__rt.setMember(${tmp} = ${o}, ${JSON.stringify(t.property)}, __rt.binary(${JSON.stringify(binop)}, __get(${tmp}, ${JSON.stringify(t.property)}), ${R}))`; }
      return `__rt.setMember(${o}, ${JSON.stringify(t.property)}, ${R})`;
    }
    if (t.kind === "IndexExpr") {
      const o = this.genExpr(t.object, scope, fn), i = this.genExpr(t.index, scope, fn);
      if (binop) { const to = this.temp(fn), ti = this.temp(fn); return `__rt.setIndex(${to} = ${o}, ${ti} = ${i}, __rt.binary(${JSON.stringify(binop)}, __idx(${to}, ${ti}), ${R}))`; }
      return `__rt.setIndex(${o}, ${i}, ${R})`;
    }
    // destructuring assignment
    const tmp = this.temp(fn), d = this.temp(fn);
    const parts = [`${tmp} = ${R}`, `${d} = __destr(${JSON.stringify(stripPattern(t))}, ${tmp})`];
    for (const n of patternNames(t)) {
      const v = scope.lookup(n);
      if (!v) parts.push(`__rt.fail(${JSON.stringify(`Undefined variable '${n}'`)})`);
      else if (!v.mutable) parts.push(`__rt.fail(${JSON.stringify(`Cannot reassign immutable variable '${n}' (declare it with 'let mut')`)})`);
      else parts.push(`${v.js} = ${d}[${JSON.stringify(n)}]`);
    }
    parts.push(tmp);
    return `(${parts.join(", ")})`;
  }
}

function isSimpleExpr(e) {
  if (!e) return true;
  return !["IfExpr", "MatchExpr", "BlockExpr", "TryExpr", "ReturnStmt", "BreakStmt", "ContinueStmt", "LetStmt", "FnStmt", "ForStmt", "WhileStmt", "DoWhileStmt", "UseStmt", "TypeStmt", "AsyncExpr"].includes(e.kind);
}

function numLit(v) {
  if (Number.isNaN(v)) return "NaN";
  if (!Number.isFinite(v)) return v > 0 ? "Infinity" : "-Infinity";
  return v < 0 || Object.is(v, -0) ? `(${v})` : String(v);
}

function stripPattern(p) {
  if (p === null || typeof p !== "object") return p;
  if (Array.isArray(p)) return p.map(stripPattern);
  const out = {};
  for (const k of Object.keys(p)) {
    if (k === "line" || k === "col") continue;
    out[k] = stripPattern(p[k]);
  }
  return out;
}

function patternNames(p, out = []) {
  if (!p) return out;
  switch (p.kind) {
    case "BindingPattern": out.push(p.name); break;
    case "ListPattern": p.elements.forEach((e) => patternNames(e, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "MapPattern": p.fields.forEach((f) => patternNames(f.pattern, out)); if (p.rest && p.rest !== "_") out.push(p.rest); break;
    case "OrPattern": { const seen = new Set(out); p.alternatives.forEach((a) => patternNames(a, []).forEach((n) => { if (!seen.has(n)) { seen.add(n); out.push(n); } })); break; }
    case "VariantPattern": (p.args || []).forEach((a) => patternNames(a, out)); break;
    case "TypedPattern": if (p.name !== "_") out.push(p.name); break;
  }
  return Array.from(new Set(out));
}

function declaredNamesOf(s) {
  switch (s.kind) {
    case "FnStmt": return [s.name];
    case "LetStmt": return patternNames(s.pattern);
    case "TypeStmt": {
      const out = [];
      const walk = (t) => { if (!t) return; if (t.kind === "UnionType") t.types.forEach(walk); else if (t.kind === "VariantType") out.push(t.name); };
      walk(s.def);
      return out;
    }
    default: return [];
  }
}

function prelude() {
  if (!RUNTIME_SOURCE) RUNTIME_SOURCE = createRuntime.toString();
  return `const __rt = (${RUNTIME_SOURCE})({});
const __b = __rt.builtins;
const __t = __rt.truthy, __str = __rt.toStr, __eq = __rt.eq, __add = __rt.add, __sub = __rt.sub, __mul = __rt.mul, __div = __rt.div, __mod = __rt.mod, __pow = __rt.pow, __neg = __rt.neg, __concat = __rt.concat;
const __lt = (a, b) => (typeof a === "number" && typeof b === "number" ? a < b : __rt.lt(a, b));
const __gt = (a, b) => (typeof a === "number" && typeof b === "number" ? a > b : __rt.gt(a, b));
const __le = (a, b) => (typeof a === "number" && typeof b === "number" ? a <= b : __rt.le(a, b));
const __ge = (a, b) => (typeof a === "number" && typeof b === "number" ? a >= b : __rt.ge(a, b));
const __get = __rt.getMember, __idx = __rt.getIndex, __range = __rt.range, __it = __rt.iterate, __match = __rt.match, __destr = __rt.destructure;
class __Ret { constructor(value) { this.value = value; } }
const __BRK = { signal: "break" }, __CONT = { signal: "continue" };
const __isSig = (e) => e instanceof __Ret || e === __BRK || e === __CONT;
const __throwRet = (v) => { throw new __Ret(v); };
const __throwSig = (s) => { throw s; };
const __nn = (v) => (v === undefined ? null : v);
const __fn = (f, name, arity, variadic) => { f.arcName = name; f.__arity = arity; if (variadic) f.__variadic = true; return f; };
const __undef = (name) => __rt.fail("Undefined variable '" + name + "'");
const __undefFn = (name) => __rt.fail("Undefined function '" + name + "'");
const __call = (f, args, name) => { if (typeof f !== "function") __rt.fail((name ? "'" + name + "'" : __str(f)) + " is not a function"); const r = f(...args); return r === undefined ? null : r; };
const __callOpt = (f, args) => (f === null || f === undefined ? null : __call(f, args));
const __pipe = (f, args) => { if (typeof f !== "function") __rt.fail("Pipeline target is not a function (got " + __rt.typeOf(f) + ")"); const r = f(...args); return r === undefined ? null : r; };
const __prop = (v) => { const r = __rt.propagate(v); if (Object.prototype.hasOwnProperty.call(r, "ret")) throw new __Ret(r.ret); return r.value; };
const __spreadMap = (v) => { if (v === null || v === undefined) return {}; if (typeof v !== "object") __rt.fail("Cannot spread " + __rt.typeOf(v) + " into a map"); return v; };
const __mkmap = (pairs) => { const o = {}; for (const [k, v] of pairs) { if (k === "...") Object.assign(o, __spreadMap(v)); else __rt.defineKey(o, k, v); } return o; };
`;
}

function toAstRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (input && input.kind === "Program") return input;
  if (input && input.ast && input.ast.kind === "Program") return input.ast;
  if (input && input.program && input.program.kind === "Program") return input.program;
  if (input && Array.isArray(input.stmts)) return input;
  if (input && typeof input.source === "string") return parse(lex(input.source));
  return { kind: "Program", stmts: [] };
}
function toAst(input) { return assertValid(toAstRaw(input)); }

function generateJS(ir, options = {}) {
  const ast = toAst(ir);
  const gen = new Gen(options);
  const res = gen.genProgram(ast, options.bindResult !== false);
  const modules = gen.moduleCode.join("\n");
  const body = res.needsRet
    ? `${res.temps}${res.decl}\ntry {\n${res.body}\n} catch ($top) { if (!($top instanceof __Ret)) throw $top; }`
    : res.code;
  return `"use strict";\n${prelude()}${modules ? modules + "\n" : ""}${body}\n`;
}

function compileToJS(source, options) { return generateJS(parse(lex(source)), options); }

module.exports = { generateJS, compileToJS, prelude, patternNames, stripPattern };
