"use strict";
// Arc code generation entry points: JavaScript (full language) and WAT (numeric subset).
const { generateJS } = require("./codegen-js.js");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");

function toAstRaw(input) {
  if (typeof input === "string") return parse(lex(input));
  if (input && input.kind === "Program") return input;
  if (input && input.ast) return input.ast;
  if (input && Array.isArray(input.stmts)) return input;
  return { kind: "Program", stmts: [] };
}
function toAst(input) { return assertValid(toAstRaw(input)); }

class WatGen {
  constructor(ty) { this.funcs = []; this.fnNames = new Set(); this.ty = ty || "f64"; }
  get int() { return this.ty === "i32"; }

  ident(n) { return "$" + String(n).replace(/[^A-Za-z0-9_]/g, "_"); }

  genFunction(name, params, body, exported) {
    const locals = new Set();
    const ctx = { params: new Set(params), locals };
    const bodyCode = body.kind === "BlockExpr" ? this.block(body.stmts, ctx, 2) : this.expr(body, ctx, 2);
    const ps = params.map((p) => `(param ${this.ident(p)} ${this.ty})`).join(" ");
    const ls = Array.from(locals).filter((l) => !ctx.params.has(l)).map((l) => `(local ${this.ident(l)} ${this.ty})`).join(" ");
    const head = `  (func ${this.ident(name)}${exported ? ` (export "${name}")` : ""}${ps ? " " + ps : ""} (result ${this.ty})${ls ? " " + ls : ""}`;
    return `${head}\n${bodyCode}\n  )`;
  }

  block(stmts, ctx, ind) {
    if (!stmts.length) return `${"  ".repeat(ind)}(${this.ty}.const 0)`;
    const lines = [];
    stmts.forEach((s, i) => {
      const last = i === stmts.length - 1;
      const code = this.stmt(s, ctx, ind, last);
      if (code) lines.push(code);
    });
    return lines.join("\n");
  }

  stmt(s, ctx, ind, last) {
    const pad = "  ".repeat(ind);
    switch (s.kind) {
      case "LetStmt":
        if (s.pattern.kind !== "BindingPattern") return `${pad};; unsupported destructuring`;
        ctx.locals.add(s.pattern.name);
        return `${pad}(local.set ${this.ident(s.pattern.name)} ${this.expr(s.value, ctx, 0)})` + (last ? `\n${pad}(local.get ${this.ident(s.pattern.name)})` : "");
      case "ReturnStmt": return `${pad}(return ${s.value ? this.expr(s.value, ctx, 0) : `(${this.ty}.const 0)`})`;
      case "WhileStmt": {
        const body = s.body.stmts.map((x) => this.stmt(x, ctx, ind + 2, false)).filter(Boolean).map((c) => c + (/^\s*\((local\.set|drop|br|return|call \$print_)/.test(c) ? "" : "")).join("\n");
        return `${pad}(block $exit\n${pad}  (loop $loop\n${pad}    (br_if $exit (i32.eqz ${this.cond(s.condition, ctx)}))\n${body}\n${pad}    (br $loop)))` + (last ? `\n${pad}(${this.ty}.const 0)` : "");
      }
      case "FnStmt": return null;
      case "ExprStmt": {
        const e = s.expr;
        if (e.kind === "AssignExpr" && e.target.kind === "Identifier") {
          ctx.locals.add(e.target.name);
          const v = e.op === "=" ? this.expr(e.value, ctx, 0) : this.binop(e.op.slice(0, -1), `(local.get ${this.ident(e.target.name)})`, this.expr(e.value, ctx, 0));
          return `${pad}(local.set ${this.ident(e.target.name)} ${v})` + (last ? `\n${pad}(local.get ${this.ident(e.target.name)})` : "");
        }
        const code = this.expr(e, ctx, 0);
        return last ? `${pad}${code}` : `${pad}(drop ${code})`;
      }
    }
    return `${pad};; unsupported statement: ${s.kind}` + (last ? `\n${pad}(${this.ty}.const 0)` : "");
  }

  // i32 condition from an expression
  cond(e, ctx) {
    const T = this.ty;
    const cmp = this.int
      ? { "<": "i32.lt_s", ">": "i32.gt_s", "<=": "i32.le_s", ">=": "i32.ge_s", "==": "i32.eq", "!=": "i32.ne" }
      : { "<": "f64.lt", ">": "f64.gt", "<=": "f64.le", ">=": "f64.ge", "==": "f64.eq", "!=": "f64.ne" };
    if (e.kind === "BinaryExpr" && cmp[e.op]) return `(${cmp[e.op]} ${this.expr(e.left, ctx)} ${this.expr(e.right, ctx)})`;
    if (e.kind === "BinaryExpr" && e.op === "and") return `(i32.and ${this.cond(e.left, ctx)} ${this.cond(e.right, ctx)})`;
    if (e.kind === "BinaryExpr" && e.op === "or") return `(i32.or ${this.cond(e.left, ctx)} ${this.cond(e.right, ctx)})`;
    if (e.kind === "UnaryExpr" && e.op === "not") return `(i32.eqz ${this.cond(e.operand, ctx)})`;
    if (e.kind === "BoolLiteral") return `(i32.const ${e.value ? 1 : 0})`;
    return `(${T}.ne ${this.expr(e, ctx)} (${T}.const 0))`;
  }

  fromCond(c) { return this.int ? c : `(f64.convert_i32_s ${c})`; }

  binop(op, a, b) {
    const T = this.ty;
    switch (op) {
      case "+": return `(${T}.add ${a} ${b})`;
      case "-": return `(${T}.sub ${a} ${b})`;
      case "*": return `(${T}.mul ${a} ${b})`;
      case "/": return this.int ? `(i32.div_s ${a} ${b})` : `(f64.div ${a} ${b})`;
      case "%": return this.int ? `(i32.rem_s ${a} ${b})` : `(f64.sub ${a} (f64.mul (f64.trunc (f64.div ${a} ${b})) ${b}))`;
    }
    return `(${T}.const 0) ;; unsupported operator ${op}`;
  }

  expr(e, ctx) {
    const T = this.ty;
    switch (e.kind) {
      case "IntLiteral": case "FloatLiteral": return `(${T}.const ${this.int ? Math.trunc(e.value) : e.value})`;
      case "BoolLiteral": return `(${T}.const ${e.value ? 1 : 0})`;
      case "NilLiteral": return `(${T}.const 0)`;
      case "Identifier": ctx.locals.add(e.name); return `(local.get ${this.ident(e.name)})`;
      case "UnaryExpr":
        if (e.op === "-") return this.int ? `(i32.sub (i32.const 0) ${this.expr(e.operand, ctx)})` : `(f64.neg ${this.expr(e.operand, ctx)})`;
        return this.fromCond(`(i32.eqz ${this.cond(e.operand, ctx)})`);
      case "BinaryExpr":
        if (["<", ">", "<=", ">=", "==", "!=", "and", "or"].includes(e.op)) return this.fromCond(this.cond(e, ctx));
        return this.binop(e.op, this.expr(e.left, ctx), this.expr(e.right, ctx));
      case "IfExpr": {
        const then = e.then.kind === "BlockExpr" ? this.block(e.then.stmts, ctx, 0).replace(/\n/g, " ") : this.expr(e.then, ctx);
        const els = e.else_ ? (e.else_.kind === "BlockExpr" ? this.block(e.else_.stmts, ctx, 0).replace(/\n/g, " ") : this.expr(e.else_, ctx)) : `(${T}.const 0)`;
        return `(if (result ${T}) ${this.cond(e.condition, ctx)} (then ${then.trim()}) (else ${els.trim()}))`;
      }
      case "CallExpr":
        if (e.callee.kind === "Identifier" && e.callee.name === "print") return `(call $print ${e.args.length ? this.expr(e.args[0], ctx) : `(${T}.const 0)`}) (${T}.const 0)`;
        if (e.callee.kind === "Identifier" && this.fnNames.has(e.callee.name)) return `(call ${this.ident(e.callee.name)} ${e.args.map((a) => this.expr(a, ctx)).join(" ")})`;
        return `(${T}.const 0) ;; unsupported call`;
      case "BlockExpr": return this.block(e.stmts, ctx, 0).replace(/\n/g, " ");
    }
    return `(${T}.const 0) ;; unsupported: ${e.kind}`;
  }
}

function usesFloats(ast) {
  let found = false;
  const walk = (n) => {
    if (found || !n || typeof n !== "object") return;
    if (Array.isArray(n)) { n.forEach(walk); return; }
    if (n.kind === "FloatLiteral" || (n.kind === "BinaryExpr" && (n.op === "/" || n.op === "**"))) { found = true; return; }
    for (const k of Object.keys(n)) walk(n[k]);
  };
  walk(ast);
  return found;
}

function generateWAT(ir) {
  const ast = toAst(ir);
  const g = new WatGen(usesFloats(ast) ? "f64" : "i32");
  const fns = ast.stmts.filter((s) => s.kind === "FnStmt");
  fns.forEach((f) => g.fnNames.add(f.name));
  const parts = ["(module", `  (import "env" "print" (func $print (param ${g.ty})))`, '  (memory (export "memory") 1)'];
  for (const f of fns) parts.push(g.genFunction(f.name, f.params.map((p) => p.name || "_"), f.body, true));
  const mainStmts = ast.stmts.filter((s) => s.kind !== "FnStmt" && s.kind !== "TypeStmt" && s.kind !== "UseStmt");
  parts.push(g.genFunction("main", [], { kind: "BlockExpr", stmts: mainStmts }, true));
  parts.push(")");
  return parts.join("\n") + "\n";
}

module.exports = { generateWAT, generateJS };
