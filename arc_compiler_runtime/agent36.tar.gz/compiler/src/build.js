"use strict";
// Arc build system and project scaffolding.
const fs = require("fs");
const path = require("path");
const { lex } = require("./lexer.js");
const { parse, assertValid } = require("./parser.js");
const { generateJS } = require("./codegen-js.js");
const { parseArcToml } = require("./package-manager.js");
const { VERSION } = require("./version.js");

function findArcFiles(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith(".") || entry.name === "node_modules" || entry.name === "dist") continue;
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...findArcFiles(p));
    else if (entry.name.endsWith(".arc")) out.push(p);
  }
  return out.sort();
}

function buildProject(dir = process.cwd(), options = {}) {
  if (typeof dir === "object" && dir !== null) { options = dir; dir = options.dir || process.cwd(); }
  const root = path.resolve(dir);
  const errors = [];
  const outputs = [];
  let manifest = {};
  const tomlPath = path.join(root, "arc.toml");
  if (fs.existsSync(tomlPath)) {
    try { manifest = parseArcToml(fs.readFileSync(tomlPath, "utf8")); } catch (e) { errors.push({ file: tomlPath, message: e.message }); }
  }
  const pkg = manifest.package || {};
  const build = manifest.build || {};
  const srcDir = path.resolve(root, options.srcDir || build.src || "src");
  const outDir = path.resolve(root, options.outDir || build.out || build.outDir || "dist");
  const hasManifest = fs.existsSync(tomlPath);
  if (!fs.existsSync(srcDir) && !hasManifest && !options.srcDir) {
    return { ok: errors.length === 0, name: pkg.name || path.basename(root), version: pkg.version || null, outputs, errors, outDir };
  }
  const files = fs.existsSync(srcDir) ? findArcFiles(srcDir) : findArcFiles(root).filter((f) => !f.includes(`${path.sep}tests${path.sep}`));
  const base = fs.existsSync(srcDir) ? srcDir : root;
  for (const file of files) {
    try {
      const source = fs.readFileSync(file, "utf8");
      const js = generateJS(assertValid(parse(lex(source))), { baseDir: path.dirname(file) });
      const rel = path.relative(base, file).replace(/\.arc$/, ".js");
      const outFile = path.join(outDir, rel);
      if (options.write !== false) {
        fs.mkdirSync(path.dirname(outFile), { recursive: true });
        fs.writeFileSync(outFile, js);
      }
      outputs.push(outFile);
    } catch (e) {
      errors.push({ file, message: e.message, line: e.line, col: e.col });
    }
  }
  return { ok: errors.length === 0, name: pkg.name || path.basename(root), version: pkg.version || null, outputs, errors, outDir };
}

function projectTemplate(name) {
  return {
    "arc.toml": `[package]\nname = "${name}"\nversion = "0.1.0"\ndescription = ""\nmain = "src/main.arc"\n\n[dependencies]\n`,
    "src/main.arc": `# ${name}\n\nfn main() {\n  print("Hello from ${name}!")\n}\n\nmain()\n`,
    "tests/main_test.arc": `use test\n\ntest.describe("${name}", fn() {\n  test.it("works", fn() {\n    test.expect_eq(1 + 1, 2)\n  })\n})\n\ntest.run_tests()\n`,
    "README.md": `# ${name}\n\nAn Arc project (arc ${VERSION}).\n\n\`\`\`bash\narc run src/main.arc\narc test tests/\n\`\`\`\n`,
    ".gitignore": "dist/\nnode_modules/\n",
  };
}

function scaffoldProject(name, baseDir, options = {}) {
  if (typeof baseDir === "object" && baseDir !== null) { options = baseDir; baseDir = options.dir; }
  if (!name || !/^[A-Za-z0-9_.-]+$/.test(String(name))) throw new Error(`Invalid project name: '${name}'`);
  const template = projectTemplate(String(name));
  const files = Object.keys(template);
  const result = { name: String(name), files, contents: template, path: null, created: false };
  const write = baseDir !== undefined || options.write;
  if (write) {
    const root = path.resolve(baseDir || process.cwd(), String(name));
    if (fs.existsSync(root) && fs.readdirSync(root).length && !options.force) throw new Error(`Directory '${root}' already exists and is not empty`);
    for (const rel of files) {
      const p = path.join(root, rel);
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, template[rel]);
    }
    result.path = root;
    result.created = true;
  }
  return result;
}

function findTestFiles(target) {
  const p = path.resolve(target || "tests");
  if (fs.existsSync(p) && fs.statSync(p).isFile()) return [p];
  const all = findArcFiles(p);
  const tests = all.filter((f) => /(_test|\.test|_spec)\.arc$|(^|[\/\\])test_[^\/\\]*\.arc$/.test(f));
  return tests.length ? tests : all;
}

function runTests(target, options = {}) {
  const { createEnv, interpretWithEnv } = require("./interpreter.js");
  const files = findTestFiles(target);
  const results = [];
  for (const file of files) {
    const output = [];
    try {
      const env = createEnv({}, { output: (s) => { output.push(s); if (options.echo) console.log(s); }, baseDir: path.dirname(file) });
      interpretWithEnv(parse(lex(fs.readFileSync(file, "utf8"))), env);
      const failedLine = output.some((l) => /^\s*✗/.test(l) || /Tests: \d+ passed, [1-9]\d* failed/.test(l));
      results.push({ file, passed: !failedLine, output });
    } catch (e) {
      results.push({ file, passed: false, error: e.message, output });
    }
  }
  return { ok: results.every((r) => r.passed), passed: results.filter((r) => r.passed).length, failed: results.filter((r) => !r.passed).length, results };
}

module.exports = { buildProject, scaffoldProject, projectTemplate, runTests, findArcFiles, findTestFiles };
