"use strict";
// Arc error types and pretty printing.

class ArcError extends Error {
  constructor(message, loc, kind = "ArcError") {
    super(message);
    this.name = kind;
    this.loc = loc || null;
    if (loc) { this.line = loc.line; this.col = loc.col; }
  }
}
class ArcSyntaxError extends ArcError {
  constructor(message, loc) { super(message, loc, "SyntaxError"); }
}
class ArcParseError extends ArcSyntaxError {}
class ArcRuntimeError extends ArcError {
  constructor(message, loc) { super(message, loc, "RuntimeError"); }
}
class ArcTypeError extends ArcError {
  constructor(message, loc) { super(message, loc, "TypeError"); }
}

function formatError(error, source, filename) {
  if (error == null) return "Unknown error";
  const message = error.message ?? String(error);
  const name = error.name && error.name !== "Error" ? error.name : "Error";
  const loc = error.loc || (error.line ? { line: error.line, col: error.col } : null);
  let out = `${name}: ${message}`;
  if (loc && loc.line) {
    out += `\n  --> ${filename ? filename + ":" : ""}${loc.line}:${loc.col ?? 1}`;
    if (source != null) {
      const lines = String(source).split(/\r?\n/);
      const text = lines[loc.line - 1];
      if (text !== undefined) {
        const gutter = String(loc.line).length;
        out += `\n${" ".repeat(gutter)} |`;
        out += `\n${loc.line} | ${text}`;
        out += `\n${" ".repeat(gutter)} | ${" ".repeat(Math.max(0, (loc.col ?? 1) - 1))}^`;
      }
    }
  }
  return out;
}

function prettyPrintError(error, source, filename) { return formatError(error, source, filename); }

module.exports = { ArcError, ArcSyntaxError, ArcParseError, ArcRuntimeError, ArcTypeError, formatError, prettyPrintError };
