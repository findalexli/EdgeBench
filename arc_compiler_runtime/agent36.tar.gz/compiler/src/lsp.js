"use strict";
// Arc language server helpers (diagnostics, completion, hover, symbols) and a
// minimal JSON-RPC stdio server.
const { lex, KEYWORDS } = require("./lexer.js");
const { parse } = require("./parser.js");
const { lint } = require("./linter.js");
const { checkTypes } = require("./typechecker.js");
const { createRuntime } = require("./runtime-core.js");

let RT = null;
function rt() { if (!RT) RT = createRuntime({}); return RT; }

const SEVERITY = { error: 1, warning: 2, info: 3, hint: 4 };

function getDiagnostics(source) {
  const out = [];
  const seen = new Set();
  const add = (d, source2) => {
    const key = `${d.line}:${d.col}:${d.message}`;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({
      range: { start: { line: Math.max(0, (d.line || 1) - 1), character: Math.max(0, (d.col || 1) - 1) }, end: { line: Math.max(0, (d.line || 1) - 1), character: Math.max(0, (d.col || 1)) } },
      severity: SEVERITY[d.severity] || 2,
      message: d.message,
      source: source2,
      code: d.rule || d.code,
    });
  };
  for (const d of lint(source)) add(d, "arc-lint");
  try { parse(lex(source)); for (const e of checkTypes(source).errors) add(e, "arc-check"); } catch (e) { /* parse errors already reported */ }
  return out;
}

function collectSymbols(program) {
  const out = [];
  for (const s of program.stmts) {
    if (s.kind === "FnStmt") out.push({ name: s.name, kind: "function", line: s.line, col: s.col, params: s.params.map((p) => p.name || "_"), detail: `fn ${s.name}(${s.params.map((p) => (p.rest ? "..." : "") + (p.name || "_")).join(", ")})` });
    else if (s.kind === "LetStmt" && s.name) out.push({ name: s.name, kind: "variable", line: s.line, col: s.col, detail: `let ${s.mutable ? "mut " : ""}${s.name}` });
    else if (s.kind === "TypeStmt") out.push({ name: s.name, kind: "type", line: s.line, col: s.col, detail: `type ${s.name}` });
  }
  return out;
}

function documentSymbols(source) {
  try { return collectSymbols(parse(lex(source))); } catch (e) { return []; }
}

function wordAt(source, position) {
  const lines = String(source).split(/\r?\n/);
  const line = lines[position.line] || "";
  let s = position.character, e = position.character;
  while (s > 0 && /\w/.test(line[s - 1])) s--;
  while (e < line.length && /\w/.test(line[e])) e++;
  return line.slice(s, e);
}

function getCompletions(source, position) {
  const items = [];
  for (const k of Object.keys(KEYWORDS)) items.push({ label: k, kind: "keyword" });
  for (const b of Object.keys(rt().builtins)) items.push({ label: b, kind: "function", detail: "builtin" });
  for (const m of rt().moduleNames) items.push({ label: m, kind: "module" });
  for (const s of documentSymbols(source)) items.push({ label: s.name, kind: s.kind, detail: s.detail });
  if (position) {
    const lines = String(source).split(/\r?\n/);
    const before = (lines[position.line] || "").slice(0, position.character);
    const m = /([A-Za-z_]\w*)\.(\w*)$/.exec(before);
    if (m && rt().hasModule(m[1])) return Object.keys(rt().loadModule(m[1])).map((k) => ({ label: k, kind: "function", detail: `${m[1]}.${k}` }));
    const prefix = /(\w*)$/.exec(before)[1];
    if (prefix) return items.filter((i) => i.label.startsWith(prefix));
  }
  return items;
}

function getHover(source, position) {
  const word = wordAt(source, position);
  if (!word) return null;
  const sym = documentSymbols(source).find((s) => s.name === word);
  if (sym) return { contents: sym.detail };
  if (Object.prototype.hasOwnProperty.call(rt().builtins, word)) return { contents: `builtin ${word}` };
  if (Object.prototype.hasOwnProperty.call(KEYWORDS, word)) return { contents: `keyword ${word}` };
  if (rt().hasModule(word)) return { contents: `module ${word}` };
  return null;
}

function getDefinition(source, position) {
  const word = wordAt(source, position);
  const sym = documentSymbols(source).find((s) => s.name === word);
  if (!sym) return null;
  return { line: sym.line - 1, character: sym.col - 1 };
}

function createServer(options = {}) {
  const useStdio = !!(options.input || options.stdio);
  const input = options.input || process.stdin;
  const output = options.output || process.stdout;
  const docs = new Map();
  let buffer = Buffer.alloc(0);
  let running = false;
  const send = (msg) => {
    const body = JSON.stringify(Object.assign({ jsonrpc: "2.0" }, msg));
    output.write(`Content-Length: ${Buffer.byteLength(body)}\r\n\r\n${body}`);
  };
  const publish = (uri) => send({ method: "textDocument/publishDiagnostics", params: { uri, diagnostics: getDiagnostics(docs.get(uri) || "") } });
  const handle = (msg) => {
    const { id, method, params } = msg;
    switch (method) {
      case "initialize": return send({ id, result: { capabilities: { textDocumentSync: 1, completionProvider: { triggerCharacters: ["."] }, hoverProvider: true, definitionProvider: true, documentSymbolProvider: true, documentFormattingProvider: true } } });
      case "initialized": return;
      case "shutdown": return send({ id, result: null });
      case "exit": return server.stop();
      case "textDocument/didOpen": docs.set(params.textDocument.uri, params.textDocument.text); return publish(params.textDocument.uri);
      case "textDocument/didChange": docs.set(params.textDocument.uri, params.contentChanges[params.contentChanges.length - 1].text); return publish(params.textDocument.uri);
      case "textDocument/didClose": docs.delete(params.textDocument.uri); return;
      case "textDocument/completion": return send({ id, result: getCompletions(docs.get(params.textDocument.uri) || "", params.position).map((c) => ({ label: c.label, detail: c.detail })) });
      case "textDocument/hover": { const h = getHover(docs.get(params.textDocument.uri) || "", params.position); return send({ id, result: h ? { contents: h.contents } : null }); }
      case "textDocument/definition": { const d = getDefinition(docs.get(params.textDocument.uri) || "", params.position); return send({ id, result: d ? { uri: params.textDocument.uri, range: { start: d, end: d } } : null }); }
      case "textDocument/documentSymbol": return send({ id, result: documentSymbols(docs.get(params.textDocument.uri) || "").map((s) => ({ name: s.name, kind: s.kind === "function" ? 12 : s.kind === "type" ? 5 : 13, location: { uri: params.textDocument.uri, range: { start: { line: s.line - 1, character: s.col - 1 }, end: { line: s.line - 1, character: s.col - 1 } } } })) });
      case "textDocument/formatting": {
        const { format } = require("./formatter.js");
        const text = docs.get(params.textDocument.uri) || "";
        const lines = text.split("\n").length;
        return send({ id, result: [{ range: { start: { line: 0, character: 0 }, end: { line: lines, character: 0 } }, newText: format(text) }] });
      }
      default: if (id !== undefined) send({ id, error: { code: -32601, message: `Method not found: ${method}` } });
    }
  };
  const onData = (chunk) => {
    buffer = Buffer.concat([buffer, Buffer.from(chunk)]);
    while (true) {
      const headerEnd = buffer.indexOf("\r\n\r\n");
      if (headerEnd < 0) return;
      const header = buffer.slice(0, headerEnd).toString();
      const m = /Content-Length: (\d+)/i.exec(header);
      if (!m) { buffer = buffer.slice(headerEnd + 4); continue; }
      const len = Number(m[1]);
      if (buffer.length < headerEnd + 4 + len) return;
      const body = buffer.slice(headerEnd + 4, headerEnd + 4 + len).toString();
      buffer = buffer.slice(headerEnd + 4 + len);
      try { handle(JSON.parse(body)); } catch (e) { /* ignore malformed */ }
    }
  };
  const server = {
    documents: docs,
    handle,
    start() { if (!running) { running = true; if (useStdio) input.on("data", onData); } return server; },
    stop() { if (running) { running = false; if (useStdio) input.removeListener("data", onData); } return server; },
    get running() { return running; },
  };
  return server;
}

module.exports = { createServer, getDiagnostics, getCompletions, getHover, getDefinition, documentSymbols };
