import sys, time, math

import os
TL = float(os.environ.get("TL", "28"))
NSTART = int(os.environ.get("NSTART", "11"))
RFRAC = float(os.environ.get("RFRAC", "0.5"))
R1 = float(os.environ.get("R1", "0.4"))
R2 = float(os.environ.get("R2", "0.35"))
R3 = float(os.environ.get("R3", "0.5"))
MC = float(os.environ.get("MC", "0.0"))
GREEDY = eval(os.environ.get("GREEDY", "[(v, dict(beta=b, fill=True, bundle=True)) for v in (1, 2) for b in (1.0, 2.0, 0.5)]"))
DEBUG = int(os.environ.get("DEBUG", "0"))
PROJ = int(os.environ.get("PROJ", "0"))
PD = int(os.environ.get("PD", "8"))
PM = float(os.environ.get("PM", "0.999"))
MB = float(os.environ.get("MB", "0.0"))
PRUNE = int(os.environ.get("PRUNE", "1"))
KICK = int(os.environ.get("KICK", "0"))
KSZ = int(os.environ.get("KSZ", "5"))
PB = float(os.environ.get("PB", "1.0"))
SPLIT = int(os.environ.get("SPLIT", "1"))
NW = int(os.environ.get("NW", "1"))
NTOP = int(os.environ.get("NTOP", "3"))
KEEP = eval(os.environ.get("KEEP", "[4, 2, 1]"))


def c2(x):
    return x * (x - 1) // 2


def c3(x):
    return x * (x - 1) * (x - 2) // 6


def c4(x):
    return x * (x - 1) * (x - 2) * (x - 3) // 24


def final_j(a, b, p, r):
    # production of one ID over r turns with no further actions
    b0, b1, b2, b3 = b
    p0, p1, p2, p3 = p
    if p0 == 0 or r <= 0:
        return 0
    return a * p0 * (b0 * r + p1 * (b1 * c2(r) + p2 * (b2 * c3(r) + p3 * b3 * c4(r))))


def state_after(b, p, w):
    b0, b1, b2, b3 = b
    p0, p1, p2, p3 = p
    nb2 = b2 + p3 * b3 * w
    nb1 = b1 + p2 * (b2 * w + p3 * b3 * c2(w))
    nb0 = b0 + p1 * (b1 * w + p2 * (b2 * c2(w) + p3 * b3 * c3(w)))
    return (nb0, nb1, nb2, b3)


T_INF = 10 ** 9


def run(N, L, T, K, A, C, allowed, alpha, beta, mask=None, beta_hi=None, gam=1.0, bundle=False, mask2=None, t1=T_INF, fill=False, fd=0, hg=1.0):
    HGP = [hg ** i for i in range(L)]
    if beta_hi is None:
        beta_hi = beta
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    acts = []
    ids = list(range(N))
    for t in range(T):
        if t == t1:
            mask = mask2
        rem = T - t
        best = None
        bestv = 0.0
        afford = []
        for j in allowed:
            bj = B[j]
            pj = P[j]
            a = A[j]
            for i in range(L):
                if mask is not None and not mask[i][j]:
                    continue
                cost = C[i][j] * (pj[i] + 1)
                np_ = list(pj)
                np_[i] += 1
                first = i
                if bundle:
                    for l in range(i):
                        if pj[l] == 0:
                            cost += C[l][j]
                            np_[l] = 1
                            if first == i:
                                first = l
                # find wait w
                if cost <= apples:
                    w = 0
                else:
                    lo, hi = 1, rem
                    if apples + tot_prod(A, B, P, ids, hi - 1) < cost:
                        continue
                    while lo < hi:
                        m = (lo + hi) // 2
                        if apples + tot_prod(A, B, P, ids, m) >= cost:
                            hi = m
                        else:
                            lo = m + 1
                    w = lo
                r = rem - w
                if r <= 0:
                    continue
                bs = state_after(bj, pj, w) if w else bj
                gain = (final_j(a, bs, np_, r) - final_j(a, bs, pj, r)) * HGP[i] - cost
                if gain <= 0:
                    continue
                v = gain / (cost ** alpha) / ((w + 1) ** (beta if i == 0 else beta_hi))
                if i:
                    v *= gam
                if fill and w == 0 and first == i:
                    afford.append((v, i, j, cost))
                if v > bestv:
                    bestv = v
                    best = (first, j, w, cost)
        if fill and best is not None and best[2] > 0:
            w = min(best[2] + fd, rem)
            slack = apples + tot_prod(A, B, P, ids, w) - best[3]
            afford.sort(reverse=True)
            for v, i, j, cost in afford:
                pj = P[j]
                np_ = list(pj)
                np_[i] += 1
                if final_j(A[j], B[j], np_, w) - final_j(A[j], B[j], pj, w) + slack >= cost:
                    best = (i, j, 0, cost)
                    break
        if best is not None and best[2] == 0:
            i, j, w = best[:3]
            apples -= C[i][j] * (P[j][i] + 1)
            P[j][i] += 1
            acts.append((i, j))
        else:
            acts.append(None)
        # production
        for j in range(N):
            bj = B[j]
            pj = P[j]
            apples += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
    return apples, acts


def coef(a, b, p):
    x = a * p[0]
    c0 = x * b[0]
    x *= p[1]
    c1 = x * b[1]
    x *= p[2]
    c2_ = x * b[2]
    x *= p[3]
    return c0, c1, c2_, x * b[3]


def run2(N, L, T, K, A, C, g, mask=None):
    import math
    q = math.exp(-g)
    E = [[0.0] * 4 for _ in range(T + 1)]
    for r in range(1, T + 1):
        k = r - 1
        qk = q ** k
        E[r] = [E[r - 1][0] + qk, E[r - 1][1] + qk * k, E[r - 1][2] + qk * c2(k), E[r - 1][3] + qk * c3(k)]
    qp = [q ** w for w in range(T + 1)]
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    acts = []
    ids = list(range(N))
    for t in range(T):
        rem = T - t
        best = None
        bestv = 0.0
        for j in range(N):
            bj = B[j]
            pj = P[j]
            a = A[j]
            for i in range(L):
                if mask is not None and not mask[i][j]:
                    continue
                cost = C[i][j] * (pj[i] + 1)
                if cost <= apples:
                    w = 0
                else:
                    lo, hi = 1, rem
                    if apples + tot_prod(A, B, P, ids, hi - 1) < cost:
                        continue
                    while lo < hi:
                        m = (lo + hi) // 2
                        if apples + tot_prod(A, B, P, ids, m) >= cost:
                            hi = m
                        else:
                            lo = m + 1
                    w = lo
                r = rem - w
                if r <= 0:
                    continue
                bs = state_after(bj, pj, w) if w else bj
                o = coef(a, bs, pj)
                np_ = list(pj)
                np_[i] += 1
                n = coef(a, bs, np_)
                Er = E[r]
                V = (n[0] - o[0]) * Er[0] + (n[1] - o[1]) * Er[1] + (n[2] - o[2]) * Er[2] + (n[3] - o[3]) * Er[3]
                v = (V - cost) * qp[w]
                if v > bestv:
                    bestv = v
                    best = (i, j, w, cost)
        if best is not None and best[2] == 0:
            i, j, w, cost = best
            apples -= cost
            P[j][i] += 1
            acts.append((i, j))
        else:
            acts.append(None)
        for j in range(N):
            bj = B[j]
            pj = P[j]
            apples += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
    return apples, acts


def run3(N, L, T, K, A, C, M, mask=None, theta=None):
    F = [[0.0] * 4 for _ in range(T + 1)]
    for t0 in range(T - 1, -1, -1):
        f1 = F[t0 + 1]
        F[t0] = [M[t0] + f1[0], f1[1] + f1[0], f1[2] + f1[1], f1[3] + f1[2]]
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    acts = []
    prod = []
    ids = list(range(N))
    for t in range(T):
        rem = T - t
        best = None
        bestv = 0.0
        for j in range(N):
            bj = B[j]
            pj = P[j]
            a = A[j]
            for i in range(L):
                if mask is not None and not mask[i][j]:
                    continue
                cost = C[i][j] * (pj[i] + 1)
                if cost <= apples:
                    w = 0
                else:
                    lo, hi = 1, rem
                    if apples + tot_prod(A, B, P, ids, hi - 1) < cost:
                        continue
                    while lo < hi:
                        m = (lo + hi) // 2
                        if apples + tot_prod(A, B, P, ids, m) >= cost:
                            hi = m
                        else:
                            lo = m + 1
                    w = lo
                r = rem - w
                if r <= 0:
                    continue
                bs = state_after(bj, pj, w) if w else bj
                o = coef(a, bs, pj)
                np_ = list(pj)
                np_[i] += 1
                n = coef(a, bs, np_)
                Ft = F[t + w]
                V = (n[0] - o[0]) * Ft[0] + (n[1] - o[1]) * Ft[1] + (n[2] - o[2]) * Ft[2] + (n[3] - o[3]) * Ft[3]
                if theta is None:
                    v = V - cost * M[t + w]
                else:
                    if w:
                        continue
                    v = V / (cost * M[t]) - theta
                if v > bestv:
                    bestv = v
                    best = (i, j, w, cost)
        if best is not None and best[2] == 0:
            i, j, w, cost = best
            apples -= cost
            P[j][i] += 1
            acts.append((i, j))
        else:
            acts.append(None)
        pr = 0
        for j in range(N):
            bj = B[j]
            pj = P[j]
            pr += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
        apples += pr
        prod.append(pr)
    return apples, acts, prod


def make_M(prod, T, smooth=1.0):
    import math
    lp = [math.log(max(p, 1)) for p in prod]
    # running max to keep monotone
    for i in range(1, T):
        if lp[i] < lp[i - 1]:
            lp[i] = lp[i - 1]
    end = lp[-1]
    return [math.exp(smooth * (end - x)) for x in lp]


def sim(N, L, T, K, A, C, acts):
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    prod = []
    for t in range(T):
        x = acts[t]
        if x is not None:
            i, j = x
            apples -= C[i][j] * (P[j][i] + 1)
            P[j][i] += 1
        pr = 0
        for j in range(N):
            bj = B[j]
            pj = P[j]
            pr += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
        apples += pr
        prod.append(pr)
    return apples, prod


def projv(N, A, T, t, apples, B, P):
    # apples at the end if nothing more is bought
    r = T - t
    r2, r3, r4 = c2(r), c3(r), c4(r)
    v = apples
    for j in range(N):
        q = j * 4
        p0 = P[q]
        if p0:
            v += A[j] * p0 * (B[q] * r + P[q + 1] * (B[q + 1] * r2 + P[q + 2] * (B[q + 2] * r3 + P[q + 3] * r4)))
    return v


def cmp_state(o, t, apples, B, P):
    # 1: new state dominated by reference, 2: identical, 0: otherwise
    to, _, ao, Bo, Po = o
    if t < to or apples > ao or P != Po:
        return 0
    if t == to and apples == ao and B == Bo:
        return 2
    for x, y in zip(B, Bo):
        if x > y:
            return 0
    return 1


def decode(N, L, T, K, A, C, order, start=0, snap=None, snaps=None, hint=0, ref=None, minpos=0, cmp_pos=-1, cmp_val=0):
    # execute purchases ASAP in given order; return final apples
    # snap: (t, pos, apples, B, P) flat lists (index j * 4 + i) to restart from
    if snap is None:
        t = 0
        pos = 0
        apples = K
        B = [1] * (N * 4)
        P = [0] * (N * 4)
    else:
        t, pos, apples, B, P = snap
        B = B[:]
        P = P[:]
    n = len(order)
    chain = []
    rate = 0
    for j in range(N):
        q = j * 4
        if P[q + 1] or P[q + 2] or P[q + 3]:
            chain.append(j)
        else:
            rate += A[j] * P[q]
    # main chain id kept in local variables, other chain ids in the lists
    jm = hint
    others = [j for j in chain if j != jm]
    qm = jm * 4
    if jm not in chain:
        rate -= A[jm] * P[qm]
    am = A[jm]
    b0, b1, b2 = B[qm], B[qm + 1], B[qm + 2]
    p0, p1, p2, p3 = P[qm], P[qm + 1], P[qm + 2], P[qm + 3]
    C0, C1, C2, C3 = C[0][jm], C[1][jm], C[2][jm], C[3][jm]
    while t < T:
        if pos < n:
            i, j = order[pos]
            if j == jm:
                if i == 0:
                    cost = C0 * (p0 + 1)
                elif i == 1:
                    cost = C1 * (p1 + 1)
                elif i == 2:
                    cost = C2 * (p2 + 1)
                else:
                    cost = C3 * (p3 + 1)
                if cost <= apples:
                    if snaps is not None and pos & 7 == 0 and (pos >> 3) >= len(snaps):
                        B[qm], B[qm + 1], B[qm + 2] = b0, b1, b2
                        P[qm], P[qm + 1], P[qm + 2], P[qm + 3] = p0, p1, p2, p3
                        snaps.append((t, pos, apples, B[:], P[:]))
                        if ref is not None and pos > minpos and (pos >> 3) < len(ref):
                            c = cmp_state(ref[pos >> 3], t, apples, B, P)
                            if c:
                                return (-1 if c == 1 else -2), pos
                    if pos == cmp_pos:
                        B[qm], B[qm + 1], B[qm + 2] = b0, b1, b2
                        P[qm], P[qm + 1], P[qm + 2], P[qm + 3] = p0, p1, p2, p3
                        if projv(N, A, T, t, apples, B, P) < cmp_val:
                            return -1, pos
                    apples -= cost
                    pos += 1
                    if i == 0:
                        p0 += 1
                    elif i == 1:
                        p1 += 1
                    elif i == 2:
                        p2 += 1
                    else:
                        p3 += 1
            else:
                q = j * 4
                cost = C[i][j] * (P[q + i] + 1)
                if cost <= apples:
                    if snaps is not None and pos & 7 == 0 and (pos >> 3) >= len(snaps):
                        B[qm], B[qm + 1], B[qm + 2] = b0, b1, b2
                        P[qm], P[qm + 1], P[qm + 2], P[qm + 3] = p0, p1, p2, p3
                        snaps.append((t, pos, apples, B[:], P[:]))
                        if ref is not None and pos > minpos and (pos >> 3) < len(ref):
                            c = cmp_state(ref[pos >> 3], t, apples, B, P)
                            if c:
                                return (-1 if c == 1 else -2), pos
                    if pos == cmp_pos:
                        B[qm], B[qm + 1], B[qm + 2] = b0, b1, b2
                        P[qm], P[qm + 1], P[qm + 2], P[qm + 3] = p0, p1, p2, p3
                        if projv(N, A, T, t, apples, B, P) < cmp_val:
                            return -1, pos
                    apples -= cost
                    pos += 1
                    if not (P[q + 1] or P[q + 2] or P[q + 3]):
                        if i == 0:
                            rate += A[j]
                        else:
                            others.append(j)
                            rate -= A[j] * P[q]
                    P[q + i] += 1
        elif pos == n:
            r = T - t
            apples += rate * r + am * p0 * (b0 * r + p1 * (b1 * c2(r) + p2 * (b2 * c3(r) + p3 * c4(r))))
            for j in others:
                q = j * 4
                p = P[q]
                if p:
                    apples += A[j] * p * (B[q] * r + P[q + 1] * (B[q + 1] * c2(r) + P[q + 2] * (B[q + 2] * c3(r) + P[q + 3] * c4(r))))
            return apples, pos
        apples += rate + am * b0 * p0
        b0 += b1 * p1
        b1 += b2 * p2
        b2 += p3
        for j in others:
            q = j * 4
            p = P[q]
            if p:
                apples += A[j] * B[q] * p
            p = P[q + 1]
            if p:
                B[q] += B[q + 1] * p
            p = P[q + 2]
            if p:
                B[q + 1] += B[q + 2] * p
            p = P[q + 3]
            if p:
                B[q + 2] += p
        t += 1
    return apples, pos


MP = [0.3, 0.5, 0.65, 0.8, 0.9, 1.0, 8, 15, 1.0]


def main_id(order, N):
    cnt = [0] * N
    for i, j in order:
        if i:
            cnt[j] += 1
    return max(range(N), key=lambda j: cnt[j])


def anneal(N, L, T, K, A, C, order, tlimit, rng, t0=0.5, t1=0.002):
    import math
    hint = main_id(order, N)
    snaps = []
    cur, _ = decode(N, L, T, K, A, C, order, snaps=snaps, hint=hint)
    curl = math.log2(max(cur, 1))
    best = (curl, order[:])
    st = time.time()
    it = 0
    last_imp = 0
    while True:
        if it & 31 == 0:
            el = (time.time() - st) / tlimit
            if el >= 1:
                break
            temp = t0 * (t1 / t0) ** el
        it += 1
        n = len(order)
        new = order[:]
        lo_all = n + 1
        nrep = 2 if rng.random() < MC else 1
        if KICK and it - last_imp > KICK:
            new = best[1][:]
            for _ in range(rng.randint(2, KSZ)):
                n = len(new)
                a = rng.randrange(n)
                x = new.pop(a)
                new.insert(max(0, min(n - 1, a + rng.randint(-40, 40))), x)
            snaps = []
            v, used = decode(N, L, T, K, A, C, new, snaps=snaps, hint=hint)
            order = new[:used]
            curl = math.log2(max(v, 1))
            last_imp = it
            continue
        for _rep in range(nrep):
            n = len(new)
            mv = rng.random()
            if n >= 12 and rng.random() < MB:
                k = rng.randint(2, 10)
                a = rng.randrange(n - k + 1)
                blk = new[a:a + k]
                del new[a:a + k]
                b = max(0, min(n - k, a + rng.randint(-20, 20)))
                new[b:b] = blk
                lo = min(a, b)
            elif mv < MP[0] and n >= 2:
                a = min(n - 2, int((n - 1) * (1.0 - (1.0 - rng.random()) ** PB)))
                b = min(n - 1, a + rng.randint(1, MP[6]))
                new[a], new[b] = new[b], new[a]
                lo = a
            elif mv < MP[1] and n >= 2:
                a = min(n - 1, int(n * (1.0 - (1.0 - rng.random()) ** PB)))
                x = new.pop(a)
                R = MP[7] if rng.random() < MP[8] else n
                b = max(0, min(n - 1, a + rng.randint(-R, R)))
                new.insert(b, x)
                lo = min(a, b)
            elif mv < MP[2] and n >= 1:
                a = min(n - 1, int(n * (1.0 - (1.0 - rng.random()) ** PB)))
                new.pop(a)
                lo = a
            elif mv < MP[3] and n >= 1:
                a = min(n, int((n + 1) * (1.0 - (1.0 - rng.random()) ** PB)))
                x = new[max(0, min(n - 1, a + rng.randint(-3, 2)))]
                new.insert(a, x)
                lo = a
            elif mv < MP[4] or n == 0:
                a = min(n, int((n + 1) * (1.0 - (1.0 - rng.random()) ** PB)))
                if rng.random() < 0.7 and n:
                    x = new[rng.randrange(n)]
                else:
                    x = (rng.randrange(L), rng.randrange(N))
                new.insert(a, x)
                lo = a
            else:
                a = min(n - 1, int(n * (1.0 - (1.0 - rng.random()) ** PB)))
                i, j = new[a]
                if rng.random() < 0.5:
                    i = rng.randrange(L)
                else:
                    j = rng.randrange(N)
                new[a] = (i, j)
                lo = a
            if lo < lo_all:
                lo_all = lo
        lo = lo_all
        # find snapshot with pos <= lo
        k = min((lo - 1) >> 3, len(snaps) - 1) if lo >= 1 else -1
        snap = snaps[k] if k >= 0 else None
        ns = snaps[:k + 1] if k >= 0 else []
        ref = None
        hi = 0
        delta = len(new) - len(order)
        if PRUNE and delta == 0:
            hi = len(new) - 1
            while hi >= lo and new[hi] == order[hi]:
                hi -= 1
            if hi < lo:
                continue
            ref = snaps
        cp = -1
        cv = 0
        if PROJ:
            if delta:
                hi = len(new) - 1
                while hi >= lo and hi - delta >= 0 and hi - delta < len(order) and new[hi] == order[hi - delta]:
                    hi -= 1
            p = hi + PD + 1
            p += (delta - p) & 7
            q = (p - delta) >> 3
            if 0 <= q < len(snaps):
                cp = p
                o = snaps[q]
                cv = projv(N, A, T, o[0], o[2], o[3], o[4]) * PM
        v, used = decode(N, L, T, K, A, C, new, snap=snap, snaps=ns, hint=hint, ref=ref, minpos=hi, cmp_pos=cp, cmp_val=cv)
        if v == -1:
            continue
        if v == -2:
            # reached a state identical to the current solution
            order = new
            snaps = ns + snaps[len(ns):]
            continue
        if v <= 0:
            continue
        vl = math.log2(v)
        if vl >= curl or rng.random() < math.exp((vl - curl) / temp):
            order = new[:used]
            snaps = ns
            curl = vl
            if vl > best[0] + 1e-9:
                best = (vl, order[:])
                last_imp = it
    return best, it


allowed_prod = None
final_total_cache = None


def tot_prod(A, B, P, ids, w):
    s = 0
    for j in ids:
        p0 = P[j][0]
        if p0 == 0:
            continue
        b0, b1, b2, b3 = B[j]
        _, p1, p2, p3 = P[j]
        s += A[j] * p0 * (b0 * w + p1 * (b1 * c2(w) + p2 * (b2 * c3(w) + p3 * b3 * c4(w))))
    return s


def main():
    global allowed_prod
    data = sys.stdin.read().split()
    N, L, T, K = map(int, data[:4])
    A = list(map(int, data[4:4 + N]))
    C = []
    idx = 4 + N
    for i in range(L):
        C.append(list(map(int, data[idx:idx + N])))
        idx += N
    allowed_prod = list(range(N))
    start = time.time()
    best = None
    res = {}
    for var, kw in GREEDY:
        for js in list(range(N)) + [-1]:
            if js < 0:
                if var != 1:
                    continue
                mask = None
            else:
                mask = [[True] * N] * var + [[j == js for j in range(N)] for _ in range(L - var)]
            s, acts = run(N, L, T, K, A, C, list(range(N)), 0.0, mask=mask, **kw)
            if js not in res or s > res[js][0]:
                res[js] = (s, acts)
    def search(seed, w=0, nw=1):
        import random
        rng = random.Random(seed)

        def chain_id(order):
            cnt = [0] * N
            for i, j in order:
                if i:
                    cnt[j] += 1
            return max(range(N), key=lambda j: cnt[j])

        def sa(order, tl, t0=0.005):
            return anneal(N, L, T, K, A, C, order, tl, rng, t0, 0.00003)[0]

        pool = [(math.log2(max(v, 1)), [x for x in acts if x]) for v, acts in res.values()]
        pool.sort(key=lambda x: -x[0])
        if SPLIT:
            pool = pool[w::nw]
        rest = TL - (time.time() - start)
        tl = rest * R1 / len(pool)
        pool = [sa(o, tl) for _, o in pool]
        pool.sort(key=lambda x: -x[0])
        if DEBUG:
            sys.stderr.write('R1 ' + ' '.join('%d:%.2f' % (chain_id(o), v) for v, o in pool) + '\n')
        # transplant best chain to other ids
        ja = chain_id(pool[0][1])
        base = pool[0][1]
        first = min([k for k, x in enumerate(base) if x[0] > 0 and x[1] == ja] or [0])
        have = set(chain_id(o) for _, o in pool[:3])
        tr = []
        for jb in range(N):
            if jb == ja:
                continue
            o = [((i, jb) if (j == ja and k >= first) else (i, j)) for k, (i, j) in enumerate(base)]
            tr.append(o)
        rest = TL - (time.time() - start)
        tl = rest * R2 / len(tr)
        pool += [sa(o, tl) for o in tr]
        pool.sort(key=lambda x: -x[0])
        if DEBUG:
            sys.stderr.write('R2 ' + ' '.join('%d:%.2f' % (chain_id(o), v) for v, o in pool) + '\n')
        sel = []
        seen = set()
        for v, o in pool:
            c = chain_id(o)
            if c in seen:
                continue
            seen.add(c)
            sel.append((v, o))
            if len(sel) >= NTOP:
                break
        pool = sel
        rest = TL - (time.time() - start)
        tl = rest * R3 / len(pool)
        pool = [sa(o, tl) for _, o in pool]
        pool.sort(key=lambda x: -x[0])
        rest = TL - (time.time() - start)
        bl, bo = sa(pool[0][1], rest, 0.002)
        return bl, bo

    import pickle
    nw = max(1, min(NW, os.cpu_count() or 1))
    kids = []
    for w in range(1, nw):
        r, wfd = os.pipe()
        pid = os.fork()
        if pid == 0:
            os.close(r)
            try:
                out = pickle.dumps(search(1000 + w, w, nw))
            except Exception:
                out = pickle.dumps(None)
            with os.fdopen(wfd, "wb") as f:
                f.write(out)
            os._exit(0)
        os.close(wfd)
        kids.append((pid, r))
    bl, bo = search(12345, 0, nw)
    for pid, r in kids:
        with os.fdopen(r, "rb") as f:
            data = f.read()
        os.waitpid(pid, 0)
        try:
            x = pickle.loads(data)
        except Exception:
            x = None
        if x is not None and x[0] > bl:
            bl, bo = x
    # build action list by ASAP execution
    Bm = [[1] * L for _ in range(N)]
    Pm = [[0] * L for _ in range(N)]
    apples = K
    pos = 0
    out = []
    for t in range(T):
        if pos < len(bo):
            i, j = bo[pos]
            cost = C[i][j] * (Pm[j][i] + 1)
            if cost <= apples:
                apples -= cost
                Pm[j][i] += 1
                pos += 1
                out.append("%d %d" % (i, j))
            else:
                out.append("-1")
        else:
            out.append("-1")
        for j in range(N):
            bj = Bm[j]
            pj = Pm[j]
            apples += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
    sys.stdout.write("\n".join(out) + "\n")
    sys.stderr.write("best %s\n" % bl)


main()
