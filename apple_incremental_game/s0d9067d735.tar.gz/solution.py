import sys
import time
import random
import os
from math import comb


def main():
    t0 = time.time()
    data = sys.stdin.read().split()
    budget = float(os.environ.get('BUDGET', '25'))
    mode = os.environ.get('MODE', 'grid')
    N, L, T, K = int(data[0]), int(data[1]), int(data[2]), int(data[3])
    A = [int(x) for x in data[4:4 + N]]
    C = [[int(data[4 + N + i * N + j]) for j in range(N)] for i in range(L)]
    MAXR = T + 400
    CB = [[float(comb(r, m)) for m in range(L + 2)] for r in range(MAXR + 2)]

    def run(extra, allow, wpen, sigma=0.0, seed=0):
        rng = random.Random(seed)
        gauss = rng.gauss
        B = [[1] * N for _ in range(L)]
        P = [[0] * N for _ in range(L)]
        apples = K
        out = []
        for t in range(T):
            R = T - t
            G = [0.0] * (L + 1)
            for j in range(N):
                if P[0][j] == 0:
                    continue
                pr = A[j] * P[0][j]
                for k in range(L):
                    if k > 0:
                        pr *= P[k][j]
                        if pr == 0:
                            break
                    G[k + 1] += pr * B[k][j]
            a0 = float(apples)
            G1, G2, G3, G4 = G[1], G[2], G[3], G[4]
            cwR = CB[R - 1]
            maxap = a0 + G1 * cwR[1] + G2 * cwR[2] + G3 * cwR[3] + G4 * cwR[4]
            Re = R + extra
            best = 0.0
            bact = None
            bw = 0
            for i, j in allow:
                cost = C[i][j] * (P[i][j] + 1)
                if cost <= apples:
                    w = 0
                else:
                    if maxap < cost:
                        continue
                    lo, hi = 0, R - 1
                    while hi - lo > 1:
                        mid = (lo + hi) >> 1
                        cw = CB[mid]
                        if a0 + G1 * cw[1] + G2 * cw[2] + G3 * cw[3] + G4 * cw[4] >= cost:
                            hi = mid
                        else:
                            lo = mid
                    w = hi
                r = Re - w
                pj = [P[x][j] for x in range(L)]
                cw = CB[w]
                cr = CB[r]
                gain = -float(cost)
                pr = A[j]
                for k in range(L):
                    if k != i:
                        pr *= pj[k]
                    if pr == 0:
                        break
                    if k >= i:
                        s = 0.0
                        q = 1
                        for l in range(k, L):
                            if l > k:
                                q *= pj[l]
                                if q == 0:
                                    break
                            s += B[l][j] * q * cw[l - k]
                        gain += s * pr * cr[k + 1]
                if wpen:
                    gain /= (1.0 + wpen * w)
                if sigma:
                    gain *= 1.0 + sigma * gauss(0, 1)
                if gain > best:
                    best = gain
                    bact = (i, j)
                    bw = w
            if bact is not None and bw == 0:
                i, j = bact
                apples -= C[i][j] * (P[i][j] + 1)
                P[i][j] += 1
                out.append("%d %d" % (i, j))
            else:
                out.append("-1")
            for j in range(N):
                apples += A[j] * B[0][j] * P[0][j]
            for i in range(1, L):
                Bi = B[i]
                Pi = P[i]
                Bl = B[i - 1]
                for j in range(N):
                    Bl[j] += Bi[j] * Pi[j]
        return apples, out

    rng0 = random.Random(1)
    lvl0 = [(0, j) for j in range(N)]
    allfull = [(i, j) for i in range(L) for j in range(N)]
    chains = [allfull] + [lvl0 + [(i, jj) for i in range(1, L)] for jj in range(N)]
    best = None
    bc = None
    if mode == 'grid':
        configs = []
        for wpen in (30.0, 100.0, 1000.0, 1e9):
            for extra in (0, 25, 50, 100, 200):
                for al in chains:
                    configs.append((extra, al, wpen))
        for cfg in configs:
            if time.time() - t0 > budget:
                break
            res = run(*cfg)
            if best is None or res[0] > best[0]:
                best = res; bc = cfg
    else:
        sigma = float(os.environ.get('SIGMA', '0.1'))
        it = 0
        while time.time() - t0 < budget:
            it += 1
            cfg = (rng0.choice((0, 25, 50, 100, 200)), rng0.choice(chains), rng0.choice((30.0, 100.0, 1000.0, 1e9)), sigma if it > 30 else 0.0, it)
            res = run(*cfg)
            if best is None or res[0] > best[0]:
                best = res; bc = cfg
    import math; sys.stderr.write("%s %s %s %.0f\n" % (bc[0], (bc[1][-1][1] if len(bc[1])<40 else -1), bc[2], 1e5*math.log2(best[0])))
    print("\n".join(best[1]))


main()
