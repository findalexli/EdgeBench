import sys
from math import comb


def main():
    data = sys.stdin.read().split()
    N, L, T, K = int(data[0]), int(data[1]), int(data[2]), int(data[3])
    A = [int(x) for x in data[4:4 + N]]
    C = [[int(data[4 + N + i * N + j]) for j in range(N)] for i in range(L)]
    B = [[1] * N for _ in range(L)]
    P = [[0] * N for _ in range(L)]
    apples = K
    CB = [[float(comb(r, m)) for m in range(L + 2)] for r in range(T + 2)]

    out = []
    for t in range(T):
        R = T - t
        # idle apples(w) = a0 + sum_m G[m] * C(w, m)
        G = [0.0] * (L + 1)
        for j in range(N):
            if P[0][j] == 0:
                continue
            pr = A[j] * P[0][j]
            for k in range(L):
                if k > 0:
                    pr *= P[k][j]
                    if pr == 0:
                        break
                G[k + 1] += pr * B[k][j]
        a0 = float(apples)

        def idle_ap(w):
            cw = CB[w]
            return a0 + G[1] * cw[1] + G[2] * cw[2] + G[3] * cw[3] + G[4] * cw[4]

        best = 0.0
        bact = None
        bw = 0
        for i in range(L):
            for j in range(N):
                cost = C[i][j] * (P[i][j] + 1)
                if cost <= apples:
                    w = 0
                else:
                    if idle_ap(R - 1) < cost:
                        continue
                    lo, hi = 0, R - 1
                    while hi - lo > 1:
                        mid = (lo + hi) // 2
                        if idle_ap(mid) >= cost:
                            hi = mid
                        else:
                            lo = mid
                    w = hi
                r = R - w
                pj = [P[x][j] for x in range(L)]
                # B_k(w)
                cw = CB[w]
                Bw = []
                for k in range(L):
                    s = 0.0
                    pr = 1
                    for l in range(k, L):
                        if l > k:
                            pr *= pj[l]
                            if pr == 0:
                                break
                        s += B[l][j] * pr * cw[l - k]
                    Bw.append(s)
                # delta value
                cr = CB[r]
                gain = -float(cost)
                pr = A[j]
                for k in range(L):
                    if k != i:
                        pr *= pj[k]
                    if pr == 0:
                        break
                    if k >= i:
                        gain += Bw[k] * pr * cr[k + 1]
                if gain > best:
                    best = gain
                    bact = (i, j)
                    bw = w
        if bact is not None and bw == 0:
            i, j = bact
            apples -= C[i][j] * (P[i][j] + 1)
            P[i][j] += 1
            out.append("%d %d" % (i, j))
        else:
            out.append("-1")
        for j in range(N):
            apples += A[j] * B[0][j] * P[0][j]
        for i in range(1, L):
            for j in range(N):
                B[i - 1][j] += B[i][j] * P[i][j]
    print("\n".join(out))


main()
