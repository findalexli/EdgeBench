import sys
import time
import random
import os
from math import comb


def main():
    t0 = time.time()
    data = sys.stdin.read().split()
    budget = float(os.environ.get('BUDGET', '4'))
    mode = os.environ.get('MODE', 'halving')
    N, L, T, K = int(data[0]), int(data[1]), int(data[2]), int(data[3])
    A = [int(x) for x in data[4:4 + N]]
    C = [[int(data[4 + N + i * N + j]) for j in range(N)] for i in range(L)]
    MAXR = T + 400
    CB = [[float(comb(r, m)) for m in range(L + 2)] for r in range(MAXR + 2)]

    def run(extra, allow, wpen, sigma=0.0, seed=0, lm=(1.0, 1.0, 1.0, 1.0)):
        rng = random.Random(seed)
        gauss = rng.gauss
        B = [[1] * N for _ in range(L)]
        P = [[0] * N for _ in range(L)]
        apples = K
        out = []
        for t in range(T):
            R = T - t
            G = [0.0] * (L + 1)
            for j in range(N):
                if P[0][j] == 0:
                    continue
                pr = A[j] * P[0][j]
                for k in range(L):
                    if k > 0:
                        pr *= P[k][j]
                        if pr == 0:
                            break
                    G[k + 1] += pr * B[k][j]
            a0 = float(apples)
            G1, G2, G3, G4 = G[1], G[2], G[3], G[4]
            cwR = CB[R - 1]
            maxap = a0 + G1 * cwR[1] + G2 * cwR[2] + G3 * cwR[3] + G4 * cwR[4]
            Re = R + extra
            best = 0.0
            bact = None
            bw = 0
            for i, j in allow:
                cost = C[i][j] * (P[i][j] + 1)
                if cost <= apples:
                    w = 0
                else:
                    if maxap < cost:
                        continue
                    lo, hi = 0, R - 1
                    while hi - lo > 1:
                        mid = (lo + hi) >> 1
                        cw = CB[mid]
                        if a0 + G1 * cw[1] + G2 * cw[2] + G3 * cw[3] + G4 * cw[4] >= cost:
                            hi = mid
                        else:
                            lo = mid
                    w = hi
                r = Re - w
                pj = [P[x][j] for x in range(L)]
                cw = CB[w]
                cr = CB[r]
                gain = -float(cost)
                pr = A[j]
                for k in range(L):
                    if k != i:
                        pr *= pj[k]
                    if pr == 0:
                        break
                    if k >= i:
                        s = 0.0
                        q = 1
                        for l in range(k, L):
                            if l > k:
                                q *= pj[l]
                                if q == 0:
                                    break
                            s += B[l][j] * q * cw[l - k]
                        gain += s * pr * cr[k + 1]
                if wpen:
                    gain /= (1.0 + wpen * w)
                gain *= lm[i]
                if sigma:
                    gain *= 1.0 + sigma * gauss(0, 1)
                if gain > best:
                    best = gain
                    bact = (i, j)
                    bw = w
            if bact is not None and bw == 0:
                i, j = bact
                apples -= C[i][j] * (P[i][j] + 1)
                P[i][j] += 1
                out.append("%d %d" % (i, j))
            else:
                out.append("-1")
            for j in range(N):
                apples += A[j] * B[0][j] * P[0][j]
            for i in range(1, L):
                Bi = B[i]
                Pi = P[i]
                Bl = B[i - 1]
                for j in range(N):
                    Bl[j] += Bi[j] * Pi[j]
        return apples, out

    rng0 = random.Random(1)
    lvl0 = [(0, j) for j in range(N)]
    allfull = [(i, j) for i in range(L) for j in range(N)]
    chains = [allfull] + [lvl0 + [(i, jj) for i in range(1, L)] for jj in range(N)]
    best = None
    bc = None
    if mode == 'grid':
        configs = []
        for wpen in (30.0, 100.0, 1000.0, 1e9):
            for extra in (0, 25, 50, 100, 200):
                for al in chains:
                    configs.append((extra, al, wpen))
        for cfg in configs:
            if time.time() - t0 > budget:
                break
            res = run(*cfg)
            if best is None or res[0] > best[0]:
                best = res; bc = cfg
    else:
        sigma = float(os.environ.get('SIGMA', '0.1'))
        LMS = eval(os.environ.get('LMS', '[(1.0,)*4]'))
        it = 0
        while time.time() - t0 < budget:
            it += 1
            cfg = (rng0.choice((0, 25, 50, 100, 200)), rng0.choice(chains), rng0.choice((30.0, 100.0, 1000.0, 1e9)), sigma if it > 30 else 0.0, it, LMS[it % len(LMS)] if it > 0 else (1.0,)*4)
            res = run(*cfg)
            if best is None or res[0] > best[0]:
                best = res; bc = cfg
    if mode == 'halving':
        import math
        pool = []
        for al in chains:
            bb = None
            for wpen in (100.0, 1e9):
                for extra in (0, 50, 200):
                    res = run(extra, al, wpen)
                    if bb is None or res[0] > bb[0]:
                        bb = res
            od = [tuple(map(int, x.split())) for x in bb[1] if x != "-1"]
            pool.append(od)
        total = float(os.environ.get('TOTAL', '24'))
        DEDUP = int(os.environ.get('DEDUP', '1'))

        def main_chain(od):
            cnt = [0] * N
            for i, j in od:
                if i >= 2:
                    cnt[j] += i
            return max(range(N), key=lambda j: cnt[j])

        def halving(pool, rng, end):
            rounds = eval(os.environ.get('ROUNDS', '[(len(pool), 0.25), (4, 0.3), (1, 0.45)]'))
            rem = end - time.time()
            for keep, frac in rounds:
                scored = []
                pool = pool[:keep]
                per = rem * frac / len(pool)
                for od in pool:
                    od = anneal(od, N, L, T, K, A, C, time.time() + per, rng)
                    scored.append((exact_out(od, N, L, T, K, A, C)[0], od))
                scored.sort(key=lambda z: -z[0])
                if DEDUP:
                    seen = set()
                    sc2 = []
                    for z in scored:
                        key = main_chain(z[1])
                        if key in seen:
                            continue
                        seen.add(key)
                        sc2.append(z)
                    scored = sc2
                pool = [z[1] for z in scored]
            return pool[0]

        end = t0 + total
        W = int(os.environ.get('WORKERS', '0')) or min(4, os.cpu_count() or 1)
        if W <= 1:
            pool = [halving(pool, rng0, end)]
        else:
            import multiprocessing as mp
            ctx = mp.get_context('fork')
            q = ctx.Queue()

            def worker(seed):
                try:
                    od = halving(pool, random.Random(seed), end - 0.3)
                    q.put(od)
                except Exception:
                    q.put(None)

            procs = [ctx.Process(target=worker, args=(1000 + w,)) for w in range(W - 1)]
            for p in procs:
                p.start()
            res = [halving(pool, rng0, end - 0.3)]
            for p in procs:
                try:
                    r = q.get(timeout=max(0.5, end + 2.0 - time.time()))
                except Exception:
                    r = None
                if r is not None:
                    res.append(r)
            for p in procs:
                p.join(timeout=0.1)
                if p.is_alive():
                    p.terminate()
            res.sort(key=lambda od: -exact_out(od, N, L, T, K, A, C)[0])
            pool = res
        lines = exact_out(pool[0], N, L, T, K, A, C)
        sys.stderr.write("%.0f\n" % (1e5*math.log2(lines[0])))
        print("\n".join(lines[1]))
        return
    gsc = best[0]
    order = [tuple(map(int, x.split())) for x in best[1] if x != "-1"]
    sa_budget = float(os.environ.get('SABUDGET', '20'))
    if sa_budget > 0:
        order = anneal(order, N, L, T, K, A, C, t0 + budget + sa_budget, rng0)
    lines = exact_out(order, N, L, T, K, A, C)
    import math
    sys.stderr.write("%s %s %s %.0f %.0f\n" % (bc[0], (bc[1][-1][1] if len(bc[1])<40 else -1), bc[2], 1e5*math.log2(gsc), 1e5*math.log2(lines[0])))
    print("\n".join(lines[1]))


def exact_out(order, N, L, T, K, A, C):
    B = [[1] * N for _ in range(L)]
    P = [[0] * N for _ in range(L)]
    a = K
    out = []
    idx = 0
    for t in range(T):
        if idx < len(order):
            i, j = order[idx]
            cost = C[i][j] * (P[i][j] + 1)
            if a >= cost:
                a -= cost
                P[i][j] += 1
                out.append("%d %d" % (i, j))
                idx += 1
            else:
                out.append("-1")
        else:
            out.append("-1")
        for j in range(N):
            a += A[j] * B[0][j] * P[0][j]
        for i in range(1, L):
            for j in range(N):
                B[i - 1][j] += B[i][j] * P[i][j]
    return a, out


def anneal(order, N, L, T, K, A, C, deadline, rng):
    import math
    NL = N * L
    N2 = 2 * N
    Cf = [float(C[x // N][x % N]) for x in range(NL)]
    Af = [float(A[x % N]) if x < N else 0.0 for x in range(NL)]
    cur = [i * N + j for i, j in order]

    SS = 8

    def simulate(seq, k, snap, record):
        # snap[m] = (t, a, B, P) at start of the turn where seq[m*SS] is attempted
        m = k // SS
        if m >= len(snap):
            m = len(snap) - 1
        k = m * SS
        t, a, B, P = snap[m]
        B = B[:]
        P = P[:]
        rate = 0.0
        for y in range(N):
            if P[y]:
                rate += Af[y] * B[y] * P[y]
        act1 = [y for y in range(N, NL) if P[y] > 0]
        n = len(seq)
        newsnap = snap[:m + 1]
        while k < n:
            x = seq[k]
            cost = Cf[x] * (P[x] + 1)
            while a < cost and t < T:
                a += rate
                for y in act1:
                    d = B[y] * P[y]
                    B[y - N] += d
                    if y < N2:
                        rate += Af[y - N] * P[y - N] * d
                t += 1
            if t >= T:
                break
            a -= cost
            P[x] += 1
            if x < N:
                rate += Af[x] * B[x]
            elif P[x] == 1:
                act1.append(x)
                act1.sort()
            a += rate
            for y in act1:
                d = B[y] * P[y]
                B[y - N] += d
                if y < N2:
                    rate += Af[y - N] * P[y - N] * d
            t += 1
            k += 1
            if k % SS == 0:
                newsnap.append((t, a, B[:], P[:]))
            if t >= T:
                break
        while t < T:
            a += rate
            for y in act1:
                d = B[y] * P[y]
                B[y - N] += d
                if y < N2:
                    rate += Af[y - N] * P[y - N] * d
            t += 1
        return a, newsnap, k

    init = (0, float(K), [1.0] * NL, [0] * NL)
    curv, snap, nb = simulate(cur, 0, [init], True)
    # drop items that cannot be bought before the end
    cur = cur[:nb]
    bestv = curv
    best = cur[:]
    T0, T1 = float(os.environ.get('T0', '0.005')), float(os.environ.get('T1', '0.0001'))
    start = time.time()
    total = deadline - start
    it = 0
    temp = T0
    lc = math.log(curv)
    LOGR = math.log(float(os.environ.get('MAXD', '300')))
    while True:
        it += 1
        if (it & 63) == 0:
            el = time.time() - start
            if el > total:
                break
            temp = T0 * (T1 / T0) ** (el / total)
        n = len(cur)
        mv = rng.random()
        new = cur[:]
        if mv < 0.3 and n >= 2:
            p = rng.randrange(n)
            d = int(math.exp(rng.random() * LOGR))
            q = min(n - 1, max(0, p + (d if rng.random() < 0.5 else -d)))
            if p == q or new[p] == new[q]:
                continue
            new[p], new[q] = new[q], new[p]
            k = min(p, q)
        elif mv < 0.55 and n >= 2:
            p = rng.randrange(n)
            d = int(math.exp(rng.random() * LOGR))
            q = min(n - 1, max(0, p + (d if rng.random() < 0.5 else -d)))
            if p == q or new[p] == new[q]:
                continue
            x = new.pop(p)
            new.insert(q, x)
            k = min(p, q)
        elif mv < 0.7 and n >= 1:
            p = rng.randrange(n)
            new.pop(p)
            k = p
        elif mv < 0.85:
            p = rng.randrange(n + 1)
            if n and rng.random() < 0.7:
                x = cur[rng.randrange(n)]
            else:
                x = rng.randrange(NL)
            new.insert(p, x)
            k = p
        else:
            if n == 0:
                continue
            p = rng.randrange(n)
            x = cur[rng.randrange(n)] if rng.random() < 0.7 else rng.randrange(NL)
            if x == new[p]:
                continue
            new[p] = x
            k = p
        if k > len(cur):
            continue
        v, nsnap, nb = simulate(new, k, snap, False)
        if v <= 0:
            continue
        lv = math.log(v)
        if lv >= lc or rng.random() < math.exp((lv - lc) / temp):
            snap = nsnap
            cur = new[:nb]
            lc = lv
            if v > bestv:
                bestv = v
                best = cur[:]
    if os.environ.get('DBG'):
        sys.stderr.write('it %d\n' % it)
    return [(x // N, x % N) for x in best]


main()
