import sys, time


def c2(x):
    return x * (x - 1) // 2


def c3(x):
    return x * (x - 1) * (x - 2) // 6


def c4(x):
    return x * (x - 1) * (x - 2) * (x - 3) // 24


def final_j(a, b, p, r):
    # production of one ID over r turns with no further actions
    b0, b1, b2, b3 = b
    p0, p1, p2, p3 = p
    if p0 == 0 or r <= 0:
        return 0
    return a * p0 * (b0 * r + p1 * (b1 * c2(r) + p2 * (b2 * c3(r) + p3 * b3 * c4(r))))


def state_after(b, p, w):
    b0, b1, b2, b3 = b
    p0, p1, p2, p3 = p
    nb2 = b2 + p3 * b3 * w
    nb1 = b1 + p2 * (b2 * w + p3 * b3 * c2(w))
    nb0 = b0 + p1 * (b1 * w + p2 * (b2 * c2(w) + p3 * b3 * c3(w)))
    return (nb0, nb1, nb2, b3)


def run(N, L, T, K, A, C, allowed, alpha, beta, mask=None):
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    acts = []
    for t in range(T):
        rem = T - t
        best = None
        bestv = 0.0
        for j in allowed:
            bj = B[j]
            pj = P[j]
            a = A[j]
            base_fin = None
            for i in range(L):
                if mask is not None and not mask[i][j]:
                    continue
                cost = C[i][j] * (pj[i] + 1)
                # find wait w
                if cost <= apples:
                    w = 0
                else:
                    if final_total_cache is None:
                        pass
                    lo, hi = 1, rem
                    if apples + tot_prod(A, B, P, allowed_prod, hi - 1) < cost:
                        continue
                    while lo < hi:
                        m = (lo + hi) // 2
                        if apples + tot_prod(A, B, P, allowed_prod, m) >= cost:
                            hi = m
                        else:
                            lo = m + 1
                    w = lo
                r = rem - w
                if r <= 0:
                    continue
                if w:
                    bs = state_after(bj, pj, w)
                else:
                    bs = bj
                old = final_j(a, bs, pj, r)
                np_ = list(pj)
                np_[i] += 1
                new = final_j(a, bs, np_, r)
                gain = new - old - cost
                if gain <= 0:
                    continue
                v = gain / (cost ** alpha) / ((w + 1) ** beta)
                if v > bestv:
                    bestv = v
                    best = (i, j, w, cost)
        if best is not None and best[2] == 0:
            i, j, w, cost = best
            apples -= cost
            P[j][i] += 1
            acts.append((i, j))
        else:
            acts.append(None)
        # production
        for j in range(N):
            bj = B[j]
            pj = P[j]
            apples += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
    return apples, acts


def coef(a, b, p):
    x = a * p[0]
    c0 = x * b[0]
    x *= p[1]
    c1 = x * b[1]
    x *= p[2]
    c2_ = x * b[2]
    x *= p[3]
    return c0, c1, c2_, x * b[3]


def run2(N, L, T, K, A, C, g, mask=None):
    import math
    q = math.exp(-g)
    E = [[0.0] * 4 for _ in range(T + 1)]
    for r in range(1, T + 1):
        k = r - 1
        qk = q ** k
        E[r] = [E[r - 1][0] + qk, E[r - 1][1] + qk * k, E[r - 1][2] + qk * c2(k), E[r - 1][3] + qk * c3(k)]
    qp = [q ** w for w in range(T + 1)]
    B = [[1] * L for _ in range(N)]
    P = [[0] * L for _ in range(N)]
    apples = K
    acts = []
    ids = list(range(N))
    for t in range(T):
        rem = T - t
        best = None
        bestv = 0.0
        for j in range(N):
            bj = B[j]
            pj = P[j]
            a = A[j]
            for i in range(L):
                if mask is not None and not mask[i][j]:
                    continue
                cost = C[i][j] * (pj[i] + 1)
                if cost <= apples:
                    w = 0
                else:
                    lo, hi = 1, rem
                    if apples + tot_prod(A, B, P, ids, hi - 1) < cost:
                        continue
                    while lo < hi:
                        m = (lo + hi) // 2
                        if apples + tot_prod(A, B, P, ids, m) >= cost:
                            hi = m
                        else:
                            lo = m + 1
                    w = lo
                r = rem - w
                if r <= 0:
                    continue
                bs = state_after(bj, pj, w) if w else bj
                o = coef(a, bs, pj)
                np_ = list(pj)
                np_[i] += 1
                n = coef(a, bs, np_)
                Er = E[r]
                V = (n[0] - o[0]) * Er[0] + (n[1] - o[1]) * Er[1] + (n[2] - o[2]) * Er[2] + (n[3] - o[3]) * Er[3]
                v = (V - cost) * qp[w]
                if v > bestv:
                    bestv = v
                    best = (i, j, w, cost)
        if best is not None and best[2] == 0:
            i, j, w, cost = best
            apples -= cost
            P[j][i] += 1
            acts.append((i, j))
        else:
            acts.append(None)
        for j in range(N):
            bj = B[j]
            pj = P[j]
            apples += A[j] * bj[0] * pj[0]
            for i in range(1, L):
                bj[i - 1] += bj[i] * pj[i]
    return apples, acts


allowed_prod = None
final_total_cache = None


def tot_prod(A, B, P, ids, w):
    s = 0
    for j in ids:
        p0 = P[j][0]
        if p0 == 0:
            continue
        b0, b1, b2, b3 = B[j]
        _, p1, p2, p3 = P[j]
        s += A[j] * p0 * (b0 * w + p1 * (b1 * c2(w) + p2 * (b2 * c3(w) + p3 * b3 * c4(w))))
    return s


def main():
    global allowed_prod
    data = sys.stdin.read().split()
    N, L, T, K = map(int, data[:4])
    A = list(map(int, data[4:4 + N]))
    C = []
    idx = 4 + N
    for i in range(L):
        C.append(list(map(int, data[idx:idx + N])))
        idx += N
    allowed_prod = list(range(N))
    start = time.time()
    best = None
    cands = []
    for beta in (3.0, 2.0, 4.0, 2.5, 3.5, 1.5, 5.0, 6.0):
        for js in range(N):
            cands.append((beta, js))
        cands.append((beta, -1))
    for beta, js in cands:
        if time.time() - start > 22:
            break
        if js < 0:
            mask = None
        else:
            mask = [[True] * N] + [[j == js for j in range(N)] for _ in range(L - 1)]
        s, acts = run(N, L, T, K, A, C, list(range(N)), 0.0, beta, mask)
        if best is None or s > best[0]:
            best = (s, acts, js, beta)
    out = []
    for a in best[1]:
        out.append("-1" if a is None else "%d %d" % a)
    sys.stdout.write("\n".join(out) + "\n")
    sys.stderr.write("best %s %s %s\n" % (best[0], best[2], best[3]))


main()
