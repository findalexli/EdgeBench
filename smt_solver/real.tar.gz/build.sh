#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
g++ -O2 -std=c++17 -pthread -o build/smt_bin src/main.cpp
chmod +x solve
