// Exact arbitrary precision integers and rationals with an int64 fast path.
#pragma once
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <utility>
#include <cassert>

typedef __int128 i128;

// ---------------------------------------------------------------------------
// BigInt: sign-magnitude, base 2^32 limbs (little endian)
// ---------------------------------------------------------------------------
struct BigInt {
    bool neg = false;
    std::vector<uint32_t> mag;  // no leading zeros; zero = empty

    BigInt() {}
    BigInt(int64_t v) { set(v); }
    static BigInt from_i128(i128 v) {
        BigInt r;
        bool n = v < 0;
        unsigned __int128 u = n ? (unsigned __int128)(-(v + 1)) + 1 : (unsigned __int128)v;
        while (u) { r.mag.push_back((uint32_t)u); u >>= 32; }
        r.neg = n && !r.mag.empty();
        return r;
    }
    void set(int64_t v) {
        mag.clear();
        neg = v < 0;
        uint64_t u = neg ? (uint64_t)(-(v + 1)) + 1 : (uint64_t)v;
        while (u) { mag.push_back((uint32_t)u); u >>= 32; }
        if (mag.empty()) neg = false;
    }
    bool is_zero() const { return mag.empty(); }
    void trim() {
        while (!mag.empty() && mag.back() == 0) mag.pop_back();
        if (mag.empty()) neg = false;
    }
    bool fits_i64() const {
        if (mag.size() > 2) return false;
        uint64_t u = 0;
        if (mag.size() > 0) u = mag[0];
        if (mag.size() > 1) u |= (uint64_t)mag[1] << 32;
        if (neg) return u <= (uint64_t)1 << 63 && !(u == (uint64_t)1 << 63);  // keep away from INT64_MIN
        return u <= (uint64_t)INT64_MAX;
    }
    int64_t to_i64() const {
        uint64_t u = 0;
        if (mag.size() > 0) u = mag[0];
        if (mag.size() > 1) u |= (uint64_t)mag[1] << 32;
        return neg ? -(int64_t)u : (int64_t)u;
    }
    double to_double() const {
        double r = 0;
        for (size_t i = mag.size(); i-- > 0;) r = r * 4294967296.0 + mag[i];
        return neg ? -r : r;
    }
    static int cmp_mag(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b) {
        if (a.size() != b.size()) return a.size() < b.size() ? -1 : 1;
        for (size_t i = a.size(); i-- > 0;)
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        return 0;
    }
    static void add_mag(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b, std::vector<uint32_t>& r) {
        const std::vector<uint32_t>& x = a.size() >= b.size() ? a : b;
        const std::vector<uint32_t>& y = a.size() >= b.size() ? b : a;
        std::vector<uint32_t> out(x.size() + 1);
        uint64_t c = 0;
        for (size_t i = 0; i < x.size(); i++) {
            c += (uint64_t)x[i] + (i < y.size() ? y[i] : 0);
            out[i] = (uint32_t)c;
            c >>= 32;
        }
        out[x.size()] = (uint32_t)c;
        r.swap(out);
        while (!r.empty() && r.back() == 0) r.pop_back();
    }
    // a >= b required
    static void sub_mag(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b, std::vector<uint32_t>& r) {
        std::vector<uint32_t> out(a.size());
        int64_t br = 0;
        for (size_t i = 0; i < a.size(); i++) {
            int64_t d = (int64_t)a[i] - br - (i < b.size() ? (int64_t)b[i] : 0);
            if (d < 0) { d += ((int64_t)1 << 32); br = 1; } else br = 0;
            out[i] = (uint32_t)d;
        }
        r.swap(out);
        while (!r.empty() && r.back() == 0) r.pop_back();
    }
    friend BigInt operator+(const BigInt& a, const BigInt& b) {
        BigInt r;
        if (a.neg == b.neg) { add_mag(a.mag, b.mag, r.mag); r.neg = a.neg; }
        else {
            int c = cmp_mag(a.mag, b.mag);
            if (c == 0) return r;
            if (c > 0) { sub_mag(a.mag, b.mag, r.mag); r.neg = a.neg; }
            else { sub_mag(b.mag, a.mag, r.mag); r.neg = b.neg; }
        }
        r.trim();
        return r;
    }
    BigInt operator-() const { BigInt r = *this; if (!r.is_zero()) r.neg = !r.neg; return r; }
    friend BigInt operator-(const BigInt& a, const BigInt& b) { return a + (-b); }
    friend BigInt operator*(const BigInt& a, const BigInt& b) {
        BigInt r;
        if (a.is_zero() || b.is_zero()) return r;
        std::vector<uint32_t> out(a.mag.size() + b.mag.size(), 0);
        for (size_t i = 0; i < a.mag.size(); i++) {
            uint64_t c = 0, ai = a.mag[i];
            for (size_t j = 0; j < b.mag.size(); j++) {
                c += ai * b.mag[j] + out[i + j];
                out[i + j] = (uint32_t)c;
                c >>= 32;
            }
            size_t k = i + b.mag.size();
            while (c) { c += out[k]; out[k] = (uint32_t)c; c >>= 32; k++; }
        }
        r.mag.swap(out);
        r.neg = a.neg != b.neg;
        r.trim();
        return r;
    }
    // truncated division of magnitudes: q = a / b, rem = a % b
    static void divmod_mag(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b,
                           std::vector<uint32_t>& q, std::vector<uint32_t>& rem) {
        assert(!b.empty());
        if (cmp_mag(a, b) < 0) { q.clear(); rem = a; return; }
        if (b.size() == 1) {
            uint64_t d = b[0], r = 0;
            q.assign(a.size(), 0);
            for (size_t i = a.size(); i-- > 0;) {
                uint64_t cur = (r << 32) | a[i];
                q[i] = (uint32_t)(cur / d);
                r = cur % d;
            }
            while (!q.empty() && q.back() == 0) q.pop_back();
            rem.clear();
            if (r) rem.push_back((uint32_t)r);
            return;
        }
        // Knuth algorithm D
        int s = __builtin_clz(b.back());
        std::vector<uint32_t> v(b.size()), u(a.size() + 1);
        size_t n = b.size(), m = a.size() - b.size();
        for (size_t i = n; i-- > 0;) {
            v[i] = (b[i] << s) | (s && i > 0 ? (uint32_t)((uint64_t)b[i - 1] >> (32 - s)) : 0);
        }
        u[a.size()] = s ? (uint32_t)((uint64_t)a.back() >> (32 - s)) : 0;
        for (size_t i = a.size(); i-- > 0;) {
            u[i] = (a[i] << s) | (s && i > 0 ? (uint32_t)((uint64_t)a[i - 1] >> (32 - s)) : 0);
        }
        q.assign(m + 1, 0);
        const uint64_t B = (uint64_t)1 << 32;
        for (size_t jj = m + 1; jj-- > 0;) {
            size_t j = jj;
            uint64_t num = ((uint64_t)u[j + n] << 32) | u[j + n - 1];
            uint64_t qhat = num / v[n - 1];
            uint64_t rhat = num % v[n - 1];
            while (qhat >= B || qhat * v[n - 2] > ((rhat << 32) | u[j + n - 2])) {
                qhat--;
                rhat += v[n - 1];
                if (rhat >= B) break;
            }
            int64_t borrow = 0;
            uint64_t carry = 0;
            for (size_t i = 0; i < n; i++) {
                uint64_t p = qhat * v[i] + carry;
                carry = p >> 32;
                int64_t t = (int64_t)u[i + j] - borrow - (int64_t)(uint32_t)p;
                if (t < 0) { t += B; borrow = 1; } else borrow = 0;
                u[i + j] = (uint32_t)t;
            }
            int64_t t = (int64_t)u[j + n] - borrow - (int64_t)carry;
            if (t < 0) {
                u[j + n] = (uint32_t)(t + B);
                // add back
                qhat--;
                uint64_t c = 0;
                for (size_t i = 0; i < n; i++) {
                    c += (uint64_t)u[i + j] + v[i];
                    u[i + j] = (uint32_t)c;
                    c >>= 32;
                }
                u[j + n] = (uint32_t)((uint64_t)u[j + n] + c);
            } else {
                u[j + n] = (uint32_t)t;
            }
            q[j] = (uint32_t)qhat;
        }
        while (!q.empty() && q.back() == 0) q.pop_back();
        rem.assign(n, 0);
        for (size_t i = 0; i < n; i++) {
            rem[i] = (u[i] >> s) | (s && i + 1 < u.size() ? (uint32_t)((uint64_t)u[i + 1] << (32 - s)) : 0);
        }
        while (!rem.empty() && rem.back() == 0) rem.pop_back();
    }
    // truncated division
    static void divmod(const BigInt& a, const BigInt& b, BigInt& q, BigInt& r) {
        divmod_mag(a.mag, b.mag, q.mag, r.mag);
        q.neg = (a.neg != b.neg);
        r.neg = a.neg;
        q.trim();
        r.trim();
    }
    friend BigInt operator/(const BigInt& a, const BigInt& b) { BigInt q, r; divmod(a, b, q, r); return q; }
    friend BigInt operator%(const BigInt& a, const BigInt& b) { BigInt q, r; divmod(a, b, q, r); return r; }
    int sign() const { return is_zero() ? 0 : (neg ? -1 : 1); }
    friend int cmp(const BigInt& a, const BigInt& b) {
        if (a.neg != b.neg) return a.neg ? -1 : 1;
        int c = cmp_mag(a.mag, b.mag);
        return a.neg ? -c : c;
    }
    friend bool operator==(const BigInt& a, const BigInt& b) { return a.neg == b.neg && a.mag == b.mag; }
    BigInt abs() const { BigInt r = *this; r.neg = false; return r; }
    static BigInt gcd(BigInt a, BigInt b) {
        a.neg = b.neg = false;
        while (!b.is_zero()) {
            if (a.fits_i64() && b.fits_i64()) {
                int64_t x = a.to_i64(), y = b.to_i64();
                while (y) { int64_t t = x % y; x = y; y = t; }
                return BigInt(x);
            }
            BigInt r = a % b;
            a = std::move(b);
            b = std::move(r);
        }
        return a;
    }
    std::string to_string() const {
        if (is_zero()) return "0";
        std::string s;
        std::vector<uint32_t> cur = mag, q, r;
        std::vector<uint32_t> ten9 = {1000000000u};
        while (!cur.empty()) {
            divmod_mag(cur, ten9, q, r);
            uint32_t chunk = r.empty() ? 0 : r[0];
            for (int i = 0; i < 9; i++) {
                s.push_back('0' + chunk % 10);
                chunk /= 10;
            }
            cur.swap(q);
        }
        while (s.size() > 1 && s.back() == '0') s.pop_back();
        if (neg) s.push_back('-');
        std::reverse(s.begin(), s.end());
        return s;
    }
    static BigInt from_string(const std::string& str) {
        BigInt r;
        size_t i = 0;
        bool n = false;
        if (i < str.size() && str[i] == '-') { n = true; i++; }
        BigInt ten9(1000000000);
        while (i < str.size()) {
            size_t len = std::min((size_t)9, str.size() - i);
            int64_t chunk = 0, mul = 1;
            for (size_t k = 0; k < len; k++) { chunk = chunk * 10 + (str[i + k] - '0'); mul *= 10; }
            r = r * BigInt(mul) + BigInt(chunk);
            i += len;
        }
        r.neg = n && !r.is_zero();
        return r;
    }
};

// ---------------------------------------------------------------------------
// Rational
// ---------------------------------------------------------------------------
static inline int64_t gcd64(int64_t a, int64_t b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b) { int64_t t = a % b; a = b; b = t; }
    return a;
}
static inline unsigned __int128 gcdu128(unsigned __int128 a, unsigned __int128 b) {
    while (b) {
        if ((a >> 64) == 0 && (b >> 64) == 0) {
            uint64_t x = (uint64_t)a, y = (uint64_t)b;
            while (y) { uint64_t t = x % y; x = y; y = t; }
            return x;
        }
        unsigned __int128 t = a % b; a = b; b = t;
    }
    return a;
}

struct BigRat {
    BigInt num, den;  // den > 0, gcd = 1
};

class Rational {
public:
    // small representation valid when big == nullptr; d > 0
    int64_t n = 0, d = 1;
    BigRat* big = nullptr;

    Rational() {}
    Rational(int64_t v) : n(v), d(1) {
        if (v == INT64_MIN) { big = new BigRat{BigInt(v), BigInt(1)}; }
    }
    Rational(int64_t a, int64_t b) { set_i128(a, b); }
    Rational(const Rational& o) : n(o.n), d(o.d), big(o.big ? new BigRat(*o.big) : nullptr) {}
    Rational(Rational&& o) noexcept : n(o.n), d(o.d), big(o.big) { o.big = nullptr; }
    Rational& operator=(const Rational& o) {
        if (this == &o) return *this;
        if (o.big) {
            if (big) *big = *o.big; else big = new BigRat(*o.big);
        } else {
            delete big; big = nullptr;
        }
        n = o.n; d = o.d;
        return *this;
    }
    Rational& operator=(Rational&& o) noexcept {
        if (this == &o) return *this;
        delete big;
        n = o.n; d = o.d; big = o.big; o.big = nullptr;
        return *this;
    }
    ~Rational() { delete big; }

    static Rational from_big(BigInt num, BigInt den) {
        Rational r;
        if (den.neg) { num = -num; den = -den; }
        BigInt g = BigInt::gcd(num, den);
        if (!(g == BigInt(1))) { num = num / g; den = den / g; }
        if (num.fits_i64() && den.fits_i64()) {
            r.n = num.to_i64(); r.d = den.to_i64();
        } else {
            r.big = new BigRat{std::move(num), std::move(den)};
        }
        return r;
    }
    void set_i128(i128 a, i128 b) {
        delete big; big = nullptr;
        if (b < 0) { a = -a; b = -b; }
        unsigned __int128 ua = a < 0 ? (unsigned __int128)(-a) : (unsigned __int128)a;
        unsigned __int128 g = gcdu128(ua, (unsigned __int128)b);
        if (g > 1) { a /= (i128)g; b /= (i128)g; }
        if (a > (i128)INT64_MIN && a <= (i128)INT64_MAX && b <= (i128)INT64_MAX) {
            n = (int64_t)a; d = (int64_t)b;
        } else {
            big = new BigRat{BigInt::from_i128(a), BigInt::from_i128(b)};
            n = 0; d = 1;
        }
    }
    BigInt bnum() const { return big ? big->num : BigInt(n); }
    BigInt bden() const { return big ? big->den : BigInt(d); }

    bool is_zero() const { return !big && n == 0; }
    bool is_int() const { return big ? big->den == BigInt(1) : d == 1; }
    int sign() const { return big ? big->num.sign() : (n > 0) - (n < 0); }
    bool is_one() const { return !big && n == 1 && d == 1; }
    bool is_minus_one() const { return !big && n == -1 && d == 1; }

    friend Rational operator+(const Rational& a, const Rational& b) {
        if (!a.big && !b.big) {
            if (a.d == 1 && b.d == 1) {
                int64_t r;
                if (!__builtin_add_overflow(a.n, b.n, &r) && r != INT64_MIN) { Rational x; x.n = r; return x; }
                Rational x; x.set_i128((i128)a.n + b.n, 1); return x;
            }
            Rational x;
            x.set_i128((i128)a.n * b.d + (i128)b.n * a.d, (i128)a.d * b.d);
            return x;
        }
        return from_big(a.bnum() * b.bden() + b.bnum() * a.bden(), a.bden() * b.bden());
    }
    friend Rational operator-(const Rational& a, const Rational& b) {
        if (!a.big && !b.big) {
            if (a.d == 1 && b.d == 1) {
                int64_t r;
                if (!__builtin_sub_overflow(a.n, b.n, &r) && r != INT64_MIN) { Rational x; x.n = r; return x; }
                Rational x; x.set_i128((i128)a.n - b.n, 1); return x;
            }
            Rational x;
            x.set_i128((i128)a.n * b.d - (i128)b.n * a.d, (i128)a.d * b.d);
            return x;
        }
        return from_big(a.bnum() * b.bden() - b.bnum() * a.bden(), a.bden() * b.bden());
    }
    Rational operator-() const {
        if (!big) { Rational x; x.n = -n; x.d = d; return x; }
        Rational x(*this);
        x.big->num = -x.big->num;
        return x;
    }
    friend Rational operator*(const Rational& a, const Rational& b) {
        if (!a.big && !b.big) {
            if (a.d == 1 && b.d == 1) {
                int64_t r;
                if (!__builtin_mul_overflow(a.n, b.n, &r) && r != INT64_MIN) { Rational x; x.n = r; return x; }
            }
            Rational x;
            x.set_i128((i128)a.n * b.n, (i128)a.d * b.d);
            return x;
        }
        return from_big(a.bnum() * b.bnum(), a.bden() * b.bden());
    }
    friend Rational operator/(const Rational& a, const Rational& b) {
        assert(!b.is_zero());
        if (!a.big && !b.big) {
            Rational x;
            x.set_i128((i128)a.n * b.d, (i128)a.d * b.n);
            return x;
        }
        return from_big(a.bnum() * b.bden(), a.bden() * b.bnum());
    }
    Rational& operator+=(const Rational& o) {
        if (!big && !o.big && d == 1 && o.d == 1) {
            int64_t r;
            if (!__builtin_add_overflow(n, o.n, &r) && r != INT64_MIN) { n = r; return *this; }
        }
        *this = *this + o; return *this;
    }
    Rational& operator-=(const Rational& o) { *this = *this - o; return *this; }
    Rational& operator*=(const Rational& o) { *this = *this * o; return *this; }
    Rational& operator/=(const Rational& o) { *this = *this / o; return *this; }
    // this += a*b
    void addmul(const Rational& a, const Rational& b) {
        if (!big && !a.big && !b.big && d == 1 && a.d == 1 && b.d == 1) {
            int64_t p, r;
            if (!__builtin_mul_overflow(a.n, b.n, &p) && !__builtin_add_overflow(n, p, &r) && r != INT64_MIN) {
                n = r; return;
            }
        }
        *this = *this + a * b;
    }

    friend int cmp(const Rational& a, const Rational& b) {
        if (!a.big && !b.big) {
            if (a.d == b.d) return (a.n > b.n) - (a.n < b.n);
            i128 l = (i128)a.n * b.d, r = (i128)b.n * a.d;
            return (l > r) - (l < r);
        }
        return cmp(a.bnum() * b.bden(), b.bnum() * a.bden());
    }
    friend bool operator==(const Rational& a, const Rational& b) {
        if (!a.big && !b.big) return a.n == b.n && a.d == b.d;
        if (!a.big || !b.big) return false;  // normalized: big only if it doesn't fit
        return a.big->num == b.big->num && a.big->den == b.big->den;
    }
    friend bool operator!=(const Rational& a, const Rational& b) { return !(a == b); }
    friend bool operator<(const Rational& a, const Rational& b) { return cmp(a, b) < 0; }
    friend bool operator>(const Rational& a, const Rational& b) { return cmp(a, b) > 0; }
    friend bool operator<=(const Rational& a, const Rational& b) { return cmp(a, b) <= 0; }
    friend bool operator>=(const Rational& a, const Rational& b) { return cmp(a, b) >= 0; }

    Rational floor() const {
        if (!big) {
            if (d == 1) return *this;
            int64_t q = n / d;
            if ((n % d != 0) && (n < 0)) q--;
            return Rational(q);
        }
        BigInt q, r;
        BigInt::divmod(big->num, big->den, q, r);
        if (!r.is_zero() && big->num.neg) q = q - BigInt(1);
        return from_big(q, BigInt(1));
    }
    Rational ceil() const {
        if (is_int()) return *this;
        return floor() + Rational(1);
    }
    Rational abs() const { return sign() < 0 ? -*this : *this; }
    Rational frac() const { return *this - floor(); }
    double to_double() const {
        if (!big) return (double)n / (double)d;
        return big->num.to_double() / big->den.to_double();
    }
    std::string num_str() const { return big ? big->num.to_string() : std::to_string(n); }
    std::string den_str() const { return big ? big->den.to_string() : std::to_string(d); }
    // SMT-LIB literal
    std::string to_smt() const {
        bool negv = sign() < 0;
        Rational a = abs();
        std::string body;
        if (a.is_int()) body = a.num_str();
        else body = "(/ " + a.num_str() + " " + a.den_str() + ")";
        if (negv) return "(- " + body + ")";
        return body;
    }
    std::string to_string() const {
        if (is_int()) return num_str();
        return num_str() + "/" + den_str();
    }
    size_t hash() const {
        if (!big) return std::hash<int64_t>()(n) * 31 + std::hash<int64_t>()(d);
        size_t h = 7;
        for (auto w : big->num.mag) h = h * 1000003 + w;
        for (auto w : big->den.mag) h = h * 1000003 + w;
        return h;
    }
    // parse decimal or integer literal
    static Rational parse(const std::string& s) {
        size_t dot = s.find('.');
        if (dot == std::string::npos) {
            if (s.size() < 18) return Rational((int64_t)std::strtoll(s.c_str(), nullptr, 10));
            return from_big(BigInt::from_string(s), BigInt(1));
        }
        std::string whole = s.substr(0, dot), fr = s.substr(dot + 1);
        bool negv = false;
        if (!whole.empty() && whole[0] == '-') { negv = true; whole = whole.substr(1); }
        std::string digits = whole + fr;
        while (digits.size() > 1 && digits[0] == '0') digits.erase(0, 1);
        if (digits.empty()) digits = "0";
        BigInt den(1);
        for (size_t i = 0; i < fr.size(); i++) den = den * BigInt(10);
        BigInt num = BigInt::from_string(digits);
        if (negv) num = -num;
        return from_big(num, den);
    }
};

// c + k*delta
struct DeltaRat {
    Rational c, k;
    DeltaRat() {}
    DeltaRat(const Rational& a) : c(a) {}
    DeltaRat(const Rational& a, const Rational& b) : c(a), k(b) {}
    friend DeltaRat operator+(const DeltaRat& a, const DeltaRat& b) { return DeltaRat(a.c + b.c, a.k + b.k); }
    friend DeltaRat operator-(const DeltaRat& a, const DeltaRat& b) { return DeltaRat(a.c - b.c, a.k - b.k); }
    friend DeltaRat operator*(const DeltaRat& a, const Rational& r) { return DeltaRat(a.c * r, a.k * r); }
    DeltaRat& operator+=(const DeltaRat& o) { c += o.c; k += o.k; return *this; }
    void addmul(const DeltaRat& a, const Rational& r) {
        c.addmul(a.c, r);
        if (!a.k.is_zero()) k.addmul(a.k, r);
    }
    friend int cmp(const DeltaRat& a, const DeltaRat& b) {
        int x = cmp(a.c, b.c);
        if (x) return x;
        return cmp(a.k, b.k);
    }
    friend bool operator<(const DeltaRat& a, const DeltaRat& b) { return cmp(a, b) < 0; }
    friend bool operator>(const DeltaRat& a, const DeltaRat& b) { return cmp(a, b) > 0; }
    friend bool operator<=(const DeltaRat& a, const DeltaRat& b) { return cmp(a, b) <= 0; }
    friend bool operator>=(const DeltaRat& a, const DeltaRat& b) { return cmp(a, b) >= 0; }
    friend bool operator==(const DeltaRat& a, const DeltaRat& b) { return a.c == b.c && a.k == b.k; }
    friend bool operator!=(const DeltaRat& a, const DeltaRat& b) { return !(a == b); }
};
