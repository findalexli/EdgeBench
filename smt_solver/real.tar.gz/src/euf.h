// Congruence closure with explanations (Nieuwenhuis & Oliveras), backtrackable.
#pragma once
#include "sat.h"
#include <unordered_map>
#include <deque>

class EUF : public Theory {
public:
    Solver& S;
    int tid;

    // nodes
    std::vector<int> left, right;    // curried application; -1 for leaves
    std::vector<int> rep, nxt, csize;
    std::vector<std::vector<int>> uses;     // app nodes having this node as direct child
    std::vector<std::vector<int>> node_atoms;  // eq atom ids mentioning node
    struct Diseq { int other; Lit r; };
    std::vector<std::vector<Diseq>> diseqs;
    std::vector<int> pf_parent;
    std::vector<Lit> pf_lit;     // LIT_UNDEF => congruence edge
    std::vector<Var> bool_var;   // bool nodes: sat var
    std::unordered_map<uint64_t, int> app_index;  // (l,r) -> node (hash consing)
    std::unordered_map<uint64_t, int> sigtab;
    int TRUE_N = -1, FALSE_N = -1;

    struct EqAtom { int a, b; Var v; };
    std::vector<EqAtom> eqatoms;
    // sat var -> (kind, id): kind 0 = eq atom, 1 = bool node
    std::unordered_map<Var, std::pair<int, int>> var_info;
    std::unordered_map<Var, std::pair<int, int>> prop_pair;

    // trail
    enum { T_PROOF, T_MERGE, T_SIG_ERASE, T_SIG_INSERT, T_DISEQ };
    struct TEntry { int kind; int a, b, c; uint64_t key; };
    std::vector<TEntry> trail;
    std::vector<int> trail_lim;
    int head = 0;
    std::vector<int> head_lim;

    struct Pending { int a, b; Lit r; };
    std::deque<Pending> pending;

    std::vector<int> stamp;
    int cur_stamp = 0;
    std::vector<int> edge_stamp;
    int cur_edge_stamp = 0;

    EUF(Solver& s, int id) : S(s), tid(id) {
        TRUE_N = mk_leaf();
        FALSE_N = mk_leaf();
        diseqs[TRUE_N].push_back({FALSE_N, LIT_UNDEF});
        diseqs[FALSE_N].push_back({TRUE_N, LIT_UNDEF});
    }

    int num_nodes() const { return (int)rep.size(); }

    int mk_leaf() {
        int n = num_nodes();
        left.push_back(-1);
        right.push_back(-1);
        rep.push_back(n);
        nxt.push_back(n);
        csize.push_back(1);
        uses.emplace_back();
        node_atoms.emplace_back();
        diseqs.emplace_back();
        pf_parent.push_back(-1);
        pf_lit.push_back(LIT_UNDEF);
        bool_var.push_back(-1);
        stamp.push_back(0);
        edge_stamp.push_back(0);
        return n;
    }
    static uint64_t pkey(int a, int b) { return ((uint64_t)(uint32_t)a << 32) | (uint32_t)b; }

    // only at level 0 (setup)
    int mk_app(int l, int r) {
        uint64_t k = pkey(l, r);
        auto it = app_index.find(k);
        if (it != app_index.end()) return it->second;
        int n = mk_leaf();
        left[n] = l;
        right[n] = r;
        app_index[k] = n;
        uses[l].push_back(n);
        if (r != l) uses[r].push_back(n);
        uint64_t sk = pkey(rep[l], rep[r]);
        auto st = sigtab.find(sk);
        if (st == sigtab.end()) sigtab[sk] = n;
        else pending.push_back({n, st->second, LIT_UNDEF});
        return n;
    }

    void add_distinct_axiom(int a, int b) {
        diseqs[a].push_back({b, LIT_UNDEF});
        diseqs[b].push_back({a, LIT_UNDEF});
    }

    int register_eq_atom(int a, int b, Var v) {
        int id = (int)eqatoms.size();
        eqatoms.push_back({a, b, v});
        node_atoms[a].push_back(id);
        if (b != a) node_atoms[b].push_back(id);
        var_info[v] = {0, id};
        // if already equal, propagate
        if (rep[a] == rep[b] && S.value(v) == L_UNDEF) {
            prop_pair[v] = {a, b};
            S.theory_enqueue(Lit(v, false), tid);
        }
        return id;
    }
    void register_bool_node(int n, Var v) {
        bool_var[n] = v;
        var_info[v] = {1, n};
    }

    // ---------------- proof forest ----------------
    int reroot(int a) {
        int prev = -1;
        Lit prevlit = LIT_UNDEF;
        int cur = a;
        while (cur != -1) {
            int nx = pf_parent[cur];
            Lit nl = pf_lit[cur];
            pf_parent[cur] = prev;
            pf_lit[cur] = prevlit;
            prev = cur;
            prevlit = nl;
            cur = nx;
        }
        return prev;
    }

    std::vector<std::pair<int, int>> expl_queue;
    std::vector<int8_t> lit_seen;

    void explain_eq(int x, int y, std::vector<Lit>& out) {
        cur_edge_stamp++;
        expl_queue.clear();
        expl_queue.push_back({x, y});
        if ((int)lit_seen.size() < S.num_vars()) lit_seen.resize(S.num_vars() + 1024, 0);
        size_t start = out.size();
        while (!expl_queue.empty()) {
            auto pr = expl_queue.back();
            expl_queue.pop_back();
            int a = pr.first, b = pr.second;
            if (a == b) continue;
            // LCA
            cur_stamp++;
            for (int n = a; n != -1; n = pf_parent[n]) stamp[n] = cur_stamp;
            int c = b;
            while (stamp[c] != cur_stamp) c = pf_parent[c];
            for (int side = 0; side < 2; side++) {
                int n = side == 0 ? a : b;
                while (n != c) {
                    int p = pf_parent[n];
                    if (edge_stamp[n] != cur_edge_stamp) {
                        edge_stamp[n] = cur_edge_stamp;
                        Lit l = pf_lit[n];
                        if (l != LIT_UNDEF) {
                            if (!lit_seen[l.var()]) { lit_seen[l.var()] = 1; out.push_back(l); }
                        } else {
                            expl_queue.push_back({left[n], left[p]});
                            expl_queue.push_back({right[n], right[p]});
                        }
                    }
                    n = p;
                }
            }
        }
        for (size_t i = start; i < out.size(); i++) lit_seen[out[i].var()] = 0;
    }

    // ---------------- merging ----------------
    bool conflict_from(const std::vector<Lit>& expl, Lit extra) {
        std::vector<Lit> c;
        for (auto l : expl) c.push_back(~l);
        if (extra != LIT_UNDEF) c.push_back(~extra);
        S.set_conflict(c);
        return false;
    }

    bool merge(int a, int b, Lit r) {
        int ra = rep[a], rb = rep[b];
        if (ra == rb) return true;
        if (csize[ra] > csize[rb]) { std::swap(ra, rb); std::swap(a, b); }
        int old_true_rep = rep[TRUE_N], old_false_rep = rep[FALSE_N];
        // proof edge a -> b
        int oldroot = reroot(a);
        pf_parent[a] = b;
        pf_lit[a] = r;
        trail.push_back({T_PROOF, a, oldroot, 0, 0});
        // diseq check over members of ra
        int m = ra;
        do {
            for (auto& d : diseqs[m]) {
                if (rep[d.other] == rb) {
                    std::vector<Lit> e;
                    explain_eq(m, d.other, e);
                    return conflict_from(e, d.r);
                }
            }
            m = nxt[m];
        } while (m != ra);
        // erase signatures of uses of ra members
        m = ra;
        do {
            for (int p : uses[m]) {
                uint64_t k = pkey(rep[left[p]], rep[right[p]]);
                auto it = sigtab.find(k);
                if (it != sigtab.end() && it->second == p) {
                    sigtab.erase(it);
                    trail.push_back({T_SIG_ERASE, p, 0, 0, k});
                }
            }
            m = nxt[m];
        } while (m != ra);
        // relabel
        m = ra;
        do { rep[m] = rb; m = nxt[m]; } while (m != ra);
        csize[rb] += csize[ra];
        trail.push_back({T_MERGE, ra, rb, 0, 0});
        // reinsert signatures / detect congruences; atoms (old ra ring, before splicing)
        int tr = rep[TRUE_N], fr = rep[FALSE_N];
        m = ra;
        do {
            for (int p : uses[m]) {
                uint64_t k = pkey(rep[left[p]], rep[right[p]]);
                auto it = sigtab.find(k);
                if (it == sigtab.end()) {
                    sigtab[k] = p;
                    trail.push_back({T_SIG_INSERT, p, 0, 0, k});
                } else if (it->second != p && rep[it->second] != rep[p]) {
                    pending.push_back({p, it->second, LIT_UNDEF});
                }
            }
            for (int aid : node_atoms[m]) {
                EqAtom& at = eqatoms[aid];
                if (rep[at.a] == rep[at.b] && S.value(at.v) == L_UNDEF) {
                    prop_pair[at.v] = {at.a, at.b};
                    S.theory_enqueue(Lit(at.v, false), tid);
                }
            }
            m = nxt[m];
        } while (m != ra);
        // bool propagation: ring that joined TRUE/FALSE class
        int other_ring = -1, base = -1;
        bool pos = false;
        if (rb == tr && old_true_rep != ra) { other_ring = ra; base = TRUE_N; pos = true; }
        else if (rb == fr && old_false_rep != ra) { other_ring = ra; base = FALSE_N; pos = false; }
        else if (old_true_rep == ra) { other_ring = rb; base = TRUE_N; pos = true; }
        else if (old_false_rep == ra) { other_ring = rb; base = FALSE_N; pos = false; }
        if (other_ring >= 0) {
            m = other_ring;
            do {
                Var v = bool_var[m];
                if (v >= 0 && S.value(v) == L_UNDEF) {
                    prop_pair[v] = {m, base};
                    S.theory_enqueue(Lit(v, !pos), tid);
                }
                m = nxt[m];
            } while (m != other_ring);
        }
        std::swap(nxt[ra], nxt[rb]);
        return true;
    }

    bool process_pending() {
        while (!pending.empty()) {
            Pending p = pending.front();
            pending.pop_front();
            if (!merge(p.a, p.b, p.r)) { pending.clear(); return false; }
        }
        return true;
    }

    bool assert_diseq(int a, int b, Lit r) {
        if (rep[a] == rep[b]) {
            std::vector<Lit> e;
            explain_eq(a, b, e);
            return conflict_from(e, r);
        }
        diseqs[a].push_back({b, r});
        diseqs[b].push_back({a, r});
        trail.push_back({T_DISEQ, a, b, 0, 0});
        return true;
    }

    // ---------------- Theory interface ----------------
    void new_level() override {
        trail_lim.push_back((int)trail.size());
        head_lim.push_back(head);
    }
    void undo(const TEntry& t) {
        switch (t.kind) {
        case T_PROOF:
            pf_parent[t.a] = -1;
            pf_lit[t.a] = LIT_UNDEF;
            reroot(t.b);
            break;
        case T_MERGE: {
            int ra = t.a, rb = t.b;
            std::swap(nxt[ra], nxt[rb]);
            csize[rb] -= csize[ra];
            int m = ra;
            do { rep[m] = ra; m = nxt[m]; } while (m != ra);
            break;
        }
        case T_SIG_ERASE: sigtab[t.key] = t.a; break;
        case T_SIG_INSERT: sigtab.erase(t.key); break;
        case T_DISEQ:
            diseqs[t.a].pop_back();
            diseqs[t.b].pop_back();
            break;
        }
    }
    void backtrack(int level) override {
        if ((int)trail_lim.size() <= level) return;
        int lim = trail_lim[level];
        for (int i = (int)trail.size() - 1; i >= lim; i--) undo(trail[i]);
        trail.resize(lim);
        trail_lim.resize(level);
        head = std::min(head, (int)S.trail.size());
        head_lim.resize(level);
        pending.clear();
    }

    bool propagate() override {
        if (!pending.empty() && !process_pending()) return false;
        while (head < (int)S.trail.size()) {
            Lit l = S.trail[head++];
            Var v = l.var();
            if (S.theory_of[v] != tid) continue;
            auto it = var_info.find(v);
            if (it == var_info.end()) continue;
            bool pos = !l.sign();
            if (it->second.first == 0) {
                EqAtom& at = eqatoms[it->second.second];
                if (pos) {
                    pending.push_back({at.a, at.b, l});
                    if (!process_pending()) return false;
                } else {
                    if (!assert_diseq(at.a, at.b, l)) return false;
                }
            } else {
                int n = it->second.second;
                pending.push_back({n, pos ? TRUE_N : FALSE_N, l});
                if (!process_pending()) return false;
            }
        }
        return true;
    }

    bool final_check() override { return true; }

    void explain(Lit l, std::vector<Lit>& out) override {
        auto it = prop_pair.find(l.var());
        explain_eq(it->second.first, it->second.second, out);
    }
};
