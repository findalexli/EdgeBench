// CDCL SAT solver with a DPLL(T) theory interface.
#pragma once
#include <vector>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <functional>

typedef int Var;
struct Lit {
    int x;
    Lit() : x(-2) {}
    explicit Lit(int raw) : x(raw) {}
    Lit(Var v, bool neg) : x(2 * v + (int)neg) {}
    Var var() const { return x >> 1; }
    bool sign() const { return x & 1; }  // true = negative
    Lit operator~() const { return Lit(x ^ 1); }
    bool operator==(const Lit& o) const { return x == o.x; }
    bool operator!=(const Lit& o) const { return x != o.x; }
    bool operator<(const Lit& o) const { return x < o.x; }
};
static const Lit LIT_UNDEF = Lit(-2);

enum LBool : int8_t { L_FALSE = 0, L_TRUE = 1, L_UNDEF = 2 };

struct Clause {
    uint32_t sz;
    uint32_t lbd : 30;
    uint32_t learnt : 1;
    uint32_t removed : 1;
    float act;
    Lit lits[1];
    Lit& operator[](int i) { return lits[i]; }
    int size() const { return sz; }
};

class Solver;

class Theory {
public:
    virtual ~Theory() {}
    virtual void new_level() = 0;
    virtual void backtrack(int level) = 0;
    // process new trail literals; return false on conflict (via S.set_conflict)
    virtual bool propagate() = 0;
    // called when all vars assigned. return true if model is fine (sat); false if it
    // produced a conflict, lemmas, new atoms or propagations.
    virtual bool final_check() = 0;
    // literals (currently true) that imply l
    virtual void explain(Lit l, std::vector<Lit>& out) = 0;
};

struct Watcher {
    Clause* c;
    Lit blocker;
};

class Solver {
public:
    // assignment
    std::vector<LBool> assigns;
    std::vector<int> level;
    std::vector<Clause*> reason;  // nullptr: decision/unit; THEORY_REASON for theory
    std::vector<int8_t> polarity;  // saved phase (1 = negative)
    std::vector<double> activity;
    std::vector<int8_t> seen;
    std::vector<int> theory_of;  // -1 none
    std::vector<int8_t> decision_var;
    std::vector<Lit> trail;
    std::vector<int> trail_lim;
    int qhead = 0;
    std::vector<std::vector<Watcher>> watches;
    std::vector<Clause*> clauses, learnts;
    std::vector<Theory*> theories;
    std::vector<int> theory_head;  // unused (theories track themselves)
    Clause* const THEORY_REASON = (Clause*)1;
    std::vector<std::vector<Lit>> theory_expl;  // cached explanations for theory-propagated vars
    std::vector<int8_t> expl_valid;
    std::vector<int8_t> prop_theory;

    // heap for VSIDS
    std::vector<int> heap, heap_idx;
    double var_inc = 1.0, var_decay = 0.95;
    double cla_inc = 1.0, cla_decay = 0.999;

    bool ok = true;
    std::vector<Lit> tconflict;  // theory conflict clause (all false)
    bool has_tconflict = false;
    std::vector<std::vector<Lit>> pending_lemmas;

    uint64_t conflicts = 0, decisions = 0, propagations = 0;
    int verbosity = 0;
    std::function<bool()> should_stop;

    int num_vars() const { return (int)assigns.size(); }
    int decision_level() const { return (int)trail_lim.size(); }
    LBool value(Var v) const { return assigns[v]; }
    LBool value(Lit l) const {
        LBool a = assigns[l.var()];
        if (a == L_UNDEF) return L_UNDEF;
        return (LBool)((int)a ^ (int)l.sign());
    }

    Var new_var(int theory = -1, bool dec = true) {
        Var v = num_vars();
        assigns.push_back(L_UNDEF);
        level.push_back(0);
        reason.push_back(nullptr);
        polarity.push_back(1);
        activity.push_back(0);
        seen.push_back(0);
        theory_of.push_back(theory);
        decision_var.push_back(dec);
        watches.emplace_back();
        watches.emplace_back();
        theory_expl.emplace_back();
        expl_valid.push_back(0);
        prop_theory.push_back(0);
        heap_idx.push_back(-1);
        if (dec) heap_insert(v);
        return v;
    }

    // ---------------- heap ----------------
    bool heap_lt(int a, int b) const { return activity[a] > activity[b]; }
    void heap_up(int i) {
        int v = heap[i];
        while (i > 0) {
            int p = (i - 1) >> 1;
            if (!heap_lt(v, heap[p])) break;
            heap[i] = heap[p];
            heap_idx[heap[i]] = i;
            i = p;
        }
        heap[i] = v;
        heap_idx[v] = i;
    }
    void heap_down(int i) {
        int v = heap[i];
        int n = (int)heap.size();
        while (true) {
            int c = 2 * i + 1;
            if (c >= n) break;
            if (c + 1 < n && heap_lt(heap[c + 1], heap[c])) c++;
            if (!heap_lt(heap[c], v)) break;
            heap[i] = heap[c];
            heap_idx[heap[i]] = i;
            i = c;
        }
        heap[i] = v;
        heap_idx[v] = i;
    }
    void heap_insert(int v) {
        if (heap_idx[v] >= 0) return;
        heap_idx[v] = (int)heap.size();
        heap.push_back(v);
        heap_up(heap_idx[v]);
    }
    int heap_pop() {
        int v = heap[0];
        heap_idx[v] = -1;
        int last = heap.back();
        heap.pop_back();
        if (!heap.empty()) {
            heap[0] = last;
            heap_idx[last] = 0;
            heap_down(0);
        }
        return v;
    }
    void var_bump(Var v, double mult = 1.0) {
        activity[v] += var_inc * mult;
        if (activity[v] > 1e100) {
            for (auto& a : activity) a *= 1e-100;
            var_inc *= 1e-100;
        }
        if (heap_idx[v] >= 0) heap_up(heap_idx[v]);
    }
    void var_decay_all() { var_inc /= var_decay; }
    void cla_bump(Clause* c) {
        c->act += (float)cla_inc;
        if (c->act > 1e20) {
            for (auto* l : learnts) l->act *= 1e-20f;
            cla_inc *= 1e-20;
        }
    }

    // ---------------- clauses ----------------
    Clause* alloc_clause(const std::vector<Lit>& lits, bool learnt) {
        size_t bytes = sizeof(Clause) + sizeof(Lit) * (lits.size() > 0 ? lits.size() - 1 : 0);
        Clause* c = (Clause*)malloc(bytes);
        c->sz = (uint32_t)lits.size();
        c->learnt = learnt;
        c->removed = 0;
        c->lbd = 0;
        c->act = 0;
        for (size_t i = 0; i < lits.size(); i++) c->lits[i] = lits[i];
        return c;
    }
    void attach(Clause* c) {
        watches[(~(*c)[0]).x].push_back({c, (*c)[1]});
        watches[(~(*c)[1]).x].push_back({c, (*c)[0]});
    }

    // add clause at level 0 (before search)
    bool add_clause(std::vector<Lit> lits) {
        if (!ok) return false;
        if (decision_level() > 0) { add_clause_dynamic(lits, false); return ok; }
        std::sort(lits.begin(), lits.end());
        std::vector<Lit> out;
        Lit prev = LIT_UNDEF;
        for (Lit l : lits) {
            if (value(l) == L_TRUE || l == ~prev) return true;
            if (value(l) != L_FALSE && l != prev) { out.push_back(l); prev = l; }
        }
        if (out.empty()) { ok = false; return false; }
        if (out.size() == 1) {
            enqueue(out[0], nullptr);
            return true;
        }
        Clause* c = alloc_clause(out, false);
        clauses.push_back(c);
        attach(c);
        return true;
    }

    // add a clause during search (lemma). Handles any assignment state.
    void add_clause_dynamic(std::vector<Lit> lits, bool learnt) {
        // remove duplicates, check tautology
        std::sort(lits.begin(), lits.end());
        std::vector<Lit> out;
        for (size_t i = 0; i < lits.size(); i++) {
            if (i > 0 && lits[i] == lits[i - 1]) continue;
            if (i > 0 && lits[i] == ~lits[i - 1]) return;
            if (value(lits[i]) == L_FALSE && level[lits[i].var()] == 0) continue;
            if (value(lits[i]) == L_TRUE && level[lits[i].var()] == 0) return;
            out.push_back(lits[i]);
        }
        if (out.empty()) { ok = false; return; }
        // order: true first, then undef, then false by decreasing level
        auto rank = [&](Lit l) -> long {
            LBool v = value(l);
            if (v == L_TRUE) return 3000000000L - level[l.var()];
            if (v == L_UNDEF) return 2000000000L;
            return level[l.var()];
        };
        std::sort(out.begin(), out.end(), [&](Lit a, Lit b) { return rank(a) > rank(b); });
        if (out.size() == 1) {
            if (value(out[0]) == L_FALSE || decision_level() > 0) backtrack(0);
            if (value(out[0]) == L_UNDEF) enqueue(out[0], nullptr);
            return;
        }
        Clause* c = alloc_clause(out, learnt);
        if (learnt) { learnts.push_back(c); c->lbd = (uint32_t)out.size(); }
        else clauses.push_back(c);
        attach(c);
        LBool v0 = value(out[0]), v1 = value(out[1]);
        if (v0 == L_FALSE) {
            // conflict
            int lvl = level[out[0].var()];
            backtrack_to_conflict(lvl);
            tconflict = out;
            has_tconflict = true;
        } else if (v1 == L_FALSE && v0 == L_UNDEF) {
            int lvl = level[out[1].var()];
            if (lvl < decision_level()) backtrack(lvl);
            enqueue(out[0], c);
        } else if (v1 == L_FALSE && v0 == L_TRUE && level[out[0].var()] > level[out[1].var()]) {
            // implied literal placed too late; fine (correct but weaker)
        }
    }
    void backtrack_to_conflict(int lvl) {
        if (lvl < decision_level()) backtrack(lvl);
    }

    // ---------------- assignment ----------------
    void enqueue(Lit l, Clause* r) {
        Var v = l.var();
        assigns[v] = (LBool)!l.sign();
        level[v] = decision_level();
        reason[v] = r;
        expl_valid[v] = 0;
        trail.push_back(l);
    }
    // theory propagation; returns false if l is already false (caller must produce conflict)
    bool theory_enqueue(Lit l, int tid) {
        LBool v = value(l);
        if (v == L_TRUE) return true;
        if (v == L_FALSE) return false;
        enqueue(l, THEORY_REASON);
        prop_theory[l.var()] = (int8_t)tid;
        propagations++;
        return true;
    }
    void set_conflict(const std::vector<Lit>& clause) {
        tconflict = clause;
        has_tconflict = true;
    }

    void new_decision_level() {
        trail_lim.push_back((int)trail.size());
        for (auto* t : theories) t->new_level();
    }

    void backtrack(int lvl) {
        if (decision_level() <= lvl) return;
        for (int i = (int)trail.size() - 1; i >= trail_lim[lvl]; i--) {
            Var v = trail[i].var();
            assigns[v] = L_UNDEF;
            reason[v] = nullptr;
            polarity[v] = trail[i].sign();
            if (decision_var[v]) heap_insert(v);
        }
        trail.resize(trail_lim[lvl]);
        trail_lim.resize(lvl);
        qhead = std::min(qhead, (int)trail.size());
        for (auto* t : theories) t->backtrack(lvl);
    }

    // BCP. returns conflicting clause or nullptr
    Clause* propagate() {
        Clause* confl = nullptr;
        while (qhead < (int)trail.size()) {
            Lit p = trail[qhead++];
            std::vector<Watcher>& ws = watches[p.x];
            Watcher* i = ws.data();
            Watcher* j = i;
            Watcher* end = i + ws.size();
            propagations++;
            Lit false_lit = ~p;
            while (i != end) {
                if (value(i->blocker) == L_TRUE) { *j++ = *i++; continue; }
                Clause* c = i->c;
                if ((*c)[0] == false_lit) { (*c)[0] = (*c)[1]; (*c)[1] = false_lit; }
                i++;
                Lit first = (*c)[0];
                Watcher w = {c, first};
                if (first != i[-1].blocker && value(first) == L_TRUE) { *j++ = w; continue; }
                bool found = false;
                for (int k = 2; k < c->size(); k++) {
                    if (value((*c)[k]) != L_FALSE) {
                        (*c)[1] = (*c)[k];
                        (*c)[k] = false_lit;
                        watches[(~(*c)[1]).x].push_back(w);
                        found = true;
                        break;
                    }
                }
                if (found) continue;
                *j++ = w;
                if (value(first) == L_FALSE) {
                    confl = c;
                    qhead = (int)trail.size();
                    while (i != end) *j++ = *i++;
                } else {
                    enqueue(first, c);
                }
            }
            ws.resize(j - ws.data());
            if (confl) break;
        }
        return confl;
    }

    // reason literals for var v (excluding v itself): fills out with literal list of the clause
    const std::vector<Lit>& theory_reason(Var v) {
        if (!expl_valid[v]) {
            std::vector<Lit>& e = theory_expl[v];
            e.clear();
            Lit l = Lit(v, assigns[v] == L_FALSE);
            theories[prop_theory[v]]->explain(l, e);
            // convert to clause form: l ∨ ¬e...
            for (auto& x : e) x = ~x;
            e.insert(e.begin(), l);
            expl_valid[v] = 1;
        }
        return theory_expl[v];
    }

    std::vector<Lit> analyze_stack, analyze_toclear;
    std::vector<Lit> tmp_lits;

    // conflict clause given as list of false literals
    void analyze(const Lit* clits, int csize, Clause* cref, std::vector<Lit>& out_learnt, int& out_bt) {
        int pathC = 0;
        Lit p = LIT_UNDEF;
        out_learnt.clear();
        out_learnt.push_back(LIT_UNDEF);
        int index = (int)trail.size() - 1;
        std::vector<Lit> buf;
        const Lit* lits = clits;
        int sz = csize;
        if (cref && cref->learnt) cla_bump(cref);
        while (true) {
            for (int j = (p == LIT_UNDEF ? 0 : 1); j < sz; j++) {
                Lit q = lits[j];
                Var v = q.var();
                if (!seen[v] && level[v] > 0) {
                    var_bump(v);
                    seen[v] = 1;
                    if (level[v] >= decision_level()) pathC++;
                    else out_learnt.push_back(q);
                }
            }
            while (!seen[trail[index--].var()]) {}
            p = trail[index + 1];
            seen[p.var()] = 0;
            pathC--;
            if (pathC <= 0) break;
            Var pv = p.var();
            Clause* r = reason[pv];
            if (r == THEORY_REASON) {
                buf = theory_reason(pv);
                lits = buf.data();
                sz = (int)buf.size();
            } else {
                // make sure p is first
                if ((*r)[0] != p) {
                    for (int k = 1; k < r->size(); k++)
                        if ((*r)[k] == p) { std::swap((*r)[0], (*r)[k]); break; }
                }
                if (r->learnt) cla_bump(r);
                lits = r->lits;
                sz = r->size();
            }
        }
        out_learnt[0] = ~p;
        // minimization (recursive)
        analyze_toclear = out_learnt;
        uint32_t abstract_level = 0;
        for (size_t i = 1; i < out_learnt.size(); i++) abstract_level |= 1u << (level[out_learnt[i].var()] & 31);
        size_t i, j;
        for (i = j = 1; i < out_learnt.size(); i++) {
            Var v = out_learnt[i].var();
            if (reason[v] == nullptr || !lit_redundant(out_learnt[i], abstract_level)) out_learnt[j++] = out_learnt[i];
        }
        out_learnt.resize(j);
        // find backtrack level
        if (out_learnt.size() == 1) out_bt = 0;
        else {
            int maxi = 1;
            for (size_t k = 2; k < out_learnt.size(); k++)
                if (level[out_learnt[k].var()] > level[out_learnt[maxi].var()]) maxi = (int)k;
            std::swap(out_learnt[1], out_learnt[maxi]);
            out_bt = level[out_learnt[1].var()];
        }
        for (auto l : analyze_toclear) seen[l.var()] = 0;
    }

    bool lit_redundant(Lit p, uint32_t abstract_levels) {
        analyze_stack.clear();
        analyze_stack.push_back(p);
        size_t top = analyze_toclear.size();
        while (!analyze_stack.empty()) {
            Lit q = analyze_stack.back();
            analyze_stack.pop_back();
            Var qv = q.var();
            Clause* r = reason[qv];
            const Lit* lits;
            int sz;
            std::vector<Lit> buf;
            if (r == THEORY_REASON) {
                buf = theory_reason(qv);
                lits = buf.data();
                sz = (int)buf.size();
            } else {
                if ((*r)[0].var() != qv) {
                    for (int k = 1; k < r->size(); k++)
                        if ((*r)[k].var() == qv) { std::swap((*r)[0], (*r)[k]); break; }
                }
                lits = r->lits;
                sz = r->size();
            }
            for (int i = 1; i < sz; i++) {
                Lit l = lits[i];
                Var v = l.var();
                if (!seen[v] && level[v] > 0) {
                    if (reason[v] != nullptr && (abstract_levels & (1u << (level[v] & 31)))) {
                        seen[v] = 1;
                        analyze_stack.push_back(l);
                        analyze_toclear.push_back(l);
                    } else {
                        for (size_t k = top; k < analyze_toclear.size(); k++) seen[analyze_toclear[k].var()] = 0;
                        analyze_toclear.resize(top);
                        return false;
                    }
                }
            }
        }
        return true;
    }

    uint32_t compute_lbd(const std::vector<Lit>& lits) {
        static std::vector<int> mark;
        static int stamp = 0;
        stamp++;
        if ((int)mark.size() <= decision_level() + 1) mark.resize(decision_level() + 2, 0);
        uint32_t n = 0;
        for (auto l : lits) {
            int lv = level[l.var()];
            if (lv < (int)mark.size() && mark[lv] != stamp) { mark[lv] = stamp; n++; }
        }
        return n;
    }

    Lit pick_branch() {
        while (!heap.empty()) {
            int v = heap[0];
            if (assigns[v] != L_UNDEF || !decision_var[v]) { heap_pop(); continue; }
            heap_pop();
            decisions++;
            return Lit(v, polarity[v]);
        }
        return LIT_UNDEF;
    }


    static double luby(double y, int x) {
        int size, seq;
        for (size = 1, seq = 0; size < x + 1; seq++, size = 2 * size + 1) {}
        while (size - 1 != x) {
            size = (size - 1) >> 1;
            seq--;
            x = x % size;
        }
        return std::pow(y, seq);
    }

    // run theory propagation; returns false on conflict
    bool theory_propagate() {
        for (auto* t : theories) {
            if (!t->propagate()) return false;
            if (has_tconflict) return false;
        }
        return true;
    }

    // handle a conflict clause given by lits (all false). returns false if UNSAT
    bool handle_conflict(std::vector<Lit> confl, Clause* cref) {
        conflicts++;
        // the conflict might be at lower level than current
        int maxlvl = 0;
        for (auto l : confl) maxlvl = std::max(maxlvl, level[l.var()]);
        if (maxlvl == 0) return false;
        if (maxlvl < decision_level()) backtrack(maxlvl);
        std::vector<Lit> learnt;
        int bt;
        analyze(confl.data(), (int)confl.size(), cref, learnt, bt);
        backtrack(bt);
        if (learnt.size() == 1) {
            enqueue(learnt[0], nullptr);
        } else {
            Clause* c = alloc_clause(learnt, true);
            c->lbd = compute_lbd(learnt);
            learnts.push_back(c);
            attach(c);
            cla_bump(c);
            enqueue(learnt[0], c);
        }
        var_decay_all();
        cla_inc /= cla_decay;
        return true;
    }

    // main search: returns L_TRUE (sat), L_FALSE (unsat), L_UNDEF (stopped)
    LBool solve() {
        if (!ok) return L_FALSE;
        int restart_count = 0;
        uint64_t next_reduce = 4000;
        uint64_t reduce_inc = 600;
        while (true) {
            double rest_base = luby(2, restart_count++) * 100;
            uint64_t conflicts_at_start = conflicts;
            while (true) {
                if (!ok) return L_FALSE;
                Clause* confl = propagate();
                if (!confl && !has_tconflict) {
                    size_t before = trail.size();
                    theory_propagate();
                    if (!has_tconflict && trail.size() != before) continue;
                }
                if (confl || has_tconflict) {
                    std::vector<Lit> cl;
                    if (has_tconflict) {
                        cl = tconflict;
                        has_tconflict = false;
                        tconflict.clear();
                        confl = nullptr;
                    } else {
                        cl.assign(confl->lits, confl->lits + confl->size());
                    }
                    if (decision_level() == 0) {
                        bool all0 = true;
                        for (auto l : cl) if (level[l.var()] > 0) all0 = false;
                        if (all0) { ok = false; return L_FALSE; }
                    }
                    if (!handle_conflict(cl, confl)) { ok = false; return L_FALSE; }
                    if ((conflicts & 255) == 0 && should_stop && should_stop()) return L_UNDEF;
                    continue;
                }
                if (!pending_lemmas.empty()) {
                    std::vector<std::vector<Lit>> lem;
                    lem.swap(pending_lemmas);
                    for (auto& l : lem) {
                        add_clause_dynamic(l, false);
                        if (!ok) return L_FALSE;
                        if (has_tconflict) break;
                    }
                    continue;
                }
                if (conflicts - conflicts_at_start >= (uint64_t)rest_base) {
                    backtrack(0);
                    break;
                }
                if (conflicts >= next_reduce) {
                    next_reduce = conflicts + 4000 + reduce_inc * (uint64_t)(conflicts / 4000);
                    reduce_db_safe();
                }
                Lit next = pick_branch();
                if (next == LIT_UNDEF) {
                    // full assignment: final check
                    bool fine = true;
                    for (auto* t : theories) {
                        if (!t->final_check()) { fine = false; break; }
                    }
                    if (fine && pending_lemmas.empty() && !has_tconflict) {
                        // double check everything assigned (new vars may have been added)
                        bool all = true;
                        for (int v = 0; v < num_vars(); v++)
                            if (assigns[v] == L_UNDEF && decision_var[v]) { all = false; heap_insert(v); }
                        if (all && qhead == (int)trail.size()) return L_TRUE;
                    }
                    if (should_stop && should_stop()) return L_UNDEF;
                    continue;
                }
                new_decision_level();
                enqueue(next, nullptr);
            }
        }
    }

    void reduce_db_safe() {
        std::sort(learnts.begin(), learnts.end(), [](Clause* a, Clause* b) {
            if (a->lbd != b->lbd) return a->lbd > b->lbd;
            return a->act < b->act;
        });
        size_t lim = learnts.size() / 2;
        std::vector<Clause*> keep, rem;
        for (size_t i = 0; i < learnts.size(); i++) {
            Clause* c = learnts[i];
            bool locked = (reason[(*c)[0].var()] == c && value((*c)[0]) == L_TRUE);
            if (i < lim && c->lbd > 2 && !locked && c->size() > 2) { c->removed = 1; rem.push_back(c); }
            else keep.push_back(c);
        }
        learnts.swap(keep);
        for (auto& ws : watches) {
            size_t j = 0;
            for (size_t i = 0; i < ws.size(); i++)
                if (!ws[i].c->removed) ws[j++] = ws[i];
            ws.resize(j);
        }
        for (auto* c : rem) free(c);
    }

    Lit make_lit(Var v, bool neg = false) { return Lit(v, neg); }
};
