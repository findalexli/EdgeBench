// Linear real/integer arithmetic theory: general simplex with bounds (Dutertre & de Moura).
#pragma once
#include "rational.h"
#include "sat.h"
#include <map>
#include <set>
#include <unordered_map>
#include <string>

struct LinForm {
    std::vector<std::pair<int, Rational>> terms;  // sorted by var, nonzero coefs
};

struct LraAtom {
    int var;       // lra var
    bool is_le;    // true: var <= k ; false: var >= k
    Rational k;
    Var bvar;      // sat var
};

class LRA : public Theory {
public:
    Solver& S;
    int tid;
    bool all_int = false;  // LIA mode

    struct RowEntry { int var; Rational coef; int cpos; };
    struct ColEntry { int row; int pos; };
    struct Row { int basic; std::vector<RowEntry> e; };

    std::vector<DeltaRat> val;
    std::vector<int8_t> has_lo, has_hi;
    std::vector<DeltaRat> lo, hi;
    std::vector<Lit> lo_r, hi_r;
    std::vector<int> row_of;       // -1 if nonbasic
    std::vector<int8_t> is_int;
    std::vector<std::vector<ColEntry>> col;
    std::vector<std::vector<int>> var_atoms;  // atom ids on var
    std::vector<Row> rows;

    std::vector<LraAtom> atoms;
    std::unordered_map<Var, int> atom_of_bvar;
    std::map<std::pair<std::vector<std::pair<int, std::string>>, int>, int> dummy;
    std::map<std::string, int> form_to_var;  // canonical form string -> slack var
    std::map<std::tuple<int, bool, std::string>, int> atom_index;
    std::vector<Lit> prop_reason;  // indexed by sat var (resized on demand)

    // backtracking
    struct BTrail { int var; bool upper; int8_t had; DeltaRat old; Lit oldr; };
    std::vector<BTrail> btrail;
    std::vector<int> btrail_lim;
    std::vector<int> head_lim;
    int head = 0;  // position in S.trail

    std::set<int> infeasible;
    std::vector<int> scratch_pos;
    uint64_t pivots = 0;
    std::vector<int> int_vars_list;

    LRA(Solver& s, int id) : S(s), tid(id) {}

    int num_vars() const { return (int)val.size(); }

    int new_var(bool isint) {
        int v = num_vars();
        val.emplace_back();
        has_lo.push_back(0);
        has_hi.push_back(0);
        lo.emplace_back();
        hi.emplace_back();
        lo_r.push_back(LIT_UNDEF);
        hi_r.push_back(LIT_UNDEF);
        row_of.push_back(-1);
        is_int.push_back(isint);
        col.emplace_back();
        var_atoms.emplace_back();
        scratch_pos.push_back(-1);
        if (isint) int_vars_list.push_back(v);
        return v;
    }

    // ------------- sparse matrix helpers -------------
    void row_add_entry(int r, int var, const Rational& c) {
        Row& R = rows[r];
        int pos = (int)R.e.size();
        R.e.push_back({var, c, (int)col[var].size()});
        col[var].push_back({r, pos});
    }
    void row_remove_entry(int r, int pos) {
        Row& R = rows[r];
        RowEntry& en = R.e[pos];
        // remove from column
        int var = en.var, cp = en.cpos;
        std::vector<ColEntry>& C = col[var];
        if (cp != (int)C.size() - 1) {
            C[cp] = C.back();
            rows[C[cp].row].e[C[cp].pos].cpos = cp;
        }
        C.pop_back();
        // remove from row
        if (pos != (int)R.e.size() - 1) {
            R.e[pos] = std::move(R.e.back());
            col[R.e[pos].var][R.e[pos].cpos].pos = pos;
        }
        R.e.pop_back();
    }

    std::string form_key(const std::vector<std::pair<int, Rational>>& f) {
        std::string s;
        for (auto& p : f) {
            s += std::to_string(p.first);
            s += ':';
            s += p.second.to_string();
            s += ' ';
        }
        return s;
    }

    // get var representing linear form (normalized by caller). single var with coef 1 -> var itself
    int var_for_form(const std::vector<std::pair<int, Rational>>& f) {
        if (f.size() == 1 && f[0].second.is_one()) return f[0].first;
        std::string key = form_key(f);
        auto it = form_to_var.find(key);
        if (it != form_to_var.end()) return it->second;
        bool isint = true;
        for (auto& p : f) if (!is_int[p.first] || !p.second.is_int()) isint = false;
        int s = new_var(isint && all_int);
        form_to_var[key] = s;
        // build row: s = sum f, substituting basic vars
        int r = (int)rows.size();
        rows.push_back(Row{s, {}});
        row_of[s] = r;
        // accumulate in a dense map
        std::vector<std::pair<int, Rational>> acc;
        std::unordered_map<int, size_t> idx;
        auto add = [&](int v, const Rational& c) {
            auto jt = idx.find(v);
            if (jt == idx.end()) { idx[v] = acc.size(); acc.push_back({v, c}); }
            else acc[jt->second].second += c;
        };
        for (auto& p : f) {
            int v = p.first;
            if (row_of[v] >= 0) {
                for (auto& en : rows[row_of[v]].e) add(en.var, p.second * en.coef);
            } else add(v, p.second);
        }
        DeltaRat sv;
        for (auto& p : acc) {
            if (p.second.is_zero()) continue;
            row_add_entry(r, p.first, p.second);
            sv.addmul(val[p.first], p.second);
        }
        val[s] = sv;
        return s;
    }

    int add_atom(int var, bool is_le, const Rational& k, Var bvar) {
        int id = (int)atoms.size();
        atoms.push_back({var, is_le, k, bvar});
        atom_of_bvar[bvar] = id;
        var_atoms[var].push_back(id);
        return id;
    }
    // get or create atom; returns sat var
    Var get_atom(int var, bool is_le, const Rational& k) {
        auto key = std::make_tuple(var, is_le, k.to_string());
        auto it = atom_index.find(key);
        if (it != atom_index.end()) return atoms[it->second].bvar;
        Var b = S.new_var(tid);
        int id = add_atom(var, is_le, k, b);
        atom_index[key] = id;
        return b;
    }

    // ------------- bounds -------------
    void set_lo(int v, const DeltaRat& b, Lit r) {
        btrail.push_back({v, false, has_lo[v], lo[v], lo_r[v]});
        has_lo[v] = 1;
        lo[v] = b;
        lo_r[v] = r;
    }
    void set_hi(int v, const DeltaRat& b, Lit r) {
        btrail.push_back({v, true, has_hi[v], hi[v], hi_r[v]});
        has_hi[v] = 1;
        hi[v] = b;
        hi_r[v] = r;
    }

    void update_nonbasic(int x, const DeltaRat& v) {
        DeltaRat d = v - val[x];
        for (auto& ce : col[x]) {
            Row& R = rows[ce.row];
            val[R.basic].addmul(d, R.e[ce.pos].coef);
            infeasible.insert(R.basic);
        }
        val[x] = v;
    }

    bool assert_upper(int x, const DeltaRat& b, Lit r) {
        if (has_hi[x] && hi[x] <= b) return true;
        if (has_lo[x] && b < lo[x]) {
            std::vector<Lit> c = {~r, ~lo_r[x]};
            S.set_conflict(c);
            return false;
        }
        set_hi(x, b, r);
        if (row_of[x] < 0) {
            if (val[x] > b) update_nonbasic(x, b);
        } else infeasible.insert(x);
        return propagate_bounds_on(x, true);
    }
    bool assert_lower(int x, const DeltaRat& b, Lit r) {
        if (has_lo[x] && lo[x] >= b) return true;
        if (has_hi[x] && b > hi[x]) {
            std::vector<Lit> c = {~r, ~hi_r[x]};
            S.set_conflict(c);
            return false;
        }
        set_lo(x, b, r);
        if (row_of[x] < 0) {
            if (val[x] < b) update_nonbasic(x, b);
        } else infeasible.insert(x);
        return propagate_bounds_on(x, false);
    }

    void ensure_prop_reason() {
        if ((int)prop_reason.size() < S.num_vars()) prop_reason.resize(S.num_vars() + 1024, LIT_UNDEF);
    }

    // propagate atoms on var x implied by its current bound
    bool propagate_bounds_on(int x, bool upper) {
        ensure_prop_reason();
        for (int aid : var_atoms[x]) {
            LraAtom& a = atoms[aid];
            if (S.value(a.bvar) != L_UNDEF) continue;
            Lit implied = LIT_UNDEF;
            if (upper) {
                const DeltaRat& u = hi[x];
                // x <= u
                if (a.is_le) {
                    if (u <= DeltaRat(a.k)) implied = Lit(a.bvar, false);
                } else {
                    // x >= k false if u < k
                    if (u < DeltaRat(a.k)) implied = Lit(a.bvar, true);
                    else if (is_int[x] && u.k.is_zero() == false) {}
                }
                if (implied != LIT_UNDEF) prop_reason[a.bvar] = hi_r[x];
            } else {
                const DeltaRat& l = lo[x];
                if (!a.is_le) {
                    if (l >= DeltaRat(a.k)) implied = Lit(a.bvar, false);
                } else {
                    if (l > DeltaRat(a.k)) implied = Lit(a.bvar, true);
                }
                if (implied != LIT_UNDEF) prop_reason[a.bvar] = lo_r[x];
            }
            if (implied != LIT_UNDEF) {
                S.theory_enqueue(implied, tid);
            }
        }
        return true;
    }

    // bound value for atom literal
    void atom_bound(const LraAtom& a, bool positive, bool& upper, DeltaRat& b) {
        bool isint = is_int[a.var];
        if (a.is_le) {
            if (positive) { upper = true; b = DeltaRat(a.k); }
            else {
                upper = false;
                if (isint) b = DeltaRat(a.k.floor() + Rational(1));
                else b = DeltaRat(a.k, Rational(1));
            }
        } else {
            if (positive) { upper = false; b = DeltaRat(a.k); }
            else {
                upper = true;
                if (isint) b = DeltaRat(a.k.ceil() - Rational(1));
                else b = DeltaRat(a.k, Rational(-1));
            }
        }
        if (isint && positive) {
            if (upper) b = DeltaRat(a.k.floor());
            else b = DeltaRat(a.k.ceil());
        }
    }

    // ------------- Theory interface -------------
    void new_level() override {
        btrail_lim.push_back((int)btrail.size());
        head_lim.push_back(head);
    }
    void backtrack(int level) override {
        if ((int)btrail_lim.size() <= level) return;
        int lim = btrail_lim[level];
        for (int i = (int)btrail.size() - 1; i >= lim; i--) {
            BTrail& t = btrail[i];
            if (t.upper) { has_hi[t.var] = t.had; hi[t.var] = t.old; hi_r[t.var] = t.oldr; }
            else { has_lo[t.var] = t.had; lo[t.var] = t.old; lo_r[t.var] = t.oldr; }
        }
        btrail.resize(lim);
        btrail_lim.resize(level);
        head = std::min(head, (int)S.trail.size());
        head_lim.resize(level);
    }

    bool propagate() override {
        while (head < (int)S.trail.size()) {
            Lit l = S.trail[head++];
            Var v = l.var();
            if (S.theory_of[v] != tid) continue;
            auto it = atom_of_bvar.find(v);
            if (it == atom_of_bvar.end()) continue;
            const LraAtom& a = atoms[it->second];
            bool upper;
            DeltaRat b;
            atom_bound(a, !l.sign(), upper, b);
            bool ok = upper ? assert_upper(a.var, b, l) : assert_lower(a.var, b, l);
            if (!ok) return false;
        }
        return check();
    }

    void explain(Lit l, std::vector<Lit>& out) override {
        Lit r = prop_reason[l.var()];
        if (r != LIT_UNDEF) out.push_back(r);
    }

    // ------------- simplex -------------
    bool violates(int b) const {
        if (has_lo[b] && val[b] < lo[b]) return true;
        if (has_hi[b] && val[b] > hi[b]) return true;
        return false;
    }

    void pivot(int r, int x) {
        // row r: basic b = sum e ; x in e
        pivots++;
        Row& R = rows[r];
        int b = R.basic;
        int px = -1;
        for (int i = 0; i < (int)R.e.size(); i++) if (R.e[i].var == x) { px = i; break; }
        Rational ax = R.e[px].coef;
        row_remove_entry(r, px);
        // x = (1/ax) b - sum (aj/ax) yj
        Rational inv = Rational(1) / ax;
        for (auto& en : rows[r].e) en.coef = -(en.coef * inv);
        row_add_entry(r, b, inv);
        rows[r].basic = x;
        row_of[x] = r;
        row_of[b] = -1;
        // substitute into other rows containing x
        std::vector<ColEntry> cx = col[x];
        for (auto& ce : cx) {
            if (ce.row == r) continue;
            int r2 = ce.row;
            Row& R2 = rows[r2];
            // find x in R2 (pos from column)
            int pos = ce.pos;
            Rational c = R2.e[pos].coef;
            row_remove_entry(r2, pos);
            // positions map
            for (int i = 0; i < (int)rows[r2].e.size(); i++) scratch_pos[rows[r2].e[i].var] = i;
            const Row& RR = rows[r];
            for (const auto& en : RR.e) {
                int p = scratch_pos[en.var];
                if (p >= 0) {
                    rows[r2].e[p].coef.addmul(c, en.coef);
                } else {
                    Rational nc = c * en.coef;
                    scratch_pos[en.var] = (int)rows[r2].e.size();
                    row_add_entry(r2, en.var, nc);
                }
            }
            // remove zeros, reset scratch
            Row& R3 = rows[r2];
            for (int i = 0; i < (int)R3.e.size(); i++) scratch_pos[R3.e[i].var] = -1;
            for (int i = (int)R3.e.size() - 1; i >= 0; i--)
                if (R3.e[i].coef.is_zero()) row_remove_entry(r2, i);
        }
        // col[x] now should only contain... x is basic: remove it from all rows (done), col[x] must be empty
    }

    void pivot_and_update(int r, int x, const DeltaRat& v) {
        int b = rows[r].basic;
        Rational ax;
        for (auto& en : rows[r].e) if (en.var == x) { ax = en.coef; break; }
        // theta = (v - val[b]) / ax
        DeltaRat theta = (v - val[b]) * (Rational(1) / ax);
        val[b] = v;
        val[x] += theta;
        for (auto& ce : col[x]) {
            if (ce.row == r) continue;
            Row& R = rows[ce.row];
            val[R.basic].addmul(theta, R.e[ce.pos].coef);
            infeasible.insert(R.basic);
        }
        pivot(r, x);
        infeasible.insert(x);
    }

    bool check() {
        int iter = 0;
        while (!infeasible.empty()) {
            if (S.should_stop && (++iter & 1023) == 0 && S.should_stop()) return true;
            int b = *infeasible.begin();
            infeasible.erase(infeasible.begin());
            if (row_of[b] < 0 || !violates(b)) continue;
            int r = row_of[b];
            bool below = has_lo[b] && val[b] < lo[b];
            // find entering variable
            int best = -1;
            size_t best_cols = SIZE_MAX;
            bool bland = iter > 1000 || pivots > 100000 ? true : false;
            (void)bland;
            for (auto& en : rows[r].e) {
                int x = en.var;
                int s = en.coef.sign();
                bool can;
                if (below) can = (s > 0) ? (!has_hi[x] || val[x] < hi[x]) : (!has_lo[x] || val[x] > lo[x]);
                else can = (s < 0) ? (!has_hi[x] || val[x] < hi[x]) : (!has_lo[x] || val[x] > lo[x]);
                if (!can) continue;
                if (iter > 200) {
                    if (best < 0 || x < best) best = x;
                } else {
                    size_t cs = col[x].size();
                    if (best < 0 || cs < best_cols || (cs == best_cols && x < best)) { best = x; best_cols = cs; }
                }
            }
            if (best < 0) {
                // conflict
                std::vector<Lit> c;
                if (below) c.push_back(~lo_r[b]); else c.push_back(~hi_r[b]);
                for (auto& en : rows[r].e) {
                    int x = en.var;
                    int s = en.coef.sign();
                    bool use_hi = below ? (s > 0) : (s < 0);
                    Lit rl = use_hi ? hi_r[x] : lo_r[x];
                    c.push_back(~rl);
                }
                // put b back for later
                infeasible.insert(b);
                S.set_conflict(c);
                return false;
            }
            iter++;
            pivot_and_update(r, best, below ? lo[b] : hi[b]);
        }
        return true;
    }

    // ------------- integer handling -------------
    bool final_check() override {
        if (!check()) return false;
        if (int_vars_list.empty()) return true;
        // find fractional int var
        int pick = -1;
        for (int v : int_vars_list) {
            if (!val[v].k.is_zero() || !val[v].c.is_int()) {
                // delta parts on int vars: treat as fractional
                pick = v;
                break;
            }
        }
        if (pick < 0) return true;
        branch(pick);
        return false;
    }

    void branch(int v) {
        Rational fl;
        if (val[v].c.is_int()) fl = val[v].k.sign() < 0 ? val[v].c - Rational(1) : val[v].c;
        else fl = val[v].c.floor();
        Var b = get_atom(v, true, fl);
        S.var_bump(b, 1000);
        (void)b;
    }

    // compute concrete rational values
    std::vector<Rational> model;
    void compute_model() {
        Rational delta(1);
        int n = num_vars();
        for (int v = 0; v < n; v++) {
            const DeltaRat& x = val[v];
            if (has_lo[v]) {
                const DeltaRat& l = lo[v];
                // l.c + l.k d <= x.c + x.k d
                if (l.c < x.c && l.k > x.k) {
                    Rational d = (x.c - l.c) / (l.k - x.k);
                    if (d < delta) delta = d;
                }
            }
            if (has_hi[v]) {
                const DeltaRat& u = hi[v];
                if (x.c < u.c && x.k > u.k) {
                    Rational d = (u.c - x.c) / (x.k - u.k);
                    if (d < delta) delta = d;
                }
            }
        }
        delta = delta / Rational(2);
        model.assign(n, Rational(0));
        // nonbasic first then basic from rows to be exact
        for (int v = 0; v < n; v++) model[v] = val[v].c + val[v].k * delta;
        for (auto& R : rows) {
            Rational s(0);
            for (auto& en : R.e) s.addmul(model[en.var], en.coef);
            model[R.basic] = s;
        }
    }
};
