// SMT solver entry point: encoding to SAT + theories, model output.
#include "terms.h"
#include "sat.h"
#include "euf.h"
#include "lra.h"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <iostream>
#include <chrono>
#include <pthread.h>
#include <unistd.h>
#include <map>

struct LinExpr {
    std::vector<std::pair<int, Rational>> t;  // sorted by var
    Rational c;
};

static LinExpr lin_add(const LinExpr& a, const LinExpr& b, const Rational& mb) {
    LinExpr r;
    r.c = a.c + b.c * mb;
    size_t i = 0, j = 0;
    while (i < a.t.size() || j < b.t.size()) {
        if (j >= b.t.size() || (i < a.t.size() && a.t[i].first < b.t[j].first)) { r.t.push_back(a.t[i++]); }
        else if (i >= a.t.size() || b.t[j].first < a.t[i].first) { r.t.push_back({b.t[j].first, b.t[j].second * mb}); j++; }
        else {
            Rational s = a.t[i].second + b.t[j].second * mb;
            if (!s.is_zero()) r.t.push_back({a.t[i].first, s});
            i++; j++;
        }
    }
    return r;
}

class Encoder;

class Combiner : public Theory {
public:
    Encoder* E;
    Combiner(Encoder* e) : E(e) {}
    void new_level() override {}
    void backtrack(int) override {}
    bool propagate() override { return true; }
    bool final_check() override;
    void explain(Lit, std::vector<Lit>&) override {}
};

class Encoder {
public:
    Frontend& F;
    TermManager& tm;
    Solver S;
    EUF* euf = nullptr;
    LRA* lra = nullptr;
    Combiner* comb = nullptr;
    Lit true_lit;
    std::vector<Lit> lit_of;
    std::unordered_map<int, int> node_of;
    std::unordered_map<int, int> var_of;
    std::unordered_map<int, LinExpr> lin_cache;
    std::unordered_map<int, int> func_leaf;
    std::unordered_map<uint64_t, Var> eq_atom_cache;
    std::vector<int> side;
    std::unordered_map<int, int> ite_const;
    std::vector<int> ulit_nodes;
    struct Shared { int node; LinExpr e; };
    std::vector<Shared> shared;
    std::vector<int8_t> node_is_arg;  // per euf node
    std::vector<int> shared_args;     // indices into shared
    std::unordered_map<int, int> shared_of_node;
    bool use_euf = false, use_lra = false;

    Encoder(Frontend& f) : F(f), tm(f.tm) {}

    void init(bool need_euf, bool need_lra) {
        use_euf = need_euf;
        use_lra = need_lra;
        Var tv = S.new_var(-1, false);
        true_lit = Lit(tv, false);
        S.add_clause({true_lit});
        if (need_euf) {
            euf = new EUF(S, (int)S.theories.size());
            S.theories.push_back(euf);
        }
        if (need_lra) {
            lra = new LRA(S, (int)S.theories.size());
            lra->all_int = tm.int_logic;
            S.theories.push_back(lra);
        }
        if (need_euf && need_lra) {
            comb = new Combiner(this);
            S.theories.push_back(comb);
        }
    }

    Lit& lit_slot(int t) {
        if ((int)lit_of.size() <= t) lit_of.resize(t + 1024, LIT_UNDEF);
        return lit_of[t];
    }

    // ---------------- arithmetic ----------------
    int ite_elim(int t) {
        auto it = ite_const.find(t);
        if (it != ite_const.end()) return it->second;
        const Term& tt = tm[t];
        int v = tm.fresh_const(tt.sort, "__ite");
        ite_const[t] = v;
        int c = tt.args[0], a = tt.args[1], b = tt.args[2];
        side.push_back(tm.mk_ite(c, tm.mk_eq(v, a), tm.mk_eq(v, b)));
        return v;
    }

    int atomic_var(int t) {
        auto it = var_of.find(t);
        if (it != var_of.end()) return it->second;
        if (!lra) throw Unsupported("arith without lra");
        int v = lra->new_var(tm.sort_of(t) == SORT_INT);
        var_of[t] = v;
        return v;
    }

    const LinExpr& lin(int t) {
        auto it = lin_cache.find(t);
        if (it != lin_cache.end()) return it->second;
        const Term& tt = tm[t];
        LinExpr r;
        switch (tt.k) {
        case K_NUM: r.c = tt.val; break;
        case K_ADD: {
            std::vector<int> args = tt.args;
            for (int a : args) {
                LinExpr la = lin(a);
                r = lin_add(r, la, Rational(1));
            }
            break;
        }
        case K_MUL: {
            Rational c = tm[tt.args[0]].val;
            int x = tt.args[1];
            LinExpr lx = lin(x);
            LinExpr z;
            r = lin_add(z, lx, c);
            break;
        }
        case K_CONST:
        case K_APP:
            r.t.push_back({atomic_var(t), Rational(1)});
            break;
        case K_ITE: {
            int v = ite_elim(t);
            r = lin(v);
            break;
        }
        default:
            throw Unsupported("non-arith term in arith context");
        }
        auto res = lin_cache.emplace(t, std::move(r));
        return res.first->second;
    }

    Lit mk_lra_atom(int var, bool is_le, const Rational& k) {
        Var b = lra->get_atom(var, is_le, k);
        return Lit(b, false);
    }

    // e op 0 ; op: 0 '<=', 1 '<', 2 '='
    Lit arith_atom(const LinExpr& e, int op) {
        if (e.t.empty()) {
            int s = e.c.sign();
            bool v = op == 0 ? s <= 0 : op == 1 ? s < 0 : s == 0;
            return v ? true_lit : ~true_lit;
        }
        Rational k = -e.c;
        std::vector<std::pair<int, Rational>> f = e.t;
        bool isint = true;
        for (auto& p : f) if (!lra->is_int[p.first]) isint = false;
        bool flip = false;  // if true: relation reversed (>=)
        if (isint) {
            // scale to integer coefficients
            BigInt L(1);
            bool all_small = true;
            for (auto& p : f) if (!p.second.is_int()) all_small = false;
            if (!all_small) {
                Rational lcm(1);
                for (auto& p : f) {
                    if (!p.second.is_int()) {
                        Rational d = Rational::from_big(p.second.bden(), BigInt(1));
                        // lcm(lcm, d)
                        BigInt g = BigInt::gcd(lcm.bnum(), d.bnum());
                        lcm = Rational::from_big(lcm.bnum() / g * d.bnum(), BigInt(1));
                    }
                }
                for (auto& p : f) p.second = p.second * lcm;
                k = k * lcm;
            }
            BigInt g(0);
            for (auto& p : f) g = BigInt::gcd(g, p.second.bnum());
            Rational gr = Rational::from_big(g, BigInt(1));
            if (!gr.is_one()) {
                for (auto& p : f) p.second = p.second / gr;
                k = k / gr;
            }
            if (f[0].second.sign() < 0) {
                for (auto& p : f) p.second = -p.second;
                k = -k;
                flip = true;
            }
            int var = lra->var_for_form(f);
            if (op == 2) {
                if (!k.is_int()) return ~true_lit;
                Lit a = mk_lra_atom(var, true, k);
                Lit b = ~mk_lra_atom(var, true, k - Rational(1));
                return mk_and_lit({a, b});
            }
            // sum <= k (or >= k if flipped) ; strict: < / >
            if (!flip) {
                Rational kk = (op == 1) ? (k.is_int() ? k - Rational(1) : k.floor()) : k.floor();
                return mk_lra_atom(var, true, kk);
            } else {
                // sum >= k  (strict: sum > k)
                Rational kk = (op == 1) ? (k.is_int() ? k + Rational(1) : k.ceil()) : k.ceil();
                // sum >= kk  <=> not (sum <= kk-1)
                return ~mk_lra_atom(var, true, kk - Rational(1));
            }
        } else {
            Rational lead = f[0].second;
            if (lead.sign() < 0) flip = true;
            Rational inv = Rational(1) / lead;
            for (auto& p : f) p.second = p.second * inv;
            k = k * inv;
            int var = lra->var_for_form(f);
            if (op == 2) {
                Lit a = mk_lra_atom(var, true, k);
                Lit b = mk_lra_atom(var, false, k);
                return mk_and_lit({a, b});
            }
            if (!flip) {
                if (op == 0) return mk_lra_atom(var, true, k);
                return ~mk_lra_atom(var, false, k);  // var < k
            } else {
                if (op == 0) return mk_lra_atom(var, false, k);  // var >= k
                return ~mk_lra_atom(var, true, k);  // var > k
            }
        }
    }

    // ---------------- EUF ----------------
    int func_node(int f) {
        auto it = func_leaf.find(f);
        if (it != func_leaf.end()) return it->second;
        int n = euf->mk_leaf();
        func_leaf[f] = n;
        return n;
    }
    void mark_arg(int n) {
        if ((int)node_is_arg.size() <= n) node_is_arg.resize(n + 1024, 0);
        node_is_arg[n] = 1;
    }
    void add_shared(int n, int t) {
        if (shared_of_node.count(n)) return;
        shared_of_node[n] = (int)shared.size();
        shared.push_back({n, lin(t)});
    }

    int euf_node(int t) {
        auto it = node_of.find(t);
        if (it != node_of.end()) return it->second;
        if (!euf) throw Unsupported("uf without euf");
        const Term& tt = tm[t];
        int n;
        if (t == tm.t_true) n = euf->TRUE_N;
        else if (t == tm.t_false) n = euf->FALSE_N;
        else if (tt.k == K_APP) {
            std::vector<int> args = tt.args;
            n = func_node(tt.sym);
            for (int a : args) {
                int an = euf_node(a);
                if (tm.is_arith_sort(tm.sort_of(a))) {
                    mark_arg(an);
                }
                n = euf->mk_app(n, an);
            }
            if (tt.sort == SORT_BOOL) {
                Var v = S.new_var(euf->tid);
                euf->register_bool_node(n, v);
                lit_slot(t) = Lit(v, false);
            }
        } else if (tt.k == K_ITE && tt.sort != SORT_BOOL) {
            int v = ite_elim(t);
            n = euf_node(v);
        } else if (tt.sort == SORT_BOOL) {
            n = euf->mk_leaf();
            Lit l = encode(t);
            Var v = S.new_var(euf->tid);
            euf->register_bool_node(n, v);
            Lit bl(v, false);
            S.add_clause({~bl, l});
            S.add_clause({bl, ~l});
        } else {
            n = euf->mk_leaf();
            if (tt.k == K_ULIT) {
                for (int o : ulit_nodes) euf->add_distinct_axiom(o, n);
                ulit_nodes.push_back(n);
            }
        }
        node_of[t] = n;
        if (tm.is_arith_sort(tt.sort)) add_shared(n, t);
        return n;
    }

    // ---------------- Tseitin ----------------
    Lit mk_and_lit(const std::vector<Lit>& ls) {
        Var v = S.new_var();
        Lit x(v, false);
        std::vector<Lit> big = {x};
        for (Lit l : ls) {
            S.add_clause({~x, l});
            big.push_back(~l);
        }
        S.add_clause(big);
        return x;
    }
    Lit mk_or_lit(const std::vector<Lit>& ls) {
        Var v = S.new_var();
        Lit x(v, false);
        std::vector<Lit> big = {~x};
        for (Lit l : ls) {
            S.add_clause({x, ~l});
            big.push_back(l);
        }
        S.add_clause(big);
        return x;
    }

    Lit encode(int t) {
        {
            Lit l = lit_slot(t);
            if (l != LIT_UNDEF) return l;
        }
        const Term& tt = tm[t];
        Lit r;
        switch (tt.k) {
        case K_TRUE: r = true_lit; break;
        case K_FALSE: r = ~true_lit; break;
        case K_CONST: r = Lit(S.new_var(), false); break;
        case K_APP: {
            euf_node(t);
            r = lit_slot(t);
            break;
        }
        case K_NOT: r = ~encode(tt.args[0]); break;
        case K_AND:
        case K_OR: {
            std::vector<int> args = tt.args;
            std::vector<Lit> ls;
            for (int a : args) ls.push_back(encode(a));
            r = tt.k == K_AND ? mk_and_lit(ls) : mk_or_lit(ls);
            break;
        }
        case K_XOR: {
            Lit a = encode(tt.args[0]), b = encode(tt.args[1]);
            r = mk_xor_lit(a, b);
            break;
        }
        case K_ITE: {
            if (tt.sort != SORT_BOOL) throw Unsupported("non-bool ite in bool ctx");
            int c0 = tt.args[0], a0 = tt.args[1], b0 = tt.args[2];
            Lit c = encode(c0), a = encode(a0), b = encode(b0);
            Lit x(S.new_var(), false);
            S.add_clause({~c, ~a, x});
            S.add_clause({~c, a, ~x});
            S.add_clause({c, ~b, x});
            S.add_clause({c, b, ~x});
            S.add_clause({~a, ~b, x});
            S.add_clause({a, b, ~x});
            r = x;
            break;
        }
        case K_EQ: {
            int a = tt.args[0], b = tt.args[1];
            int s = tm.sort_of(a);
            if (s == SORT_BOOL) {
                Lit la = encode(a), lb = encode(b);
                r = ~mk_xor_lit(la, lb);
            } else if (tm.is_arith_sort(s)) {
                LinExpr d = lin_add(lin(a), lin(b), Rational(-1));
                r = arith_atom(d, 2);
            } else {
                int na = euf_node(a), nb = euf_node(b);
                r = euf_eq(na, nb);
            }
            break;
        }
        case K_LE:
        case K_LT: {
            int a = tt.args[0], b = tt.args[1];
            LinExpr d = lin_add(lin(a), lin(b), Rational(-1));
            r = arith_atom(d, tt.k == K_LE ? 0 : 1);
            break;
        }
        default:
            throw Unsupported("encode: unexpected term");
        }
        lit_slot(t) = r;
        return r;
    }

    Lit mk_xor_lit(Lit a, Lit b) {
        Lit x(S.new_var(), false);
        S.add_clause({~x, a, b});
        S.add_clause({~x, ~a, ~b});
        S.add_clause({x, ~a, b});
        S.add_clause({x, a, ~b});
        return x;
    }

    Lit euf_eq(int na, int nb) {
        if (na == nb) return true_lit;
        if (na > nb) std::swap(na, nb);
        uint64_t key = EUF::pkey(na, nb);
        auto it = eq_atom_cache.find(key);
        if (it != eq_atom_cache.end()) return Lit(it->second, false);
        Var v = S.new_var(euf->tid);
        eq_atom_cache[key] = v;
        euf->register_eq_atom(na, nb, v);
        return Lit(v, false);
    }

    void assert_top(int t) {
        std::vector<int> stack = {t};
        while (!stack.empty()) {
            int x = stack.back();
            stack.pop_back();
            const Term& tx = tm[x];
            if (tx.k == K_AND) {
                for (int a : tx.args) stack.push_back(a);
                continue;
            }
            if (tx.k == K_NOT && tm[tx.args[0]].k == K_OR) {
                for (int a : tm[tx.args[0]].args) stack.push_back(tm.mk_not(a));
                continue;
            }
            if (tx.k == K_OR) {
                std::vector<int> args = tx.args;
                std::vector<Lit> cl;
                for (int a : args) cl.push_back(encode(a));
                S.add_clause(cl);
                continue;
            }
            if (tx.k == K_NOT && tm[tx.args[0]].k == K_AND) {
                std::vector<int> args = tm[tx.args[0]].args;
                std::vector<Lit> cl;
                for (int a : args) cl.push_back(~encode(a));
                S.add_clause(cl);
                continue;
            }
            S.add_clause({encode(x)});
        }
    }

    void encode_all() {
        for (int a : F.assertions) {
            assert_top(a);
            while (!side.empty()) {
                int s = side.back();
                side.pop_back();
                assert_top(s);
            }
        }
        // make sure every UF application seen in the input is registered (model completeness)
        if (euf) {
            for (auto& pr : F.uf_keys) {
                euf_node(pr.second);
                while (!side.empty()) {
                    int s = side.back();
                    side.pop_back();
                    assert_top(s);
                }
            }
            for (auto& sh : shared) {
                if (sh.node < (int)node_is_arg.size() && node_is_arg[sh.node]) shared_args.push_back(shared_of_node[sh.node]);
            }
        }
    }

    // ---------------- combination ----------------
    Rational eval_lin(const LinExpr& e) {
        Rational r = e.c;
        for (auto& p : e.t) r.addmul(lra->model[p.first], p.second);
        return r;
    }

    // create equality atom between two arith-sorted euf nodes with both facets
    Var make_shared_eq(int n1, int n2) {
        if (n1 > n2) std::swap(n1, n2);
        uint64_t key = EUF::pkey(n1, n2);
        auto it = eq_atom_cache.find(key);
        if (it != eq_atom_cache.end()) return it->second;
        const LinExpr& e1 = shared[shared_of_node[n1]].e;
        const LinExpr& e2 = shared[shared_of_node[n2]].e;
        LinExpr d = lin_add(e1, e2, Rational(-1));
        Var v = S.new_var(euf->tid);
        eq_atom_cache[key] = v;
        Lit E(v, false);
        if (d.t.empty()) {
            if (d.c.is_zero()) S.pending_lemmas.push_back({E});
            else S.pending_lemmas.push_back({~E});
        } else {
            Lit le = arith_atom(d, 0);
            LinExpr nd = lin_add(LinExpr(), d, Rational(-1));
            Lit ge = arith_atom(nd, 0);
            S.pending_lemmas.push_back({~E, le});
            S.pending_lemmas.push_back({~E, ge});
            S.pending_lemmas.push_back({E, ~le, ~ge});
        }
        euf->register_eq_atom(n1, n2, v);
        return v;
    }

    bool combine_check() {
        lra->compute_model();
        std::vector<Rational> vals(shared.size());
        for (size_t i = 0; i < shared.size(); i++) vals[i] = eval_lin(shared[i].e);
        bool progress = false;
        // (A) same class, different values
        std::unordered_map<int, int> cls_first;
        for (size_t i = 0; i < shared.size(); i++) {
            int r = euf->rep[shared[i].node];
            auto it = cls_first.find(r);
            if (it == cls_first.end()) { cls_first[r] = (int)i; continue; }
            if (vals[it->second] != vals[i]) {
                make_shared_eq(shared[it->second].node, shared[i].node);
                progress = true;
            }
        }
        if (progress) return false;
        // (B) argument terms with equal values but different classes
        std::map<std::string, std::vector<int>> by_val;
        for (int i : shared_args) by_val[vals[i].to_string()].push_back(i);
        for (auto& kv : by_val) {
            auto& lst = kv.second;
            for (size_t j = 1; j < lst.size(); j++) {
                int a = shared[lst[0]].node, b = shared[lst[j]].node;
                if (euf->rep[a] == euf->rep[b]) continue;
                Var v = make_shared_eq(a, b);
                if (S.value(v) == L_UNDEF) {
                    S.polarity[v] = 0;
                    S.var_bump(v, 100);
                    progress = true;
                }
            }
        }
        return !progress;
    }
};

bool Combiner::final_check() { return E->combine_check(); }

// ---------------------------------------------------------------------------
static std::string json_escape(const std::string& s) {
    std::string o;
    for (char c : s) {
        if (c == '"') o += "\\\"";
        else if (c == '\\') o += "\\\\";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof buf, "\\u%04x", c);
            o += buf;
        } else o += c;
    }
    return o;
}

static std::chrono::steady_clock::time_point g_start;
static double elapsed() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - g_start).count();
}

struct Args { std::string path; };

static int real_main(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) { printf("unknown\n"); return 0; }
    std::stringstream ss;
    ss << in.rdbuf();
    std::string text = ss.str();
    Frontend F;
    try {
        F.run(text);
    } catch (Unsupported& e) {
        fprintf(stderr, "unsupported: %s\n", e.what());
        printf("unknown\n");
        return 0;
    }
    TermManager& tm = F.tm;
    // determine needed theories
    bool has_uf = false, has_arith = false;
    for (int fid : F.declared_funcs) {
        const Func& fn = tm.funcs[fid];
        if (!fn.args.empty()) has_uf = true;
        if (tm.is_arith_sort(fn.ret)) has_arith = true;
        for (int s : fn.args) if (tm.is_arith_sort(s)) has_arith = true;
        if (fn.args.empty() && fn.ret > SORT_REAL) has_uf = true;
        if (fn.args.empty() && !tm.arith_logic && fn.ret != SORT_BOOL) has_uf = true;
    }
    if (tm.arith_logic) has_arith = true;
    Encoder E(F);
    E.init(has_uf, has_arith);
    try {
        E.encode_all();
    } catch (Unsupported& e) {
        fprintf(stderr, "unsupported: %s\n", e.what());
        printf("unknown\n");
        return 0;
    }
    fprintf(stderr, "encoded: vars=%d clauses=%zu t=%.2f\n", E.S.num_vars(), E.S.clauses.size(), elapsed());
    E.S.should_stop = []() { return elapsed() > 1e9; };
    LBool res = E.S.solve();
    fprintf(stderr, "result after %.2fs conflicts=%llu decisions=%llu\n", elapsed(),
            (unsigned long long)E.S.conflicts, (unsigned long long)E.S.decisions);
    if (res == L_FALSE) { printf("unsat\n"); return 0; }
    if (res == L_UNDEF) { printf("unknown\n"); return 0; }
    // model
    if (E.lra) E.lra->compute_model();
    std::string out = "sat\n{\"values\":{";
    bool first = true;
    auto emit = [&](const std::string& k, const std::string& v) {
        if (!first) out += ",";
        first = false;
        out += "\"" + json_escape(k) + "\":\"" + json_escape(v) + "\"";
    };
    auto class_label = [&](int node) -> std::string {
        int r = E.euf->rep[node];
        // literal in class?
        if (!E.ulit_nodes.empty()) {
            for (auto& kv : E.node_of) {
                if (tm[kv.first].k == K_ULIT && E.euf->rep[kv.second] == r) return F.sx.strs[tm[kv.first].sym];
            }
        }
        return "@c" + std::to_string(r);
    };
    auto value_of = [&](int t) -> std::string {
        int s = tm.sort_of(t);
        if (s == SORT_BOOL) {
            Lit l = t < (int)E.lit_of.size() ? E.lit_of[t] : LIT_UNDEF;
            if (l == LIT_UNDEF) return "false";
            return E.S.value(l) == L_TRUE ? "true" : "false";
        }
        if (tm.is_arith_sort(s)) {
            auto it = E.var_of.find(t);
            Rational v(0);
            if (it != E.var_of.end()) v = E.lra->model[it->second];
            return v.to_smt();
        }
        auto it = E.node_of.find(t);
        if (it == E.node_of.end()) return "@u" + std::to_string(t);
        return class_label(it->second);
    };
    for (int fid : F.declared_funcs) {
        const Func& fn = tm.funcs[fid];
        if (!fn.args.empty()) continue;
        int t = tm.mk_const(fid);
        emit(fn.name, value_of(t));
    }
    std::unordered_map<int, int> seen_key;
    for (auto& pr : F.uf_keys) {
        if (seen_key.count(pr.first)) continue;
        seen_key[pr.first] = pr.second;
        std::string key;
        F.sx.render(pr.first, key);
        emit(key, value_of(pr.second));
    }
    out += "}}\n";
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}

static std::string g_path;
static void* thread_main(void*) {
    real_main(g_path);
    fflush(stdout);
    return nullptr;
}

int main(int argc, char** argv) {
    g_start = std::chrono::steady_clock::now();
    if (argc < 2) { printf("unknown\n"); return 0; }
    g_path = argv[1];
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, (size_t)4 << 30);
    pthread_t th;
    if (pthread_create(&th, &attr, thread_main, nullptr) != 0) {
        real_main(g_path);
    } else {
        pthread_join(th, nullptr);
    }
    fflush(stdout);
    _exit(0);
}
