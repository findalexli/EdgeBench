// S-expression parsing, hash-consed terms and SMT-LIB elaboration.
#pragma once
#include "rational.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <stdexcept>
#include <cstring>
#include <deque>
#include <algorithm>

struct Unsupported : std::runtime_error {
    explicit Unsupported(const std::string& s) : std::runtime_error(s) {}
};

// ---------------------------------------------------------------------------
// S-expressions (hash-consed)
// ---------------------------------------------------------------------------
struct SExprStore {
    std::vector<std::string> strs;
    std::unordered_map<std::string, int> str_id;
    struct Node { int atom; std::vector<int> kids; };
    std::vector<Node> nodes;
    std::unordered_map<int, int> atom_node;  // str id -> node
    struct VecHash {
        size_t operator()(const std::vector<int>& v) const {
            size_t h = 1469598103934665603ULL;
            for (int x : v) { h ^= (size_t)x + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2); }
            return h;
        }
    };
    std::unordered_map<std::vector<int>, int, VecHash> list_node;

    int intern(const std::string& s) {
        auto it = str_id.find(s);
        if (it != str_id.end()) return it->second;
        int id = (int)strs.size();
        strs.push_back(s);
        str_id.emplace(s, id);
        return id;
    }
    int mk_atom(int sid) {
        auto it = atom_node.find(sid);
        if (it != atom_node.end()) return it->second;
        int id = (int)nodes.size();
        nodes.push_back({sid, {}});
        atom_node[sid] = id;
        return id;
    }
    int mk_list(std::vector<int>&& kids) {
        auto it = list_node.find(kids);
        if (it != list_node.end()) return it->second;
        int id = (int)nodes.size();
        nodes.push_back({-1, kids});
        list_node.emplace(std::move(kids), id);
        return id;
    }
    bool is_atom(int n) const { return nodes[n].atom >= 0; }
    const std::string& atom_str(int n) const { return strs[nodes[n].atom]; }
    const std::vector<int>& kids(int n) const { return nodes[n].kids; }

    // parse whole text into top-level forms
    std::vector<int> parse(const std::string& text) {
        std::vector<int> top;
        std::vector<std::vector<int>> stack;
        size_t i = 0, n = text.size();
        while (i < n) {
            char ch = text[i];
            if (isspace((unsigned char)ch)) { i++; continue; }
            if (ch == ';') { while (i < n && text[i] != '\n') i++; continue; }
            if (ch == '(') { stack.emplace_back(); i++; continue; }
            if (ch == ')') {
                if (stack.empty()) throw Unsupported("unbalanced )");
                std::vector<int> k = std::move(stack.back());
                stack.pop_back();
                int node = mk_list(std::move(k));
                if (stack.empty()) top.push_back(node); else stack.back().push_back(node);
                i++;
                continue;
            }
            size_t j;
            if (ch == '|') {
                j = i + 1;
                while (j < n && text[j] != '|') j++;
                if (j >= n) throw Unsupported("unterminated |");
                j++;
            } else if (ch == '"') {
                j = i + 1;
                while (j < n) {
                    if (text[j] == '"') { if (j + 1 < n && text[j + 1] == '"') { j += 2; continue; } break; }
                    j++;
                }
                j++;
            } else {
                j = i;
                while (j < n && !isspace((unsigned char)text[j]) && text[j] != '(' && text[j] != ')' && text[j] != ';') j++;
            }
            int node = mk_atom(intern(text.substr(i, j - i)));
            if (stack.empty()) top.push_back(node); else stack.back().push_back(node);
            i = j;
        }
        if (!stack.empty()) throw Unsupported("unbalanced (");
        return top;
    }

    void render(int n, std::string& out) const {
        if (is_atom(n)) { out += atom_str(n); return; }
        out += '(';
        const auto& k = kids(n);
        for (size_t i = 0; i < k.size(); i++) {
            if (i) out += ' ';
            render(k[i], out);
        }
        out += ')';
    }
};

// ---------------------------------------------------------------------------
// Terms
// ---------------------------------------------------------------------------
enum Kind : uint8_t {
    K_TRUE, K_FALSE, K_CONST, K_APP, K_NUM, K_ULIT,
    K_NOT, K_AND, K_OR, K_XOR, K_ITE, K_EQ,
    K_ADD, K_MUL, K_LE, K_LT
};

enum { SORT_BOOL = 0, SORT_INT = 1, SORT_REAL = 2 };

struct Term {
    Kind k;
    int sort;
    int sym;  // function id for CONST/APP; string id for ULIT
    std::vector<int> args;
    Rational val;
};

struct Func {
    std::string name;  // raw token
    std::vector<int> args;
    int ret;
    bool internal;
};

struct TermManager {
    std::deque<Term> terms;
    struct TKey {
        Kind k; int sort; int sym; std::vector<int> args; Rational val;
        bool operator==(const TKey& o) const {
            return k == o.k && sort == o.sort && sym == o.sym && args == o.args && val == o.val;
        }
    };
    struct TKeyHash {
        size_t operator()(const TKey& t) const {
            size_t h = (size_t)t.k * 1000003u + (size_t)(t.sort + 7) * 7919u + (size_t)(t.sym + 3) * 104729u;
            for (int x : t.args) h ^= (size_t)x + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
            h ^= t.val.hash() + (h << 3);
            return h;
        }
    };
    std::unordered_map<TKey, int, TKeyHash> table;
    std::vector<Func> funcs;
    std::vector<std::string> sort_names;
    int t_true, t_false;
    bool arith_logic = true;  // numerals are numbers
    bool int_logic = false;   // numerals are Int

    TermManager() {
        sort_names = {"Bool", "Int", "Real"};
        t_true = mk(K_TRUE, SORT_BOOL, -1, {});
        t_false = mk(K_FALSE, SORT_BOOL, -1, {});
    }

    const Term& operator[](int t) const { return terms[t]; }
    int mk(Kind k, int sort, int sym, std::vector<int> args, const Rational& val = Rational()) {
        TKey key{k, sort, sym, args, val};
        auto it = table.find(key);
        if (it != table.end()) return it->second;
        int id = (int)terms.size();
        terms.push_back({k, sort, sym, args, val});
        table.emplace(std::move(key), id);
        return id;
    }
    int sort_of(int t) const { return terms[t].sort; }
    bool is_arith_sort(int s) const { return arith_logic && (s == SORT_INT || s == SORT_REAL); }

    int new_func(const std::string& name, std::vector<int> args, int ret, bool internal) {
        funcs.push_back({name, args, ret, internal});
        return (int)funcs.size() - 1;
    }
    int mk_const(int f) { return mk(K_CONST, funcs[f].ret, f, {}); }
    int fresh_const(int sort, const std::string& prefix) {
        int f = new_func(prefix + std::to_string(funcs.size()), {}, sort, true);
        return mk_const(f);
    }
    int mk_num(const Rational& v, int sort) { return mk(K_NUM, sort, -1, {}, v); }

    int mk_not(int a) {
        const Term& t = terms[a];
        if (t.k == K_NOT) return t.args[0];
        if (a == t_true) return t_false;
        if (a == t_false) return t_true;
        return mk(K_NOT, SORT_BOOL, -1, {a});
    }
    int mk_andor(Kind k, const std::vector<int>& in) {
        bool is_and = (k == K_AND);
        int unit = is_and ? t_true : t_false, zero = is_and ? t_false : t_true;
        std::vector<int> out;
        std::vector<int> stack(in.rbegin(), in.rend());
        while (!stack.empty()) {
            int a = stack.back();
            stack.pop_back();
            if (a == unit) continue;
            if (a == zero) return zero;
            if (terms[a].k == k) {
                const auto& ar = terms[a].args;
                for (size_t i = ar.size(); i-- > 0;) stack.push_back(ar[i]);
                continue;
            }
            out.push_back(a);
        }
        std::sort(out.begin(), out.end());
        out.erase(std::unique(out.begin(), out.end()), out.end());
        for (size_t i = 0; i < out.size(); i++) {
            const Term& t = terms[out[i]];
            if (t.k == K_NOT && std::binary_search(out.begin(), out.end(), t.args[0])) return zero;
        }
        if (out.empty()) return unit;
        if (out.size() == 1) return out[0];
        return mk(k, SORT_BOOL, -1, out);
    }
    int mk_and(const std::vector<int>& a) { return mk_andor(K_AND, a); }
    int mk_or(const std::vector<int>& a) { return mk_andor(K_OR, a); }
    int mk_implies(int a, int b) { return mk_or({mk_not(a), b}); }
    int mk_xor(int a, int b) {
        if (a == b) return t_false;
        if (a == t_false) return b;
        if (b == t_false) return a;
        if (a == t_true) return mk_not(b);
        if (b == t_true) return mk_not(a);
        if (a > b) std::swap(a, b);
        return mk(K_XOR, SORT_BOOL, -1, {a, b});
    }
    int mk_iff(int a, int b) {
        if (a == b) return t_true;
        if (a == t_true) return b;
        if (b == t_true) return a;
        if (a == t_false) return mk_not(b);
        if (b == t_false) return mk_not(a);
        if (terms[a].k == K_NOT && terms[a].args[0] == b) return t_false;
        if (terms[b].k == K_NOT && terms[b].args[0] == a) return t_false;
        if (a > b) std::swap(a, b);
        return mk(K_EQ, SORT_BOOL, -1, {a, b});
    }
    int mk_ite(int c, int a, int b) {
        if (c == t_true) return a;
        if (c == t_false) return b;
        if (a == b) return a;
        if (terms[c].k == K_NOT) return mk_ite(terms[c].args[0], b, a);
        int s = sort_of(a);
        if (s == SORT_BOOL) {
            if (a == t_true && b == t_false) return c;
            if (a == t_false && b == t_true) return mk_not(c);
            if (a == t_true) return mk_or({c, b});
            if (a == t_false) return mk_and({mk_not(c), b});
            if (b == t_true) return mk_or({mk_not(c), a});
            if (b == t_false) return mk_and({c, a});
        }
        return mk(K_ITE, s, -1, {c, a, b});
    }
    int mk_eq(int a, int b) {
        if (a == b) return t_true;
        int s = sort_of(a);
        if (s == SORT_BOOL) return mk_iff(a, b);
        const Term& ta = terms[a];
        const Term& tb = terms[b];
        if (ta.k == K_NUM && tb.k == K_NUM) return ta.val == tb.val ? t_true : t_false;
        if (ta.k == K_ULIT && tb.k == K_ULIT) return t_false;  // distinct literals
        if (a > b) std::swap(a, b);
        return mk(K_EQ, SORT_BOOL, -1, {a, b});
    }
    int mk_add(const std::vector<int>& in) {
        std::vector<int> out;
        Rational c(0);
        int sort = in.empty() ? SORT_REAL : sort_of(in[0]);
        for (int a : in) {
            if (sort_of(a) == SORT_REAL) sort = SORT_REAL;
            const Term& t = terms[a];
            if (t.k == K_NUM) { c += t.val; continue; }
            if (t.k == K_ADD) {
                for (int x : t.args) {
                    if (terms[x].k == K_NUM) c += terms[x].val; else out.push_back(x);
                }
                continue;
            }
            out.push_back(a);
        }
        if (!c.is_zero()) out.push_back(mk_num(c, sort));
        if (out.empty()) return mk_num(Rational(0), sort);
        if (out.size() == 1) return out[0];
        return mk(K_ADD, sort, -1, out);
    }
    int mk_mul(const std::vector<int>& in) {
        Rational c(1);
        std::vector<int> nonconst;
        int sort = sort_of(in[0]);
        for (int a : in) {
            if (sort_of(a) == SORT_REAL) sort = SORT_REAL;
            const Term& t = terms[a];
            if (t.k == K_NUM) c *= t.val;
            else nonconst.push_back(a);
        }
        if (nonconst.empty()) return mk_num(c, sort);
        if (nonconst.size() > 1) throw Unsupported("nonlinear");
        if (c.is_zero()) return mk_num(Rational(0), sort);
        if (c.is_one()) return nonconst[0];
        int x = nonconst[0];
        const Term& tx = terms[x];
        if (tx.k == K_MUL) {
            Rational c2 = c * terms[tx.args[0]].val;
            if (c2.is_one()) return tx.args[1];
            return mk(K_MUL, sort, -1, {mk_num(c2, sort), tx.args[1]});
        }
        return mk(K_MUL, sort, -1, {mk_num(c, sort), x});
    }
    int mk_neg(int a) { return mk_mul({mk_num(Rational(-1), sort_of(a)), a}); }
    int mk_le(int a, int b) {
        if (terms[a].k == K_NUM && terms[b].k == K_NUM) return terms[a].val <= terms[b].val ? t_true : t_false;
        return mk(K_LE, SORT_BOOL, -1, {a, b});
    }
    int mk_lt(int a, int b) {
        if (terms[a].k == K_NUM && terms[b].k == K_NUM) return terms[a].val < terms[b].val ? t_true : t_false;
        return mk(K_LT, SORT_BOOL, -1, {a, b});
    }
};

// ---------------------------------------------------------------------------
// Elaboration of SMT-LIB commands
// ---------------------------------------------------------------------------
struct Frontend {
    SExprStore sx;
    TermManager tm;
    std::string logic;
    std::unordered_map<int, int> sorts;  // string id (normalized symbol) -> sort id
    struct Sym { int kind; int id; };    // kind 0: func, 1: define, 2: named term
    std::unordered_map<std::string, Sym> globals;
    struct Define { std::vector<std::pair<std::string, int>> params; int ret; int body; int cached; };
    std::vector<Define> defines;
    std::unordered_map<std::string, std::vector<int>> env;
    std::vector<int> assertions;
    std::vector<std::pair<int, int>> uf_keys;  // (sexpr node, term)
    std::vector<int> declared_funcs;
    int check_sat_count = 0;

    static std::string norm(const std::string& s) {
        if (s.size() >= 2 && s[0] == '|' && s.back() == '|') return s.substr(1, s.size() - 2);
        return s;
    }

    int parse_sort(int n) {
        if (sx.is_atom(n)) {
            std::string s = norm(sx.atom_str(n));
            if (s == "Bool") return SORT_BOOL;
            if (tm.arith_logic) {
                if (s == "Int") return SORT_INT;
                if (s == "Real") return SORT_REAL;
            }
            auto it = sorts.find(sx.intern(s));
            if (it != sorts.end()) return it->second;
            if (s == "Int" || s == "Real") {
                int id = (int)tm.sort_names.size();
                tm.sort_names.push_back(s);
                sorts[sx.intern(s)] = id;
                return id;
            }
            throw Unsupported("unknown sort " + s);
        }
        throw Unsupported("parametric sort");
    }

    void set_logic(const std::string& l) {
        logic = l;
        if (l == "QF_UF") { tm.arith_logic = false; }
        else if (l == "QF_LIA" || l == "QF_IDL" || l == "QF_UFLIA" || l == "QF_UFIDL") { tm.int_logic = true; }
    }

    void run(const std::string& text) {
        std::vector<int> top = sx.parse(text);
        for (int f : top) command(f);
    }

    void command(int f) {
        if (sx.is_atom(f)) return;
        const auto& k = sx.kids(f);
        if (k.empty() || !sx.is_atom(k[0])) return;
        const std::string& c = sx.atom_str(k[0]);
        if (c == "set-logic") {
            set_logic(sx.atom_str(k[1]));
        } else if (c == "declare-sort") {
            std::string name = norm(sx.atom_str(k[1]));
            if (k.size() > 2 && sx.is_atom(k[2]) && sx.atom_str(k[2]) != "0") throw Unsupported("parametric sort");
            int id = (int)tm.sort_names.size();
            tm.sort_names.push_back(name);
            sorts[sx.intern(name)] = id;
        } else if (c == "declare-fun" || c == "declare-const") {
            std::string raw = sx.atom_str(k[1]);
            std::vector<int> args;
            int ret;
            if (c == "declare-fun") {
                for (int a : sx.kids(k[2])) args.push_back(parse_sort(a));
                ret = parse_sort(k[3]);
            } else {
                ret = parse_sort(k[2]);
            }
            int fid = tm.new_func(raw, args, ret, false);
            globals[norm(raw)] = {0, fid};
            declared_funcs.push_back(fid);
        } else if (c == "define-fun") {
            std::string raw = sx.atom_str(k[1]);
            Define d;
            for (int p : sx.kids(k[2])) {
                const auto& pk = sx.kids(p);
                d.params.push_back({norm(sx.atom_str(pk[0])), parse_sort(pk[1])});
            }
            d.ret = parse_sort(k[3]);
            d.body = k[4];
            d.cached = -1;
            if (d.params.empty()) {
                d.cached = elab(d.body);
            }
            defines.push_back(d);
            globals[norm(raw)] = {1, (int)defines.size() - 1};
        } else if (c == "assert") {
            assertions.push_back(elab(k[1]));
        } else if (c == "check-sat") {
            check_sat_count++;
        } else if (c == "push" || c == "pop") {
            throw Unsupported("incremental");
        }
        // other commands ignored
    }

    int lookup_symbol(const std::string& raw) {
        std::string s = norm(raw);
        auto e = env.find(s);
        if (e != env.end() && !e->second.empty()) return e->second.back();
        auto g = globals.find(s);
        if (g != globals.end()) {
            if (g->second.kind == 0) {
                const Func& fn = tm.funcs[g->second.id];
                if (!fn.args.empty()) throw Unsupported("function used as constant");
                return tm.mk_const(g->second.id);
            }
            if (g->second.kind == 1) {
                Define& d = defines[g->second.id];
                if (!d.params.empty()) throw Unsupported("define used as constant");
                return d.cached;
            }
            return g->second.id;
        }
        if (s == "true") return tm.t_true;
        if (s == "false") return tm.t_false;
        // numerals
        if (!raw.empty() && (isdigit((unsigned char)raw[0]) || (raw[0] == '-' && raw.size() > 1 && isdigit((unsigned char)raw[1])))) {
            if (!tm.arith_logic) {
                return tm.mk(K_ULIT, -1, sx.intern(raw), {});
            }
            Rational v = Rational::parse(raw);
            bool dec = raw.find('.') != std::string::npos;
            int sort = (tm.int_logic && !dec) ? SORT_INT : SORT_REAL;
            return tm.mk_num(v, sort);
        }
        throw Unsupported("unknown symbol " + raw);
    }

    int elab(int n) {
        if (sx.is_atom(n)) return lookup_symbol(sx.atom_str(n));
        const auto& k = sx.kids(n);
        if (k.empty()) throw Unsupported("empty app");
        if (!sx.is_atom(k[0])) {
            // (_ ...) indexed or other
            throw Unsupported("complex head");
        }
        const std::string op = sx.atom_str(k[0]);
        size_t na = k.size() - 1;
        auto arg = [&](size_t i) { return elab(k[i + 1]); };
        auto all_args = [&]() {
            std::vector<int> v;
            v.reserve(na);
            for (size_t i = 0; i < na; i++) v.push_back(arg(i));
            return v;
        };
        if (op == "let") {
            std::vector<std::pair<std::string, int>> binds;
            for (int b : sx.kids(k[1])) {
                const auto& bk = sx.kids(b);
                binds.push_back({norm(sx.atom_str(bk[0])), elab(bk[1])});
            }
            for (auto& b : binds) env[b.first].push_back(b.second);
            int r = elab(k[2]);
            for (auto& b : binds) env[b.first].pop_back();
            return r;
        }
        if (op == "!") {
            int t = elab(k[1]);
            for (size_t i = 2; i + 1 < k.size(); i++) {
                if (sx.is_atom(k[i]) && sx.atom_str(k[i]) == ":named") {
                    globals[norm(sx.atom_str(k[i + 1]))] = {2, t};
                }
            }
            return t;
        }
        if (op == "not") return tm.mk_not(arg(0));
        if (op == "and") return tm.mk_and(all_args());
        if (op == "or") return tm.mk_or(all_args());
        if (op == "=>") {
            std::vector<int> a = all_args();
            int r = a.back();
            for (size_t i = a.size() - 1; i-- > 0;) r = tm.mk_implies(a[i], r);
            return r;
        }
        if (op == "xor") {
            std::vector<int> a = all_args();
            int r = a[0];
            for (size_t i = 1; i < a.size(); i++) r = tm.mk_xor(r, a[i]);
            return r;
        }
        if (op == "ite") {
            int c = arg(0), a = arg(1), b = arg(2);
            return tm.mk_ite(c, a, b);
        }
        if (op == "=") {
            std::vector<int> a = all_args();
            fix_ulit_sorts(a);
            std::vector<int> conj;
            for (size_t i = 0; i + 1 < a.size(); i++) conj.push_back(mk_eq_arith(a[i], a[i + 1]));
            return tm.mk_and(conj);
        }
        if (op == "distinct") {
            std::vector<int> a = all_args();
            fix_ulit_sorts(a);
            std::vector<int> conj;
            for (size_t i = 0; i < a.size(); i++)
                for (size_t j = i + 1; j < a.size(); j++) conj.push_back(tm.mk_not(mk_eq_arith(a[i], a[j])));
            return tm.mk_and(conj);
        }
        if (tm.arith_logic) {
            if (op == "+") return tm.mk_add(all_args());
            if (op == "-") {
                std::vector<int> a = all_args();
                if (a.size() == 1) return tm.mk_neg(a[0]);
                std::vector<int> s = {a[0]};
                for (size_t i = 1; i < a.size(); i++) s.push_back(tm.mk_neg(a[i]));
                return tm.mk_add(s);
            }
            if (op == "*") return tm.mk_mul(all_args());
            if (op == "/") {
                std::vector<int> a = all_args();
                int r = a[0];
                for (size_t i = 1; i < a.size(); i++) {
                    const Term& d = tm[a[i]];
                    if (d.k != K_NUM || d.val.is_zero()) throw Unsupported("nonlinear division");
                    r = tm.mk_mul({tm.mk_num(Rational(1) / d.val, SORT_REAL), r});
                    if (tm[r].sort == SORT_INT) {
                        // keep real sort
                    }
                }
                return r;
            }
            if (op == "<=" || op == "<" || op == ">=" || op == ">") {
                std::vector<int> a = all_args();
                std::vector<int> conj;
                for (size_t i = 0; i + 1 < a.size(); i++) {
                    int x = a[i], y = a[i + 1];
                    if (op == "<=") conj.push_back(tm.mk_le(x, y));
                    else if (op == "<") conj.push_back(tm.mk_lt(x, y));
                    else if (op == ">=") conj.push_back(tm.mk_le(y, x));
                    else conj.push_back(tm.mk_lt(y, x));
                }
                return tm.mk_and(conj);
            }
            if (op == "to_real" || op == "to_int" || op == "is_int" || op == "div" || op == "mod" || op == "abs")
                throw Unsupported(op);
        }
        // function application
        std::string s = norm(op);
        auto e = env.find(s);
        if (e != env.end() && !e->second.empty()) throw Unsupported("applying bound var");
        auto g = globals.find(s);
        if (g == globals.end()) throw Unsupported("unknown function " + op);
        if (g->second.kind == 0) {
            int fid = g->second.id;
            const Func& fn = tm.funcs[fid];
            if (fn.args.size() != na) throw Unsupported("arity");
            std::vector<int> a = all_args();
            for (size_t i = 0; i < a.size(); i++) {
                if (tm[a[i]].k == K_ULIT) a[i] = tm.mk(K_ULIT, fn.args[i], tm[a[i]].sym, {});
            }
            int t = tm.mk(K_APP, fn.ret, fid, a);
            uf_keys.push_back({n, t});
            return t;
        }
        if (g->second.kind == 1) {
            Define& d = defines[g->second.id];
            if (d.params.size() != na) throw Unsupported("define arity");
            std::vector<int> a = all_args();
            std::unordered_map<std::string, std::vector<int>> saved;
            saved.swap(env);
            for (size_t i = 0; i < na; i++) env[d.params[i].first].push_back(a[i]);
            int r = elab(d.body);
            env.swap(saved);
            return r;
        }
        throw Unsupported("named term applied");
    }

    void fix_ulit_sorts(std::vector<int>& a) {
        int s = -1;
        for (int x : a) if (tm[x].k != K_ULIT) s = tm.sort_of(x);
        if (s < 0) return;
        for (int& x : a) if (tm[x].k == K_ULIT) x = tm.mk(K_ULIT, s, tm[x].sym, {});
    }
    int mk_eq_arith(int a, int b) { return tm.mk_eq(a, b); }
};
