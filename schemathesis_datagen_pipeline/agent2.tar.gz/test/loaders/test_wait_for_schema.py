"""Tests for retrying schema loading while waiting for the schema to become available."""

import time

import pytest
import requests
from flask import Flask, jsonify
from graphql import build_schema, get_introspection_query, graphql_sync

import schemathesis
from schemathesis.core.errors import LoaderError, LoaderErrorKind

OPENAPI_SCHEMA = {
    "openapi": "3.0.2",
    "info": {"title": "Test", "version": "0.1"},
    "paths": {"/users": {"get": {"responses": {"200": {"description": "OK"}}}}},
}
GRAPHQL_SDL = "type Query { getBooks: [Book] }\ntype Book { title: String }"


def _graphql_introspection():
    return {"data": graphql_sync(build_schema(GRAPHQL_SDL), get_introspection_query()).data}


def start(app_runner, app):
    """Start the app and wait until it accepts connections (avoids races with tests not using `wait_for_schema`)."""
    app.add_url_rule("/health", "health", lambda: "OK")
    port = app_runner.run_flask_app(app)
    deadline = time.monotonic() + 5
    while True:
        try:
            requests.get(f"http://127.0.0.1:{port}/health", timeout=1)
            return port
        except requests.ConnectionError:
            if time.monotonic() > deadline:
                raise
            time.sleep(0.02)


def make_app(unavailable_count):
    """Respond with 503 for the first `unavailable_count` requests, then serve schemas."""
    app = Flask(__name__)
    app.config["calls"] = 0

    def maybe_unavailable():
        app.config["calls"] += 1
        if unavailable_count is None or app.config["calls"] <= unavailable_count:
            return "Service Unavailable", 503
        return None

    @app.route("/openapi.json")
    def openapi():
        return maybe_unavailable() or jsonify(OPENAPI_SCHEMA)

    @app.route("/graphql", methods=["POST"])
    def graphql():
        return maybe_unavailable() or jsonify(_graphql_introspection())

    return app


LOADERS = [
    pytest.param(schemathesis.openapi.from_url, "openapi.json", id="openapi"),
    pytest.param(schemathesis.graphql.from_url, "graphql", id="graphql"),
]


@pytest.mark.parametrize(("loader", "path"), LOADERS)
def test_retry_on_503_then_success(app_runner, loader, path):
    app = make_app(unavailable_count=3)
    port = start(app_runner, app)
    schema = loader(f"http://127.0.0.1:{port}/{path}", wait_for_schema=5)
    assert schema.location.endswith(path)
    assert app.config["calls"] == 4


@pytest.mark.parametrize(("loader", "path"), LOADERS)
def test_retry_on_503_exhausted(app_runner, loader, path):
    app = make_app(unavailable_count=None)
    port = start(app_runner, app)
    with pytest.raises(LoaderError) as exc:
        loader(f"http://127.0.0.1:{port}/{path}", wait_for_schema=1)
    assert exc.value.kind == LoaderErrorKind.HTTP_SERVER_ERROR
    assert "503 Service Unavailable" in exc.value.message
    assert app.config["calls"] > 1


@pytest.mark.parametrize(("loader", "path"), LOADERS)
def test_no_retry_on_503_without_wait_for_schema(app_runner, loader, path):
    app = make_app(unavailable_count=1)
    port = start(app_runner, app)
    with pytest.raises(LoaderError) as exc:
        loader(f"http://127.0.0.1:{port}/{path}")
    assert exc.value.kind == LoaderErrorKind.HTTP_SERVER_ERROR
    assert exc.value.message == "Failed to load schema due to server error (HTTP 503 Service Unavailable)"
    assert app.config["calls"] == 1


@pytest.mark.parametrize("status", [500, 502])
def test_no_retry_on_other_server_errors(app_runner, status):
    app = Flask(__name__)
    app.config["calls"] = 0

    @app.route("/openapi.json")
    def openapi():
        app.config["calls"] += 1
        return "Error", status

    port = start(app_runner, app)
    with pytest.raises(LoaderError):
        schemathesis.openapi.from_url(f"http://127.0.0.1:{port}/openapi.json", wait_for_schema=1)
    assert app.config["calls"] == 1


def test_cli_wait_for_schema_retries_on_503(cli, app_runner):
    app = make_app(unavailable_count=3)
    port = start(app_runner, app)
    result = cli.run(
        f"http://127.0.0.1:{port}/openapi.json",
        "--wait-for-schema=5",
        "--max-examples=1",
        "--phases=examples",
    )
    assert app.config["calls"] >= 4
    assert "503" not in result.stdout


def test_cli_wait_for_schema_exhausted_on_503(cli, app_runner):
    app = make_app(unavailable_count=None)
    port = start(app_runner, app)
    result = cli.run(f"http://127.0.0.1:{port}/openapi.json", "--wait-for-schema=1", "--max-examples=1")
    assert result.exit_code != 0
    assert "503 Service Unavailable" in result.stdout
