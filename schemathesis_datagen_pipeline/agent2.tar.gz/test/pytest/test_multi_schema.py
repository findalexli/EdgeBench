import pytest

import schemathesis

MULTI_SCHEMA_SETUP = """
users_schema = schemathesis.openapi.from_dict({
    "openapi": "3.0.2",
    "info": {"title": "Users", "version": "0.1"},
    "paths": {"/users": {"get": {"responses": {"200": {"description": "OK"}}}}},
})
orders_schema = schemathesis.openapi.from_dict({
    "openapi": "3.0.2",
    "info": {"title": "Orders", "version": "0.1"},
    "paths": {
        "/orders": {
            "get": {"responses": {"200": {"description": "OK"}}},
            "post": {"responses": {"200": {"description": "OK"}}},
        }
    },
})
"""


def test_importable():
    assert callable(schemathesis.pytest.parametrize)


def test_multi_schema_sync(testdir):
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema, orders=orders_schema)
@settings(max_examples=1)
def test_api(request, case):
    request.config.HYPOTHESIS_CASES += 1
    assert case.operation.path in ("/users", "/orders")
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(passed=3)
    result.stdout.re_match_lines(
        [
            r".*::test_api\[users\]\[GET /users\] PASSED",
            r".*::test_api\[orders\]\[GET /orders\] PASSED",
            r".*::test_api\[orders\]\[POST /orders\] PASSED",
        ],
        consecutive=False,
    )


def test_multi_schema_operations_match_schema(testdir):
    # Each schema's items must only receive cases from that schema
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema, orders=orders_schema)
@settings(max_examples=1)
def test_api(request, case):
    name = request.node.name
    if "[users]" in name:
        assert case.operation.path == "/users"
    else:
        assert "[orders]" in name
        assert case.operation.path == "/orders"
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(passed=3)


def test_multi_schema_keyword_selection(testdir):
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema, orders=orders_schema)
@settings(max_examples=1)
def test_api(case):
    pass
""",
    )
    result = testdir.runpytest("-v", "-k", "orders")
    result.assert_outcomes(passed=2)


@pytest.mark.parametrize("plugin", ["asyncio", "aiohttp.pytest_plugin"])
def test_multi_schema_async(testdir, plugin):
    marker = "@pytest.mark.asyncio" if plugin == "asyncio" else ""
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + f"""
@schemathesis.pytest.parametrize(users=users_schema, orders=orders_schema)
{marker}
@settings(max_examples=1)
async def test_api(request, case):
    request.config.HYPOTHESIS_CASES += 1
    assert case.operation.path in ("/users", "/orders")
""",
        pytest_plugins=[plugin],
    )
    args = ["-v"]
    for disabled in {"asyncio", "aiohttp.pytest_plugin", "trio"} - {plugin}:
        args.extend(("-p", f"no:{disabled}"))
    result = testdir.runpytest(*args)
    result.assert_outcomes(passed=3)
    result.stdout.re_match_lines(
        [r".*::test_api\[users\]\[GET /users\] PASSED", r".*::test_api\[orders\]\[POST /orders\] PASSED"],
        consecutive=False,
    )


def test_multi_schema_failure_reported_per_schema(testdir):
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema, orders=orders_schema)
@settings(max_examples=1)
def test_api(case):
    assert case.operation.path != "/users"
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(passed=2, failed=1)
    result.stdout.re_match_lines([r".*::test_api\[users\]\[GET /users\] FAILED"], consecutive=False)


def test_multi_schema_with_pytest_parametrize(testdir):
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema)
@pytest.mark.parametrize("value", [1, 2])
@settings(max_examples=1)
def test_api(case, value):
    pass
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(passed=2)
    result.stdout.re_match_lines([r".*::test_api\[users\]\[GET /users\]\[1\] PASSED"], consecutive=False)


def test_multi_schema_applied_twice(testdir):
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@schemathesis.pytest.parametrize(users=users_schema)
@schemathesis.pytest.parametrize(orders=orders_schema)
def test_api(case):
    pass
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(failed=1)
    result.stdout.re_match_lines([r".*You have applied `parametrize` to the `test_api` test more than once"])


def test_invalid_arguments():
    with pytest.raises(schemathesis.errors.IncorrectUsage):
        schemathesis.pytest.parametrize()
    with pytest.raises(schemathesis.errors.IncorrectUsage, match="Invalid schema for `users`"):
        schemathesis.pytest.parametrize(users=42)


def test_schema_parametrize_reuse(testdir):
    # The same base function is decorated by different schemas and assigned to different names
    testdir.make_test(
        MULTI_SCHEMA_SETUP
        + """
@settings(max_examples=1)
def _check(request, case):
    request.config.HYPOTHESIS_CASES += 1
    name = request.node.name
    if name.startswith("test_users"):
        assert case.operation.path == "/users"
    else:
        assert case.operation.path == "/orders"

test_users = users_schema.parametrize()(_check)
test_orders = orders_schema.parametrize()(_check)
""",
    )
    result = testdir.runpytest("-v")
    result.assert_outcomes(passed=3)
    result.stdout.re_match_lines(
        [
            r".*::test_users\[GET /users\] PASSED",
            r".*::test_orders\[GET /orders\] PASSED",
            r".*::test_orders\[POST /orders\] PASSED",
        ],
        consecutive=False,
    )


def test_schema_parametrize_reuse_with_hooks(simple_schema):
    # Per-test hooks applied to one reused test must not leak into the other one
    from schemathesis.hooks import HookDispatcherMark

    schema_a = schemathesis.openapi.from_dict(simple_schema)
    schema_b = schemathesis.openapi.from_dict(simple_schema)

    def shared_hook(ctx, query):
        return query

    def local_hook(ctx, query):
        return query

    @schema_a.hooks.apply(shared_hook, name="map_query")
    def _check(case):
        pass

    test_a = schema_a.hooks.apply(local_hook, name="map_query")(schema_a.parametrize()(_check))
    test_b = schema_b.parametrize()(_check)

    assert HookDispatcherMark.get(test_a).get_all_by_name("map_query") == [shared_hook, local_hook]
    assert HookDispatcherMark.get(test_b).get_all_by_name("map_query") == [shared_hook]
    assert HookDispatcherMark.get(_check).get_all_by_name("map_query") == [shared_hook]


def test_schema_parametrize_reuse_independent_marks(simple_schema):
    from schemathesis.pytest.plugin import SchemaHandleMark

    schema_a = schemathesis.openapi.from_dict(simple_schema)
    schema_b = schemathesis.openapi.from_dict(simple_schema)

    def _check(case):
        pass

    test_a = schema_a.parametrize()(_check)
    test_b = schema_b.parametrize()(_check)

    assert test_a is not test_b
    assert not SchemaHandleMark.is_set(_check)
    assert SchemaHandleMark.get(test_a).test_function is test_a
    assert SchemaHandleMark.get(test_b).test_function is test_b
    assert SchemaHandleMark.get(test_a) is not SchemaHandleMark.get(test_b)
