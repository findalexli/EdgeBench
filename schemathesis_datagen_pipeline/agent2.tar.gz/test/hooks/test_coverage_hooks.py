import unittest

import pytest
from hypothesis import Phase, settings

import schemathesis
from schemathesis.config._projects import ProjectConfig
from schemathesis.generation import GenerationMode
from schemathesis.generation.hypothesis.builder import HypothesisTestConfig, HypothesisTestMode, create_test
from schemathesis.generation.meta import TestPhase
from schemathesis.hooks import GLOBAL_HOOK_DISPATCHER, HookDispatcher, HookDispatcherMark, HookScope


@pytest.fixture
def schema():
    raw = {
        "openapi": "3.0.2",
        "info": {"title": "Test", "version": "0.1"},
        "paths": {
            "/users": {
                "get": {
                    "parameters": [
                        {"name": "id", "in": "query", "required": True, "schema": {"type": "integer"}},
                    ],
                    "responses": {"200": {"description": "OK"}},
                },
                "post": {
                    "parameters": [
                        {"name": "key", "in": "query", "required": True, "schema": {"type": "string"}},
                    ],
                    "responses": {"200": {"description": "OK"}},
                },
            }
        },
    }
    return schemathesis.openapi.from_dict(raw)


@pytest.fixture
def global_hooks():
    before = {name: list(hooks) for name, hooks in GLOBAL_HOOK_DISPATCHER._hooks.items()}
    yield GLOBAL_HOOK_DISPATCHER
    GLOBAL_HOOK_DISPATCHER._hooks.clear()
    GLOBAL_HOOK_DISPATCHER._hooks.update(before)


def collect_coverage_cases(operation, test_dispatcher=None, modes=(GenerationMode.POSITIVE, GenerationMode.NEGATIVE)):
    config = ProjectConfig()
    config.generation.update(modes=list(modes))
    config.phases.examples.enabled = False
    config.phases.fuzzing.enabled = False
    config.phases.stateful.enabled = False
    cases = []

    def test(case):
        if case.meta is not None and case.meta.phase.name == TestPhase.COVERAGE:
            cases.append(case)

    if test_dispatcher is not None:
        HookDispatcherMark.set(test, test_dispatcher)

    test_func = create_test(
        operation=operation,
        test_func=test,
        config=HypothesisTestConfig(
            modes=[HypothesisTestMode.COVERAGE],
            project=config,
            settings=settings(phases=[Phase.explicit]),
        ),
    )
    try:
        test_func()
    except (pytest.skip.Exception, unittest.SkipTest):
        # Hypothesis skips the test when no examples are left to run
        pass
    return cases


def test_coverage_without_hooks_generates_cases(schema):
    cases = collect_coverage_cases(schema["/users"]["GET"])
    assert cases
    # Sanity check: some coverage cases are missing the required `id`
    assert any("id" not in case.query for case in cases)


def test_schema_filter_case_in_coverage(schema):
    @schema.hook
    def filter_case(context, case):
        return "id" in case.query

    cases = collect_coverage_cases(schema["/users"]["GET"])
    assert cases
    assert all("id" in case.query for case in cases)


def test_schema_map_case_in_coverage(schema):
    @schema.hook
    def map_case(context, case):
        case.headers = {**(case.headers or {}), "X-Token": "secret"}
        return case

    cases = collect_coverage_cases(schema["/users"]["GET"])
    assert cases
    assert all(case.headers["X-Token"] == "secret" for case in cases)


def test_map_case_return_value_replaces_case(schema):
    operation = schema["/users"]["GET"]
    replacement = operation.Case(query={"id": 42})

    @schema.hook
    def map_case(context, case):
        return replacement

    received = []
    config = ProjectConfig()
    config.phases.examples.enabled = False
    config.phases.fuzzing.enabled = False

    def test(case):
        received.append(case)

    create_test(
        operation=operation,
        test_func=test,
        config=HypothesisTestConfig(
            modes=[HypothesisTestMode.COVERAGE],
            project=config,
            settings=settings(phases=[Phase.explicit]),
        ),
    )()
    assert received
    assert all(case is replacement for case in received)


def test_filter_case_runs_before_map_case(schema):
    calls = []

    @schema.hook
    def map_case(context, case):
        calls.append("map")
        case.query = {"id": "mapped"}
        return case

    @schema.hook
    def filter_case(context, case):
        calls.append("filter")
        # Filter must see the original case, not the mapped one
        assert case.query.get("id") != "mapped"
        return True

    cases = collect_coverage_cases(schema["/users"]["GET"])
    assert cases
    assert all(case.query == {"id": "mapped"} for case in cases)
    # Every case is first filtered, then mapped
    assert calls[:2] == ["filter", "map"]


def test_filter_case_rejects_all(schema):
    @schema.hook
    def filter_case(context, case):
        return False

    assert collect_coverage_cases(schema["/users"]["GET"]) == []


def test_dispatcher_ordering(schema, global_hooks):
    order = []

    @schemathesis.hook("map_case")
    def global_map(context, case):
        order.append("global")
        case.query = {**case.query, "trace": ["global"]}
        return case

    @schema.hook("map_case")
    def schema_map(context, case):
        order.append("schema")
        case.query["trace"] = [*case.query["trace"], "schema"]
        return case

    def local_map(context, case):
        order.append("test")
        case.query["trace"] = [*case.query["trace"], "test"]
        return case

    local = HookDispatcher(scope=HookScope.TEST)
    local.register_hook_with_name(local_map, "map_case")

    cases = collect_coverage_cases(schema["/users"]["GET"], test_dispatcher=local)
    assert cases
    assert all(case.query["trace"] == ["global", "schema", "test"] for case in cases)
    assert order[:3] == ["global", "schema", "test"]


@pytest.mark.parametrize("level", ["global", "schema", "test"])
def test_filter_case_from_each_dispatcher_level(schema, global_hooks, level):
    def filter_case(context, case):
        return False

    local = None
    if level == "global":
        schemathesis.hook(filter_case)
    elif level == "schema":
        schema.hook(filter_case)
    else:
        local = HookDispatcher(scope=HookScope.TEST)
        local.register_hook_with_name(filter_case, "filter_case")

    assert collect_coverage_cases(schema["/users"]["GET"], test_dispatcher=local) == []


def test_hook_applicability_respected(schema):
    @schema.hook.apply_to(method="POST")
    def map_case(context, case):
        case.headers = {**(case.headers or {}), "X-Applied": "yes"}
        return case

    @schema.hook.skip_for(method="POST")
    def filter_case(context, case):
        return False

    post_cases = collect_coverage_cases(schema["/users"]["POST"])
    assert post_cases
    assert all(case.headers["X-Applied"] == "yes" for case in post_cases)
    # GET: filter applies & rejects everything
    assert collect_coverage_cases(schema["/users"]["GET"]) == []


def test_hook_context_has_operation(schema):
    seen = []

    @schema.hook
    def filter_case(context, case):
        seen.append(context.operation)
        return True

    operation = schema["/users"]["GET"]
    collect_coverage_cases(operation)
    assert seen
    assert all(item.label == operation.label for item in seen)


def test_coverage_hooks_pytest_plugin(testdir, simple_openapi):
    testdir.make_test(
        """
from schemathesis.generation.meta import TestPhase

@schema.hook
def filter_case(context, case):
    return case.query is not None and case.query.get("id") != "reject-me"

@schema.hook
def map_case(context, case):
    case.headers = {**(case.headers or {}), "X-Mapped": "1"}
    return case

COVERAGE_CASES = []

@schema.parametrize()
@settings(phases=[Phase.explicit])
def test_a(case):
    if case.meta.phase.name == TestPhase.COVERAGE:
        COVERAGE_CASES.append(case)
        assert case.headers["X-Mapped"] == "1"
        assert case.query is not None

def test_b():
    assert COVERAGE_CASES
    """,
        schema=simple_openapi,
    )
    result = testdir.runpytest("-p", "no:randomly")
    result.assert_outcomes(passed=2)
