"""Support for running a single test function against multiple named schemas."""

from __future__ import annotations

import copy
import types
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, NoReturn

from schemathesis.core.errors import IncorrectUsage
from schemathesis.core.marks import METADATA_ATTR, Mark

if TYPE_CHECKING:
    from schemathesis.schemas import BaseSchema


def _is_schema_mapping(value: object) -> bool:
    from schemathesis.schemas import BaseSchema

    return isinstance(value, dict) and all(isinstance(schema, BaseSchema) for schema in value.values())


MultiSchemaHandleMark = Mark[dict[str, "BaseSchema"]](attr_name="schemas", check=_is_schema_mapping)


def copy_test_function(func: Callable) -> Callable:
    """Create an independent copy of a test function.

    The copy shares code, globals, and closure with the original but has its own attributes, so
    Schemathesis-specific metadata attached to it does not leak back into the original function.
    This allows the same base function to be decorated multiple times by different schemas.
    """
    if not isinstance(func, types.FunctionType):
        return func
    new = types.FunctionType(func.__code__, func.__globals__, func.__name__, func.__defaults__, func.__closure__)
    new.__kwdefaults__ = copy.copy(func.__kwdefaults__)
    new.__qualname__ = func.__qualname__
    new.__module__ = func.__module__
    new.__doc__ = func.__doc__
    new.__annotations__ = dict(func.__annotations__)
    new.__dict__.update(func.__dict__)
    # Avoid sharing mutable state with the original function
    if "pytestmark" in new.__dict__:
        new.pytestmark = list(new.__dict__["pytestmark"])  # type: ignore[attr-defined]
    metadata = getattr(func, METADATA_ATTR, None)
    if metadata is not None:
        metadata = copy.copy(metadata)
        dispatcher = getattr(metadata, "hook_dispatcher", None)
        if dispatcher is not None:
            from schemathesis.hooks import HookDispatcher

            new_dispatcher = HookDispatcher(scope=dispatcher.scope)
            for name, hooks in dispatcher._hooks.items():
                new_dispatcher._hooks[name] = list(hooks)
            metadata.hook_dispatcher = new_dispatcher
        setattr(new, METADATA_ATTR, metadata)
    return new


def _is_parametrized(func: Callable) -> bool:
    from schemathesis.pytest.plugin import SchemaHandleMark

    return SchemaHandleMark.is_set(func) or MultiSchemaHandleMark.is_set(func)


def _double_parametrize_error(func: Callable) -> Callable:
    def wrapped_test(*_: Any, **__: Any) -> NoReturn:
        raise IncorrectUsage(
            f"You have applied `parametrize` to the `{func.__name__}` test more than once, which "
            "overrides the previous decorator. "
            "The `parametrize` decorator could be applied to the same function at most once."
        )

    return wrapped_test


def parametrize(**schemas: BaseSchema) -> Callable[[Callable], Callable]:
    """Run the decorated test against API operations from multiple named schemas.

    Each generated test item has the schema name as an extra bracketed prefix before
    the operation label, e.g. `test_api[users][GET /users]`.

    Args:
        **schemas: Mapping of schema names to schema instances.

    Example:
        ```python
        import schemathesis

        users = schemathesis.openapi.from_url("http://users.local/openapi.json")
        orders = schemathesis.openapi.from_url("http://orders.local/openapi.json")


        @schemathesis.pytest.parametrize(users=users, orders=orders)
        def test_api(case):
            case.call_and_validate()
        ```

    """
    from schemathesis.hooks import HookDispatcher
    from schemathesis.schemas import BaseSchema

    if not schemas:
        raise IncorrectUsage("`schemathesis.pytest.parametrize` requires at least one schema")
    for name, schema in schemas.items():
        if not isinstance(schema, BaseSchema):
            raise IncorrectUsage(
                f"Invalid schema for `{name}`: expected a schema instance, got `{type(schema).__name__}`"
            )

    def wrapper(func: Callable) -> Callable:
        if _is_parametrized(func):
            return _double_parametrize_error(func)
        func = copy_test_function(func)
        HookDispatcher.add_dispatcher(func)
        MultiSchemaHandleMark.set(func, {name: schema.clone(test_function=func) for name, schema in schemas.items()})
        return func

    return wrapper
