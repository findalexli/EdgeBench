"""Structured generation strategies for well-known HTTP headers.

Conditional request headers (RFC 7232) and the `Range` header (RFC 7233) have well-defined grammars.
Generating values that follow them lets the tested application exercise its range & cache handling logic,
instead of rejecting arbitrary strings early.
"""

from __future__ import annotations

import string
from typing import TYPE_CHECKING

from schemathesis.generation.modes import GenerationMode

if TYPE_CHECKING:
    from datetime import datetime

    from hypothesis import strategies as st

__all__ = [
    "ETAG_LIST_FORMAT",
    "HEADER_FORMATS",
    "HEADER_NAME_TO_FORMAT",
    "HTTP_DATE_FORMAT",
    "KNOWN_HEADER_FORMATS",
    "RANGE_FORMAT",
    "SLIGHTLY_INVALID_VALUE_PROBABILITY",
    "STRUCTURED_HEADER_FORMATS",
    "VALID_VALUE_PROBABILITY",
    "byte_range_specs",
    "entity_tags",
    "etag_list",
    "etag_list_values",
    "get_header_format",
    "get_header_strategies",
    "get_header_strategy",
    "get_strategies",
    "get_strategy",
    "header_strategy",
    "http_date",
    "http_date_values",
    "invalid_range_values",
    "is_structured_header_format",
    "random_header_values",
    "range_header",
    "range_header_values",
    "range_values",
    "slightly_invalid_range",
    "slightly_invalid_range_values",
]

# Internal format keys for structured headers
ETAG_LIST_FORMAT = "_etag_list"
HTTP_DATE_FORMAT = "_http_date"
RANGE_FORMAT = "_range"

STRUCTURED_HEADER_FORMATS = (ETAG_LIST_FORMAT, HTTP_DATE_FORMAT, RANGE_FORMAT)

# Lowercase header name -> internal format key
HEADER_FORMATS: dict[str, str] = {
    "if-match": ETAG_LIST_FORMAT,
    "if-none-match": ETAG_LIST_FORMAT,
    "if-modified-since": HTTP_DATE_FORMAT,
    "if-unmodified-since": HTTP_DATE_FORMAT,
    "range": RANGE_FORMAT,
}

# Probability of generating a fully valid value in negative mode
VALID_VALUE_PROBABILITY = 0.3
# Probability of generating a slightly invalid value in negative mode (if available for the format)
SLIGHTLY_INVALID_VALUE_PROBABILITY = 0.4

_DAY_NAMES = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
_MONTH_NAMES = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
# RFC 7232: etagc = %x21 / %x23-7E / obs-text
_ETAG_CHARACTERS = "".join(chr(code) for code in range(0x21, 0x7F) if code != 0x22)
_MAX_POSITION = 10**12


def get_header_format(name: str) -> str | None:
    """Get the internal format key for a header name if it is a known structured header."""
    return HEADER_FORMATS.get(name.lower())


def is_structured_header_format(value: object) -> bool:
    return value in STRUCTURED_HEADER_FORMATS


def entity_tags() -> st.SearchStrategy[str]:
    """Single strong or weak entity tag. E.g. `"abc"` or `W/"abc"`."""
    from hypothesis import strategies as st

    opaque = st.text(alphabet=_ETAG_CHARACTERS, max_size=32).map(lambda value: f'"{value}"')
    return st.one_of(opaque, opaque.map(lambda value: f"W/{value}"))


def etag_list_values() -> st.SearchStrategy[str]:
    """Values for `If-Match` / `If-None-Match`: `*` or a comma-separated list of entity tags."""
    from hypothesis import strategies as st

    return st.one_of(
        st.just("*"),
        entity_tags(),
        st.lists(entity_tags(), min_size=1, max_size=5).map(", ".join),
    )


def _format_http_date(value: datetime) -> str:
    return (
        f"{_DAY_NAMES[value.weekday()]}, {value.day:02d} {_MONTH_NAMES[value.month - 1]} {value.year:04d} "
        f"{value.hour:02d}:{value.minute:02d}:{value.second:02d} GMT"
    )


def http_date_values() -> st.SearchStrategy[str]:
    """IMF-fixdate values (RFC 7231). E.g. `Sun, 06 Nov 1994 08:49:37 GMT`."""
    from datetime import datetime

    from hypothesis import strategies as st

    return st.datetimes(min_value=datetime(1970, 1, 1), max_value=datetime(9999, 12, 31, 23, 59, 59)).map(
        _format_http_date
    )


def _positions() -> st.SearchStrategy[int]:
    from hypothesis import strategies as st

    return st.one_of(st.integers(min_value=0, max_value=1024), st.integers(min_value=0, max_value=_MAX_POSITION))


def byte_range_specs() -> st.SearchStrategy[str]:
    """Single range spec: `first-last` (first <= last), `first-` or `-suffix`."""
    from hypothesis import strategies as st

    int_range = st.tuples(_positions(), _positions()).map(
        lambda pair: f"{min(pair)}-{max(pair)}",
    )
    open_ended = _positions().map(lambda first: f"{first}-")
    suffix = st.integers(min_value=1, max_value=_MAX_POSITION).map(lambda length: f"-{length}")
    return st.one_of(int_range, open_ended, suffix)


def range_values() -> st.SearchStrategy[str]:
    """Values for the `Range` header. E.g. `bytes=0-499`, `bytes=500-`, `bytes=-500` or `bytes=0-0,-1`."""
    from hypothesis import strategies as st

    return st.lists(byte_range_specs(), min_size=1, max_size=4).map(lambda specs: "bytes=" + ",".join(specs))


def slightly_invalid_range_values() -> st.SearchStrategy[str]:
    """Near-valid `Range` values that violate RFC 7233 in specific ways."""
    from hypothesis import strategies as st

    # `first-last` where `last < first`
    inverted = st.tuples(_positions(), _positions()).filter(lambda pair: pair[0] != pair[1])
    inverted_range = inverted.map(lambda pair: f"bytes={max(pair)}-{min(pair)}")
    # Negative positions
    negative = st.integers(min_value=1, max_value=_MAX_POSITION)
    negative_range = st.one_of(
        st.tuples(negative, _positions()).map(lambda pair: f"bytes=-{pair[0]}-{pair[1]}"),
        st.tuples(_positions(), negative).map(lambda pair: f"bytes={pair[0]}--{pair[1]}"),
        negative.map(lambda value: f"bytes=-{value}-"),
    )
    # Unknown range units
    wrong_unit = st.tuples(
        st.sampled_from(["byte", "Bytes ", "items", "bits", "chars", "none", "octets"]), byte_range_specs()
    ).map(lambda pair: f"{pair[0]}={pair[1]}")
    # No range specs at all
    empty = st.sampled_from(["bytes=", "bytes=,", "bytes= ", "bytes=-", "bytes"])
    return st.one_of(inverted_range, negative_range, wrong_unit, empty)


def random_header_values() -> st.SearchStrategy[str]:
    """Arbitrary header values that are still possible to send over the network."""
    from hypothesis import strategies as st

    return st.text(alphabet=st.sampled_from(string.ascii_letters + string.digits + string.punctuation + " ")).map(
        str.strip
    )


_VALID_STRATEGIES = {
    ETAG_LIST_FORMAT: etag_list_values,
    HTTP_DATE_FORMAT: http_date_values,
    RANGE_FORMAT: range_values,
}
_SLIGHTLY_INVALID_STRATEGIES = {
    RANGE_FORMAT: slightly_invalid_range_values,
}


def get_header_strategy(format: str, mode: GenerationMode) -> st.SearchStrategy[str]:
    """Strategy for the given structured header format key.

    In positive mode, only grammatically valid values are generated. In negative mode, valid,
    slightly-invalid and completely random values are mixed.
    """
    from hypothesis import strategies as st

    valid = _VALID_STRATEGIES[format]()
    if mode.is_positive:
        return valid
    slightly_invalid_factory = _SLIGHTLY_INVALID_STRATEGIES.get(format)
    random = random_header_values()

    @st.composite  # type: ignore[untyped-decorator]
    def negative(draw: st.DrawFn) -> str:
        choice = draw(st.floats(min_value=0, max_value=1, exclude_max=True))
        if choice < VALID_VALUE_PROBABILITY:
            return draw(valid)
        if slightly_invalid_factory is not None and choice < VALID_VALUE_PROBABILITY + SLIGHTLY_INVALID_VALUE_PROBABILITY:
            return draw(slightly_invalid_factory())
        return draw(random)

    return negative()


def get_header_strategies(mode: GenerationMode = GenerationMode.POSITIVE) -> dict[str, st.SearchStrategy[str]]:
    """Strategies for all structured header formats in the given generation mode."""
    return {format: get_header_strategy(format, mode) for format in STRUCTURED_HEADER_FORMATS}


# Aliases
etag_list = etag_list_values
http_date = http_date_values
range_header = range_values
range_header_values = range_values
slightly_invalid_range = slightly_invalid_range_values
invalid_range_values = slightly_invalid_range_values
get_strategy = get_header_strategy
header_strategy = get_header_strategy
get_strategies = get_header_strategies
KNOWN_HEADER_FORMATS = HEADER_FORMATS
HEADER_NAME_TO_FORMAT = HEADER_FORMATS
