from __future__ import annotations

import re
from functools import lru_cache

from schemathesis.core.errors import InternalError

# Unicode property escape translations (PCRE/Java/JS -> Python approximations)
# These cover Latin-based scripts which handle the majority of real-world APIs
_LETTER_CLASS = r"a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u024F"
_LETTER_UPPER_CLASS = r"A-Z\u00C0-\u00D6\u00D8-\u00DE\u0100-\u0136\u0139-\u0147\u014A-\u0178\u0179-\u017D"
_LETTER_LOWER_CLASS = r"a-z\u00DF-\u00F6\u00F8-\u00FF\u0101-\u0137\u013A-\u0148\u014B-\u0177\u017A-\u017E"
_OTHER_LETTER_CLASS = r"\u00AA\u00BA\u01BB\u01C0-\u01C3\u0294"
_DIGIT_CLASS = r"0-9"
_ALNUM_CLASS = rf"{_LETTER_CLASS}{_DIGIT_CLASS}"
_SPACE_CLASS = r" \t\n\r\f\v"
_XDIGIT_CLASS = r"0-9A-Fa-f"
_ASCII_CLASS = r"\x00-\x7F"
# Punctuation: ASCII + Latin-1 Supplement + General Punctuation
_PUNCT_CLASS = r"!\"#%&'()*,\-./:;?@\[\\\]_{}\u00A1\u00A7\u00AB\u00B6\u00B7\u00BB\u00BF\u2010-\u2027\u2030-\u203E"
# Combining marks (common diacritical marks)
_MARK_CLASS = r"\u0300-\u036F\u0483-\u0489\u1DC0-\u1DFF\u20D0-\u20FF"
# Symbols: currency, math, misc symbols
_SYMBOL_CLASS = r"$+<=>^`|~\u00A2-\u00A6\u00A8\u00A9\u00AC\u00AE-\u00B1\u00B4\u00D7\u00F7\u2200-\u22FF\u2600-\u26FF"
# Control characters
_CONTROL_CLASS = r"\x00-\x1F\x7F-\x9F"
# Graph (visible characters) and Print (graph + space)
_GRAPH_CLASS = r"!-~\u00A1-\u00AC\u00AE-\u00FF"
_PRINT_CLASS = rf" {_GRAPH_CLASS}"
# Blank (horizontal whitespace)
_BLANK_CLASS = r" \t"

# Order matters - check bracketed forms first to avoid double-bracketing
_UNICODE_PROPERTY_MAP = (
    # Bracketed forms (must come first)
    (r"[\p{L}]", f"[{_LETTER_CLASS}]"),
    (r"[\p{Lu}]", f"[{_LETTER_UPPER_CLASS}]"),
    (r"[\p{Ll}]", f"[{_LETTER_LOWER_CLASS}]"),
    (r"[\p{Lo}]", f"[{_OTHER_LETTER_CLASS}]"),
    (r"[\p{N}]", f"[{_DIGIT_CLASS}]"),
    (r"[\p{Nd}]", f"[{_DIGIT_CLASS}]"),
    (r"[\p{Alpha}]", f"[{_LETTER_CLASS}]"),
    (r"[\p{Digit}]", f"[{_DIGIT_CLASS}]"),
    (r"[\p{XDigit}]", f"[{_XDIGIT_CLASS}]"),
    (r"[\p{Alnum}]", f"[{_ALNUM_CLASS}]"),
    (r"[\p{Space}]", f"[{_SPACE_CLASS}]"),
    (r"[\p{Z}]", f"[{_SPACE_CLASS}]"),
    (r"[\p{Zs}]", f"[{_SPACE_CLASS}]"),
    (r"[\p{P}]", f"[{_PUNCT_CLASS}]"),
    (r"[\p{Punct}]", f"[{_PUNCT_CLASS}]"),
    (r"[\p{M}]", f"[{_MARK_CLASS}]"),
    (r"[\p{S}]", f"[{_SYMBOL_CLASS}]"),
    (r"[\p{C}]", f"[{_CONTROL_CLASS}]"),
    (r"[\p{Cntrl}]", f"[{_CONTROL_CLASS}]"),
    (r"[\p{ASCII}]", f"[{_ASCII_CLASS}]"),
    (r"[\p{Graph}]", f"[{_GRAPH_CLASS}]"),
    (r"[\p{Print}]", f"[{_PRINT_CLASS}]"),
    (r"[\p{Blank}]", f"[{_BLANK_CLASS}]"),
    (r"[\p{Upper}]", f"[{_LETTER_UPPER_CLASS}]"),
    (r"[\p{IsLetter}]", f"[{_LETTER_CLASS}]"),
    (r"[\P{L}]", f"[^{_LETTER_CLASS}]"),
    (r"[\P{N}]", f"[^{_DIGIT_CLASS}]"),
    (r"[\P{Nd}]", f"[^{_DIGIT_CLASS}]"),
    (r"[\P{C}]", f"[^{_CONTROL_CLASS}]"),
    (r"[\P{M}]", f"[^{_MARK_CLASS}]"),
    # Shorthand forms in brackets (single-letter properties without braces)
    (r"[\pL]", f"[{_LETTER_CLASS}]"),
    (r"[\pN]", f"[{_DIGIT_CLASS}]"),
    (r"[\pP]", f"[{_PUNCT_CLASS}]"),
    (r"[\pM]", f"[{_MARK_CLASS}]"),
    (r"[\pS]", f"[{_SYMBOL_CLASS}]"),
    (r"[\pC]", f"[{_CONTROL_CLASS}]"),
    (r"[\pZ]", f"[{_SPACE_CLASS}]"),
    (r"[\PL]", f"[^{_LETTER_CLASS}]"),
    (r"[\PN]", f"[^{_DIGIT_CLASS}]"),
    (r"[\PC]", f"[^{_CONTROL_CLASS}]"),
    (r"[\PM]", f"[^{_MARK_CLASS}]"),
    # Standalone forms with braces
    (r"\p{L}", f"[{_LETTER_CLASS}]"),
    (r"\p{Lu}", f"[{_LETTER_UPPER_CLASS}]"),
    (r"\p{Ll}", f"[{_LETTER_LOWER_CLASS}]"),
    (r"\p{Lo}", f"[{_OTHER_LETTER_CLASS}]"),
    (r"\p{N}", f"[{_DIGIT_CLASS}]"),
    (r"\p{Nd}", f"[{_DIGIT_CLASS}]"),
    (r"\p{Alpha}", f"[{_LETTER_CLASS}]"),
    (r"\p{Digit}", f"[{_DIGIT_CLASS}]"),
    (r"\p{XDigit}", f"[{_XDIGIT_CLASS}]"),
    (r"\p{Alnum}", f"[{_ALNUM_CLASS}]"),
    (r"\p{Space}", f"[{_SPACE_CLASS}]"),
    (r"\p{Z}", f"[{_SPACE_CLASS}]"),
    (r"\p{Zs}", f"[{_SPACE_CLASS}]"),
    (r"\p{P}", f"[{_PUNCT_CLASS}]"),
    (r"\p{Punct}", f"[{_PUNCT_CLASS}]"),
    (r"\p{M}", f"[{_MARK_CLASS}]"),
    (r"\p{S}", f"[{_SYMBOL_CLASS}]"),
    (r"\p{C}", f"[{_CONTROL_CLASS}]"),
    (r"\p{Cntrl}", f"[{_CONTROL_CLASS}]"),
    (r"\p{ASCII}", f"[{_ASCII_CLASS}]"),
    (r"\p{Graph}", f"[{_GRAPH_CLASS}]"),
    (r"\p{Print}", f"[{_PRINT_CLASS}]"),
    (r"\p{Blank}", f"[{_BLANK_CLASS}]"),
    (r"\p{Upper}", f"[{_LETTER_UPPER_CLASS}]"),
    (r"\p{IsLetter}", f"[{_LETTER_CLASS}]"),
    (r"\P{L}", f"[^{_LETTER_CLASS}]"),
    (r"\P{N}", f"[^{_DIGIT_CLASS}]"),
    (r"\P{Nd}", f"[^{_DIGIT_CLASS}]"),
    (r"\P{C}", f"[^{_CONTROL_CLASS}]"),
    (r"\P{M}", f"[^{_MARK_CLASS}]"),
    # Shorthand standalone forms (single-letter properties without braces)
    (r"\pL", f"[{_LETTER_CLASS}]"),
    (r"\pN", f"[{_DIGIT_CLASS}]"),
    (r"\pP", f"[{_PUNCT_CLASS}]"),
    (r"\pM", f"[{_MARK_CLASS}]"),
    (r"\pS", f"[{_SYMBOL_CLASS}]"),
    (r"\pC", f"[{_CONTROL_CLASS}]"),
    (r"\pZ", f"[{_SPACE_CLASS}]"),
    (r"\PL", f"[^{_LETTER_CLASS}]"),
    (r"\PN", f"[^{_DIGIT_CLASS}]"),
    (r"\PC", f"[^{_CONTROL_CLASS}]"),
    (r"\PM", f"[^{_MARK_CLASS}]"),
)


@lru_cache(maxsize=256)
def normalize_regex(pattern: object) -> str | None:
    r"""Translate PCRE-style Unicode property escapes and Python-specific anchors.

    Handles:
    - PCRE Unicode property escapes (\p{L}, \pL, etc.) -> Python equivalents
    - Python anchors (\A, \Z) -> Rust-compatible equivalents (^, $)

    Returns the translated pattern if successful, None if translation failed
    or the result is not a valid Python regex.
    """
    if not isinstance(pattern, str):
        return None
    # Check for both braced (\p{L}) and shorthand (\pL) forms
    has_braced = r"\p{" in pattern or r"\P{" in pattern
    has_shorthand = any(
        esc in pattern
        for esc in (r"\pL", r"\pN", r"\pP", r"\pM", r"\pS", r"\pC", r"\pZ", r"\PL", r"\PN", r"\PC", r"\PM")
    )
    # Check for Python-specific anchors that need Rust translation
    has_python_anchors = pattern.startswith(r"\A") or pattern.endswith(r"\Z")

    if not has_braced and not has_shorthand and not has_python_anchors:
        return None  # No translation needed

    translated = pattern
    for pcre_escape, python_equiv in _UNICODE_PROPERTY_MAP:
        translated = translated.replace(pcre_escape, python_equiv)

    # Check if there are still untranslated Unicode property escapes
    if r"\p{" in translated or r"\P{" in translated:
        return None  # Contains unsupported escapes

    # Translate Python-specific anchors to Rust equivalents for jsonschema-rs
    if translated.startswith(r"\A"):
        translated = "^" + translated[2:]
    if translated.endswith(r"\Z"):
        translated = translated[:-2] + "$"

    # Verify the translated pattern is valid
    if is_valid_python_regex(translated):
        return translated
    return None


def is_valid_python_regex(pattern: object) -> bool:
    """Check if a pattern is valid Python regex."""
    if not isinstance(pattern, str):
        return False
    try:
        re.compile(pattern)
        return True
    except re.error:
        return False


try:  # pragma: no cover
    import re._constants as sre
    import re._parser as sre_parse
except ImportError:
    import sre_constants as sre
    import sre_parse

ANCHOR = sre.AT
REPEATS: tuple
if hasattr(sre, "POSSESSIVE_REPEAT"):
    REPEATS = (sre.MIN_REPEAT, sre.MAX_REPEAT, sre.POSSESSIVE_REPEAT)
else:
    REPEATS = (sre.MIN_REPEAT, sre.MAX_REPEAT)
LITERAL = sre.LITERAL
NOT_LITERAL = sre.NOT_LITERAL
IN = sre.IN
MAXREPEAT = sre_parse.MAXREPEAT
ATOMIC_GROUP = getattr(sre, "ATOMIC_GROUP", None)
POSSESSIVE_REPEAT = getattr(sre, "POSSESSIVE_REPEAT", None)

# Single-character items that can be quantified directly, without wrapping them into a group
SINGLE_CHARACTER_OPS = (LITERAL, NOT_LITERAL, IN, sre.ANY)
# Items that do not consume any characters
ZERO_WIDTH_OPS = (sre.AT, sre.ASSERT, sre.ASSERT_NOT)
LEADING_ANCHORS = (sre.AT_BEGINNING, sre.AT_BEGINNING_STRING)
TRAILING_ANCHORS = (sre.AT_END, sre.AT_END_STRING)
# Marker for repeats whose bounds were updated - they are always serialized with explicit `{m,n}` quantifiers
UPDATED_REPEAT = "UPDATED_REPEAT"


class _UnsupportedPatternError(Exception):
    """The parsed pattern contains constructs that can not be serialized back."""


@lru_cache
def update_quantifier(pattern: str, min_length: int | None, max_length: int | None) -> str:
    """Update the quantifier of a regular expression based on given min and max lengths."""
    if not pattern or (min_length in (None, 0) and max_length is None):
        return pattern

    try:
        parsed = sre_parse.parse(pattern)
    except (re.error, RecursionError, OverflowError, ValueError):
        # Invalid pattern
        return pattern
    try:
        items = _transform(parsed, min_length, max_length)
        if items is None:
            return pattern
        updated = _serialize_flags(parsed.state.flags) + _serialize_sequence(items)
    except (_UnsupportedPatternError, RecursionError):
        return pattern
    try:
        re.compile(updated)
    except re.error as exc:
        raise InternalError(
            f"The combination of min_length={min_length} and max_length={max_length} applied to the original pattern '{pattern}' resulted in an invalid regex: '{updated}'. "
            "This indicates a bug in the regex quantifier merging logic"
        ) from exc
    return updated


def _transform(parsed: sre_parse.SubPattern, min_length: int | None, max_length: int | None) -> list | None:
    """Return a new list of top-level AST items with updated quantifiers or `None` if the pattern can't be updated."""
    items = list(parsed.data)
    state = parsed.state
    # Indices of items that actually consume characters
    consuming = [idx for idx, (op, _) in enumerate(items) if op not in ZERO_WIDTH_OPS]
    if not consuming:
        return None
    is_anchored = (
        len(items) >= 2
        and items[0][0] == ANCHOR
        and items[0][1] in LEADING_ANCHORS
        and items[-1][0] == ANCHOR
        and items[-1][1] in TRAILING_ANCHORS
    )
    if len(consuming) == 1:
        idx = consuming[0]
        has_assertions = any(
            op != ANCHOR or value not in LEADING_ANCHORS + TRAILING_ANCHORS
            for op, value in items
            if op in ZERO_WIDTH_OPS
        )
        updated = _update_single_item(state, items[idx], min_length, max_length, is_anchored, has_assertions)
        if updated is None:
            return None
        items[idx] = updated
        return items
    if not is_anchored:
        return None
    return _update_multiple_items(state, items, min_length, max_length)


def _width(state: sre_parse.State, items: list) -> tuple[int, int]:
    if isinstance(items, sre_parse.SubPattern):
        return items.getwidth()
    return sre_parse.SubPattern(state, list(items)).getwidth()


def _canonicalize(op: int, value: object) -> tuple[int, object]:
    # Special case for patterns canonicalisation. Some frameworks generate `[\w\W]` instead of `.`
    # Such patterns lead to significantly slower data generation
    if op == IN and _matches_anything(value):  # type: ignore[arg-type]
        return sre.ANY, None
    if op in REPEATS:
        min_repeat, max_repeat, subpattern = value  # type: ignore[misc]
        if len(subpattern) == 1 and subpattern[0][0] == IN and _matches_anything(subpattern[0][1]):
            return op, (min_repeat, max_repeat, [(sre.ANY, None)])
    return op, value


def _update_single_item(
    state: sre_parse.State,
    item: tuple,
    min_length: int | None,
    max_length: int | None,
    is_anchored: bool,
    has_assertions: bool,
) -> tuple | None:
    op, value = _canonicalize(*item)
    if op in REPEATS:
        min_repeat, max_repeat, subpattern = value  # type: ignore[misc]
        # With a single consuming item, lazy & possessive repeats match the same strings as greedy ones
        return _update_repeat(state, min_repeat, max_repeat, subpattern, min_length, max_length)
    if op in SINGLE_CHARACTER_OPS:
        if op == sre.ANY:
            # `.` is the same as `.{1}`
            return _update_repeat(state, 1, 1, [(op, value)], min_length, max_length)
        if (
            is_anchored
            and op == LITERAL
            and ((min_length is not None and min_length > 1) or (max_length is not None and max_length < 1))
        ):
            # Single literal has the length of 1, but quantifiers could be != 1, which means we can't merge them
            return None
        # Repeat the character class directly, unless surrounding assertions depend on its exact position
        if max_length == 0 or has_assertions:
            return None
        minimum = 1 if min_length is None else max(min_length, 1)
        maximum = MAXREPEAT if max_length is None else max_length
        if minimum > maximum:
            return None
        return (UPDATED_REPEAT, (minimum, maximum, [(op, value)], sre.MAX_REPEAT))
    return None


def _update_repeat(
    state: sre_parse.State,
    min_repeat: int,
    max_repeat: int,
    subpattern: list,
    min_length: int | None,
    max_length: int | None,
    op: int = sre.MAX_REPEAT,
) -> tuple | None:
    """Merge repetition bounds with length constraints, taking the inner length of the repeated part into account."""
    inner_min, inner_max = _width(state, subpattern)
    if inner_max == 0:
        # Empty pattern contributes 0 chars regardless of repetitions
        if min_length is not None and min_length > 0:
            return None
        return (UPDATED_REPEAT, (min_repeat, min_repeat, subpattern, op))
    if inner_min == 0:
        # Can't reason about the resulting length
        return None
    if max_length is not None and 0 < max_length < inner_min:
        return None

    final_min = min_repeat
    if min_length is not None:
        # Need at least ceil(min_length / inner_min) repetitions
        final_min = max(min_repeat, -(-min_length // inner_min))

    final_max = max_repeat
    if max_length is not None:
        # Can have at most floor(max_length / inner_length) repetitions
        inner_length = inner_max if inner_max < MAXREPEAT else inner_min
        external_max = max_length // inner_length
        final_max = external_max if max_repeat == MAXREPEAT else min(max_repeat, external_max)

    if final_min > final_max:
        return None
    return (UPDATED_REPEAT, (final_min, final_max, subpattern, op))


def _update_multiple_items(
    state: sre_parse.State, items: list, min_length: int | None, max_length: int | None
) -> list | None:
    """Update regex pattern with multiple quantified parts to satisfy length constraints."""
    fixed_length = 0
    quantified = []
    for idx, (op, value) in enumerate(items):
        if op in REPEATS:
            op, value = _canonicalize(op, value)
            min_repeat, max_repeat, subpattern = value
            quantified.append((idx, op, min_repeat, max_repeat, subpattern, _width(state, subpattern)[0]))
        else:
            lo, hi = _width(state, [(op, value)])
            if lo != hi:
                # Variable-length parts that can't be adjusted
                return None
            fixed_length += lo

    if not quantified:
        return None

    # Adjust length constraints by subtracting fixed parts length
    if min_length is not None:
        min_length -= fixed_length
        if min_length < 0:
            return None
    if max_length is not None:
        max_length -= fixed_length
        if max_length < 0:
            return None

    bounds = [(min_repeat, max_repeat) for _, _, min_repeat, max_repeat, _, _ in quantified]
    repetition_lengths = [length for *_, length in quantified]
    distribution = _distribute_length_constraints(bounds, repetition_lengths, min_length, max_length)
    if not distribution:
        return None

    result = list(items)
    for (idx, op, _, _, subpattern, _), (new_min, new_max) in zip(quantified, distribution):
        result[idx] = (UPDATED_REPEAT, (new_min, new_max, subpattern, op))
    return result


def _matches_anything(value: list) -> bool:
    """Check if the given pattern is equivalent to '.' (match any character)."""
    # Common forms: [\w\W], [\s\S], etc.
    return value in (
        [(sre.CATEGORY, sre.CATEGORY_WORD), (sre.CATEGORY, sre.CATEGORY_NOT_WORD)],
        [(sre.CATEGORY, sre.CATEGORY_SPACE), (sre.CATEGORY, sre.CATEGORY_NOT_SPACE)],
        [(sre.CATEGORY, sre.CATEGORY_DIGIT), (sre.CATEGORY, sre.CATEGORY_NOT_DIGIT)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_WORD), (sre.CATEGORY, sre.CATEGORY_WORD)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_SPACE), (sre.CATEGORY, sre.CATEGORY_SPACE)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_DIGIT), (sre.CATEGORY, sre.CATEGORY_DIGIT)],
    )


def _distribute_length_constraints(
    bounds: list[tuple[int, int]], repetition_lengths: list[int], min_length: int | None, max_length: int | None
) -> list[tuple[int, int]] | None:
    """Distribute length constraints among quantified pattern parts."""
    # Handle exact length case with dynamic programming
    if min_length == max_length:
        assert min_length is not None
        target = min_length
        dp: dict[tuple[int, int], list[tuple[int, ...]] | None] = {}

        def find_valid_combination(pos: int, remaining: int) -> list[tuple[int, ...]] | None:
            if (pos, remaining) in dp:
                return dp[(pos, remaining)]

            if pos == len(bounds):
                return [()] if remaining == 0 else None

            max_repeat: int
            min_repeat, max_repeat = bounds[pos]
            repeat_length = repetition_lengths[pos]

            if repeat_length == 0:
                # Contributes nothing - use the smallest possible number of repetitions
                rest = find_valid_combination(pos + 1, remaining)
                dp[(pos, remaining)] = None if rest is None else [(min_repeat,) + r for r in rest]
                return dp[(pos, remaining)]

            if max_repeat == MAXREPEAT:
                max_repeat = remaining // repeat_length + 1

            # Try each possible length for current quantifier
            for repeat_count in range(min_repeat, max_repeat + 1):
                used_length = repeat_count * repeat_length
                if used_length > remaining:
                    break

                rest = find_valid_combination(pos + 1, remaining - used_length)
                if rest is not None:
                    dp[(pos, remaining)] = [(repeat_count,) + r for r in rest]
                    return dp[(pos, remaining)]

            dp[(pos, remaining)] = None
            return None

        distribution = find_valid_combination(0, target)
        if distribution:
            return [(length, length) for length in distribution[0]]
        return None

    # Handle range case by distributing min/max bounds (in characters)
    result = []
    remaining_min = min_length or 0
    remaining_max = MAXREPEAT if max_length is None else max_length

    for (min_repeat, max_repeat), repeat_length in zip(bounds, repetition_lengths):
        if repeat_length == 0:
            result.append((min_repeat, min_repeat))
            continue

        if remaining_min > 0:
            part_min = min(max_repeat, max(min_repeat, -(-remaining_min // repeat_length)))
        else:
            part_min = min_repeat

        if remaining_max < MAXREPEAT:
            part_max = min(max_repeat, remaining_max // repeat_length)
        else:
            part_max = max_repeat

        if part_min > part_max:
            return None

        result.append((part_min, part_max))

        remaining_min = max(0, remaining_min - part_min * repeat_length)
        if remaining_max < MAXREPEAT:
            remaining_max -= part_max * repeat_length

    if remaining_min > 0 or remaining_max < 0:
        return None

    return result


def _calculate_min_repetition_length(subpattern: list) -> int:
    """Calculate minimum length contribution per repetition of a quantified group."""
    total = 0
    for op, value in subpattern:
        if op in [LITERAL, NOT_LITERAL, IN, sre.ANY]:
            total += 1
        elif op == sre.SUBPATTERN:
            _, _, _, inner_pattern = value
            total += _calculate_min_repetition_length(inner_pattern)
        elif op in REPEATS:
            min_repeat, _, inner_pattern = value
            inner_min = _calculate_min_repetition_length(inner_pattern)
            total += min_repeat * inner_min
    return total


def _build_quantifier(minimum: int | None, maximum: int | None) -> str:
    """Construct a quantifier string based on min and max values."""
    if maximum == MAXREPEAT or maximum is None:
        return f"{{{minimum or 0},}}"
    if minimum == maximum:
        return f"{{{minimum}}}"
    return f"{{{minimum or 0},{maximum}}}"


# Serialization of the parsed AST back to a regex string

_FLAG_LETTERS = (
    (re.IGNORECASE, "i"),
    (re.MULTILINE, "m"),
    (re.DOTALL, "s"),
    (re.ASCII, "a"),
)
_SPECIAL_CHARACTERS = frozenset(".^$*+?{}[]\\|()")
_CLASS_SPECIAL_CHARACTERS = frozenset("\\]^-[&~|")
_CONTROL_ESCAPES = {"\t": "\\t", "\n": "\\n", "\r": "\\r", "\f": "\\f", "\v": "\\v"}
_CATEGORIES = {
    sre.CATEGORY_DIGIT: "\\d",
    sre.CATEGORY_NOT_DIGIT: "\\D",
    sre.CATEGORY_SPACE: "\\s",
    sre.CATEGORY_NOT_SPACE: "\\S",
    sre.CATEGORY_WORD: "\\w",
    sre.CATEGORY_NOT_WORD: "\\W",
}
_ANCHORS = {
    sre.AT_BEGINNING: "^",
    sre.AT_BEGINNING_STRING: "\\A",
    sre.AT_END: "$",
    sre.AT_END_STRING: "\\Z",
    sre.AT_BOUNDARY: "\\b",
    sre.AT_NON_BOUNDARY: "\\B",
}


def _serialize_flags(flags: int, negative: int = 0, inline: bool = False) -> str:
    positive = "".join(letter for flag, letter in _FLAG_LETTERS if flags & flag)
    if inline:
        removed = "".join(letter for flag, letter in _FLAG_LETTERS if negative & flag)
        if removed:
            return f"{positive}-{removed}"
        return positive
    if positive:
        return f"(?{positive})"
    return ""


def _escape_character(code: int, special: frozenset[str]) -> str:
    char = chr(code)
    if char in special:
        return "\\" + char
    if char in _CONTROL_ESCAPES:
        return _CONTROL_ESCAPES[char]
    if char.isprintable():
        return char
    if code < 0x100:
        return f"\\x{code:02x}"
    if code < 0x10000:
        return f"\\u{code:04x}"
    return f"\\U{code:08x}"


def _serialize_sequence(items: list) -> str:
    if len(items) == 1 and items[0][0] == sre.BRANCH:
        return _serialize_branch(items[0][1])
    return "".join(_serialize_item(op, value) for op, value in items)


def _serialize_branch(value: tuple) -> str:
    _, alternatives = value
    return "|".join(_serialize_sequence(list(alternative)) for alternative in alternatives)


def _serialize_atom(items: list) -> str:
    """Serialize items so they could be followed by a quantifier."""
    if len(items) == 1:
        op, value = items[0]
        if op in SINGLE_CHARACTER_OPS or op in (sre.SUBPATTERN, ATOMIC_GROUP):
            return _serialize_item(op, value)
    return f"(?:{_serialize_sequence(items)})"


def _serialize_in(value: list) -> str:
    negate = False
    parts = []
    for op, av in value:
        if op == sre.NEGATE:
            negate = True
        elif op == LITERAL:
            parts.append(_escape_character(av, _CLASS_SPECIAL_CHARACTERS))
        elif op == sre.RANGE:
            low, high = av
            parts.append(
                f"{_escape_character(low, _CLASS_SPECIAL_CHARACTERS)}-{_escape_character(high, _CLASS_SPECIAL_CHARACTERS)}"
            )
        elif op == sre.CATEGORY:
            if av not in _CATEGORIES:
                raise _UnsupportedPatternError
            parts.append(_CATEGORIES[av])
        else:
            raise _UnsupportedPatternError
    if not negate and len(value) == 1 and value[0][0] == sre.CATEGORY:
        return parts[0]
    return "[" + ("^" if negate else "") + "".join(parts) + "]"


def _serialize_quantifier(op: object, min_repeat: int, max_repeat: int) -> str:
    if min_repeat == 0 and max_repeat == MAXREPEAT:
        quantifier = "*"
    elif min_repeat == 1 and max_repeat == MAXREPEAT:
        quantifier = "+"
    elif min_repeat == 0 and max_repeat == 1:
        quantifier = "?"
    else:
        quantifier = _build_quantifier(min_repeat, max_repeat)
    if op == sre.MIN_REPEAT:
        return quantifier + "?"
    if op == POSSESSIVE_REPEAT:
        return quantifier + "+"
    return quantifier


def _serialize_item(op: object, value: object) -> str:
    if op == LITERAL:
        return _escape_character(value, _SPECIAL_CHARACTERS)  # type: ignore[arg-type]
    if op == NOT_LITERAL:
        return "[^" + _escape_character(value, _CLASS_SPECIAL_CHARACTERS) + "]"  # type: ignore[arg-type]
    if op == sre.ANY:
        return "."
    if op == IN:
        return _serialize_in(value)  # type: ignore[arg-type]
    if op == ANCHOR:
        if value not in _ANCHORS:
            raise _UnsupportedPatternError
        return _ANCHORS[value]
    if op == sre.BRANCH:
        return f"(?:{_serialize_branch(value)})"  # type: ignore[arg-type]
    if op == sre.SUBPATTERN:
        group, add_flags, del_flags, subpattern = value  # type: ignore[misc]
        inner = _serialize_sequence(list(subpattern))
        if group is None:
            return f"(?{_serialize_flags(add_flags, del_flags, inline=True)}:{inner})"
        if add_flags or del_flags:
            # Flags can't be attached to capturing groups directly
            return f"((?{_serialize_flags(add_flags, del_flags, inline=True)}:{inner}))"
        return f"({inner})"
    if op == UPDATED_REPEAT:
        min_repeat, max_repeat, subpattern, repeat_op = value  # type: ignore[misc]
        quantifier = _build_quantifier(min_repeat, max_repeat)
        if repeat_op == POSSESSIVE_REPEAT:
            # Lazy quantifiers match the same strings, but possessive ones may not
            quantifier += "+"
        return _serialize_atom(list(subpattern)) + quantifier
    if op in REPEATS:
        min_repeat, max_repeat, subpattern = value  # type: ignore[misc]
        return _serialize_atom(list(subpattern)) + _serialize_quantifier(op, min_repeat, max_repeat)
    if op in (sre.ASSERT, sre.ASSERT_NOT):
        direction, subpattern = value  # type: ignore[misc]
        prefix = {(sre.ASSERT, 1): "?=", (sre.ASSERT, -1): "?<=", (sre.ASSERT_NOT, 1): "?!", (sre.ASSERT_NOT, -1): "?<!"}
        return f"({prefix[(op, direction)]}{_serialize_sequence(list(subpattern))})"
    if op == ATOMIC_GROUP:
        return f"(?>{_serialize_sequence(list(value))})"  # type: ignore[arg-type]
    if op == sre.GROUPREF:
        return f"(?:\\{value})"
    if op == sre.GROUPREF_EXISTS:
        group, yes, no = value  # type: ignore[misc]
        result = f"(?({group}){_serialize_sequence(list(yes))}"
        if no is not None:
            result += f"|{_serialize_sequence(list(no))}"
        return result + ")"
    raise _UnsupportedPatternError
